import pathlib,hashlib,json,subprocess,datetime
root=pathlib.Path("/Users/me/hamon-estate-a3425ebf9874/household-review-independent-local-estate")
source=pathlib.Path('/Users/me/hamon-estate-a3425ebf9874/household-monthly-review/source')
compiled=source.parent/'receiving/candidate-dist/src'
expected={'src/monthly-review.ts':'7347fea52320f20180a73801906d44224563049fcec52beedb618d60f12766eb','src/household-review.ts':'f0e5f83f329ed9e6af8d301d4c62226893122f98b8b7b7052caf018b81384602','src/ledger.ts':'743eb94413383d8872b2eb4670d2813c2924d78cf9ae0d2b479432f9e8ae8c07'}
compiled_expected={'monthly-review.js':'c64e13da45aec753b3e20e03fd11c2b7adfd7bc316cdd2b5c85ee974938493ab','household-review.js':'8faa9f48c6d087a4c36abb63ebb48d3931a636ee0e54acd19bdd03b19d1e0764','ledger.js':'8e80c26b8f68767f80d87bc79a41ff0711f5996dffe5652ef859c4ecef3ac48a'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={p:sha(source/p) for p in expected}
c_before={p:sha(compiled/p) for p in compiled_expected}
assert before==expected,(before,expected)
assert c_before==compiled_expected,(c_before,compiled_expected)
out=root/'run-1';out.mkdir()
command=['/opt/homebrew/bin/node',str(root/'independent-consumers.mjs'),str(compiled),str(out)]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
r=subprocess.run(command,capture_output=True,text=True,timeout=35)
(out/'stdout.txt').write_text(r.stdout);(out/'stderr.txt').write_text(r.stderr)
after={p:sha(source/p) for p in expected};c_after={p:sha(compiled/p) for p in compiled_expected}
result=json.loads((out/'result.json').read_text()) if (out/'result.json').exists() else {'passed':False,'missing_result':True}
receipt={'schema':'household.independent_native_execution.v1','started':start,'completed':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'exit':r.returncode,'node':subprocess.check_output(['/opt/homebrew/bin/node','--version'],text=True).strip(),'source_before':before,'source_after':after,'compiled_before':c_before,'compiled_after':c_after,'source_unchanged':before==after and c_before==c_after,'driver_sha256':sha(root/'independent-consumers.mjs'),'result_sha256':sha(out/'result.json') if (out/'result.json').exists() else None,'stdout_sha256':sha(out/'stdout.txt'),'stderr_sha256':sha(out/'stderr.txt'),'passed':r.returncode==0 and result.get('passed') and before==after and c_before==c_after,'scope':'two distinct synthetic consumers of the exact existing native compiled modules; domain and source unchanged; no repetition of author suite'}
(root/'execution.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'receipt':receipt,'result':result}))
