import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile, writeFile, readdir, stat } from "node:fs/promises";
import { join } from "node:path";
import { spawnSync } from "node:child_process";
import { pathToFileURL } from "node:url";

const [compiledRoot, outputRoot] = process.argv.slice(2);
const { createMonthlyReview } = await import(pathToFileURL(join(compiledRoot, "monthly-review.js")).href);
const sha = x => createHash("sha256").update(x).digest("hex");
const tx = (id, type, amountMinor, currency, category, date="2026-10-01") => ({
  id, type, amountMinor, currency, category, date,
  createdAt:"2026-10-01T00:00:00.000Z",
  note:"private-note-"+id, idempotencyKey:"private-key-"+id
});
const checks = [];
const groups = [];
const check = (name, fn) => { fn(); checks.push(name); };
const opts={month:"2026-10",currency:"USD",sourceLabel:"selected-byte-view.json",generatedAt:"2026-10-08T00:00:00.000Z"};

try {
  const first={version:2,transactions:[tx("view-id","income",117,"USD","view-only-category")],budgets:[]};
  const payload=Buffer.from(JSON.stringify(first));
  const prefix=Buffer.from("OUTSIDE-PREFIX-private-sentinel\n");
  const suffix=Buffer.from("\nOUTSIDE-SUFFIX-private-sentinel");
  const backing=Buffer.concat([prefix,payload,suffix]);
  const view=new Uint8Array(backing.buffer,backing.byteOffset+prefix.length,payload.length);
  const before=Buffer.from(backing);
  const report=createMonthlyReview(view,opts);
  check("nonzero-offset view hashes only admitted bytes",()=>assert.equal(report.source.sha256,sha(payload)));
  check("source byte count excludes backing buffer prefix and suffix",()=>assert.equal(report.source.bytes,payload.length));
  check("projection sees the selected view's real transaction",()=>assert.deepEqual([report.selectedTransactions,report.summary.incomeMinor,report.summary.expenseMinor],[1,117,0]));
  check("creating the review does not mutate any caller backing bytes",()=>assert.deepEqual(backing,before));
  const frozen=JSON.stringify(report);
  backing.fill(0);
  check("later caller buffer mutation cannot alter the detached review",()=>assert.equal(JSON.stringify(report),frozen));
  check("outside-view and transaction-private fields are absent from HTML",()=>{
    for(const text of ["OUTSIDE-PREFIX-private-sentinel","OUTSIDE-SUFFIX-private-sentinel","view-id","private-note-view-id","private-key-view-id"]) assert.equal(report.html.includes(text),false,text);
  });
  const second=createMonthlyReview(Buffer.from(JSON.stringify({version:2,transactions:[tx("second","expense",9,"USD","other")],budgets:[]})),opts);
  second.summary.byCategory.other.expenseMinor=999;
  check("another return value cannot mutate a prior detached review",()=>assert.equal(JSON.stringify(report),frozen));
  groups.push("nonzero-offset byte view and detached lifetime");

  const max=Number.MAX_SAFE_INTEGER;
  const mixed={version:2,transactions:[
    tx("usd-in","income",101,"USD","salary"),
    tx("usd-out","expense",58,"USD","food"),
    tx("eur-a","income",max,"EUR","foreign"),
    tx("eur-b","income",max,"EUR","foreign"),
    tx("usd-old-a","income",max,"USD","earlier","2026-09-01"),
    tx("usd-old-b","income",max,"USD","earlier","2026-09-02")
  ],budgets:[{category:"food",month:"2026-10",currency:"USD",limitMinor:70}]};
  const input=join(outputRoot,"mixed-ledger.json");
  const good=join(outputRoot,"usd.html");
  const bad=join(outputRoot,"eur-refused.html");
  const inputBytes=Buffer.from(JSON.stringify(mixed));
  await writeFile(input,inputBytes,{flag:"wx",mode:0o600});
  const run=currency=>spawnSync(process.execPath,[join(compiledRoot,"household-review.js"),"--ledger",input,"--month","2026-10","--currency",currency,"--output",currency==="USD"?good:bad],{encoding:"utf8",timeout:10000});
  const usd=run("USD");
  check("actual CLI admits a safe selection despite excluded unsafe aggregates",()=>assert.equal(usd.status,0,usd.stderr));
  const meta=JSON.parse(usd.stdout);
  const html=await readFile(good,"utf8");
  check("actual CLI selects exactly two USD rows and exact integer totals",()=>{
    assert.equal(meta.selectedTransactions,2);
    for(const [id,value] of [["income","101"],["expense","58"],["net","43"]]) assert.ok(html.includes('id="summary-'+id+'">'+value+'</p>'),id);
    assert.ok(html.includes('<td class="number">12</td>'));
  });
  check("actual CLI output metadata binds complete saved bytes to exact source",()=>{
    assert.equal(meta.sourceSha256,sha(inputBytes));assert.equal(meta.reportSha256,sha(Buffer.from(html)));
    assert.equal(meta.reportBytes,Buffer.byteLength(html));
  });
  const eur=run("EUR");
  check("the same actual CLI refuses the overflowing selected EUR aggregate",()=>{
    assert.equal(eur.status,1);
    assert.match(eur.stderr,/safe integer|exceed|overflow/i);
  });
  const names=await readdir(outputRoot);
  check("refusal publishes no partial output or leftover publication temp",()=>{
    assert.equal(names.includes("eur-refused.html"),false);
    assert.equal(names.some(n=>n.startsWith(".household-review-")),false);
  });
  const afterInput=await readFile(input);
  check("both CLI attempts leave exact source bytes intact",()=>assert.deepEqual(afterInput,inputBytes));
  const outputMode=(await stat(good)).mode&0o777;
  check("successful output remains private",()=>assert.equal(outputMode,0o600));
  groups.push("selected-currency and selected-month overflow isolation through actual CLI");
  const result={schema:"household.independent_consumer_receiving.v1",passed:true,groups,checks,source_sha256:sha(inputBytes),usd:{status:usd.status,metadata:meta},eur:{status:eur.status,stderr:eur.stderr},live_data:false,network:false};
  await writeFile(join(outputRoot,"result.json"),JSON.stringify(result,null,2)+"\n",{flag:"wx",mode:0o600});
  console.log(JSON.stringify({passed:true,groups:groups.length,checks:checks.length}));
} catch(error) {
  const result={schema:"household.independent_consumer_receiving.v1",passed:false,groups,checks,error:String(error),stack:error.stack};
  await writeFile(join(outputRoot,"result.json"),JSON.stringify(result,null,2)+"\n",{flag:"wx",mode:0o600});
  console.error(error);process.exitCode=1;
}
