## Household outcome and receiving source

External contributor `estate-a3425ebf9874-monthly-review`, under Jacob's standing autonomous estate mandate. Root serializes publication.

Create a local **explicit ledger file → month/currency review → self-contained HTML file** command. Household members should be able to inspect the existing checked monthly income/expense totals, category totals and budget results in a browser or print them, without writing a ledger or connecting to an account.

The current concrete source is canonical receiving draft PR8 at `591ab6f5a2d65bf596aeb707dbb635ee981ec926`, tree `bf7d8bedaa3ed02665e56b021f543259b8c4a854`, preserving accepted native `07e223b5`. Canonical main remains README-only `c063549f`. The source has the existing `validateLedgerData` and `monthlySummary` domain APIs; its executable is the MCP server, and no monthly HTML review command exists in the inspected tree.

## Six new source paths

- `src/monthly-review.ts`: bounded snapshot admission and escaped, self-contained report projection using the unchanged native domain functions.
- `src/household-review.ts`: explicit local CLI with complete-file, exclusive publication.
- `test/monthly-review.test.ts`
- `test/monthly-review-cli.test.ts`
- `tools/check-monthly-review.mjs`: maintained focused offline-browser/print receiving.
- `docs/MONTHLY_REVIEW.md`

All six are absent on the receiving head. Server/index, ledger/Store, recording/idempotency, monthly summary, budget/currency policy, cashflow, CSV import/export, filtering, dependencies, lockfile, package/TypeScript configuration, existing tests and README are outside this source fence.

## Consumer contract

Require an explicit existing ledger file, YYYY-MM and currency. Read one bounded complete UTF-8 JSON snapshot, retain its exact byte count/SHA-256, and call existing validation and checked monthly summary logic without mutating the admitted data.

Show exact integer minor units with the selected currency. Preserve existing mixed-currency, ambiguous legacy-budget and unsafe-total refusals; do not infer a currency, convert money, relabel missing information or turn cash-flow totals into an account balance. Preserve literal category spelling and make legacy unassigned budget status visible when the existing domain admits that context. Transaction notes, recording keys and IDs are outside this summary projection.

Include snapshot/generation provenance and explicit period/currency selection. Escape arbitrary selected labels and refuse text that cannot be represented faithfully. The output is a static local document with no server, external resources, browser storage or automatic refresh. Browser printing uses a dedicated print layout.

Prepare the full output before exclusively publishing a new file. Existing files/symlinks, including the input or a hard-link alias, remain untouched. Missing, invalid, over-limit or unwritable inputs/output paths produce a clean refusal rather than an empty or partial successful report.

## Native qualification and ownership

Use isolated synthetic ledgers and source under `/Users/me/hamon-estate-a3425ebf9874/household-monthly-review`. The installed native Node26.3.0/TypeScript5.9.3 and locked @types/node24.19.1 dependency route is read-only; no install or owner-file mutation.

Freeze the existing domain/absent-command witness and fixtures before implementation. Qualify exact values, currency/legacy/empty cases, hostile/Unicode labels, literal privacy boundaries, safe totals, source/destination preservation, actual CLI output, native offline browser/print, and meaningful failure controls. Request independent receiving of the frozen new source; preserve initial failures and source/evidence pins.

ce7 retains source-parent integration and estate61749b retains canonical content receiving through issue3/PR8. Budget-copy5, filter6, CSV-statement7 and import-client9 retain their scopes. This is an additive after-owner contribution; no adoption of their draft or native snapshot ancestry is claimed. Deliver the narrow qualified delta through that route, or target normal main only after their integration. No live ledger, service, account, deployment or competition action is included.

Fresh project issues/PRs, the complete issue3 thread, current primary source, report search and latest105 central coordination comments were inspected before this claim; no monthly-review owner was found.