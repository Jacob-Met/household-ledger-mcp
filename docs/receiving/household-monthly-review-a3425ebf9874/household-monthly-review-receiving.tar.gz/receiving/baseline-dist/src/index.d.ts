import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { LedgerStore } from "./ledger.js";
export declare function resolveDataPath(): string;
export declare function resolvePort(): number;
export declare function resolveHost(): string;
export declare function createMcpServer(store: LedgerStore): Server;
export declare function main(): Promise<void>;
