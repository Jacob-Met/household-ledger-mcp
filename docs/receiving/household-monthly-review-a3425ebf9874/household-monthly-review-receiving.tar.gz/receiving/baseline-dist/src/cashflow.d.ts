/**
 * Read-only calendar-month cashflow, composed from the existing monthly summary.
 * No opening balance, currency conversion, persistence or budget assignment.
 */
import { type LedgerData, type MonthlySummary } from "./ledger.js";
export declare const MAX_CASHFLOW_MONTHS = 120;
export interface CashflowTrendInput {
    /** Inclusive YYYY-MM, within the monthly-summary year range. */
    fromMonth: string;
    /** Inclusive YYYY-MM. At most 120 calendar months including both endpoints. */
    toMonth: string;
    currency?: string;
}
export interface CashflowMonth {
    month: string;
    incomeMinor: number;
    expenseMinor: number;
    netMinor: number;
    /** Net transactions since fromMonth, starting from zero; not an account balance. */
    cumulativeNetMinor: number;
    byCategory: MonthlySummary["byCategory"];
    budgets: MonthlySummary["budgets"];
}
export interface CashflowTrend {
    fromMonth: string;
    toMonth: string;
    monthCount: number;
    /** One denomination for the entire interval; null only for an unselected empty interval. */
    currency: string | null;
    totals: {
        incomeMinor: number;
        expenseMinor: number;
        netMinor: number;
    };
    months: CashflowMonth[];
}
export declare function cashflowTrend(data: LedgerData, input: CashflowTrendInput): CashflowTrend;
