import { LedgerStore, type Transaction } from "./ledger.js";
import { type TransactionCsvRow } from "./transaction-csv.js";
export declare const TRANSACTION_IMPORT_SCHEMA = "household-transaction-import/1";
export interface ImportPreviewRow extends TransactionCsvRow {
    action: "add" | "already_recorded" | "conflict";
    existingTransaction?: Transaction;
    reason?: string;
}
export interface ImportTotals {
    currency: string;
    incomeMinor: number;
    expenseMinor: number;
    netMinor: number;
}
export interface TransactionImportPreview {
    schema: typeof TRANSACTION_IMPORT_SCHEMA;
    sourceSha256: string;
    /** Content binding, not authentication or a lock on the ledger. */
    reviewToken: string | null;
    canCommit: boolean;
    counts: {
        total: number;
        add: number;
        alreadyRecorded: number;
        conflict: number;
    };
    totals: {
        allRows: ImportTotals[];
        additions: ImportTotals[];
    };
    rows: ImportPreviewRow[];
}
export declare function previewTransactionImport(store: LedgerStore, args: unknown): Promise<TransactionImportPreview>;
export declare function commitTransactionImport(store: LedgerStore, args: unknown): Promise<{
    schema: typeof TRANSACTION_IMPORT_SCHEMA;
    sourceSha256: string;
    added: number;
    alreadyRecorded: number;
    totals: ImportTotals[];
    transactions: Transaction[];
}>;
export declare const TRANSACTION_IMPORT_TOOL_DEFS: readonly [{
    readonly name: "preview_transaction_import";
    readonly description: "Validate and preview a complete CSV of household transactions without writing. Requires a stable native idempotencyKey per row. Shows exact normalized values, original matching/conflicting records and per-currency totals. Review every row before committing; raw CSV is not persisted.";
    readonly annotations: {
        readonly readOnlyHint: true;
        readonly destructiveHint: false;
        readonly idempotentHint: true;
        readonly openWorldHint: false;
    };
    readonly inputSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly properties: {
            readonly csv: {
                readonly type: "string";
                readonly maxLength: number;
                readonly description: "Complete CSV text, up to 256 KiB UTF-8 and 500 rows. Required headers: idempotencyKey,type,amountMinor,currency,date,category; optional note. Amounts are positive integer minor units. No bank-format inference or missing-field defaults.";
            };
        };
        readonly required: readonly ["csv"];
    };
}, {
    readonly name: "commit_transaction_import";
    readonly description: "After the user reviews the exact normalized CSV preview, import its entire batch atomically through the existing ledger writer. Supply the same CSV and reviewToken. Current matching keys return original records without duplication; any conflict refuses all additions. A retry of the same content is safe. Run one server process per ledger file.";
    readonly annotations: {
        readonly readOnlyHint: false;
        readonly destructiveHint: false;
        readonly idempotentHint: true;
        readonly openWorldHint: false;
    };
    readonly inputSchema: {
        readonly type: "object";
        readonly additionalProperties: false;
        readonly properties: {
            readonly csv: {
                readonly type: "string";
                readonly maxLength: number;
                readonly description: "The exact complete CSV text that was reviewed.";
            };
            readonly reviewToken: {
                readonly type: "string";
                readonly pattern: "^[0-9a-f]{64}$";
                readonly description: "Content-binding token returned by preview_transaction_import. It does not lock the ledger or authenticate approval; current keys are rechecked inside the writer.";
            };
        };
        readonly required: readonly ["csv", "reviewToken"];
    };
}];
