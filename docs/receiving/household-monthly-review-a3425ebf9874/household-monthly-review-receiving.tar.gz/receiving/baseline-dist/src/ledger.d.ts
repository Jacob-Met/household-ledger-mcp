/** Highest supported version. Explicitly denominated budgets require version 2. */
export declare const LEDGER_VERSION = 2;
export type TransactionType = "income" | "expense";
export interface Transaction {
    id: string;
    type: TransactionType;
    /** Integer minor units (e.g. cents). Always > 0. */
    amountMinor: number;
    currency: string;
    /** ISO calendar date YYYY-MM-DD. */
    date: string;
    category: string;
    note?: string;
    /** Stable caller key for one logical recording, retained across retries. */
    idempotencyKey?: string;
    createdAt: string;
}
export interface Budget {
    /** Category this budget applies to. */
    category: string;
    /** YYYY-MM */
    month: string;
    /** Integer minor units, >= 0. */
    limitMinor: number;
    /** Explicit denomination. Absence preserves a legacy, unassigned budget. */
    currency?: string;
}
export interface LedgerData {
    version: number;
    transactions: Transaction[];
    budgets: Budget[];
}
export interface RecordTransactionInput {
    type: TransactionType;
    amountMinor: number;
    currency: string;
    date: string;
    category: string;
    note?: string;
    idempotencyKey?: string;
}
export interface ListTransactionsFilter {
    type?: TransactionType;
    category?: string;
    from?: string;
    to?: string;
    limit?: number;
    offset?: number;
}
export interface MonthlySummary {
    year: number;
    month: number;
    /** Currency of transaction totals, or null for an empty unselected month. */
    currency: string | null;
    incomeMinor: number;
    expenseMinor: number;
    netMinor: number;
    byCategory: Record<string, {
        incomeMinor: number;
        expenseMinor: number;
    }>;
    budgets: Array<{
        category: string;
        /** Present only for an explicitly denominated budget. */
        currency?: string;
        limitMinor: number;
        spentMinor: number;
        remainingMinor: number;
        over: boolean;
    }>;
}
export declare class ValidationError extends Error {
}
export declare function validateDate(value: unknown): string;
export declare function validateMonth(value: unknown): string;
export declare function emptyLedger(): LedgerData;
export declare function validateLedgerData(raw: unknown): LedgerData;
export declare class LedgerStore {
    private readonly filePath;
    private static readonly pending;
    constructor(filePath: string);
    /** Read, mutate and persist one operation before the next mutation reads. */
    update<T>(mutate: (data: LedgerData) => T | Promise<T>): Promise<T>;
    load(): Promise<LedgerData>;
    /** Atomic snapshot replacement. Use update() for read-modify-write operations. */
    save(data: LedgerData): Promise<void>;
}
export declare function recordTransaction(data: LedgerData, input: RecordTransactionInput): Transaction;
export declare function listTransactions(data: LedgerData, filter?: ListTransactionsFilter): {
    total: number;
    transactions: Transaction[];
};
export declare function setBudget(data: LedgerData, category: string, month: string, limitMinor: number, currency?: string, replaceUnassigned?: boolean): Budget;
export declare function monthlySummary(data: LedgerData, year: number, month: number, currency?: string): MonthlySummary;
export declare function getBudgets(data: LedgerData, month: string, currency?: string): Budget[];
