import { type RecordTransactionInput } from "./ledger.js";
export declare const MAX_IMPORT_BYTES: number;
export declare const MAX_IMPORT_ROWS = 500;
export declare const MAX_IMPORT_FIELD_BYTES = 8192;
export interface TransactionCsvRow {
    /** Physical CSV line on which this record begins, including quoted newlines. */
    line: number;
    input: RecordTransactionInput & {
        idempotencyKey: string;
    };
}
export interface ParsedTransactionCsv {
    sourceSha256: string;
    rows: TransactionCsvRow[];
}
export declare function parseTransactionCsv(value: unknown): ParsedTransactionCsv;
