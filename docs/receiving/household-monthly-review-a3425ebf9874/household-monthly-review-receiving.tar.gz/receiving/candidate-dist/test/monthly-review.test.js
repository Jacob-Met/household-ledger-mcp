import test from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { createMonthlyReview, MAX_REVIEW_INPUT_BYTES, MAX_REVIEW_OUTPUT_BYTES } from "../src/monthly-review.js";
const fixed = { month: "2026-04", currency: "USD", generatedAt: "2026-10-08T17:00:00.000Z" };
const encode = (value) => Buffer.from(JSON.stringify(value) + "\n");
const hash = (value) => createHash("sha256").update(value).digest("hex");
const transaction = (id, amountMinor, category, extra = {}) => ({
    id, amountMinor, category, type: "expense", currency: "USD", date: "2026-04-12", createdAt: "2026-04-12T12:00:00.000Z", ...extra,
});
const empty = () => ({ version: 2, transactions: [], budgets: [] });
function rowText(html, body) {
    const table = html.match(new RegExp('<tbody id="' + body + '">([\\s\\S]*?)</tbody>'))?.[1] ?? "";
    return [...table.matchAll(/<tr>([\s\S]*?)<\/tr>/g)].map(match => match[1]);
}
test("one explicit selection preserves native gross arithmetic and omits transaction-private fields", () => {
    const data = empty();
    data.transactions.push(transaction("PRIVATE-ID", 10000, "Salary", { type: "income", note: "PRIVATE-NOTE", idempotencyKey: "PRIVATE-KEY" }), transaction("refund", 300, "Food", { type: "income" }), transaction("spent", 2100, "Food", { currency: " usd " }), transaction("euro", 999999, "OTHER-CURRENCY", { currency: "EUR" }), transaction("later", 888888, "OTHER-MONTH", { date: "2026-05-01" }));
    data.budgets.push({ category: "Food", month: "2026-04", limitMinor: 2000, currency: "USD" }, { category: "Food", month: "2026-04", limitMinor: 100, currency: "EUR" });
    const input = encode(data), before = Buffer.from(input);
    const report = createMonthlyReview(input, { ...fixed, currency: " usd ", sourceLabel: "fictional.json" });
    assert.deepEqual(input, before);
    assert.equal(report.currency, "USD");
    assert.equal(report.selectedTransactions, 3);
    assert.deepEqual([report.summary.incomeMinor, report.summary.expenseMinor, report.summary.netMinor], [10300, 2100, 8200]);
    assert.equal(report.summary.budgets[0].remainingMinor, -100);
    assert.equal(report.summary.budgets[0].spentMinor, 2100, "income does not offset budget spending");
    assert.equal(report.source.sha256, hash(before));
    assert.equal(report.source.bytes, before.length);
    assert.match(report.html, /id="summary-income">10,300</);
    assert.match(report.html, /id="summary-expense">2,100</);
    assert.match(report.html, /id="summary-net">8,200</);
    assert.match(report.html, /Over limit/);
    for (const privateText of ["PRIVATE-ID", "PRIVATE-NOTE", "PRIVATE-KEY", "OTHER-CURRENCY", "OTHER-MONTH"]) {
        assert.ok(!report.html.includes(privateText), privateText);
    }
    input.fill(0);
    assert.equal(report.source.sha256, hash(before));
    assert.match(report.html, /fictional.json/);
});
test("zero and budget-only selections stay explicit without inventing activity or limits", () => {
    const noRows = createMonthlyReview(encode(empty()), fixed);
    assert.equal(noRows.summary.currency, "USD");
    assert.equal(noRows.selectedTransactions, 0);
    assert.match(noRows.html, /id="empty-categories"/);
    assert.match(noRows.html, /id="empty-budgets"/);
    assert.match(noRows.html, /Zero recorded totals do not establish/);
    const data = empty();
    data.budgets.push({ category: "Future", month: "2026-04", limitMinor: 600, currency: "USD" }, { category: "Zero", month: "2026-04", limitMinor: 0, currency: "USD" });
    const report = createMonthlyReview(encode(data), fixed);
    assert.equal(report.selectedTransactions, 0);
    assert.deepEqual(report.summary.budgets.map(b => b.remainingMinor), [600, 0]);
    assert.equal(rowText(report.html, "budget-body").length, 2);
    assert.match(report.html, /Zero limit; no expenses/);
});
test("legacy budgets retain an explicit unassigned label in their admitted single-currency context", () => {
    const data = {
        version: 1, transactions: [transaction("a", 25, "Legacy")],
        budgets: [{ category: "Legacy", month: "2026-04", limitMinor: 20 }],
    };
    const input = encode(data), report = createMonthlyReview(input, fixed);
    assert.equal(report.source.ledgerVersion, 1);
    assert.equal(report.summary.budgets[0].currency, undefined);
    assert.match(report.html, /Currency unassigned · legacy single-currency context/);
    assert.equal(report.summary.budgets[0].remainingMinor, -5);
    assert.deepEqual(input, encode(data), "no currency migration");
});
test("native ambiguous legacy and unsafe-gross-total refusals remain effective", () => {
    const legacy = {
        version: 1, transactions: [transaction("a", 1, "A"), transaction("b", 1, "A", { currency: "EUR" })],
        budgets: [{ category: "A", month: "2026-04", limitMinor: 10 }],
    };
    assert.throws(() => createMonthlyReview(encode(legacy), fixed), /no currency/);
    legacy.transactions.pop();
    assert.throws(() => createMonthlyReview(encode(legacy), { ...fixed, currency: "EUR" }), /no currency/);
    legacy.transactions = [];
    assert.throws(() => createMonthlyReview(encode(legacy), fixed), /no currency/);
    const gross = empty();
    gross.transactions = [transaction("a", Number.MAX_SAFE_INTEGER, "A"), transaction("b", 1, "B")];
    assert.throws(() => createMonthlyReview(encode(gross), fixed), /safe integer/);
});
test("special object keys and exact category spellings become ordinary table rows", () => {
    const data = empty();
    data.transactions = [
        transaction("a", 4, "__proto__"), transaction("b", 7, "constructor"), transaction("c", 9, "constructor "),
    ];
    data.budgets = [{ category: "__proto__", month: "2026-04", limitMinor: 0, currency: "USD" }];
    const report = createMonthlyReview(encode(data), fixed);
    assert.equal(report.summary.byCategory["__proto__"].expenseMinor, 4);
    assert.equal(report.summary.byCategory["constructor"].expenseMinor, 7);
    assert.equal(report.summary.byCategory["constructor "].expenseMinor, 9);
    assert.equal(rowText(report.html, "category-body").length, 3);
    assert.match(report.html, /<bdi class="label">constructor <\/bdi>/);
    assert.equal(report.summary.budgets[0].remainingMinor, -4);
});
test("markup, valid Unicode and HTML newline characters are preserved as inert labels", () => {
    const category = "</style><script>alert('x')</script><img src=x onerror=x>&\"😀\u2028\u2029\r\n\t";
    const data = empty();
    data.transactions = [transaction("a", 11, category)];
    const report = createMonthlyReview(encode(data), { ...fixed, sourceLabel: "<unsafe>&\".json" });
    assert.match(report.html, /&lt;\/style&gt;&lt;script&gt;alert\(&#39;x&#39;\)&lt;\/script&gt;/);
    assert.match(report.html, /😀\u2028\u2029&#13;&#10;&#9;/);
    assert.match(report.html, /&lt;unsafe&gt;&amp;&quot;\.json/);
    assert.ok(!report.html.includes("<script"));
    assert.ok(!report.html.includes("<img"));
    assert.ok(!report.html.includes("localStorage"));
    assert.match(report.html, /default-src 'none'/);
});
test("only unrepresentable displayed labels are refused, without leaking excluded notes or rows", () => {
    for (const category of ["bad\u0000label", "bad\ud800", "bad\udfff"]) {
        const data = empty();
        data.transactions = [transaction("a", 1, category)];
        assert.throws(() => createMonthlyReview(encode(data), fixed), /NUL|surrogate/);
        data.transactions[0].currency = "EUR";
        assert.equal(createMonthlyReview(encode(data), fixed).selectedTransactions, 0);
        data.transactions[0].category = "Good";
        data.transactions[0].currency = "USD";
        data.transactions[0].note = category;
        assert.equal(createMonthlyReview(encode(data), fixed).selectedTransactions, 1);
        data.budgets = [{ category, month: "2026-04", limitMinor: 0, currency: "USD" }];
        assert.throws(() => createMonthlyReview(encode(data), fixed), /NUL|surrogate/);
    }
});
test("selection and provenance admit no implicit month, currency, or invalid generated time", () => {
    const data = encode(empty());
    for (const currency of ["", " ", "US", "USDD", undefined, null]) {
        assert.throws(() => createMonthlyReview(data, { ...fixed, currency }), /currency/);
    }
    for (const month of ["", "2026-4", "2026-00", "2026-13", "1969-12", undefined]) {
        assert.throws(() => createMonthlyReview(data, { ...fixed, month }), /month|year/);
    }
    for (const generatedAt of ["today", "2026-02-30T00:00:00.000Z", "2026-10-08T17:00:00Z"]) {
        assert.throws(() => createMonthlyReview(data, { ...fixed, generatedAt }), /timestamp/);
    }
    assert.throws(() => createMonthlyReview(data, { ...fixed, sourceLabel: "" }), /source label/);
    assert.throws(() => createMonthlyReview(data, { ...fixed, sourceLabel: "x".repeat(181) }), /source label/);
    assert.throws(() => createMonthlyReview(data, { ...fixed, sourceLabel: "\ud800" }), /surrogate/);
});
test("strict byte admission refuses invalid UTF-8, BOM, malformed JSON and oversized snapshots", () => {
    for (const bytes of [Buffer.alloc(0), Buffer.from([0xff]), Buffer.from("{"), Buffer.concat([Buffer.from([0xef, 0xbb, 0xbf]), encode(empty())])]) {
        assert.throws(() => createMonthlyReview(bytes, fixed), /bytes|UTF-8 JSON/);
    }
    assert.throws(() => createMonthlyReview(Buffer.alloc(MAX_REVIEW_INPUT_BYTES + 1), fixed), /bytes/);
    assert.throws(() => createMonthlyReview(encode({ version: 9, transactions: [], budgets: [] }), fixed), /version/);
});
test("output escaping expansion refuses the whole oversized report", () => {
    const data = empty();
    data.transactions = [transaction("a", 1, "&".repeat(Math.floor(MAX_REVIEW_OUTPUT_BYTES / 5)))];
    const input = encode(data);
    assert.ok(input.byteLength < MAX_REVIEW_INPUT_BYTES);
    assert.throws(() => createMonthlyReview(input, fixed), /complete monthly review exceeds/);
});
test("safe-integer limits render exactly without decimal or exponent conversion", () => {
    const data = empty();
    data.transactions = [transaction("a", Number.MAX_SAFE_INTEGER, "Maximum", { type: "income" })];
    const report = createMonthlyReview(encode(data), fixed);
    assert.match(report.html, /id="summary-income">9,007,199,254,740,991</);
    assert.equal(report.summary.netMinor, Number.MAX_SAFE_INTEGER);
    assert.match(report.html, /not an account balance/);
    assert.match(report.html, /freshness, completeness, and authenticity are unknown/);
});
//# sourceMappingURL=monthly-review.test.js.map