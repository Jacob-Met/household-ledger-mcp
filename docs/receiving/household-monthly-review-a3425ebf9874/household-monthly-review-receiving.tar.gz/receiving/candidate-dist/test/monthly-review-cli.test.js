import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, writeFile, readFile, stat, lstat, readdir, mkdir, link, symlink, rm, truncate } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { spawn, spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { MAX_REVIEW_INPUT_BYTES } from "../src/monthly-review.js";
const cli = fileURLToPath(new URL("../src/household-review.js", import.meta.url));
const sample = JSON.stringify({
    version: 2,
    transactions: [{
            id: "PRIVATE-IDENTITY", type: "expense", amountMinor: 123, currency: "USD", date: "2026-04-01",
            category: "Food", note: "PRIVATE-NOTE", idempotencyKey: "PRIVATE-KEY", createdAt: "2026-04-01T00:00:00.000Z",
        }],
    budgets: [{ category: "Food", month: "2026-04", currency: "USD", limitMinor: 120 }],
}, null, 2) + "\n";
const args = (input, output) => [cli, "--ledger", input, "--month", "2026-04", "--currency", "USD", "--output", output];
function run(argv, timeout = 5000) {
    return spawnSync(process.execPath, argv, { encoding: "utf8", timeout, env: { ...process.env, LEDGER_FILE: "/must-not-be-used" } });
}
async function within(body) {
    const root = await mkdtemp(join(tmpdir(), "household-review-test-"));
    const input = join(root, "fictional-ledger.json");
    await writeFile(input, sample, { mode: 0o600 });
    try {
        await body(root, input);
    }
    finally {
        await rm(root, { recursive: true, force: true });
    }
}
async function noTemps(root) {
    assert.deepEqual((await readdir(root)).filter(p => p.startsWith(".household-review-")), []);
}
function refused(result) {
    assert.equal(result.status, 1, result.stderr);
    assert.equal(result.stdout, "");
    assert.match(result.stderr, /^household-review: [^\r\n]+\n$/);
    assert.ok(!result.stderr.includes("\n    at "));
}
test("actual compiled CLI publishes one private, complete source-bound HTML file", async () => within(async (root, input) => {
    const destination = join(root, "monthly.html"), before = await stat(input);
    const result = run(args(input, destination));
    assert.equal(result.status, 0, result.stderr);
    assert.equal(result.stderr, "");
    const receipt = JSON.parse(result.stdout), output = await readFile(destination);
    assert.equal(receipt.month, "2026-04");
    assert.equal(receipt.currency, "USD");
    assert.equal(receipt.selectedTransactions, 1);
    assert.equal(receipt.sourceSha256, createHash("sha256").update(sample).digest("hex"));
    assert.equal(receipt.reportSha256, createHash("sha256").update(output).digest("hex"));
    assert.equal(receipt.reportBytes, output.length);
    assert.ok(output.toString("utf8").endsWith("</html>\n"));
    assert.match(output.toString("utf8"), /<td class="number">-3<\/td>/);
    for (const value of ["PRIVATE-IDENTITY", "PRIVATE-NOTE", "PRIVATE-KEY", input]) {
        assert.ok(!output.toString("utf8").includes(value), value);
    }
    if (process.platform !== "win32")
        assert.equal((await stat(destination)).mode & 0o777, 0o600);
    assert.equal(await readFile(input, "utf8"), sample);
    const after = await stat(input);
    assert.equal(after.ino, before.ino);
    assert.equal(after.mtimeMs, before.mtimeMs);
    await noTemps(root);
}));
test("existing destination, input alias, hardlink and symlink are preserved", async () => within(async (root, input) => {
    const destination = join(root, "already.html"), hard = join(root, "hard.html"), symbolic = join(root, "symbolic.html");
    await writeFile(destination, "EXISTING-REPORT-SENTINEL");
    await link(input, hard);
    await symlink(input, symbolic);
    for (const output of [destination, input, hard, symbolic])
        refused(run(args(input, output)));
    assert.equal(await readFile(destination, "utf8"), "EXISTING-REPORT-SENTINEL");
    assert.equal(await readFile(input, "utf8"), sample);
    assert.equal((await stat(hard)).ino, (await stat(input)).ino);
    assert.equal((await lstat(symbolic)).isSymbolicLink(), true);
    await noTemps(root);
}));
test("a dangling output symlink and an existing directory are refused without replacement", async () => within(async (root, input) => {
    const symbolic = join(root, "dangling.html"), directory = join(root, "directory");
    await symlink(join(root, "absent-target"), symbolic);
    await mkdir(directory);
    refused(run(args(input, symbolic)));
    refused(run(args(input, directory)));
    assert.equal((await lstat(symbolic)).isSymbolicLink(), true);
    assert.equal((await stat(directory)).isDirectory(), true);
    await assert.rejects(stat(join(root, "absent-target")), { code: "ENOENT" });
    await noTemps(root);
}));
test("missing, malformed and oversized inputs leave no report or temporary files", async () => within(async (root, input) => {
    const destination = join(root, "refused.html");
    refused(run(args(join(root, "absent.json"), destination)));
    await writeFile(input, "{\"version\":");
    refused(run(args(input, destination)));
    await truncate(input, MAX_REVIEW_INPUT_BYTES + 1);
    refused(run(args(input, destination)));
    await assert.rejects(stat(destination), { code: "ENOENT" });
    await noTemps(root);
}));
test("directories and POSIX FIFOs are rejected promptly rather than read indefinitely", async () => within(async (root) => {
    const destination = join(root, "refused.html");
    refused(run(args(root, destination)));
    if (process.platform !== "win32") {
        const fifo = join(root, "pipe.json");
        const mkfifo = spawnSync("mkfifo", [fifo], { encoding: "utf8" });
        assert.equal(mkfifo.status, 0, mkfifo.stderr);
        const result = run(args(fifo, destination), 2000);
        assert.equal(result.error, undefined);
        refused(result);
        assert.match(result.stderr, /regular file/);
    }
    await noTemps(root);
}));
test("argument and domain refusals do not create outputs or consult a default ledger", async () => within(async (root, input) => {
    const destination = join(root, "refused.html"), complete = args(input, destination);
    const cases = [
        [cli], [cli, "--help", "--month", "2026-04"], [...complete, "--currency", "USD"],
        [cli, "--ledger", input, "--month", "2026-04", "--currency", "", "--output", destination],
        [cli, "--ledger", input, "--month", "2026-04", "--currency", "USD", "--ledger", destination],
        [cli, "--ledger", input, "--month", "2026-13", "--currency", "USD", "--output", destination],
        [cli, "--ledger", input, "--month", "2026-04", "--currency", "US", "--output", destination],
    ];
    for (const argv of cases)
        refused(run(argv));
    const help = run([cli, "--help"]);
    assert.equal(help.status, 0);
    assert.match(help.stdout, /NEW_HTML_FILE/);
    await assert.rejects(stat(destination), { code: "ENOENT" });
    assert.equal(await readFile(input, "utf8"), sample);
    await noTemps(root);
}));
test("a nonexistent output parent is not created and leaves the source unchanged", async () => within(async (root, input) => {
    refused(run(args(input, join(root, "new-parent", "monthly.html"))));
    await assert.rejects(stat(join(root, "new-parent")), { code: "ENOENT" });
    assert.equal(await readFile(input, "utf8"), sample);
    await noTemps(root);
}));
test("concurrent real CLI publishers admit exactly one complete output", async () => within(async (root, input) => {
    const destination = join(root, "race.html");
    const results = await Promise.all(Array.from({ length: 6 }, () => new Promise((resolve, reject) => {
        const child = spawn(process.execPath, args(input, destination), { stdio: ["ignore", "pipe", "pipe"] });
        let stdout = "", stderr = "";
        child.stdout.setEncoding("utf8");
        child.stderr.setEncoding("utf8");
        child.stdout.on("data", data => { stdout += data; });
        child.stderr.on("data", data => { stderr += data; });
        child.on("error", reject);
        child.on("close", code => resolve({ code, stdout, stderr }));
    })));
    const successes = results.filter(result => result.code === 0);
    assert.equal(successes.length, 1);
    for (const result of results.filter(result => result.code !== 0)) {
        assert.equal(result.code, 1);
        assert.match(result.stderr, /output .*exists|output appeared/);
    }
    const bytes = await readFile(destination);
    assert.equal(JSON.parse(successes[0].stdout).reportSha256, createHash("sha256").update(bytes).digest("hex"));
    assert.ok(bytes.toString("utf8").endsWith("</html>\n"));
    assert.equal(await readFile(input, "utf8"), sample);
    await noTemps(root);
}));
//# sourceMappingURL=monthly-review-cli.test.js.map