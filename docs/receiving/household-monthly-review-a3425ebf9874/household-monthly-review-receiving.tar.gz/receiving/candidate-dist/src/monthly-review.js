/**
 * A detached, explicit-currency monthly review of one exact ledger byte snapshot.
 * Domain validation and arithmetic remain owned by ledger.ts.
 */
import { createHash } from "node:crypto";
import { TextDecoder } from "node:util";
import { monthlySummary, validateLedgerData, validateMonth } from "./ledger.js";
export const MAX_REVIEW_INPUT_BYTES = 8 * 1024 * 1024;
export const MAX_REVIEW_OUTPUT_BYTES = 8 * 1024 * 1024;
function requireLabel(value, field) {
    if (typeof value !== "string")
        throw new Error(field + " must be text");
    for (let i = 0; i < value.length; i++) {
        const code = value.charCodeAt(i);
        if (code === 0)
            throw new Error(field + " contains a NUL character that HTML cannot preserve");
        if (code >= 0xd800 && code <= 0xdbff) {
            const next = value.charCodeAt(++i);
            if (!(next >= 0xdc00 && next <= 0xdfff)) {
                throw new Error(field + " contains an unpaired Unicode surrogate");
            }
        }
        else if (code >= 0xdc00 && code <= 0xdfff) {
            throw new Error(field + " contains an unpaired Unicode surrogate");
        }
    }
    return value;
}
/** Numeric references keep CR/LF labels exact across HTML newline parsing. */
function escapeHtml(value) {
    return value.replace(/[&<>"'\r\n\t]/g, char => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
        "\r": "&#13;", "\n": "&#10;", "\t": "&#9;",
    })[char]);
}
function label(value) {
    return '<bdi class="label">' + escapeHtml(value) + "</bdi>";
}
/** No decimal scale, conversion, or floating-point currency formatter is used. */
function amount(value) {
    if (!Number.isSafeInteger(value))
        throw new Error("review amount exceeds the safe integer range");
    return String(value).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}
function order(a, b) {
    return a < b ? -1 : a > b ? 1 : 0;
}
const styles = String.raw `:root { color-scheme: light; font: 16px/1.5 system-ui, -apple-system, "Segoe UI", sans-serif; color: #20312d; background: #f2f5f0; }
* { box-sizing: border-box; }
body { margin: 0; min-width: 280px; }
main { width: min(70rem, calc(100% - 2rem)); margin: 2.5rem auto; }
header { margin-bottom: 1.5rem; }
h1 { font-size: clamp(1.8rem, 4vw, 2.7rem); line-height: 1.15; margin: .25rem 0 .7rem; }
h2 { font-size: 1.25rem; margin: 0 0 .75rem; }
p { margin: .6rem 0; }
.kicker { color: #255f4c; font-weight: 750; letter-spacing: .08em; text-transform: uppercase; font-size: .8rem; }
.selection { display: flex; flex-wrap: wrap; gap: .65rem; margin: 1rem 0; }
.badge { padding: .3rem .6rem; border: 1px solid #9ab5a8; border-radius: .4rem; background: #e5efe8; font-weight: 700; }
.subtitle, .muted { color: #52665d; }
.cards { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: .8rem; margin: 1.2rem 0; }
.card { min-width: 0; padding: 1.2rem; background: #fff; border: 1px solid #c7d5ca; border-radius: .75rem; }
.card h2 { color: #52665d; font-size: .85rem; margin: 0; }
.value { font: 750 clamp(1.4rem, 3vw, 2rem)/1.35 ui-monospace, SFMono-Regular, Consolas, monospace; margin: .45rem 0 .25rem; overflow-wrap: anywhere; }
.unit { color: #52665d; font-size: .8rem; }
section { min-width: 0; padding: 1.25rem; margin: 1rem 0; background: #fff; border: 1px solid #c7d5ca; border-radius: .75rem; }
.table-scroll { max-width: 100%; overflow-x: auto; padding: .25rem; }
.table-scroll:focus-visible { outline: 3px solid #a34d00; outline-offset: 2px; }
table { width: 100%; border-collapse: collapse; }
caption { text-align: left; color: #52665d; font-size: .88rem; padding-bottom: .8rem; }
th, td { padding: .7rem .65rem; border-bottom: 1px solid #d9e1da; vertical-align: top; text-align: left; }
thead th { color: #41564a; background: #f0f5ee; font-size: .85rem; }
th[scope="row"] { font-weight: 650; max-width: 25rem; min-width: 9rem; overflow-wrap: anywhere; }
bdi.label { white-space: pre-wrap; overflow-wrap: anywhere; }
.number { text-align: right; font-variant-numeric: tabular-nums; font-family: ui-monospace, SFMono-Regular, Consolas, monospace; white-space: nowrap; }
.status { min-width: 9rem; font-weight: 650; }
.over { color: #923a24; }
.within { color: #255f4c; }
.legacy { display: block; color: #7a561c; font-size: .8rem; font-weight: 500; margin-top: .3rem; }
.empty { padding: .9rem; border: 1px dashed #a8bbad; border-radius: .4rem; background: #f6f8f3; }
.provenance { display: grid; grid-template-columns: max-content minmax(0, 1fr); gap: .4rem 1rem; font-size: .9rem; }
.provenance dt { color: #52665d; }
.provenance dd { margin: 0; overflow-wrap: anywhere; }
.hash { font: .82rem/1.5 ui-monospace, SFMono-Regular, Consolas, monospace; word-break: break-all; }
footer { margin-top: 1.3rem; font-size: .88rem; color: #52665d; }
@media (max-width: 560px) {
 main { width: calc(100% - 1.25rem); margin: 1.4rem auto; }
 .cards { grid-template-columns: minmax(0, 1fr); gap: .6rem; }
 .card { padding: 1rem; }
 section { padding: 1rem; }
 .provenance { grid-template-columns: minmax(0, 1fr); gap: .15rem; }
 .provenance dd { margin-bottom: .6rem; }
}
@media print {
 :root, body { background: #fff; color: #111; font-size: 10pt; }
 main { width: 100%; margin: 0; }
 h1 { font-size: 23pt; }
 .cards { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); }
 .card, section { border-radius: 0; box-shadow: none; }
 .card { break-inside: avoid; }
 section { padding: .8rem 0; border: 0; }
 .table-scroll { overflow: visible; padding: 0; }
 table { width: 100%; font-size: 8pt; }
 th, td { padding: .35rem .3rem; }
 th[scope="row"] { min-width: 0; max-width: 12rem; }
 .status { min-width: 0; }
 .number { white-space: normal; overflow-wrap: anywhere; }
 thead { display: table-header-group; }
 tr { break-inside: avoid; }
 .provenance { grid-template-columns: max-content minmax(0, 1fr); }
 .screen-only { display: none; }
}`;
/**
 * Reads no filesystem or environment state and retains no reference to input.
 * A source hash identifies captured bytes, not freshness or authenticity.
 */
export function createMonthlyReview(input, options) {
    if (!(input instanceof Uint8Array))
        throw new Error("ledger snapshot must be bytes");
    if (input.byteLength === 0 || input.byteLength > MAX_REVIEW_INPUT_BYTES) {
        throw new Error("ledger snapshot must contain 1.." + MAX_REVIEW_INPUT_BYTES + " bytes");
    }
    if (!options || typeof options !== "object")
        throw new Error("month and currency are required");
    const month = validateMonth(options.month);
    if (typeof options.currency !== "string" || !/^[A-Za-z]{3}$/.test(options.currency.trim())) {
        throw new Error("currency must be an explicit 3-letter code");
    }
    const currency = options.currency.trim().toUpperCase();
    const sourceLabel = requireLabel(options.sourceLabel ?? "ledger snapshot", "source label");
    if (sourceLabel.trim().length === 0 || [...sourceLabel].length > 180) {
        throw new Error("source label must contain 1..180 characters");
    }
    const generatedAt = options.generatedAt ?? new Date().toISOString();
    if (typeof generatedAt !== "string" || !/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(generatedAt) ||
        !Number.isFinite(Date.parse(generatedAt)) || new Date(generatedAt).toISOString() !== generatedAt) {
        throw new Error("generatedAt must be an exact UTC ISO timestamp");
    }
    const bytes = Buffer.from(input);
    let raw;
    try {
        // Preserve a leading BOM, matching the native JSON reader's refusal.
        raw = JSON.parse(new TextDecoder("utf-8", { fatal: true, ignoreBOM: true }).decode(bytes));
    }
    catch {
        throw new Error("ledger snapshot must be valid UTF-8 JSON without a byte-order mark");
    }
    const data = validateLedgerData(raw);
    const [year, monthNumber] = month.split("-").map(Number);
    const summary = monthlySummary(data, year, monthNumber, currency);
    const selectedTransactions = data.transactions.filter(t => t.date.startsWith(month) && t.currency.trim().toUpperCase() === currency).length;
    const categories = Object.entries(summary.byCategory).sort(([a], [b]) => order(a, b));
    for (const [category] of categories)
        requireLabel(category, "selected category");
    const budgets = [...summary.budgets].sort((a, b) => order(a.category, b.category));
    for (const budget of budgets)
        requireLabel(budget.category, "selected budget category");
    const source = {
        label: sourceLabel,
        bytes: bytes.byteLength,
        sha256: createHash("sha256").update(bytes).digest("hex"),
        ledgerVersion: data.version,
    };
    const parts = [];
    let outputBytes = 0;
    const append = (part) => {
        outputBytes += Buffer.byteLength(part, "utf8");
        if (outputBytes > MAX_REVIEW_OUTPUT_BYTES) {
            throw new Error("complete monthly review exceeds the " + MAX_REVIEW_OUTPUT_BYTES + "-byte output limit");
        }
        parts.push(part);
    };
    const moneyCell = (value) => '<td class="number">' + amount(value) + "</td>";
    append("<!doctype html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n");
    append('<meta name="viewport" content="width=device-width, initial-scale=1">\n');
    append('<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'; base-uri \'none\'; form-action \'none\'">\n');
    append("<title>Household monthly review · " + month + " · " + currency + "</title>\n");
    append("<style>\n" + styles + "\n</style>\n</head>\n<body>\n");
    append('<main data-month="' + month + '" data-currency="' + currency + '">\n<header>\n');
    append('<p class="kicker">Household Ledger · local snapshot</p>\n<h1>Monthly category &amp; budget review</h1>\n');
    append('<p class="subtitle">An explicit month and currency, evaluated from the captured ledger bytes.</p>\n');
    append('<div class="selection"><span class="badge" id="selected-month">' + month +
        '</span><span class="badge" id="selected-currency">' + currency + "</span></div>\n");
    append('<p><strong id="selected-count">' + selectedTransactions + "</strong> selected transactions. " +
        "Amounts are exact integer <strong>minor units</strong>; no decimal scale or currency conversion is assumed.</p>\n</header>\n");
    append('<div class="cards" aria-label="Selected monthly totals">\n');
    for (const [id, title, value] of [
        ["income", "Income recorded", summary.incomeMinor],
        ["expense", "Expenses recorded", summary.expenseMinor],
        ["net", "Income minus expenses", summary.netMinor],
    ]) {
        append('<article class="card"><h2>' + title + '</h2><p class="value" id="summary-' + id + '">' +
            amount(value) + '</p><p class="unit">' + currency + " minor units</p></article>\n");
    }
    append("</div>\n<section aria-labelledby=\"category-heading\">\n<h2 id=\"category-heading\">By category</h2>\n");
    if (categories.length === 0) {
        append('<p class="empty" id="empty-categories">No recorded transactions match this month and currency. Zero recorded totals do not establish that activity is complete.</p>\n');
    }
    else {
        append('<div class="table-scroll" tabindex="0" role="region" aria-label="Category totals; scroll horizontally if needed"><table>\n');
        append("<caption>Recorded income and expenses, separately. Category labels retain their exact spelling.</caption>\n");
        append('<thead><tr><th scope="col">Category</th><th scope="col" class="number">Income · minor units</th><th scope="col" class="number">Expenses · minor units</th></tr></thead>\n<tbody id="category-body">\n');
        for (const [category, totals] of categories) {
            append('<tr><th scope="row">' + label(category) + "</th>" +
                moneyCell(totals.incomeMinor) + moneyCell(totals.expenseMinor) + "</tr>\n");
        }
        append("</tbody></table></div>\n");
    }
    append("</section>\n<section aria-labelledby=\"budget-heading\">\n<h2 id=\"budget-heading\">Category budgets</h2>\n");
    append("<p>Spending uses recorded expenses only; category income does not reduce it. A negative remaining amount is over the stored limit.</p>\n");
    if (budgets.length === 0) {
        append('<p class="empty" id="empty-budgets">No category budgets match this month and currency. No limit has been inferred.</p>\n');
    }
    else {
        append('<div class="table-scroll" tabindex="0" role="region" aria-label="Budget comparison; scroll horizontally if needed"><table>\n');
        append("<caption>Stored limits compared with the selected monthly expenses, all in integer minor units.</caption>\n");
        append('<thead><tr><th scope="col">Category</th><th scope="col" class="number">Limit</th><th scope="col" class="number">Spent</th><th scope="col" class="number">Remaining</th><th scope="col">Evaluation</th></tr></thead>\n<tbody id="budget-body">\n');
        for (const budget of budgets) {
            const status = budget.over ? "Over limit" : budget.limitMinor === 0 ? "Zero limit; no expenses" : "Within stored limit";
            append('<tr><th scope="row">' + label(budget.category) +
                (budget.currency === undefined ? '<span class="legacy">Currency unassigned · legacy single-currency context</span>' : "") +
                "</th>" + moneyCell(budget.limitMinor) + moneyCell(budget.spentMinor) + moneyCell(budget.remainingMinor) +
                '<td class="status ' + (budget.over ? "over" : "within") + '">' + status + "</td></tr>\n");
        }
        append("</tbody></table></div>\n");
    }
    append("</section>\n<section aria-labelledby=\"snapshot-heading\">\n<h2 id=\"snapshot-heading\">Snapshot &amp; evaluation</h2>\n");
    append('<dl class="provenance"><dt>Source label</dt><dd id="source-label">' + label(source.label) + "</dd>\n");
    append('<dt>Captured bytes</dt><dd id="source-bytes">' + source.bytes + "</dd>\n");
    append('<dt>Source SHA-256</dt><dd class="hash" id="source-sha256">' + source.sha256 + "</dd>\n");
    append('<dt>Ledger format version</dt><dd>' + source.ledgerVersion + "</dd>\n");
    append('<dt>Report generated (UTC)</dt><dd><time id="generated-at" datetime="' + generatedAt + '">' + generatedAt + "</time></dd>\n");
    append("<dt>Evaluation</dt><dd>Native ledger validation and monthlySummary rules; explicit month and currency.</dd></dl>\n");
    append("<p>This static report reflects only the captured bytes. It does not refresh. Source freshness, completeness, and authenticity are unknown; the hash identifies bytes without certifying them. The generation time is not a transaction update time.</p>\n");
    append("<p>The net figure is recorded income minus expenses for this selection, not an account balance or a cash-flow forecast. Other months and currencies are excluded. No conversion, recommendations, or limit assignment is performed.</p>\n");
    append("<p>Transaction IDs, notes, and idempotency keys are omitted. Category and source labels, totals, and budget limits are present: keep this file private.</p>\n</section>\n");
    append('<footer><p class="screen-only">Open this saved file offline. Use your browser’s Print command for a paper or PDF copy.</p><p>No scripts, external assets, network requests, or browser storage are required.</p></footer>\n');
    append("</main>\n</body>\n</html>\n");
    return { html: parts.join(""), month, currency, generatedAt, source, selectedTransactions, summary };
}
//# sourceMappingURL=monthly-review.js.map