#!/usr/bin/env node
export declare function runMonthlyReview(argv: string[]): Promise<string>;
