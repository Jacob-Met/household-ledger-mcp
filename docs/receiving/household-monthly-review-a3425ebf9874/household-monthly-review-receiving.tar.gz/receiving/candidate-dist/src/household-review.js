#!/usr/bin/env node
/**
 * Explicit local-file entry point. It never opens LedgerStore or starts MCP.
 */
import { constants } from "node:fs";
import { open, lstat, link, unlink } from "node:fs/promises";
import { basename, dirname, resolve, join } from "node:path";
import { pathToFileURL } from "node:url";
import { createHash, randomUUID } from "node:crypto";
import { createMonthlyReview, MAX_REVIEW_INPUT_BYTES } from "./monthly-review.js";
const usage = "Usage: node dist/src/household-review.js --ledger FILE --month YYYY-MM --currency CODE --output NEW_HTML_FILE";
function parseArguments(argv) {
    const values = new Map();
    const allowed = new Set(["--ledger", "--month", "--currency", "--output"]);
    if (argv.length !== 8)
        throw new Error("supply each of --ledger, --month, --currency, and --output exactly once");
    for (let i = 0; i < argv.length; i += 2) {
        const key = argv[i], value = argv[i + 1];
        if (!allowed.has(key) || values.has(key) || value === undefined || value.length === 0) {
            throw new Error("unknown, repeated, or empty monthly review argument");
        }
        values.set(key, value);
    }
    if (values.size !== 4)
        throw new Error("all four monthly review arguments are required");
    return {
        ledger: values.get("--ledger"), month: values.get("--month"),
        currency: values.get("--currency"), output: values.get("--output"),
    };
}
function hasCode(error, code) {
    return typeof error === "object" && error !== null && "code" in error && error.code === code;
}
async function requireNewDestination(path) {
    try {
        await lstat(path);
    }
    catch (error) {
        if (hasCode(error, "ENOENT"))
            return;
        throw error;
    }
    throw new Error("output already exists; choose a new file (existing files, links, and directories are never replaced)");
}
/** An opened regular file and bounded reads also refuse FIFOs without waiting. */
async function readSnapshot(path) {
    const handle = await open(path, constants.O_RDONLY | constants.O_NONBLOCK);
    try {
        const before = await handle.stat({ bigint: true });
        if (!before.isFile())
            throw new Error("ledger input must be an existing regular file");
        if (before.size === 0n || before.size > BigInt(MAX_REVIEW_INPUT_BYTES)) {
            throw new Error("ledger input must contain 1.." + MAX_REVIEW_INPUT_BYTES + " bytes");
        }
        const chunks = [];
        let count = 0;
        while (count <= MAX_REVIEW_INPUT_BYTES) {
            const chunk = Buffer.alloc(Math.min(65536, MAX_REVIEW_INPUT_BYTES + 1 - count));
            const { bytesRead } = await handle.read(chunk, 0, chunk.length, count);
            if (bytesRead === 0)
                break;
            chunks.push(chunk.subarray(0, bytesRead));
            count += bytesRead;
        }
        if (count > MAX_REVIEW_INPUT_BYTES)
            throw new Error("ledger input grew beyond the byte limit");
        const after = await handle.stat({ bigint: true });
        if (BigInt(count) !== before.size || before.size !== after.size ||
            before.mtimeNs !== after.mtimeNs || before.ctimeNs !== after.ctimeNs) {
            throw new Error("ledger changed while reading; retry from a stable snapshot");
        }
        return Buffer.concat(chunks, count);
    }
    finally {
        await handle.close();
    }
}
/** Link a completed private temp file without overwriting even a late arrival. */
async function publishNew(destination, bytes) {
    const temporary = join(dirname(destination), ".household-review-" + randomUUID() + ".tmp");
    const handle = await open(temporary, "wx", 0o600);
    let published = false;
    let operationError;
    try {
        try {
            await handle.writeFile(bytes);
            await handle.sync();
        }
        finally {
            await handle.close();
        }
        await link(temporary, destination);
        published = true;
    }
    catch (error) {
        operationError = error;
    }
    finally {
        try {
            await unlink(temporary);
        }
        catch (error) {
            if (!hasCode(error, "ENOENT")) {
                if (published)
                    throw new Error("complete report saved, but temporary-file cleanup failed: " + temporary);
                if (operationError === undefined)
                    operationError = error;
            }
        }
    }
    if (operationError !== undefined) {
        if (hasCode(operationError, "EEXIST")) {
            throw new Error("output appeared before publication; it was preserved, choose a new file");
        }
        throw operationError;
    }
}
export async function runMonthlyReview(argv) {
    if (argv.length === 1 && argv[0] === "--help") {
        return usage + "\nCreates a private static HTML file from one explicit local ledger, month, and currency.\n" +
            "Inputs are read only. Output must be new; no files or links are replaced.\n" +
            "Amounts remain exact integer minor units; use the browser Print command for a PDF.\n";
    }
    const args = parseArguments(argv);
    const inputPath = resolve(args.ledger), destination = resolve(args.output);
    await requireNewDestination(destination);
    const snapshot = await readSnapshot(inputPath);
    const report = createMonthlyReview(snapshot, {
        month: args.month, currency: args.currency, sourceLabel: basename(inputPath),
    });
    const output = Buffer.from(report.html, "utf8");
    await publishNew(destination, output);
    return JSON.stringify({
        output: destination, month: report.month, currency: report.currency,
        selectedTransactions: report.selectedTransactions,
        sourceBytes: report.source.bytes, sourceSha256: report.source.sha256,
        reportBytes: output.byteLength,
        reportSha256: createHash("sha256").update(output).digest("hex"),
    }) + "\n";
}
if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
    try {
        process.stdout.write(await runMonthlyReview(process.argv.slice(2)));
    }
    catch (error) {
        const message = (error instanceof Error ? error.message : String(error)).replace(/[\r\n\t]/g, " ").slice(0, 1000);
        process.stderr.write("household-review: " + message + "\n");
        process.exitCode = 1;
    }
}
//# sourceMappingURL=household-review.js.map