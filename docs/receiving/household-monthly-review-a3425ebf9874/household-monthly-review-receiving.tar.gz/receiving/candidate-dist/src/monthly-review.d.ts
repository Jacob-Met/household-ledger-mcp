import { type MonthlySummary } from "./ledger.js";
export declare const MAX_REVIEW_INPUT_BYTES: number;
export declare const MAX_REVIEW_OUTPUT_BYTES: number;
export interface MonthlyReviewOptions {
    month: string;
    currency: string;
    sourceLabel?: string;
    generatedAt?: string;
}
export interface MonthlyReview {
    html: string;
    month: string;
    currency: string;
    generatedAt: string;
    source: {
        label: string;
        bytes: number;
        sha256: string;
        ledgerVersion: number;
    };
    selectedTransactions: number;
    summary: MonthlySummary;
}
/**
 * Reads no filesystem or environment state and retains no reference to input.
 * A source hash identifies captured bytes, not freshness or authenticity.
 */
export declare function createMonthlyReview(input: Uint8Array, options: MonthlyReviewOptions): MonthlyReview;
