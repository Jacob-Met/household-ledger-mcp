import assert from 'node:assert/strict';
import { readFile, mkdir, stat } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
const [dist, fixture, output] = process.argv.slice(2);
const { validateLedgerData, monthlySummary } = await import(pathToFileURL(dist + '/src/ledger.js').href);
const hash = b => createHash('sha256').update(b).digest('hex');
const before = await readFile(fixture), beforeStat = await stat(fixture);
const data = validateLedgerData(JSON.parse(before.toString('utf8')));
const summary = monthlySummary(data, 2026, 4, 'USD');
assert.equal(summary.incomeMinor, 312500);
assert.equal(summary.expenseMinor, 139300);
assert.equal(summary.netMinor, 173200);
assert.equal(summary.byCategory['__proto__'].expenseMinor, 500);
assert.equal(summary.budgets.find(b => b.category === 'Groceries').remainingMinor, -800);
assert.equal(summary.budgets.find(b => b.category === '__proto__').remainingMinor, -500);
await mkdir(output);
const destination = output + '/review.html';
const command = [dist + '/src/household-review.js','--ledger',fixture,'--month','2026-04','--currency','USD','--output',destination];
const result = spawnSync(process.execPath, command, {encoding:'utf8'});
const receipt = {
  domain: 'PASS: original checked totals and special category',
  expected: {month:'2026-04',currency:'USD',incomeMinor:312500,expenseMinor:139300,netMinor:173200},
  command:[process.execPath,...command],exit_code:result.status,stdout:result.stdout,stderr:result.stderr,
  source_sha256:hash(before),source_bytes:before.length
};
const after = await readFile(fixture), afterStat = await stat(fixture);
assert.deepEqual(after,before);
assert.equal(afterStat.ino,beforeStat.ino);assert.equal(afterStat.mtimeMs,beforeStat.mtimeMs);
receipt.source_unchanged = true;
if(result.status===0){
  const html = await readFile(destination,'utf8');
  assert.ok(html.includes('2026-04')&&html.includes('USD')&&html.includes(hash(before)));
  for(const privateText of ['PRIVATE-NOTE-DO-NOT-PUBLISH','sensitive-record-key','OTHER-CURRENCY-PRIVATE-NOTE','t-salary'])
    assert.ok(!html.includes(privateText),privateText);
  receipt.html_sha256=hash(Buffer.from(html));receipt.html_bytes=Buffer.byteLength(html);
  receipt.feature='PASS: actual monthly HTML command produced selected source-bound output';
}else{receipt.feature='FAIL: the requested new local review command is unavailable';process.exitCode=1;}
console.log(JSON.stringify(receipt,null,2));
