# Offline monthly review

Create a readable category and budget report from one explicit local ledger file. The report is a private, self-contained HTML document you can open without a server or network and print from your browser.

## Create a report

Build the existing project, then pass all four arguments explicitly:

    npm run build
    node dist/src/household-review.js \
      --ledger /absolute/path/to/ledger.json \
      --month 2026-04 \
      --currency USD \
      --output /absolute/path/to/new-monthly-review.html

Use a new destination filename. Existing files, directories, symbolic links and hard links are never replaced. The parent directory must already exist. The CLI does not read a default ledger environment variable, open an MCP session, start a server, or alter the source ledger.

A successful invocation prints one JSON receipt containing the destination, selected month/currency/count, source byte length and SHA-256, and report byte length and SHA-256. Errors go to stderr with exit status 1; no stack trace is printed. Run with only `--help` for usage.

Open the saved HTML file in a browser. Use the browser's **Print** command to create a paper or PDF copy. Wide tables scroll inside labeled keyboard-focusable regions on a narrow screen. The print layout exposes the full tables and repeats column headings across pages. No JavaScript, external fonts, images, storage, or network access is required.

## What the figures mean

- **Month and currency are required.** Currency uses the existing three-letter-code rule, with surrounding whitespace removed and letters uppercased. The report does not validate a code against an external currency registry, infer a currency, or convert amounts.
- **Every amount is an exact integer in minor units.** The file does not assume a currency's decimal scale. For example, `18,800` means 18,800 stored minor units, without claiming that the currency has two decimal places.
- **Income, expenses, and their difference** include only transactions in the selected month and currency. The difference is not an account balance or a forecast.
- **Category budgets** compare stored limits with the selected recorded expenses. Income in the same category does not reduce spending. Negative remaining units mean the stored limit is exceeded. A stored zero limit is shown explicitly; a missing budget does not become zero.
- **Legacy unassigned budgets** remain unassigned. The unchanged domain allows them only in their original single-transaction-currency context. The report labels this case and refuses ambiguous, empty, mixed-currency, or differently selected legacy-budget evaluations. It never migrates or assigns them.
- **Zero recorded activity** does not prove that activity is complete. Source freshness, completeness, and authenticity are unknown.

The implementation calls the existing `validateLedgerData`, `validateMonth`, and `monthlySummary` functions in `src/ledger.ts`. Their validation, safe-integer arithmetic and currency rules remain authoritative.

## Snapshot and privacy boundaries

The report records the source basename, exact captured byte length, SHA-256, ledger-format version, and report generation time in UTC. A hash identifies the captured bytes; it does not certify their authenticity. The report does not refresh, and its generation time is not a transaction update time.

Transaction IDs, notes and idempotency keys are omitted. The complete source path is not embedded. Category labels, source basename, totals and budgets are present, so keep the report and any printed copies private.

Category spelling and valid Unicode are preserved as text, with markup escaped. A selected label containing NUL or an unpaired Unicode surrogate is refused because HTML cannot preserve it. An excluded note or unselected category does not become report content.

The CLI admits an existing regular file of at most 8 MiB, reads a bounded detached UTF-8 JSON snapshot, and rejects detected in-place size/time changes during that read. The native store's atomic replacement leaves an already opened snapshot intact. This is not a cross-process lock or a guarantee that a later source file still matches the report.

UTF-8 decoding is strict. Empty input, a byte-order mark, malformed JSON, invalid ledger data, unsafe totals, and a complete HTML result above 8 MiB are refused. The whole output is admitted or refused; it is never silently truncated.

A completed temporary file in the destination directory is written with requested mode `0600`, flushed, and linked exclusively to the new destination. A concurrently created destination is preserved. The temporary file is then removed. This path relies on normal local-filesystem regular-file and hard-link semantics; directory creation, filesystem ACL management, network-volume guarantees, and automatic replacement are outside its scope. If publication succeeds but temporary cleanup fails, the CLI identifies that exceptional state explicitly.

## Focused receiving

The additive Node tests exercise the new projection and actual compiled CLI, including concurrent publishers and source/destination preservation:

    npm run build
    node --test dist/test/monthly-review.test.js dist/test/monthly-review-cli.test.js

A maintained receiver can exercise the actual direct-file output in an isolated native Chromium profile. It creates only synthetic ledgers in a new evidence directory outside the source tree:

    node tools/check-monthly-review.mjs \
      --output-dir /absolute/path/to/new-receiving-dir \
      --chrome /path/to/chrome

Use `--dist /absolute/build-dir` if emitted files are elsewhere. The receiver needs Node with its built-in WebSocket API (Node 22 or newer), a preinstalled Chromium-compatible browser, and at least 128 MiB free for its own profile. The product CLI remains compatible with the project's existing Node 20 target.

Receiving covers actual CLI output, rendered totals and provenance, hostile Unicode text, empty selection without JavaScript, 390px containment and native keyboard scrolling, and a real saved browser PDF. On macOS, the system PDFKit reader independently reads the saved PDF text and page count. Original PNG captures, command outputs, file hashes and a source-bound JSON receipt are preserved; the receiver closes its browser and removes only its own temporary profile. It does not log in, read household data, invoke providers, or launch the MCP service.
