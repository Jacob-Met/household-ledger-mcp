# Household transaction filters — exact after-owner receiving packet

Repository: Jacob-Met/household-ledger-mcp; issue #6.
Native accepted parent: 07e223b5da19cea0f048219d8c85689fcc1ba83f, tree76cd2cc60b10dabdd301d32a53da4b833015193d.
Frozen production/test/docs contribution: f3aa61a5576c3cffb4c6762d5ef8aa970ec86634, treee69cd3751afae62e293a44f6300ed882fe2aa187.
Additive author evidence: 836dd14f5b1d3a0b32e9fbb5e3d22b63913ab279; complete resulting tree: ad58412f8979f84fed1b88f8f4b03e09a27b1dd0.
Branch: work/transaction-filters-20261008.

## Receive without replacing existing ownership

The six-path source delta extends only ListTransactionsFilter/listTransactions and the existing list_transactions schema/description, with two new tests, a user guide and a short README addition. The second commit adds only docs/evidence/transaction-filters-18a24bf0c281. ce7 retains source-parent integration;61749b retains canonical receiving; issue5 budget-copy and all prior owner scopes remain intact.

after-owner.patch is the exact two-commit format-patch over the accepted native parent. after-owner.bundle is incremental and requires that exact parent. complete-native.bundle is self-contained for isolated source inspection; clone it with --branch work/transaction-filters-20261008. source-manifest.json verifies every resulting path/mode/blob and SHA-256. Bundle verification outputs are retained.

Apply only the narrow patch on its matching owner input, or review its composition if the receiving source has advanced. Neither the inherited native snapshot ancestry nor a custody/artifact branch is canonical-main ancestry. Do not merge either wholesale into canonical main. The public receiving branch at d821d8ce contains the earlier accepted native packet, not a production source tree.

## Native qualification

Typecheck, build and22 focused methods pass (7new plus15 original core methods), no skips/cancellations. The same HTTP test moves from4/17 to17/17 receiving checks, with17 actual tool calls plus tools/list on each side. The same six domain cases move from1/6 to6/6. Every original source-control failure is retained. The fixture imports actual CSV through existing tools and tests real HTTP filtering, total/pagination, literal Unicode, refusal, full ledger bytes, process restart and exact recording replay. All86 source files remain exact through candidate execution.

The canonical author narrative is docs/evidence/transaction-filters-18a24bf0c281/README.md in the source bundle. It documents exact boundaries, the original optional reporter-count metadata limitation and the explicit independent-review gate. qualification.json is copied here for convenience. Independent acceptance is a separate root/runtime contribution and is not claimed in this packet.

Native source: /Users/me/household-transaction-filters-18a24bf0c281/source on Mac0e3d582f-e25b-44b2-8418-9639fc4e4e33.
No live ledger, account, endpoint, deployment, canonical source branch or other owner's state was changed.
