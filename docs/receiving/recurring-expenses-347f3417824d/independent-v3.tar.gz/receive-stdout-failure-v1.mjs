import assert from "node:assert/strict";
import {readFile,mkdir,writeFile,readdir} from "node:fs/promises";
import {openSync,closeSync} from "node:fs";
import {createHash} from "node:crypto";
import {spawnSync} from "node:child_process";
import {resolve} from "node:path";
const [oraclePath,producerCLI,outArg]=process.argv.slice(2);
if(!outArg)throw Error("Usage: node receive-stdout-failure-v1.mjs ORACLES PRODUCER_CLI NEW_OUT");
const out=resolve(outArg);await mkdir(out);
const hash=b=>createHash("sha256").update(b).digest("hex");
const oracleBytes=await readFile(oraclePath);
assert.equal(hash(oracleBytes),"860f6161c3b6ca8d07c70a25a9455abe7247bc3b701f83851ffb3afbdc033dd7");
const oracle=JSON.parse(oracleBytes),c=oracle.consumer_case;
const sentinelPath=out+"/readonly-stdout.bin",sentinel=Buffer.from("Independent stdout sentinel: keep exact bytes.\n");
await writeFile(sentinelPath,sentinel,{flag:"wx"});
const sourcePath=out+"/rules.json",outputPath=out+"/delivered-plan.json";
const rules={schema:"household-recurring-expenses/1",currency:c.currency,rules:structuredClone(c.rules)};
const rulesBytes=Buffer.from(JSON.stringify(rules,null,2)+"\n");await writeFile(sourcePath,rulesBytes,{flag:"wx"});
const cliBefore={path:producerCLI,bytes:(await readFile(producerCLI)).length,sha256:hash(await readFile(producerCLI))};
const results=[],children=[];
async function child(name,args){
 const fd=openSync(sentinelPath,"r");let p;
 try{p=spawnSync(process.execPath,["--max-old-space-size=64",...args],{cwd:out,stdio:["ignore",fd,"pipe"],encoding:"utf8",timeout:20000,maxBuffer:1024*1024});}
 finally{closeSync(fd);}
 const r={name,executable:process.execPath,args:["--max-old-space-size=64",...args],stdio:{stdin:"ignore",stdout:{path:sentinelPath,opened:"r",inheritedDescriptor:true},stderr:"captured pipe"},status:p.status,signal:p.signal,error:p.error?{name:p.error.name,message:p.error.message,code:p.error.code}:null,stderr:p.stderr??"",stdoutCapture:p.stdout===null?"not captured; inherited read-only descriptor":"unexpected capture"};
 children.push(r);await writeFile(out+"/"+name+"-child.json",JSON.stringify(r,null,2)+"\n",{flag:"wx"});
 assert.deepEqual(await readFile(sentinelPath),sentinel);
 return r;
}
async function group(name,fn){try{const detail=await fn();results.push({name,status:"pass",detail});return true;}catch(e){results.push({name,status:"fail",error:{name:e.name,message:e.message,stack:e.stack}});return false;}}
const probeCode="const fs=require('node:fs');try{fs.writeSync(1,Buffer.from('must not write'));process.stderr.write(JSON.stringify({blocked:false})+'\\n');process.exitCode=23;}catch(e){process.stderr.write(JSON.stringify({blocked:true,name:e.name,code:e.code,message:e.message})+'\\n');process.exitCode=['EBADF','EACCES','EPERM'].includes(e.code)?0:24;}";
const admitted=await group("actual read-only stdout descriptor admission",async()=>{
 const p=await child("descriptor-control",["-e",probeCode]);assert.equal(p.error,null);assert.equal(p.signal,null);assert.equal(p.status,0);
 const report=JSON.parse(p.stderr);assert.equal(report.blocked,true);assert.ok(["EBADF","EACCES","EPERM"].includes(report.code));
 return {mechanism:"Child attempted actual writeSync(1) to parent's openSync(path,'r') descriptor",observed:report,sentinelSha256:hash(sentinel)};
});
if(admitted){
 await group("receipt delivery failure preserves complete plan and exits1",async()=>{
  const beforeNames=(await readdir(out)).sort();
  const p=await child("receipt-failure",[producerCLI,"--rules",sourcePath,"--month",c.month,"--out",outputPath]);
  assert.equal(p.error,null);assert.equal(p.signal,null);assert.equal(p.status,1);
  const actual=await readFile(outputPath),plan=JSON.parse(actual);
  const expected={schema:"household-expense-plan/1",expenses:[{date:"2026-10-09",category:"food",amountMinor:250},{date:"2026-10-09",category:"food",amountMinor:250}]};
  assert.deepEqual(plan,expected);assert.deepEqual(actual,Buffer.from(JSON.stringify(plan,null,2)+"\n"));
  assert.deepEqual(await readFile(sourcePath),rulesBytes);
  const afterNames=(await readdir(out)).filter(x=>!["receipt-failure-child.json","delivered-plan.json"].includes(x)).sort();assert.deepEqual(afterNames,beforeNames);
  return {exit:p.status,completeOutputExists:true,output:{path:outputPath,bytes:actual.length,sha256:hash(actual)},sourceSha256:hash(rulesBytes),receiptNotDeliverable:"stdout is the independently proven read-only descriptor",temporaryCleanup:true};
 });
 await group("standalone help delivery failure exits1 without product output",async()=>{
  const beforeNames=(await readdir(out)).sort();
  const p=await child("help-failure",[producerCLI,"--help"]);assert.equal(p.error,null);assert.equal(p.signal,null);assert.equal(p.status,1);
  const afterNames=(await readdir(out)).filter(x=>x!=="help-failure-child.json").sort();assert.deepEqual(afterNames,beforeNames);
  assert.deepEqual(await readFile(sourcePath),rulesBytes);
  return {exit:p.status,productFilesCreated:0,stdoutBoundToSameReadOnlyDescriptor:true};
 });
}
const cliAfter={path:producerCLI,bytes:(await readFile(producerCLI)).length,sha256:hash(await readFile(producerCLI))};assert.deepEqual(cliAfter,cliBefore);
const receipt={schema:"household-recurring-independent-stdout-failure/1",at:new Date().toISOString(),platform:process.platform,node:process.version,attribution:"Narrow post-seal coverage supplement prepared before candidate exposure. Existing four-group CLI receiver remains unchanged and separate.",oracleSha256:hash(oracleBytes),cliBefore,cliAfter,descriptorAdmitted:admitted,results,passed:results.filter(x=>x.status==="pass").length,total:results.length,expectedTotal:3,children:children.map(({stderr,...r})=>({...r,stderrBytes:Buffer.byteLength(stderr),stderrSha256:hash(stderr)})),sentinel:{path:sentinelPath,bytes:sentinel.length,sha256:hash(await readFile(sentinelPath))}};
await writeFile(out+"/receipt.json",JSON.stringify(receipt,null,2)+"\n",{flag:"wx"});console.log(JSON.stringify(receipt));process.exitCode=receipt.passed===3?0:1;
