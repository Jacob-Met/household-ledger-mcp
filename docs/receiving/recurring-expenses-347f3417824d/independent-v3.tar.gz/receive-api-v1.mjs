import assert from "node:assert/strict";
import {readFile,mkdir,writeFile} from "node:fs/promises";
import {createHash} from "node:crypto";
import {pathToFileURL} from "node:url";
const [oraclePath,producerPath,consumerPath,out]=process.argv.slice(2);
if(!out)throw Error("Usage: node receive-api-v1.mjs ORACLES PRODUCER_MODULE CONSUMER_MODULE NEW_OUT");
await mkdir(out);
const bytes=await readFile(oraclePath),hash=b=>createHash("sha256").update(b).digest("hex");
assert.equal(hash(bytes),"860f6161c3b6ca8d07c70a25a9455abe7247bc3b701f83851ffb3afbdc033dd7");
const oracle=JSON.parse(bytes);
const sourceBefore={producer:hash(await readFile(producerPath)),consumer:hash(await readFile(consumerPath))};
const {generateRecurringExpensePlan:generate}=await import(pathToFileURL(producerPath));
const {previewExpensePlan:preview}=await import(pathToFileURL(consumerPath));
assert.equal(typeof generate,"function");
const results=[];
const monthly=(every=1,missingDay="last")=>({unit:"month",every,missingDay});
const rule=(id="r",extra={})=>({id,start:"2026-10-09",category:"food",amountMinor:100,repeat:monthly(),...extra});
const input=(rules=[],currency="USD")=>({schema:"household-recurring-expenses/1",currency,rules});
function deepFrozen(v,seen=new Set()){if(v&&typeof v==="object"){assert.ok(Object.isFrozen(v));if(!seen.has(v)){seen.add(v);for(const x of Object.values(v))deepFrozen(x,seen);}}}
function keys(v,k){assert.deepEqual(Object.keys(v).sort(),k.slice().sort());}
function check(value,source,month){
 keys(value,oracle.public_contract.resultKeys);assert.equal(value.month,month);assert.equal(value.currency,source.currency.trim().toUpperCase());
 keys(value.plan,["schema","expenses"]);assert.equal(value.plan.schema,"household-expense-plan/1");
 assert.equal(value.occurrences.length,value.plan.expenses.length);deepFrozen(value);
 for(let i=0;i<value.occurrences.length;i++){const row=value.occurrences[i];keys(row,oracle.public_contract.occurrenceKeys);assert.equal(row.position,i+1);assert.equal(row.date,value.plan.expenses[i].date);assert.equal(row.ruleId,source.rules[row.rulePosition-1].id);}
 for(const row of value.skipped){keys(row,oracle.public_contract.skippedKeys);assert.equal(row.reason,"missing-day");assert.equal(row.month,month);assert.equal(row.ruleId,source.rules[row.rulePosition-1].id);assert.equal(Object.hasOwn(row,"date"),false);}
 return value;
}
function call(source,month="2026-10"){const before=structuredClone(source);const result=generate(source,month);assert.deepEqual(source,before);return check(result,source,month);}
async function group(name,fn){try{const detail=await fn();results.push({name,status:"pass",detail});}catch(e){results.push({name,status:"fail",error:{name:e.name,message:e.message,stack:e.stack}});}}
await group("sealed analytical calendar and ordering cases",()=>{
 const cases=[];
 for(const [index,c] of oracle.calendar_cases.entries()){
  const source=input(structuredClone(c.rules));const r=call(source,c.month);
  const expected=c.dates.flatMap((dates,i)=>dates.map(date=>({date,index:i}))).sort((a,b)=>a.date.localeCompare(b.date)||a.index-b.index);
  assert.deepEqual(r.plan.expenses,expected.map(({date,index:i})=>({date,category:c.rules[i].category.trim(),amountMinor:c.rules[i].amountMinor,...(Object.hasOwn(c.rules[i],"note")?{note:c.rules[i].note}:{})})));
  assert.deepEqual(r.occurrences,expected.map(({date,index:i},position)=>({position:position+1,ruleId:c.rules[i].id,rulePosition:i+1,date})));
  assert.deepEqual(r.skipped,c.skips??[]);assert.equal(r.plan.expenses.reduce((a,b)=>a+b.amountMinor,0),c.total);
  if(c.expectedRuleOrder)assert.deepEqual(r.occurrences.map(x=>x.ruleId),c.expectedRuleOrder);
  cases.push({index,group:c.group,month:c.month,count:r.occurrences.length,skips:r.skipped});
 }
 return cases;
});
await group("safe integer precision and native aggregate boundary",()=>{
 for(const c of oracle.precision_cases){const source=input(c.amounts.map((amountMinor,i)=>rule("r"+i,{amountMinor})));
  if(!c.accepted)assert.throws(()=>generate(source,"2026-10"));
  else {const r=call(source);assert.equal(preview({version:1,transactions:[],budgets:[]},r.plan,r.month,r.currency).plannedExpenseMinor,c.total);}}
 return oracle.precision_cases;
});
await group("100 rules and500 occurrences preserve exact deterministic order",()=>{
 const c=oracle.count_case;const source=input(Array.from({length:100},(_,i)=>rule("r"+i,{start:c.start,amountMinor:1,repeat:c.repeat})));
 const r=call(source,c.month);assert.equal(r.occurrences.length,500);
 assert.deepEqual(r.plan.expenses.map(x=>x.date),c.dates.flatMap(d=>Array(100).fill(d)));
 assert.deepEqual(r.occurrences.map(x=>x.rulePosition),c.dates.flatMap(()=>Array.from({length:100},(_,i)=>i+1)));
 assert.throws(()=>generate(input([...source.rules,rule("extra")]),c.month));
 return {count:r.occurrences.length,total:r.plan.expenses.reduce((a,b)=>a+b.amountMinor,0)};
});
await group("literal notes, absent notes, native normalization and detached results",()=>{
 const note="CR\rCRLF\r\nNUL"+String.fromCharCode(0)+" surrogate"+String.fromCharCode(0xd800);
 const source=input([rule("A",{category:" food "}),rule("a",{category:" food ",note:""}),rule("001",{category:" food ",note}),rule("e"+String.fromCharCode(0x301)),rule(String.fromCharCode(0xe9))]," usd ");
 const r=call(source);assert.equal(r.currency,"USD");assert.equal(Object.hasOwn(r.plan.expenses[0],"note"),false);
 assert.equal(r.plan.expenses[1].note,"");assert.equal(r.plan.expenses[2].note,note);assert.equal(r.plan.expenses[2].category,"food");
 assert.deepEqual(r.occurrences.map(x=>x.ruleId),source.rules.map(x=>x.id));
 const saved=JSON.stringify(r);source.rules[0].amountMinor=999;assert.equal(JSON.stringify(r),saved);
 return {literalNoteJSON:JSON.stringify(note),rules:r.occurrences.map(x=>x.ruleId)};
});
await group("duplicate identity, codepoint and wellformed ID boundaries",()=>{
 const emoji=String.fromCodePoint(0x1f642);call(input([rule(emoji.repeat(128))]));
 const invalid=[""," bad","bad ","x".repeat(129),emoji.repeat(129),"a"+String.fromCharCode(0),"a"+String.fromCharCode(31),"a"+String.fromCharCode(127),String.fromCharCode(0xd800)];
 for(const id of invalid)assert.throws(()=>generate(input([rule(id)]),"2026-10"));
 assert.throws(()=>generate(input([rule("same"),rule("same")]),"2026-10"));
 return {boundaryCodepoints:128,rejected:invalid.length+1};
});
await group("strict root, rule and repeat field admission",()=>{
 const roots=[null,[],{},input(),{...input(),extra:1}];roots.splice(3,1);
 for(const x of roots)assert.throws(()=>generate(x,"2026-10"));
 for(const key of ["id","start","category","amountMinor","repeat"]){const r=rule();delete r[key];assert.throws(()=>generate(input([r]),"2026-10"));}
 for(const r of [rule("r",{extra:1}),rule("r",{repeat:{...monthly(),extra:1}}),rule("r",{repeat:{unit:"week",every:1,missingDay:"skip"}}),rule("r",{repeat:{unit:"month",every:1}}),rule("r",{repeat:monthly(1,"nearest")})])assert.throws(()=>generate(input([r]),"2026-10"));
 return {strictFields:true};
});
await group("all inactive rules still receive native field validation",()=>{
 for(const patch of [{category:" "},{amountMinor:0},{amountMinor:-0},{amountMinor:NaN},{amountMinor:1.5},{amountMinor:true},{amountMinor:Infinity},{amountMinor:9007199254740992},{note:null}]){
  const source=input([rule("inactive",{start:"2000-01-01",end:"2000-01-01",...patch})]);
  const before=structuredClone(source);assert.throws(()=>generate(source,"2026-10"));assert.deepEqual(source,before);
 }
 assert.throws(()=>generate(input([],"US"),"2026-10"));call(input([],"xxx"));
 return {inactiveFieldsRefused:9,emptyCurrencyValidated:true};
});
await group("date, inclusive active range and recurrence period refusals",()=>{
 for(const start of ["1969-12-31","2025-02-29","2100-02-29","2026-04-31","2026-1-01","10000-01-01"])assert.throws(()=>generate(input([rule("r",{start})]),"2026-10"));
 assert.throws(()=>generate(input([rule("r",{end:"2026-10-08"})]),"2026-10"));
 for(const month of ["1969-12","10000-01","2026-13","2026-1",null])assert.throws(()=>generate(input(),month));
 for(const every of [0,53,1.5,true])assert.throws(()=>generate(input([rule("r",{repeat:{unit:"week",every}})]),"2026-10"));
 for(const every of [0,121,1.5,true])assert.throws(()=>generate(input([rule("r",{repeat:{unit:"month",every,missingDay:"last"}})]),"2026-10"));
 return {dateAndPeriodRefusals:true};
});
await group("source versus complete output byte limits",()=>{
 const max=1048576;
 const source=input([rule("inactive",{start:"2000-01-01",end:"2000-01-01",note:""})]);
 const overhead=Buffer.byteLength(JSON.stringify(source));source.rules[0].note="x".repeat(max-overhead);
 assert.equal(Buffer.byteLength(JSON.stringify(source)),max);call(source);
 source.rules[0].note+="x";assert.throws(()=>generate(source,"2026-10"));
 const amplified=input(Array.from({length:100},(_,i)=>rule("r"+i,{start:"2026-05-01",amountMinor:1,note:"x".repeat(2100),repeat:{unit:"week",every:1}})));
 assert.ok(Buffer.byteLength(JSON.stringify(amplified))<max);assert.throws(()=>generate(amplified,"2026-05"));
 return {sourceExactBytes:max,oversizeSourceRefused:true,wholeOutputRefused:true};
});
await group("real unchanged consumer accepts generated plan without ledger mutation",()=>{
 const c=oracle.consumer_case,source=input(structuredClone(c.rules)),r=call(source,c.month);
 const ledger=structuredClone(c.ledger),before=structuredClone(ledger);
 const p=preview(ledger,r.plan,r.month,r.currency),e=c.expected;
 assert.equal(p.expenses.length,e.occurrences);assert.equal(p.plannedExpenseMinor,e.plannedExpenseMinor);
 assert.equal(p.recorded.expenseMinor,e.recordedExpenseMinor);assert.equal(p.hypothetical.expenseMinor,e.hypotheticalExpenseMinor);
 assert.equal(p.recorded.netMinor,e.recordedNetMinor);assert.equal(p.hypothetical.netMinor,e.hypotheticalNetMinor);
 assert.equal(p.budgets[0].recordedRemainingMinor,400);assert.equal(p.budgets[0].hypotheticalRemainingMinor,-100);
 assert.equal(p.budgets[0].recordedOver,false);assert.equal(p.budgets[0].hypotheticalOver,true);assert.deepEqual(ledger,before);
 return p;
});
const sourceAfter={producer:hash(await readFile(producerPath)),consumer:hash(await readFile(consumerPath))};assert.deepEqual(sourceAfter,sourceBefore);
const receipt={schema:"household-recurring-independent-api/1",at:new Date().toISOString(),node:process.version,oracleSha256:hash(bytes),sourceBefore,sourceAfter,results,passed:results.filter(x=>x.status==="pass").length,total:results.length};
await writeFile(out+"/receipt.json",JSON.stringify(receipt,null,2)+"\n",{flag:"wx"});
console.log(JSON.stringify(receipt));process.exitCode=receipt.passed===receipt.total?0:1;
