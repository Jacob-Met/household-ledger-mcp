# Independent recurring-expense receiving

This package preserves the independent oracle and executable inputs, a portable summary of actual receiving, synthetic physical files, and the exact compiled modules used on macOS with Node 26.3.0. Packaging did not execute tests or change production source.

The original unchanged expense-plan consumer passed 3/3 controls before the producer was implemented. The final v2 producer then passed the unchanged API receiver (10/10 groups, including 21 analytical calendar cases), physical CLI receiver (4/4), and the separately sealed stdout-failure supplement (3/3: one actual descriptor control and two product failure cases). Each receiving process exited 0. Expected failing product children exited 1 or 2 as specified. The read-only descriptor control observed EBADF; a receipt failure left a complete plan and returned 1, and unavailable help output returned 1.

The oracle and original/API/CLI executables were sealed before candidate access. The preserved CLI-v1 predecessor was never executed. CLI-v2 made a pre-exposure serialization check correction; its historical correction record is retained verbatim. The subsequently supplied canonical contract also fixes object construction order, an author choice beyond the original consumer format. No receiver was changed after its actual run.

Author v1 was not subjected to the independent matrix. Post-freeze input boundaries identified during author, root and independent source review were probed and corrected by the author; package-context qualification was also completed before independent v2 execution. The original 3/3 controls were not repeated. Native source and compiled module identities are recorded in qualification.json; all three inherited compiled modules match the original donor. The runtime package is copied unchanged and declares type=module.

Raw execution, stream, and source-custody receipts remain in private custody. Their exact byte counts and SHA-256 hashes are listed in qualification.json. This public summary is a derived projection, not a replacement or purported byte-for-byte copy of those receipts. No native absolute paths, hostnames, device IDs or account identifiers are included. The source reviewer’s complete inherited-tree proof is a separate gate.

## Replay

No package installation is needed for these compiled modules. From this extracted directory, use Node 26.3.0 and new, absent output directories. These commands are instructions; package creation did not run them:

```sh
node --max-old-space-size=64 receive-original-v1.mjs oracles-v1.json "$PWD/runtime/src/expense-plan.js" replay-original
node --max-old-space-size=64 receive-api-v1.mjs oracles-v1.json "$PWD/runtime/src/recurring-expenses.js" "$PWD/runtime/src/expense-plan.js" replay-api
node --max-old-space-size=64 receive-cli-v2.mjs oracles-v1.json "$PWD/runtime/src/household-recurring-plan.js" "$PWD/runtime/src/household-plan.js" replay-cli
node --max-old-space-size=64 receive-stdout-failure-v1.mjs oracles-v1.json "$PWD/runtime/src/household-recurring-plan.js" replay-stdout
```

The stdout supplement first verifies that an actual child cannot write to the inherited read-only descriptor before testing product delivery. Other operating systems have not been received by this packet. Replays may contain new local paths in their own receipts.

The explicit generated plan intentionally has no currency field. Downstream use must supply the same currency from the producer receipt. The accepted native witness used USD and month 2026-10. Synthetic example files preserve BOM/CRLF, literal note values, duplicate occurrences and complete delivered plan bytes. No real ledger, provider, persistent Store or bank data was used or changed.

manifest.json hashes every payload member other than itself. The deterministic archive contains regular files only, with normalized tar metadata and gzip time zero. Publication, merge, hosted checks and product adoption are not asserted by this independent native packet.
