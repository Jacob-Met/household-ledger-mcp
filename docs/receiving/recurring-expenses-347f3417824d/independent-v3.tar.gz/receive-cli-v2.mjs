import assert from "node:assert/strict";
import {readFile,mkdir,writeFile,access,readdir} from "node:fs/promises";
import {createHash} from "node:crypto";
import {spawnSync} from "node:child_process";
import {resolve} from "node:path";
const [oraclePath,producerCLI,consumerCLI,outArg]=process.argv.slice(2);
if(!outArg)throw Error("Usage: node receive-cli-v1.mjs ORACLES PRODUCER_CLI CONSUMER_CLI NEW_OUT");
const out=resolve(outArg);await mkdir(out);
const hash=b=>createHash("sha256").update(b).digest("hex"),obytes=await readFile(oraclePath);
assert.equal(hash(obytes),"860f6161c3b6ca8d07c70a25a9455abe7247bc3b701f83851ffb3afbdc033dd7");
const oracle=JSON.parse(obytes),c=oracle.consumer_case;
const paths={rules:out+"/rules.json",ledger:out+"/ledger.json",plan:out+"/plan.json",report:out+"/consumer.html"};
const literal="CR\rCRLF\r\nNUL"+String.fromCharCode(0)+" surrogate"+String.fromCharCode(0xd800);
const rules={schema:"household-recurring-expenses/1",currency:" usd ",rules:structuredClone(c.rules)};
rules.rules[0].category=" food ";rules.rules[0].note=literal;
const rulesBytes=Buffer.concat([Buffer.from([0xef,0xbb,0xbf]),Buffer.from(JSON.stringify(rules,null,2).replace(/\n/g,"\r\n")+"\r\n")]);
const ledgerBytes=Buffer.from(JSON.stringify(c.ledger,null,2)+"\n");
await writeFile(paths.rules,rulesBytes,{flag:"wx"});await writeFile(paths.ledger,ledgerBytes,{flag:"wx"});
const moduleBefore={producerCLI:hash(await readFile(producerCLI)),consumerCLI:hash(await readFile(consumerCLI))};
const children=[],results=[];
async function child(name,module,args){
 const p=spawnSync(process.execPath,[module,...args],{cwd:out,encoding:"utf8",timeout:20000,maxBuffer:2*1024*1024});
 const row={name,executable:process.execPath,args:[module,...args],status:p.status,signal:p.signal,error:p.error?{name:p.error.name,message:p.error.message,code:p.error.code}:null,stdout:p.stdout??"",stderr:p.stderr??""};
 children.push(row);await writeFile(out+"/"+name+"-child.json",JSON.stringify(row,null,2)+"\n",{flag:"wx"});
 return row;
}
async function group(name,fn){try{const detail=await fn();results.push({name,status:"pass",detail});}catch(e){results.push({name,status:"fail",error:{name:e.name,message:e.message,stack:e.stack}});}}
await group("physical recurring JSON to exact explicit plan and native receipt",async()=>{
 const p=await child("producer",producerCLI,["--rules",paths.rules,"--month",c.month,"--out",paths.plan]);
 assert.equal(p.status,0);assert.equal(p.signal,null);assert.equal(p.error,null);
 const receipt=JSON.parse(p.stdout);assert.equal(p.stdout,JSON.stringify(receipt)+"\n");
 assert.deepEqual(Object.keys(receipt).sort(),["schema","month","currency","source","output","occurrences","skipped"].sort());
 assert.equal(receipt.schema,"household-recurring-expense-plan-delivery/1");assert.equal(receipt.month,c.month);assert.equal(receipt.currency,"USD");
 const expected={schema:"household-expense-plan/1",expenses:[{date:"2026-10-09",category:"food",amountMinor:250,note:literal},{date:"2026-10-09",category:"food",amountMinor:250}]};
 const actual=await readFile(paths.plan),parsed=JSON.parse(actual);assert.deepEqual(parsed,expected);assert.deepEqual(actual,Buffer.from(JSON.stringify(parsed,null,2)+"\n"));
 assert.deepEqual(receipt.source,{path:paths.rules,bytes:rulesBytes.length,sha256:hash(rulesBytes)});
 assert.deepEqual(receipt.output,{path:paths.plan,bytes:actual.length,sha256:hash(actual)});
 assert.deepEqual(receipt.occurrences,[{position:1,ruleId:"one",rulePosition:1,date:"2026-10-09"},{position:2,ruleId:"two",rulePosition:2,date:"2026-10-09"}]);
 assert.deepEqual(receipt.skipped,[]);
 assert.deepEqual(await readFile(paths.rules),rulesBytes);assert.deepEqual(await readFile(paths.ledger),ledgerBytes);
 return receipt;
});
await group("actual unchanged consumer CLI receives physical plan without recording",async()=>{
 const planBefore=await readFile(paths.plan);
 const p=await child("consumer",consumerCLI,["--ledger",paths.ledger,"--plan",paths.plan,"--month",c.month,"--currency","USD","--out",paths.report]);
 assert.equal(p.status,0);assert.equal(p.signal,null);assert.equal(p.error,null);
 const html=await readFile(paths.report,"utf8");const match=html.match(/<script type="application\/json" id="expense-plan-data">([\s\S]*?)<\/script>/);
 assert.ok(match,"Missing native inert inspection record");const actual=JSON.parse(match[1]),e=c.expected;
 assert.equal(actual.expenses.length,2);assert.equal(actual.expenses[0].note,literal);assert.equal(Object.hasOwn(actual.expenses[1],"note"),false);
 assert.equal(actual.plannedExpenseMinor,e.plannedExpenseMinor);assert.equal(actual.recorded.expenseMinor,e.recordedExpenseMinor);
 assert.equal(actual.hypothetical.expenseMinor,e.hypotheticalExpenseMinor);assert.equal(actual.recorded.netMinor,e.recordedNetMinor);assert.equal(actual.hypothetical.netMinor,e.hypotheticalNetMinor);
 assert.equal(actual.budgets[0].recordedRemainingMinor,400);assert.equal(actual.budgets[0].hypotheticalRemainingMinor,-100);assert.equal(actual.budgets[0].hypotheticalOver,true);
 assert.deepEqual(actual.provenance.plan,{path:paths.plan,bytes:planBefore.length,sha256:hash(planBefore)});
 assert.deepEqual(await readFile(paths.ledger),ledgerBytes);assert.deepEqual(await readFile(paths.rules),rulesBytes);assert.deepEqual(await readFile(paths.plan),planBefore);
 return {htmlBytes:Buffer.byteLength(html),htmlSha256:hash(html),inspection:actual};
});
await group("existing destination remains exact and receipt is refused",async()=>{
 const before=await readFile(paths.plan),namesBefore=(await readdir(out)).sort();
 const p=await child("existing-output",producerCLI,["--rules",paths.rules,"--month",c.month,"--out",paths.plan]);
 assert.equal(p.status,1);assert.equal(p.stdout,"");assert.deepEqual(await readFile(paths.plan),before);
 const namesAfter=(await readdir(out)).filter(x=>x!=="existing-output-child.json").sort();assert.deepEqual(namesAfter,namesBefore);
 return {exit:p.status,planSha256:hash(before),temporaryCleanup:true};
});
await group("invalid inactive rule refuses complete delivery",async()=>{
 const bad=structuredClone(rules);bad.rules[0].start="2000-01-01";bad.rules[0].end="2000-01-01";bad.rules[0].amountMinor=0;
 const source=out+"/invalid-rules.json",destination=out+"/invalid-plan.json";const data=Buffer.from(JSON.stringify(bad)+"\n");await writeFile(source,data,{flag:"wx"});
 const p=await child("invalid-inactive",producerCLI,["--rules",source,"--month",c.month,"--out",destination]);
 assert.equal(p.status,2);assert.equal(p.stdout,"");await assert.rejects(access(destination),{code:"ENOENT"});assert.deepEqual(await readFile(source),data);
 return {exit:p.status,noOutput:true,sourceSha256:hash(data)};
});
const moduleAfter={producerCLI:hash(await readFile(producerCLI)),consumerCLI:hash(await readFile(consumerCLI))};assert.deepEqual(moduleAfter,moduleBefore);
const receipt={schema:"household-recurring-independent-cli/1",at:new Date().toISOString(),node:process.version,oracleSha256:hash(obytes),moduleBefore,moduleAfter,children:children.map(({stdout,stderr,...r})=>({...r,stdoutBytes:Buffer.byteLength(stdout),stdoutSha256:hash(stdout),stderrBytes:Buffer.byteLength(stderr),stderrSha256:hash(stderr)})),results,passed:results.filter(x=>x.status==="pass").length,total:results.length};
await writeFile(out+"/receipt.json",JSON.stringify(receipt,null,2)+"\n",{flag:"wx"});console.log(JSON.stringify(receipt));process.exitCode=receipt.passed===receipt.total?0:1;
