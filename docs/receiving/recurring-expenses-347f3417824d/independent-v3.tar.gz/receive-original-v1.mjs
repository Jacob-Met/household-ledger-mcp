import assert from "node:assert/strict";
import {readFile,mkdir,writeFile} from "node:fs/promises";
import {createHash} from "node:crypto";
import {pathToFileURL} from "node:url";
const [oraclePath,consumerPath,out]=process.argv.slice(2);
if(!out) throw Error("Usage: node receive-original-v1.mjs ORACLES CONSUMER_MODULE NEW_OUT");
await mkdir(out);
const bytes=await readFile(oraclePath);
assert.equal(createHash("sha256").update(bytes).digest("hex"),"860f6161c3b6ca8d07c70a25a9455abe7247bc3b701f83851ffb3afbdc033dd7");
const oracle=JSON.parse(bytes);
const consumer=await import(pathToFileURL(consumerPath));
const c=oracle.consumer_case;
const plan={schema:"household-expense-plan/1",expenses:c.rules.map(r=>({date:r.start,category:r.category,amountMinor:r.amountMinor}))};
const ledger=structuredClone(c.ledger), before=structuredClone(ledger);
const results=[];
async function group(name,fn){try{const detail=await fn();results.push({name,status:"pass",detail});}catch(e){results.push({name,status:"fail",error:{name:e.name,message:e.message,stack:e.stack}});}}
await group("unchanged explicit-plan consumer",()=>{
 const p=consumer.previewExpensePlan(ledger,plan,c.month,c.currency),e=c.expected;
 assert.equal(p.expenses.length,e.occurrences);assert.equal(p.plannedExpenseMinor,e.plannedExpenseMinor);
 assert.equal(p.recorded.expenseMinor,e.recordedExpenseMinor);assert.equal(p.hypothetical.expenseMinor,e.hypotheticalExpenseMinor);
 assert.equal(p.recorded.netMinor,e.recordedNetMinor);assert.equal(p.hypothetical.netMinor,e.hypotheticalNetMinor);
 assert.equal(p.budgets[0].recordedRemainingMinor,e.budgetRecordedRemainingMinor);
 assert.equal(p.budgets[0].hypotheticalRemainingMinor,e.budgetHypotheticalRemainingMinor);
 assert.equal(p.budgets[0].recordedOver,false);assert.equal(p.budgets[0].hypotheticalOver,true);
 assert.deepEqual(ledger,before);return p;
});
await group("original missing-feature witness",()=>{
 const rules={schema:"household-recurring-expenses/1",currency:c.currency,rules:c.rules};
 let error;try{consumer.previewExpensePlan(ledger,rules,c.month,c.currency);}catch(e){error=e;}
 assert.ok(error,"Original expense-plan consumer unexpectedly accepted recurring rules directly");
 assert.deepEqual(ledger,before);
 return {refused:true,name:error.name,message:error.message,interpretation:"Original consumer requires explicit dated plan; no producer implementation tested."};
});
await group("original duplicate and unsafe-total admission",()=>{
 const good=consumer.previewExpensePlan(ledger,plan,c.month,c.currency);
 assert.equal(good.expenses.length,2);assert.equal(good.plannedExpenseMinor,500);
 const unsafe={schema:"household-expense-plan/1",expenses:[9007199254740991,1].map(amountMinor=>({date:"2026-10-09",category:"food",amountMinor}))};
 assert.throws(()=>consumer.previewExpensePlan({version:1,transactions:[],budgets:[]},unsafe,c.month,c.currency));
 assert.deepEqual(ledger,before);return {duplicateCount:2,overflowRefused:true};
});
const receipt={schema:"household-recurring-original-controls/1",at:new Date().toISOString(),node:process.version,consumerPath,consumerSha256:createHash("sha256").update(await readFile(consumerPath)).digest("hex"),oracleSha256:createHash("sha256").update(bytes).digest("hex"),results,passed:results.filter(x=>x.status==="pass").length,total:results.length};
await writeFile(out+"/receipt.json",JSON.stringify(receipt,null,2)+"\n",{flag:"wx"});
console.log(JSON.stringify(receipt));process.exitCode=receipt.passed===receipt.total?0:1;
