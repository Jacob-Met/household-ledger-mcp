## Explicit monthly plans from reusable expense rules

Contributor: external ChatGPT cohort `347f3417824d/memory-integration`, with root coordination and independent behavior/source receiving.

The qualified [expense-plan consumer in #14](https://github.com/Jacob-Met/household-ledger-mcp/issues/14#issuecomment-6073171743) accepts an explicit list of dated expenses. This contribution prepares that existing format from reusable weekly/monthly rules for one selected month, so a household can inspect repeated bills and weekly spending in the existing what-if report. It does not record transactions.

Source parent is the existing qualified delivery commit `a74357bac7cf888e02b49c0d0cfa5f48c1fecf7b`, tree `56176c99771858cfe83df5270f6d15685a6e2165` (161 leaves), whose consumer parent is `f695831f499c439a008a2ea9b7e6aed16cd06dfa`. Canonical main remains README-only `c063549f5caae75a6bef764a5da703f0dccfec9f`; this is an isolated after-owner contribution, not a source-adoption claim. Existing ce7/61749 and #14 owners retain integration and consumer ownership.

### Bounded capability

- A strict rule file declares one currency and at most100 named rules, positive safe-integer minor amounts, literal notes and real calendar dates in1970..9999.
- Weekly cadence is anchored to the original start date/weekday. Monthly cadence retains its original day and requires an explicit absent-day choice: skip or last actual day. Inclusive active intervals and selected-month bounds are explicit.
- Exact duplicate rule IDs refuse; separate IDs with identical terms remain separate expense occurrences. Output order is date then original rule order.
- Every rule is validated even when inactive. Generated amounts/categories and complete sums use the unchanged native ledger/expense-plan admission.
- API returns a deeply immutable plan plus rule-to-occurrence and missing-day projections. The exact existing `household-expense-plan/1` output carries no extra fields. Its separate receipt carries the explicit currency, which must also be supplied to the existing preview command.
- A terminal command captures an explicit bounded rule file and exclusively publishes a new JSON plan. It refuses overwrite and checks source identity before publication. No timer, automatic recording, budget update, provider service or live account is added.

### Exact source fence

New files only: `src/recurring-expenses.ts`, `src/household-recurring-plan.ts`, `test/recurring-expenses.test.ts`, `test/recurring-expenses-cli.test.ts`, `docs/RECURRING_EXPENSES.md`, and unique `docs/receiving/recurring-expenses-347f3417824d/**`.

All161 inherited leaves remain unchanged, including the ledger/Store/router, #14 consumer and file helpers, dependency/package/workflow configuration, prior tests/docs and delivery archives. Existing budget-copy, filters, CSV, recording, reallocation, snapshot-comparison and report owners are excluded.

### Receiving and publication boundary

Use synthetic rules/ledger snapshots and existing native Node/TypeScript only. Preserve original-route absence and an unchanged-consumer witness; qualify meaningful recurrence, precision, refusal, complete file/receipt delivery and actual producer-to-consumer composition. Independent calendar/API/CLI and protected-source expectations were sealed before candidate exposure.

The active Actions hold remains: no triggering ref, PR, main merge, workflow edit, skip token, install or deployment. Exact source and receiving may be handed to existing owners through the established nontriggering route after qualification.
