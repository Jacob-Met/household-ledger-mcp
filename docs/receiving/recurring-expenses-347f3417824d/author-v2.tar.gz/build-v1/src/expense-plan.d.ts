import type { MonthlySummary } from "./ledger.js";
export declare const MAX_LEDGER_BYTES: number;
export declare const MAX_PLAN_BYTES: number;
export declare const MAX_EXPENSES = 500;
export declare const MAX_CATEGORIES = 5000;
export declare const MAX_REPORT_BYTES: number;
export interface PlannedExpense {
    position: number;
    date: string;
    category: string;
    amountMinor: number;
    currency: string;
    note?: string;
}
export interface CategoryComparison {
    category: string;
    recordedIncomeMinor: number;
    recordedExpenseMinor: number;
    plannedExpenseMinor: number;
    hypotheticalIncomeMinor: number;
    hypotheticalExpenseMinor: number;
    budgetCount: number;
}
export interface BudgetComparison {
    position: number;
    category: string;
    currency?: string;
    limitMinor: number;
    recordedSpentMinor: number;
    recordedRemainingMinor: number;
    recordedOver: boolean;
    hypotheticalSpentMinor: number;
    hypotheticalRemainingMinor: number;
    hypotheticalOver: boolean;
}
export interface ExpensePlanPreview {
    schema: "household-expense-plan-preview/1";
    month: string;
    currency: string;
    expenses: PlannedExpense[];
    plannedExpenseMinor: number;
    recorded: MonthlySummary;
    hypothetical: MonthlySummary;
    categories: CategoryComparison[];
    budgets: BudgetComparison[];
}
export interface SnapshotIdentity {
    path: string;
    bytes: number;
    sha256: string;
}
export interface ReportIdentity {
    ledger: SnapshotIdentity;
    plan: SnapshotIdentity;
    generatedAt: string;
}
export declare function parseSnapshot(bytes: Uint8Array, maximum: number, label: string): unknown;
export declare function identifySnapshot(path: string, bytes: Uint8Array): SnapshotIdentity;
export declare function previewExpensePlan(ledger: unknown, input: unknown, month: unknown, currency: unknown): ExpensePlanPreview;
export declare function renderExpensePlan(preview: ExpensePlanPreview, identity: ReportIdentity): string;
