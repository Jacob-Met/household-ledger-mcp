interface Stamp {
    dev: string;
    ino: string;
    size: string;
    mtimeNs: string;
    ctimeNs: string;
}
export interface CapturedInput {
    path: string;
    bytes: Buffer;
    stamp: Stamp;
    maximum: number;
    label: string;
}
export declare function captureInput(path: string, maximum: number, label: string): Promise<CapturedInput>;
export declare function checkCapturedInputs(inputs: CapturedInput[]): Promise<void>;
export declare function publishNewReport(path: string, html: string, inputs: CapturedInput[]): Promise<void>;
export declare function main(argv?: string[]): Promise<number>;
export {};
