export declare const MAX_RULES = 100;
export declare const MAX_RULE_BYTES: number;
export interface GeneratedExpense {
    readonly date: string;
    readonly category: string;
    readonly amountMinor: number;
    readonly note?: string;
}
export interface RecurringExpensePlan {
    readonly month: string;
    readonly currency: string;
    readonly plan: {
        readonly schema: "household-expense-plan/1";
        readonly expenses: readonly GeneratedExpense[];
    };
    readonly occurrences: readonly {
        readonly position: number;
        readonly ruleId: string;
        readonly rulePosition: number;
        readonly date: string;
    }[];
    readonly skipped: readonly {
        readonly ruleId: string;
        readonly rulePosition: number;
        readonly month: string;
        readonly requestedDay: number;
        readonly reason: "missing-day";
    }[];
}
export declare function generateRecurringExpensePlan(input: unknown, selectedMonth: unknown): RecurringExpensePlan;
