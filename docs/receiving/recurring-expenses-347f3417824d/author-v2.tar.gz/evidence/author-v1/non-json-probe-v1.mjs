import { pathToFileURL } from "node:url";
const root = process.argv[2];
const { generateRecurringExpensePlan: generate } = await import(pathToFileURL(root + "/build-v1/src/recurring-expenses.js"));
const { ValidationError } = await import(pathToFileURL(root + "/build-v1/src/ledger.js"));
const rule = () => ({ id:"a",start:"2026-01-01",category:"Food",amountMinor:100,repeat:{unit:"month",every:1,missingDay:"last"} });
const input = () => ({ schema:"household-recurring-expenses/1",currency:"USD",rules:[rule()] });
const cases = [
 ["month-bigint",() => [input(),202610n]],
 ["start-bigint",() => {const x=input();x.rules[0].start=20260101n;return[x,"2026-10"];}],
 ["end-bigint",() => {const x=input();x.rules[0].end=20261001n;return[x,"2026-10"];}],
 ["amount-bigint",() => {const x=input();x.rules[0].amountMinor=100n;return[x,"2026-10"];}],
 ["array-toJSON",() => {const x=input();x.rules.toJSON=()=>[];return[x,"2026-10"];}],
 ["array-iterator",() => {const x=input();x.rules[Symbol.iterator]=function*(){yield {...rule(),amountMinor:7};};return[x,"2026-10"];}],
 ["array-prototype",() => {const x=input();Object.setPrototypeOf(x.rules,Object.create(Array.prototype));return[x,"2026-10"];}],
 ["array-accessor",() => {const x=input();Object.defineProperty(x.rules,"0",{enumerable:true,configurable:true,get:rule});return[x,"2026-10"];}],
 ["amount-symbol-control",() => {const x=input();x.rules[0].amountMinor=Symbol("bad");return[x,"2026-10"];}],
 ["end-undefined-control",() => {const x=input();x.rules[0].end=undefined;return[x,"2026-10"];}],
 ["note-undefined-control",() => {const x=input();x.rules[0].note=undefined;return[x,"2026-10"];}],
];
const results=cases.map(([name,make])=>{
 try { const [x,m]=make();const result=generate(x,m);return{name,validationError:false,returned:true,amount:result.plan.expenses[0]?.amountMinor}; }
 catch(e){return{name,validationError:e instanceof ValidationError,returned:false,errorClass:e.constructor.name,message:e.message};}
});
const frozen=input();frozen.rules[0].note="\u0000\ud800\r\n";Object.freeze(frozen.rules[0].repeat);Object.freeze(frozen.rules[0]);Object.freeze(frozen.rules);Object.freeze(frozen);
const accepted=generate(frozen,"2026-10");
const control=accepted.plan.expenses[0].note==="\u0000\ud800\r\n"&&Object.isFrozen(accepted.plan.expenses);
console.log(JSON.stringify({schema:"household.author-non-json-probe.v1",attribution:"Post-freeze author/root source-review boundary; not an independent pre-candidate oracle.",results,frozenLiteralControl:control,allPassed:control&&results.every(r=>r.validationError)}));
process.exitCode=control&&results.every(r=>r.validationError)?0:1;
