import { pathToFileURL } from "node:url";
const root=process.argv[2];
const { generateRecurringExpensePlan:generate }=await import(pathToFileURL(root+"/build-v1/src/recurring-expenses.js"));
const { ValidationError }=await import(pathToFileURL(root+"/build-v1/src/ledger.js"));
const input=()=>({schema:"household-recurring-expenses/1",currency:"USD",rules:[{id:"a",start:"2026-01-01",category:"Food",amountMinor:100,repeat:{unit:"month",every:1,missingDay:"last"}}]});
const rows=[];
for(const placement of ["root","array","rule","repeat"]){
 const x=input();let traps=0;
 const wrap=target=>new Proxy(target,{
  get(t,k,r){traps++;return Reflect.get(t,k,r);},
  getPrototypeOf(t){traps++;return Reflect.getPrototypeOf(t);},
  ownKeys(t){traps++;return Reflect.ownKeys(t);},
  getOwnPropertyDescriptor(t,k){traps++;return Reflect.getOwnPropertyDescriptor(t,k);},
 });
 let value=x;if(placement==="root")value=wrap(x);if(placement==="array")x.rules=wrap(x.rules);if(placement==="rule")x.rules[0]=wrap(x.rules[0]);if(placement==="repeat")x.rules[0].repeat=wrap(x.rules[0].repeat);
 let errorClass=null,validationError=false;try{generate(value,"2026-10");}catch(e){errorClass=e.constructor.name;validationError=e instanceof ValidationError;}
 rows.push({placement,traps,errorClass,validationError,passed:validationError&&traps===0});
}
for(const placement of ["revoked-root","revoked-array"]){
 const pair=Proxy.revocable(placement==="revoked-root"?input():input().rules,{});pair.revoke();
 let value=pair.proxy;if(placement==="revoked-array"){value=input();value.rules=pair.proxy;}
 let errorClass=null,validationError=false;try{generate(value,"2026-10");}catch(e){errorClass=e.constructor.name;validationError=e instanceof ValidationError;}
 rows.push({placement,errorClass,validationError,passed:validationError});
}
console.log(JSON.stringify({schema:"household.author-proxy-probe.v1",attribution:"Root/source-review requested post-freeze boundary, not a blind oracle.",rows,allPassed:rows.every(x=>x.passed)}));process.exitCode=rows.every(x=>x.passed)?0:1;
