import os,sys,json,hashlib,subprocess,time,re,socket,resource
from pathlib import Path
root=Path('<author-root>')
evidence=root/'evidence/author-v1';source=root/'candidate-v1';build=root/'build-v1'
def identity(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(65536),b''):h.update(chunk)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def write_json(name,value):
 p=evidence/name;raw=(json.dumps(value,indent=2)+'\n').encode()
 with p.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
 return identity(p)
pressure=int(subprocess.check_output(['/usr/sbin/sysctl','-n','kern.memorystatus_vm_pressure_level'],text=True))
vm=subprocess.check_output(['/usr/bin/vm_stat'],text=True);page=int(re.search(r'page size of (\d+) bytes',vm).group(1))
free=int(re.search(r'Pages free:\s+(\d+)',vm).group(1))*page
st=os.statvfs(root);disk=st.f_bavail*st.f_frsize
owned=sum(p.stat().st_size for p in root.rglob('*') if p.is_file())
admission={'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'host':socket.gethostname(),'uid':os.getuid(),'pressure':pressure,'free_page_bytes':free,'disk_available_bytes':disk,'owned_bytes':owned,'thresholds':{'free_page_bytes':402653184,'disk_available_bytes':134217728,'owned_cap':8388608},'compiler_heap_mib':192,'compiler_timeout_s':60,'test_heap_mib':96,'test_timeout_s':60}
admission['admitted']=socket.gethostname()=='<native-macos-host>' and os.getuid()==501 and pressure==1 and free>=402653184 and disk>=134217728 and owned<8388608 and not build.exists()
admit_pin=write_json('build-admission-v1.json',admission)
if not admission['admitted']:
 print(json.dumps({'admission':admission,'receipt':admit_pin,'compiler_started':False}));sys.exit(74)
manifest=json.loads((evidence/'prequalification-inputs.json').read_text())
for f in manifest['files']:
 p=source/f['path'];actual=identity(p);assert actual['bytes']==f['bytes'] and actual['sha256']==f['sha256']
toolbase=Path('<existing-node-modules>')
toolpaths=[Path('<node-26.3.0>').resolve(),toolbase/'typescript/package.json',toolbase/'typescript/bin/tsc',toolbase/'typescript/lib/tsc.js',toolbase/'typescript/lib/_tsc.js',toolbase/'@types/node/package.json']
tools_before=[identity(p) for p in toolpaths]
env=os.environ.copy();env.pop('NODE_COMPILE_CACHE',None);env['NODE_DISABLE_COMPILE_CACHE']='1'
temp=evidence/'tmp';temp.mkdir();env['TMPDIR']=str(temp)
commands=[
 ('compile',['<node-26.3.0>','--max-old-space-size=192',str(toolbase/'typescript/bin/tsc'),'--project',str(source/'tsconfig.json'),'--outDir',str(build),'--typeRoots',str(toolbase/'@types'),'--types','node']),
 ('tests',['<node-26.3.0>','--max-old-space-size=96','--test','--test-concurrency=1','--test-timeout=30000',str(build/'test/recurring-expenses.test.js'),str(build/'test/recurring-expenses-cli.test.js')])
]
runs=[]
for name,cmd in commands:
 start=time.monotonic()
 try:
  r=subprocess.run(cmd,cwd=source,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
  entry={'name':name,'argv':cmd,'exit':r.returncode,'seconds':time.monotonic()-start,'timed_out':False}
  out,err=r.stdout,r.stderr
 except subprocess.TimeoutExpired as ex:
  out,err=ex.stdout or b'',ex.stderr or b'';entry={'name':name,'argv':cmd,'exit':None,'seconds':time.monotonic()-start,'timed_out':True}
 for label,raw in [('stdout',out),('stderr',err)]:
  p=evidence/(name+'.'+label+'.log')
  with p.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
  entry[label]=identity(p)
 entry['observed_children_maxrss_bytes']=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
 runs.append(entry)
 if entry['exit']!=0:break
unchanged=all(identity(source/f['path'])['sha256']==f['sha256'] for f in manifest['files'])
tools_after=[identity(p) for p in toolpaths]
outputs=[identity(p) for p in sorted(build.rglob('*')) if p.is_file()] if build.exists() else []
receipt={'schema':'household.author-execution.v1','admission':admit_pin,'runs':runs,'source_inputs_unchanged':unchanged,'tool_inputs_before':tools_before,'tool_inputs_after':tools_after,'tools_unchanged':tools_before==tools_after,'outputs':outputs,'native_scope':'Isolated five-module/two-test TypeScript component; not a full service npm build or old owner-suite rerun.','all_passed':len(runs)==2 and all(r['exit']==0 for r in runs) and unchanged and tools_before==tools_after}
pin=write_json('execution-v1.json',receipt)
print(json.dumps({'runs':[{'name':r['name'],'exit':r['exit'],'seconds':r['seconds'],'maxrss_bytes':r['observed_children_maxrss_bytes']} for r in runs],'all_passed':receipt['all_passed'],'receipt':pin}))
sys.exit(0 if receipt['all_passed'] else 1)
