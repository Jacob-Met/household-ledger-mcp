# Recurring-expense producer: author qualification

This packet receives five additive maintained files on the existing Household Ledger expense-plan consumer at a74357bac7cf888e02b49c0d0cfa5f48c1fecf7b. The existing service/ledger/Store/router/consumer/package/workflow files were not edited. The source-only union has 166 leaves; independent source receiving binds that complete union separately.

## Actual results

- Original consumer: three independent controls passed, including refusal of the recurrence schema as an unsupported explicit-plan field. The independent packet preserves that separate run.
- V1: the isolated TypeScript component compiled and all 15 maintained tests passed. Its sibling build directory did not have separately frozen package ancestry; no independent candidate matrix ran on v1.
- Post-freeze source review then found bigint diagnostic, rules-array and Proxy admission boundaries. The actual v1 non-JSON probe exited 1 (eight failing cases, rejection/literal controls retained); the distinct Proxy probe exited 1 (six failing cases). These are author/root review findings, not pre-candidate independent oracles.
- V2 changes only API admission and two maintained API tests. Its compile, 17 maintained tests, non-JSON probe and Proxy probe each exited 0. The two replay probes changed only their compiled import paths.
- The final compiled directory is below the exact inherited type=module package. The three emitted inherited JavaScript modules are byte-identical to the independently received original direct-use bundle.
- Independent final receiving separately passed API 10/10, CLI 4/4, and failed-stdout 3/3. That packet is separate and is not synthesized here.

A preliminary admission wrapper had an overescaped vm_stat regex and exited 1 before any file or Node action. Its original traceback/command identity and the corrected wrapper remain in the evidence. No failed result has been replaced by a later pass.

## Replay without installing dependencies

Node 26.3.0 was used for these recorded results. The source package declares Node 20 or later, but this packet does not claim a new cross-version matrix. Use a temporary extracted directory:

```sh
node --max-old-space-size=96 --test --test-concurrency=1 candidate-v2/dist/test/recurring-expenses.test.js candidate-v2/dist/test/recurring-expenses-cli.test.js
node --max-old-space-size=64 evidence/author-v1/non-json-probe-v1.mjs "$PWD"
node --max-old-space-size=64 evidence/author-v1/proxy-probe-v1.mjs "$PWD"
node --max-old-space-size=64 evidence/author-v2/non-json-probe-v2.mjs "$PWD"
node --max-old-space-size=64 evidence/author-v2/proxy-probe-v2.mjs "$PWD"
```

The two v1 commands are expected to exit 1. Their received build-v1 directory contains the five exact original compiled modules; a package.json is supplied only for portable replay and does not rewrite the historical package-context limitation. The v2 commands are expected to exit 0. Tests use synthetic files in a temporary directory and remove only those owned fixtures.

For actual use, see candidate-v2/docs/RECURRING_EXPENSES.md. Run the compiled recurring producer to make a new explicit plan, then the existing compiled household-plan consumer with the receipt's currency. No ledger records, timers, server activation or accounts are changed.

## Identity and evidence limits

MANIFEST.json gives every archived member's SHA-256, Git blob identity, size, and its native source identity where applicable. Frozen source and compiled bytes are exact. Public receipt/log copies replace private host/path identifiers with documented tokens; their original private SHA-256 remains in the manifest. The private originals remain in custody. Sanitized receipts are derived evidence, not byte-identical original receipts.

The component compile covered five modules and two test files, not the complete service or another owner's full suite. The bounded compiler heap was 192 MiB; measured process RSS reached 241,139,712 bytes, so heap and RSS are not treated as equal. No GitHub Actions, branch/PR merge, installed service adoption, runtime scheduling or full service build is claimed by this packet.

The input data contract is deliberately limited to ordinary JSON data. Literal note strings, including NUL and unpaired UTF-16 surrogates accepted by the existing consumer, remain supported. Rejection of Proxy/custom array behavior is input admission, not a claim about hostile global runtime modification.
