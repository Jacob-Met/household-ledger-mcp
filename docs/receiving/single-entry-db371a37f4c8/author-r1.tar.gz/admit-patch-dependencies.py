from pathlib import Path
import json,hashlib,subprocess,shutil,datetime,os
r=Path('/dev/shm/hamon-household-entry-db371a37f4c8-production');src=r/'candidate';manifest=json.loads((r/'candidate-source-pins-r1.json').read_text())
paths=manifest['newPaths'];parts=[]
for p in paths:
 b=(src/p).read_bytes();assert b.endswith(b'\n')
 text=b.decode();lines=text.splitlines(keepends=True)
 git=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
 parts.append('diff --git a/'+p+' b/'+p+'\nnew file mode 100644\nindex 0000000..'+git+'\n--- /dev/null\n+++ b/'+p+'\n@@ -0,0 +1,'+str(len(lines))+' @@\n'+''.join('+'+x for x in lines))
patch=''.join(parts).encode();(r/'after-owner.patch').write_bytes(patch)
proof=r/'patch-admission';shutil.copytree(r/'original',proof,ignore=shutil.ignore_patterns('node_modules','dist'))
commands=[]
for args in [['git','apply','--check',str(r/'after-owner.patch')],['git','apply',str(r/'after-owner.patch')]]:
 c=subprocess.run(args,cwd=proof,capture_output=True,timeout=10);commands.append({'argv':args,'exit':c.returncode,'stdout':c.stdout.decode(),'stderr':c.stderr.decode()});assert c.returncode==0
for p in list(x['path'] for x in json.loads((r/'original-source-pins.json').read_text())['files'])+paths:assert (proof/p).read_bytes()==(src/p).read_bytes(),p
# Pin installed package manifests against the unchanged lock; this is an
# installed-tree provenance observation, not a claim npm ci was executed.
lock=json.loads((src/'package-lock.json').read_text())['packages'];donor=(src/'node_modules').resolve()
deps=[];differences=[]
for key,value in lock.items():
 if not key.startswith('node_modules/'):continue
 p=donor/key[len('node_modules/'):] / 'package.json'
 if p.is_file():
  b=p.read_bytes();actual=json.loads(b).get('version');row={'path':key,'lockedVersion':value.get('version'),'installedVersion':actual,'packageSha256':hashlib.sha256(b).hexdigest()};deps.append(row)
  if actual!=value.get('version'):differences.append(row)
 else:differences.append({'path':key,'missing':True})
pins=[]
for p in sorted(donor.rglob('*')):
 if p.is_file() and not p.is_symlink() and p.suffix in ['.js','.cjs','.mjs','.json','.ts']:
  b=p.read_bytes();pins.append({'path':str(p.relative_to(donor)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(r/'dependency-source-pins.json').write_text(json.dumps({'donor':str(donor),'packages':deps,'lockDifferences':differences,'files':pins},indent=2)+'\n')
out={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':manifest['base'],'sourcePaths':len(paths),'inheritedSourceFiles':25,'patchBytes':len(patch),'patchSha256':hashlib.sha256(patch).hexdigest(),'commands':commands,'afterApplyExactSourceFiles':25+len(paths),'dependencyFiles':len(pins),'dependencyBytes':sum(x['bytes'] for x in pins),'lockDifferences':differences}
(r/'patch-and-dependency-admission.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
