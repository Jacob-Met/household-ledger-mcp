from pathlib import Path
import subprocess,json,time,os,shutil
r=Path('/dev/shm/hamon-household-entry-db371a37f4c8-production');e=r/'evidence-author'
assert shutil.disk_usage(r).free>256*1024*1024
env=dict(os.environ,TMPDIR=str(e));out=[]
for label,cmd in [('compile-r3',['node','node_modules/typescript/lib/tsc.js']),('focused-r1',['node','--test','dist/test/record-client.test.js','dist/test/record-client-http.test.js','dist/test/recording.test.js'])]:
 t=time.time();c=subprocess.run(cmd,cwd=r/'candidate',env=env,capture_output=True,timeout=150)
 (e/(label+'.stdout')).write_bytes(c.stdout);(e/(label+'.stderr')).write_bytes(c.stderr)
 d={'label':label,'exit':c.returncode,'seconds':time.time()-t};(e/(label+'.json')).write_text(json.dumps(d)+'\n');out.append(d)
 if c.returncode:print(c.stdout.decode());print(c.stderr.decode());break
print(json.dumps(out))
