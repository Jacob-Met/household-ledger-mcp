from pathlib import Path
import os,json,hashlib,subprocess,shutil,time
r=Path('/dev/shm/hamon-household-entry-db371a37f4c8-production'); d=Path('/tmp/c36a60df2cc1-household-compare/worktree/node_modules')
assert d.is_dir()
lock=json.loads((r/'original/package-lock.json').read_text())['packages']
deps=[]
for name in ['typescript','@modelcontextprotocol/sdk','@types/node']:
 p=d/name/'package.json'; j=json.loads(p.read_text());assert j['version']==lock['node_modules/'+name]['version']
 deps.append({'name':name,'path':str(p),'version':j['version'],'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
assert shutil.disk_usage(r).free>256*1024*1024
(r/'original/node_modules').symlink_to(d,target_is_directory=True)
e=r/'evidence-original';e.mkdir()
t=time.time();c=subprocess.run(['/usr/bin/node',str(d/'typescript/lib/tsc.js')],cwd=r/'original',capture_output=True,timeout=60)
(e/'compile.stdout').write_bytes(c.stdout);(e/'compile.stderr').write_bytes(c.stderr)
n=subprocess.run(['/usr/bin/node','dist/src/household-record.js','--help'],cwd=r/'original',capture_output=True,timeout=10)
(e/'missing-client.stdout').write_bytes(n.stdout);(e/'missing-client.stderr').write_bytes(n.stderr)
rec={'dependencies':deps,'node':subprocess.check_output(['/usr/bin/node','--version'],text=True).strip(),'compileExit':c.returncode,'missingClientExit':n.returncode,'missingClientCode':b'MODULE_NOT_FOUND' in n.stderr,'elapsed':time.time()-t}
(e/'baseline.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec))
assert c.returncode==0 and n.returncode!=0 and b'MODULE_NOT_FOUND' in n.stderr
shutil.copytree(r/'original',r/'candidate',symlinks=True,ignore=shutil.ignore_patterns('dist'))
