from pathlib import Path
import os,pty,subprocess,select,time,json,hashlib,socket,signal,shutil,datetime
r=Path("/dev/shm/hamon-household-entry-db371a37f4c8-production");e=r/"evidence-author/terminal-r1";e.mkdir()
assert shutil.disk_usage(r).free>256*1024*1024
source=r/"candidate";manifest=json.loads((r/"candidate-source-pins-r1.json").read_text())
def verify():
 for f in manifest["files"]:assert hashlib.sha256((source/f["path"]).read_bytes()).hexdigest()==f["sha256"],f["path"]
verify()
sock=socket.socket();sock.bind(("127.0.0.1",0));port=sock.getsockname()[1];sock.close()
ledger=e/"ledger.json";env=dict(os.environ,TMPDIR=str(e),HOUSEHOLD_LEDGER_DATA_PATH=str(ledger),HOUSEHOLD_LEDGER_HOST="127.0.0.1",HOUSEHOLD_LEDGER_PORT=str(port))
server_out=open(e/"server.stdout","wb");server_err=open(e/"server.stderr","wb")
server=subprocess.Popen(["node","dist/src/index.js"],cwd=source,env=env,stdout=server_out,stderr=server_err,start_new_session=True)
cases=[]
def run(name,args,answers):
 m,s=pty.openpty();p=subprocess.Popen(["node","dist/src/household-record.js"]+args,cwd=source,env=env,stdin=s,stdout=s,stderr=s,start_new_session=True);os.close(s)
 output=b"";start=time.time();position=0
 try:
  for needle,answer in answers:
   deadline=time.time()+20
   while needle.encode() not in output[position:]:
    if time.time()>deadline:raise AssertionError("prompt timeout "+needle+" "+output.decode(errors="replace"))
    ready,_,_=select.select([m],[],[],.1)
    if ready:
     try:b=os.read(m,65536)
     except OSError:b=b""
     if not b:raise AssertionError("early terminal exit "+output.decode(errors="replace"))
     output+=b
   position=output.index(needle.encode(),position)+len(needle.encode())
   os.write(m,answer)
  deadline=time.time()+20
  while p.poll() is None:
   if time.time()>deadline:raise AssertionError("exit timeout")
   ready,_,_=select.select([m],[],[],.1)
   if ready:
    try:output+=os.read(m,65536)
    except OSError:pass
  while select.select([m],[],[],0)[0]:
   try:b=os.read(m,65536)
   except OSError:break
   if not b:break
   output+=b
  (e/(name+".terminal")).write_bytes(output)
  row={"name":name,"pid":p.pid,"exit":p.returncode,"seconds":time.time()-start,"sha256":hashlib.sha256(output).hexdigest()};cases.append(row)
  return p.returncode,output.decode(errors="replace")
 finally:
  if p.poll() is None:os.killpg(p.pid,signal.SIGTERM);p.wait(timeout=5)
  os.close(m)
def fields():
 return [("Direction",b"expense\n"),("INTEGER",b"1250\n"),("currency:",b" usd \n"),("YYYY-MM-DD",b"2026-10-08\n"),("Category:",b" food \n"),("blank to omit", "東京 receipt\n".encode())]
try:
 deadline=time.time()+20
 while "listening on" not in (e/"server.stdout").read_text():
  if time.time()>deadline or server.poll() is not None:raise AssertionError("server startup")
  time.sleep(.05)
 endpoint="http://127.0.0.1:"+str(port)+"/mcp";request=e/"request.json"
 code,text=run("cancel-new",["new","--endpoint",endpoint,"--request",str(request)],fields()+[("Type RECORD",b"cancel\n")])
 assert code==2 and request.exists() and not ledger.exists()
 saved=request.read_bytes();obj=json.loads(saved);assert obj["transaction"]["amountMinor"]==1250 and obj["transaction"]["currency"]=="USD" and obj["transaction"]["category"]=="food"
 assert text.index("Review one recording")<text.index("Type RECORD")
 code,text=run("confirm-resume",["resume","--request",str(request)],[("Type RECORD",b"RECORD\nRECORD\n")])
 assert code==0 and "Confirmed recording:" in text
 before=ledger.read_bytes();tx=json.loads(before)["transactions"];assert len(tx)==1 and tx[0]["idempotencyKey"]==obj["transaction"]["idempotencyKey"]
 assert request.read_bytes()==saved and tx[0]["note"]=="東京 receipt"
 code,text=run("cancel-eof",["resume","--request",str(request)],[("Type RECORD",b"\x04")])
 assert code==2 and ledger.read_bytes()==before and request.read_bytes()==saved
 code,text=run("invalid-amount",["new","--endpoint",endpoint,"--request",str(e/"bad.json")],[("Direction",b"income\n"),("INTEGER",b"1.5\n")])
 assert code==1 and not (e/"bad.json").exists() and ledger.read_bytes()==before
 c=subprocess.run(["node","dist/src/household-record.js","resume","--request",str(request)],cwd=source,env=env,input=b"RECORD\n",capture_output=True,timeout=10)
 (e/"piped.stdout").write_bytes(c.stdout);(e/"piped.stderr").write_bytes(c.stderr)
 assert c.returncode==1 and b"interactive" in c.stderr and ledger.read_bytes()==before
 cases.append({"name":"piped-refusal","exit":c.returncode})
 verify()
 result={"status":"passed","cases":cases,"sourceManifest":hashlib.sha256((r/"candidate-source-pins-r1.json").read_bytes()).hexdigest(),"ledgerSha256":hashlib.sha256(before).hexdigest(),"requestSha256":hashlib.sha256(saved).hexdigest()}
except BaseException as ex:
 result={"status":"failed","cases":cases,"error":repr(ex)}
 raise
finally:
 if server.poll() is None:os.killpg(server.pid,signal.SIGTERM)
 server.wait(timeout=5);server_out.close();server_err.close()
 result["serverExit"]=server.returncode;result["serverShutdown"]="intentional SIGTERM after client closure"
 (e/"receipt.json").write_text(json.dumps(result,indent=2)+"\n")
 print(json.dumps(result))
