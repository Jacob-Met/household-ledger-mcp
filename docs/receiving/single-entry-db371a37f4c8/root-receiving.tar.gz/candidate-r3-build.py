import pathlib,json,hashlib,datetime,subprocess,os,shutil,traceback
r=pathlib.Path('/home/jacob/snap/chromium/common/hamon-household-entry-receiving-db371a37f4c8')
source=r/'candidate-r3-source-build';donor=pathlib.Path('/tmp/c36a60df2cc1-household-compare/worktree/node_modules')
rec={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'purpose':'Resolve one retained independent compiler timeout after measured native resource recovery; qualified artifact unchanged; no product test rerun.'}
h=lambda b:hashlib.sha256(b).hexdigest()
try:
 mem={s.split(':')[0]:int(s.split(':')[1].split()[0])*1024 for s in pathlib.Path('/proc/meminfo').read_text().splitlines() if s.startswith('MemAvailable:')}
 rec['guard']={'load1m':os.getloadavg()[0],'memoryAvailable':mem['MemAvailable'],'diskFree':shutil.disk_usage(r).free,'activeOwnedCompilers':[]}
 for p in pathlib.Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   exe=(p/'exe').resolve().name;cwd=str((p/'cwd').resolve())
   if exe in ['cargo','rustc'] and 'hamon-resonance' in cwd:rec['guard']['activeOwnedCompilers'].append({'pid':int(p.name),'executable':exe,'cwd':cwd})
  except OSError:pass
 if rec['guard']['load1m']>=10 or rec['guard']['memoryAvailable']<1500*1024*1024 or rec['guard']['diskFree']<40*1024*1024 or rec['guard']['activeOwnedCompilers']:
  rec['status']='guard-held';raise RuntimeError('bounded compiler window not admitted')
 source.mkdir(mode=0o700)
 manifest=json.loads((r/'candidate-r1-pins.json').read_text())
 for f in manifest['files']:
  b=(r/'candidate-r1-source'/f['path']).read_bytes();assert h(b)==f['sha256'],f['path']
  if not f['path'].startswith('dist/'):
   p=source/f['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 (source/'node_modules').symlink_to(donor,target_is_directory=True)
 argv=['/usr/bin/node',str(donor/'typescript/bin/tsc'),'-p',str(source/'tsconfig.json')]
 rec['argv']=argv
 with (r/'candidate-r3-build.log').open('wb') as log:
  process=subprocess.Popen(argv,cwd=source,stdout=log,stderr=subprocess.STDOUT)
  rec['compilerPid']=process.pid
  try:code=process.wait(timeout=75)
  except subprocess.TimeoutExpired:
   process.kill();rec['compilerExit']=process.wait(timeout=5);raise
 rec['compilerExit']=code;assert code==0
 for f in manifest['files']:assert h((source/f['path']).read_bytes())==f['sha256'],f['path']
 for f in manifest['files']:assert h((r/'candidate-r1-source'/f['path']).read_bytes())==f['sha256'],f['path']
 rec['all99FilesExact']=True;rec['sourceFiles']=30;rec['compiledFiles']=69;rec['qualifiedArtifactUnchanged']=True;rec['status']='passed';rec['ok']=True
except BaseException as e:rec['ok']=False;rec['error']=repr(e);rec['traceback']=traceback.format_exc()
rec['completed']=datetime.datetime.now(datetime.timezone.utc).isoformat()
b=(json.dumps(rec,indent=2)+'\n').encode();(r/'candidate-r3-build-receipt.json').write_bytes(b)
print(json.dumps({**rec,'receiptBytes':len(b),'receiptSha':h(b)}),flush=True)
if not rec['ok']:raise SystemExit(1)
