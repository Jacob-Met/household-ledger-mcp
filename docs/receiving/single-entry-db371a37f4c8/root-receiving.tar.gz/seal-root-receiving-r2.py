import pathlib,json,hashlib,datetime,os,stat,tarfile,io,shutil
r=pathlib.Path('/home/jacob/snap/chromium/common/hamon-household-entry-receiving-db371a37f4c8')
h=lambda b:hashlib.sha256(b).hexdigest()
dep=json.loads((r/'author-dependency-source-pins.json').read_text());donor=pathlib.Path(dep['donor']).resolve()
assert not dep['lockDifferences']
for f in dep['files']:
 p=pathlib.Path(f['path']);p=p if p.is_absolute() else donor/p
 assert p.resolve().is_relative_to(donor)
 assert h(p.read_bytes())==f['sha256'],str(p)
manifest=json.loads((r/'candidate-r1-pins.json').read_text())
for f in manifest['files']:
 for directory in ['candidate-r1-source','candidate-r3-source-build']:
  assert h((r/directory/f['path']).read_bytes())==f['sha256']
build=json.loads((r/'candidate-r3-build-receipt.json').read_text())
assert build['ok'] and build['all99FilesExact']
assert not pathlib.Path('/proc/2643840').exists() and not pathlib.Path('/proc/2643762').exists()
note=(r/'ROOT.md').read_text()
for old,new in [('all116','all 116'),('all99','all 99'),('All99','All 99'),('All25','All 25'),('All116','All 116'),('with22','with 22'),('with69','with 69'),('and69','and 69'),('and57','and 57'),('and69','and 69'),('tree311','tree 311'),('The99','The 99'),('SHA256','SHA-256 '),('before90','before 90'),('after90','after 90'),('under load around40','under load around 40'),('about8','about 8'),('The22:','The 22:'),('R3 receipt SHA-256 ','R3 receipt SHA-256 ')]:
 note=note.replace(old,new)
(r/'ROOT.md').write_text(note)
seal_dir=r/'publication';seal_dir.mkdir(mode=0o700)
final={'completed':datetime.datetime.now(datetime.timezone.utc).isoformat(),'receivingAccepted':True,'rootIndependentBuildPassed':True,'compiledAndSource99Exact':True,'dependencySourceFilesExact':len(dep['files']),'dependencyManifestSha':h((r/'author-dependency-source-pins.json').read_bytes()),'priorNativeAuditSha':h((r/'final-native-audit-r1.json').read_bytes()),'r3BuildReceiptSha':h((r/'candidate-r3-build-receipt.json').read_bytes()),'rootNoteSha':h((r/'ROOT.md').read_bytes()),'actionsTriggered':False,'installedAdoptionClaimed':False}
(r/'final-native-audit-r2.json').write_text(json.dumps(final,indent=2)+'\n')
files=[];special=[]
for current,dirs,names in os.walk(r,followlinks=False):
 dirs[:]=[d for d in dirs if d not in ['node_modules','publication','candidate-r3-source-build'] and not (pathlib.Path(current)/d).is_symlink()]
 for name in names:
  p=pathlib.Path(current)/name;relative=p.relative_to(r).as_posix();s=p.lstat()
  if stat.S_ISREG(s.st_mode):
   b=p.read_bytes();files.append({'path':relative,'bytes':len(b),'sha256':h(b),'mode':stat.S_IMODE(s.st_mode)})
  else:special.append({'path':relative,'type':'symlink' if stat.S_ISLNK(s.st_mode) else 'fifo' if stat.S_ISFIFO(s.st_mode) else 'other','mode':stat.S_IMODE(s.st_mode),'target':os.readlink(p) if stat.S_ISLNK(s.st_mode) else None})
files.sort(key=lambda f:f['path'])
m={'files':files,'specialFixtureMetadata':special,'excludedReproducibleBuild':'candidate-r3-source-build exactly equals archived candidate-r1-source; R3 script/log/receipt are included.','dependencies':'External node_modules links excluded; exact2960-file source manifest included.','created':datetime.datetime.now(datetime.timezone.utc).isoformat()}
mb=(json.dumps(m,indent=2,ensure_ascii=False)+'\n').encode();(seal_dir/'root-receiving-manifest.json').write_bytes(mb)
out=seal_dir/'household-single-entry-root-receiving.tar.gz'
assert not out.exists()
assert shutil.disk_usage(r).free>sum(f['bytes'] for f in files)*2+10*1024*1024
with tarfile.open(out,'w:gz') as t:
 for f in files:t.add(r/f['path'],arcname=f['path'],recursive=False)
 ti=tarfile.TarInfo('ROOT-RECEIVING-MANIFEST.json');ti.size=len(mb);ti.mode=0o600;t.addfile(ti,io.BytesIO(mb))
with tarfile.open(out,'r:gz') as t:
 assert len(t.getmembers())==len(files)+1
 for f in files:assert h(t.extractfile(f['path']).read())==f['sha256']
 assert t.extractfile('ROOT-RECEIVING-MANIFEST.json').read()==mb
b=out.read_bytes()
receipt={'completed':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':out.name,'bytes':len(b),'sha256':h(b),'git':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'payloadFiles':len(files),'members':len(files)+1,'payloadBytes':sum(f['bytes'] for f in files),'manifestSha256':h(mb),'roundtripExact':True,'specialFixtures':special,'finalAuditSha':h((r/'final-native-audit-r2.json').read_bytes()),'rootNoteSha':h((r/'ROOT.md').read_bytes()),'remoteObjectCreated':False}
(seal_dir/'root-receiving-seal.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'finalAudit':final,'seal':receipt},ensure_ascii=False),flush=True)
