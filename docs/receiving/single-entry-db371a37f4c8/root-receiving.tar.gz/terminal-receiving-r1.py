import pathlib,json,hashlib,os,sys,subprocess,datetime,time,socket,http.client,http.server,threading,pty,select,errno,traceback,stat,shutil,signal
ROOT=pathlib.Path('/home/jacob/snap/chromium/common/hamon-household-entry-receiving-db371a37f4c8')
RUN=ROOT/'terminal-r1'
ORIGINAL=ROOT/'original-source'
CANDIDATE=ROOT/'candidate-r1-source'
os.umask(0o077)
STATE={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'groups':[],'requests':[],'terminals':[],'services':[],'proxyErrors':[]}
ACTIVE={'case':None,'path':None,'dropNextRecord':False}
CHILDREN=[]
SERVICE=None
PROXY=None
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,j):p.write_text(json.dumps(j,indent=2,ensure_ascii=False)+'\n')
def snapshot(p):
 try:
  b=p.read_bytes();s=p.stat()
  return {'bytes':len(b),'sha256':sha(b),'mtimeNs':s.st_mtime_ns,'mode':stat.S_IMODE(s.st_mode)}
 except FileNotFoundError:return None
def record_count():return sum(1 for x in STATE['requests'] if x.get('rpc',{}).get('method')=='tools/call' and x['rpc'].get('params',{}).get('name')=='record_transaction')
def source_audit():
 counts={}
 for label,folder,pinsname in [('original',ORIGINAL,'original-source-pins.json'),('candidate',CANDIDATE,'candidate-r1-pins.json')]:
  pins=json.loads((ROOT/pinsname).read_text())['files']
  for f in pins:assert sha((folder/f['path']).read_bytes())==f['sha256'],(label,f['path'])
  counts[label]=len(pins)
 return counts
class NativeService:
 def __init__(self,port=None):
  if port is None:
   with socket.socket() as reserve:
    reserve.bind(('127.0.0.1',0));port=reserve.getsockname()[1]
  self.port=port;self.index=len(STATE['services'])+1
  self.out=RUN/f'native-server-{self.index}.stdout.log';self.err=RUN/f'native-server-{self.index}.stderr.log'
  argv=['/usr/bin/node',str(ORIGINAL/'dist/src/index.js')]
  env=dict(os.environ,HOUSEHOLD_LEDGER_HOST='127.0.0.1',HOUSEHOLD_LEDGER_PORT=str(port),HOUSEHOLD_LEDGER_DATA_PATH=str(LEDGER))
  with self.out.open('wb') as o,self.err.open('wb') as e:self.p=subprocess.Popen(argv,cwd=ORIGINAL,env=env,stdin=subprocess.DEVNULL,stdout=o,stderr=e)
  CHILDREN.append(self.p)
  self.receipt={'pid':self.p.pid,'argv':argv,'port':port,'dataPath':str(LEDGER),'started':now()}
  STATE['services'].append(self.receipt)
  for _ in range(150):
   assert self.p.poll() is None,('native-server-early-exit',self.p.returncode,self.err.read_text())
   if f'listening on http://127.0.0.1:{port}' in self.out.read_text():break
   time.sleep(.05)
  else:raise AssertionError('native startup missing')
  c=http.client.HTTPConnection('127.0.0.1',port,timeout=3);c.request('GET','/healthz');r=c.getresponse();b=r.read();c.close()
  assert r.status==200 and json.loads(b)=={'ok':True,'service':'household-ledger-mcp'}
 def close(self):
  if self.p.poll() is None:self.p.terminate();self.receipt['shutdown']='deliberate owned SIGTERM'
  self.receipt['exit']=self.p.wait(timeout=5);self.receipt['completed']=now()
class Forwarder(http.server.BaseHTTPRequestHandler):
 protocol_version='HTTP/1.1'
 def log_message(self,*args):pass
 def do_GET(self):self.forward()
 def do_POST(self):self.forward()
 def do_DELETE(self):self.forward()
 def forward(self):
  entry={'at':now(),'case':ACTIVE['case'],'method':self.command,'path':self.path}
  upstream=None
  try:
   body=self.rfile.read(int(self.headers.get('Content-Length','0')))
   try:rpc=json.loads(body)
   except (ValueError,UnicodeDecodeError):rpc={}
   entry.update({'rpc':rpc,'requestBytes':len(body),'requestSha':sha(body)})
   is_record=rpc.get('method')=='tools/call' and rpc.get('params',{}).get('name')=='record_transaction'
   if is_record:
    p=pathlib.Path(ACTIVE['path']);entry['recoveryBeforeForward']=snapshot(p)
    assert entry['recoveryBeforeForward'] is not None,'recovery missing before native forward'
    recovery=json.loads(p.read_bytes());assert recovery['transaction']==rpc['params']['arguments']
    entry['recoveryPath']=str(p);entry['ledgerBeforeForward']=snapshot(LEDGER)
   STATE['requests'].append(entry)
   headers={k:v for k,v in self.headers.items() if k.lower() not in ['host','connection','transfer-encoding','content-length']}
   headers['Host']=f'127.0.0.1:{SERVICE.port}';headers['Content-Length']=str(len(body))
   upstream=http.client.HTTPConnection('127.0.0.1',SERVICE.port,timeout=20)
   upstream.request(self.command,self.path,body=body,headers=headers)
   r=upstream.getresponse();data=r.read();entry.update({'status':r.status,'responseBytes':len(data),'responseSha':sha(data),'responseText':data.decode('utf8','replace')})
   if is_record:
    entry['ledgerAfterUpstream']=snapshot(LEDGER)
    ledger=json.loads(LEDGER.read_text());entry['matchingStoredTransactions']=[x for x in ledger['transactions'] if x.get('idempotencyKey')==rpc['params']['arguments']['idempotencyKey']]
   if is_record and ACTIVE['dropNextRecord']:
    assert len(entry['matchingStoredTransactions'])==1,'upstream record not committed before fault'
    entry['fault']='actual upstream response fully received and persisted record verified; downstream socket closed before any response headers'
    ACTIVE['dropNextRecord']=False;entry['faultAt']=now()
    self.close_connection=True
    try:self.connection.shutdown(socket.SHUT_RDWR)
    except OSError:pass
    self.connection.close();return
   self.send_response(r.status)
   for k,v in r.getheaders():
    if k.lower() not in ['transfer-encoding','connection','content-length']:self.send_header(k,v)
   self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
  except BaseException as e:
   entry['error']=repr(e);STATE['proxyErrors'].append({'case':entry['case'],'error':repr(e),'traceback':traceback.format_exc()})
   self.close_connection=True
  finally:
   if upstream:upstream.close()
class Terminal:
 def __init__(self,label,args,path=None):
  ACTIVE['case']=label;ACTIVE['path']=str(path) if path else None
  self.label=label;self.raw=bytearray();self.cursor=0
  self.master,slave=pty.openpty()
  argv=['/usr/bin/node',str(CANDIDATE/'dist/src/household-record.js')]+args
  self.p=subprocess.Popen(argv,cwd=CANDIDATE,stdin=slave,stdout=slave,stderr=slave,start_new_session=True,close_fds=True)
  os.close(slave);CHILDREN.append(self.p)
  self.receipt={'label':label,'pid':self.p.pid,'argv':argv,'started':now(),'events':[]}
  STATE['terminals'].append(self.receipt);self.closed=False
 def pump(self,seconds=.1):
  ready,_,_=select.select([self.master],[],[],seconds)
  if ready:
   try:b=os.read(self.master,65536)
   except OSError as e:
    if e.errno==errno.EIO:return False
    raise
   if b:self.raw.extend(b);return True
  return False
 def until(self,text,timeout=12):
  needle=text.encode();deadline=time.monotonic()+timeout
  while needle not in self.raw[self.cursor:]:
   self.pump(.05)
   if self.p.poll() is not None and needle not in self.raw[self.cursor:]:
    self.pump(0);raise AssertionError((self.label,'exited before prompt',text,self.p.returncode,self.raw.decode('utf8','replace')))
   if time.monotonic()>deadline:raise AssertionError((self.label,'timeout',text,self.raw.decode('utf8','replace')))
  i=self.raw.find(needle,self.cursor);self.cursor=i+len(needle)
  self.receipt['events'].append({'at':now(),'observed':text,'byteOffset':i})
  return self.text()
 def text(self):return self.raw.decode('utf8','strict').replace('\r\n','\n')
 def send(self,line):
  os.write(self.master,(line+'\n').encode())
  self.receipt['events'].append({'at':now(),'input':line})
 def eof(self):os.write(self.master,b'\x04');self.receipt['events'].append({'at':now(),'inputControl':'EOF'})
 def finish(self,expected,timeout=22):
  deadline=time.monotonic()+timeout
  while self.p.poll() is None:
   self.pump(.05)
   if time.monotonic()>deadline:raise AssertionError((self.label,'did not exit',self.text()))
  while self.pump(0):pass
  code=self.p.wait();self.receipt['exit']=code;self.receipt['completed']=now()
  self.receipt['transcriptSha']=sha(self.raw);self.receipt['transcriptBytes']=len(self.raw)
  (RUN/(self.label+'.pty.log')).write_bytes(self.raw)
  dump(RUN/(self.label+'.terminal.json'),self.receipt)
  os.close(self.master);self.closed=True
  assert code==expected,(self.label,'exit',code,expected,self.text())
  return self.text()
def terminal_review(t,request):
 t.until('Type RECORD to send this exact request once; anything else cancels: ')
 text=t.text();start=text.index('Review one recording (amountMinor is an integer, not a decimal amount):\n')
 review=text[start:].split('Type RECORD to send this exact request once; anything else cancels: ')[0]
 fields={}
 for line in review.splitlines()[1:]:
  k,v=line.strip().split(': ',1);fields[k]=json.loads(v)
 assert fields==request,('complete reviewed request mismatch',fields,request)
 t.receipt['reviewedRequest']=fields
 return fields
PROMPTS=['Direction (income or expense): ','Amount in positive INTEGER minor units: ','Three-letter currency: ','Date (YYYY-MM-DD): ','Category: ','Note (single line; blank to omit): ']
def new_terminal(label,p,values,endpoint=None,fields=6):
 t=Terminal(label,['new','--endpoint',endpoint or ENDPOINT,'--request',str(p)],p)
 for prompt,value in zip(PROMPTS[:fields],values[:fields]):t.until(prompt);t.send(value)
 return t
def resume_terminal(label,p):
 return Terminal(label,['resume','--request',str(p)],p)
def write_request(label,tx):
 p=RUN/(label+'.request.json');dump(p,{'version':1,'endpoint':ENDPOINT,'transaction':tx});return p
def confirmed(text):
 line=next(x for x in text.splitlines() if x.startswith('Confirmed recording: '))
 return json.loads(line.removeprefix('Confirmed recording: '))
def assert_preserved(before,requests):
 assert LEDGER.read_bytes()==before,'ledger bytes changed'
 assert record_count()==requests,'unexpected native record call'
def group(name,**facts):
 STATE['groups'].append({'name':name,'pass':True,**facts});print(json.dumps(STATE['groups'][-1],ensure_ascii=False),flush=True)

try:
 RUN.mkdir(mode=0o700)
 STATE['sourceBefore']=source_audit()
 STATE['capacityBefore']={'persistentFree':shutil.disk_usage(ROOT).free,'ramFree':shutil.disk_usage('/dev/shm').free}
 assert STATE['capacityBefore']['persistentFree']>12*1024*1024
 LEDGER=RUN/'fixture-ledger.json'
 original_bytes=(ROOT/'original-oracle-r1/golden-ledger.json').read_bytes();LEDGER.write_bytes(original_bytes)
 GOLDEN=json.loads((ROOT/'original-oracle-r1/golden.json').read_text())
 assert sha(original_bytes)==GOLDEN['ledgerSha256']
 binding=json.loads((ROOT/'candidate-interface-binding-r1.json').read_text())
 before_argv=['/usr/bin/node',str(ORIGINAL/'dist/src/household-record.js'),'--help']
 before=subprocess.run(before_argv,cwd=ORIGINAL,stdin=subprocess.DEVNULL,capture_output=True,timeout=10)
 (RUN/'original-missing-client.stdout.log').write_bytes(before.stdout);(RUN/'original-missing-client.stderr.log').write_bytes(before.stderr)
 assert before.returncode==1 and b'MODULE_NOT_FOUND' in before.stderr
 STATE['originalMissingClient']={'argv':before_argv,'exit':before.returncode,'stderrSha':sha(before.stderr)}
 SERVICE=NativeService()
 PROXY=http.server.ThreadingHTTPServer(('127.0.0.1',0),Forwarder)
 PROXY.daemon_threads=True
 proxy_thread=threading.Thread(target=PROXY.serve_forever,daemon=True);proxy_thread.start()
 ENDPOINT=f'http://127.0.0.1:{PROXY.server_port}/mcp'
 STATE['endpoint']=ENDPOINT
 expense=binding['newInteractiveExpense']
 values=[expense['type'],str(expense['amount']),expense['currency'],expense['date'],expense['category'],expense['note']]
 p=RUN/'new-expense.request.json'
 t=new_terminal('01-new-review-cancel',p,values)
 t.until('Recovery request saved at ')
 request=json.loads(p.read_text());saved=p.read_bytes()
 assert request['version']==1 and request['endpoint']==ENDPOINT
 expected_tx={'type':'expense','amountMinor':2750,'currency':'JPY','date':'2026-10-08','category':'Transport / 東京','note':'Late ride <&> 🌙 / receipt 7'}
 assert {k:v for k,v in request['transaction'].items() if k!='idempotencyKey'}==expected_tx
 assert request['transaction']['idempotencyKey'] and stat.S_IMODE(p.stat().st_mode)==0o600
 terminal_review(t,request)
 assert len(STATE['requests'])==0 and LEDGER.read_bytes()==original_bytes
 t.send('cancel');text=t.finish(2)
 assert 'Canceled; no record call. Recovery request retained.' in text
 assert p.read_bytes()==saved;assert_preserved(original_bytes,0)
 group('new entry shows all normalized fields and saved identity before confirmation; cancel performs no MCP connection',requestSha=sha(saved),mode='0600')
 t=resume_terminal('02-confirm-saved-new',p);terminal_review(t,request)
 assert_preserved(original_bytes,0)
 t.send('RECORD');new_result=confirmed(t.finish(0))
 assert {k:new_result[k] for k in request['transaction']}==request['transaction']
 after_new=LEDGER.read_bytes();data=json.loads(after_new)
 assert data['transactions'][:-1]==GOLDEN['ledger']['transactions'] and data['budgets']==GOLDEN['ledger']['budgets']
 assert data['transactions'][-1]==new_result and len(data['transactions'])==3
 assert record_count()==1 and p.read_bytes()==saved
 entry=next(x for x in STATE['requests'] if x.get('matchingStoredTransactions'))
 assert entry['recoveryBeforeForward']['sha256']==sha(saved)
 group('explicit confirmation makes one actual native recording after the exact recovery file exists',nativeId=new_result['id'],recordCalls=record_count(),ledgerSha=sha(after_new))
 t=resume_terminal('03-resume-cancel',p);terminal_review(t,request);t.send('no');t.finish(2)
 assert_preserved(after_new,1)
 st=LEDGER.stat().st_mtime_ns
 t=resume_terminal('04-resume-exact-retry',p);terminal_review(t,request);t.send('RECORD');again=confirmed(t.finish(0))
 assert again==new_result and LEDGER.read_bytes()==after_new and LEDGER.stat().st_mtime_ns==st and record_count()==2
 group('cancelled resume sends nothing; confirmed exact retry returns the same native object without file rewrite',nativeId=again['id'],mtimeNs=st)
 txE={k:v for k,v in GOLDEN['expense'].items() if k not in ['id','createdAt']}
 assert txE['note']=='Late ride <&> 🌙\nreceipt 7'
 multiline_path=write_request('original-multiline-expense',txE);multiline_bytes=multiline_path.read_bytes()
 t=resume_terminal('05-original-multiline-retry',multiline_path)
 terminal_review(t,json.loads(multiline_bytes));t.send('RECORD')
 nativeE=confirmed(t.finish(0));assert nativeE==GOLDEN['expense']
 assert_preserved(after_new,3);assert multiline_path.read_bytes()==multiline_bytes
 group('valid saved multiline request reviews escaped literal text and returns the separately executed original native identity',nativeId=nativeE['id'],note=txE['note'])
 changed={**txE,'amountMinor':2751};changed_path=write_request('conflicting-expense',changed);changed_bytes=changed_path.read_bytes()
 t=resume_terminal('06-same-key-conflict',changed_path);terminal_review(t,json.loads(changed_bytes));t.send('RECORD');text=t.finish(3)
 assert 'UNCONFIRMED:' in text and 'Confirmed recording:' not in text
 assert_preserved(after_new,4);assert changed_path.read_bytes()==changed_bytes
 conflict=[x for x in STATE['requests'] if x['case']=='06-same-key-conflict' and x.get('matchingStoredTransactions')][0]
 assert 'idempotencyKey already records a different transaction' in conflict['responseText']
 assert conflict['matchingStoredTransactions']==[GOLDEN['expense']]
 group('same-key changed field receives the original service conflict and preserves all entries and budget',nativeConflict=True)
 income=binding['newInteractiveIncome']
 income_values=[income['type'],str(income['amount']),income['currency'],income['date'],income['category'],income['note']]
 lost_path=RUN/'lost-ack-income.request.json'
 t=new_terminal('07-real-commit-lost-ack',lost_path,income_values)
 t.until('Recovery request saved at ')
 lost_bytes=lost_path.read_bytes();lost_request=json.loads(lost_bytes);terminal_review(t,lost_request)
 assert record_count()==4
 ACTIVE['dropNextRecord']=True
 t.send('RECORD');text=t.finish(3)
 assert 'UNCONFIRMED:' in text and 'Confirmed recording:' not in text and 'Do not create a replacement key' in text
 assert lost_path.read_bytes()==lost_bytes and not ACTIVE['dropNextRecord']
 assert record_count()==5
 after_lost=LEDGER.read_bytes();data=json.loads(after_lost);assert len(data['transactions'])==4
 lost_tx=next(x for x in data['transactions'] if x.get('idempotencyKey')==lost_request['transaction']['idempotencyKey'])
 assert {k:lost_tx[k] for k in lost_request['transaction']}==lost_request['transaction']
 assert data['transactions'][:-1]==json.loads(after_new)['transactions'] and data['budgets']==GOLDEN['ledger']['budgets']
 dropped=[x for x in STATE['requests'] if x.get('fault')]
 assert len(dropped)==1 and dropped[0]['matchingStoredTransactions']==[lost_tx]
 assert dropped[0]['recoveryBeforeForward']['sha256']==sha(lost_bytes)
 group('real native commit followed by lost downstream acknowledgement remains unconfirmed with one attempt and retained identity',nativeId=lost_tx['id'],attempts=1,fault=dropped[0]['fault'])
 t=resume_terminal('08-lost-ack-cancel-resume',lost_path);terminal_review(t,lost_request);t.send('cancel');t.finish(2)
 assert_preserved(after_lost,5)
 old_port=SERVICE.port;SERVICE.close();SERVICE=NativeService(old_port)
 st=LEDGER.stat().st_mtime_ns
 t=resume_terminal('09-lost-ack-confirm-after-restart',lost_path);terminal_review(t,lost_request);t.send('RECORD');recovered=confirmed(t.finish(0))
 assert recovered==lost_tx and LEDGER.read_bytes()==after_lost and LEDGER.stat().st_mtime_ns==st
 assert record_count()==6 and lost_path.read_bytes()==lost_bytes
 group('explicit recovery after native service restart returns the committed identity with no duplicate or file rewrite',nativeId=recovered['id'],ledgerSha=sha(after_lost),nativeRecordCalls=record_count(),mtimeNs=st)

 steady=LEDGER.read_bytes();calls=record_count();http_before=len(STATE['requests'])
 invalid_inputs=[
  ('zero',1,'0',6),('negative',1,'-7',2),('fractional',1,'1.25',2),('unsafe',1,'9007199254740992',6),
  ('direction',0,'transfer',6),('currency',2,'JP',6),('date',3,'2023-02-29',6),('category',4,'  ',6)]
 for name,index,value,fields in invalid_inputs:
  inputs=values.copy();inputs[index]=value;pbad=RUN/('invalid-input-'+name+'.request.json')
  t=new_terminal('10-input-'+name,pbad,inputs,fields=fields);text=t.finish(1)
  assert 'Recording refused:' in text and not pbad.exists();assert_preserved(steady,calls)
 assert len(STATE['requests'])==http_before
 group('eight invalid interactive inputs refuse before saving or making an MCP connection',cases=len(invalid_inputs))
 bads=[]
 base=json.loads(multiline_bytes)
 bads.append(('version',{**base,'version':2}))
 without_key=json.loads(multiline_bytes);without_key['transaction'].pop('idempotencyKey');bads.append(('missing-key',without_key))
 unnormalized=json.loads(multiline_bytes);unnormalized['transaction']['currency']='jpy';bads.append(('unnormalized',unnormalized))
 bads.append(('unknown-field',{**base,'recordNow':True}))
 outside={**base,'endpoint':'http://192.0.2.1:37611/mcp'};bads.append(('outside-loopback',outside))
 paths=[]
 for name,obj in bads:
  pbad=RUN/('invalid-recovery-'+name+'.json');dump(pbad,obj);paths.append((name,pbad))
 for name,data in [('json',b'{"version":'),('utf8',b'\xff\xfe'),('oversize',b'x'*65537)]:
  pbad=RUN/('invalid-recovery-'+name);pbad.write_bytes(data);paths.append((name,pbad))
 pdir=RUN/'invalid-recovery-directory';pdir.mkdir();paths.append(('directory',pdir))
 plink=RUN/'invalid-recovery-symlink';plink.symlink_to(multiline_path);paths.append(('symlink',plink))
 pfifo=RUN/'invalid-recovery-fifo';os.mkfifo(pfifo,0o600);paths.append(('fifo',pfifo))
 for name,pbad in paths:
  original=pbad.read_bytes() if pbad.is_file() and not pbad.is_symlink() else None
  t=resume_terminal('11-recovery-'+name,pbad);text=t.finish(1)
  assert 'Recording refused:' in text and 'Type RECORD' not in text
  if original is not None:assert pbad.read_bytes()==original
  assert_preserved(steady,calls)
 assert len(STATE['requests'])==http_before
 group('malformed, altered, unsupported, oversized and nonregular recovery requests refuse without a connection or replacement',cases=len(paths))
 existing=RUN/'existing-private-request.json';existing_bytes=b'Original recovery evidence <&> \xf0\x9f\x8c\x99\n';existing.write_bytes(existing_bytes)
 missing_parent=RUN/'absent-parent'/'request.json'
 for label,pbad in [('existing',existing),('missing-parent',missing_parent)]:
  t=new_terminal('12-save-failure-'+label,pbad,values);text=t.finish(1)
  assert 'Recording refused:' in text and 'Type RECORD' not in text
  assert_preserved(steady,calls)
 assert existing.read_bytes()==existing_bytes and not missing_parent.exists()
 assert len(STATE['requests'])==http_before
 group('recovery write failures stop before review/send and preserve an existing recovery file',cases=2)
 for label,endpoint in [('external','http://192.0.2.1:37611/mcp'),('query',ENDPOINT+'?ledger=other')]:
  pbad=RUN/('invalid-new-endpoint-'+label+'.json')
  t=new_terminal('13-endpoint-'+label,pbad,values,endpoint);text=t.finish(1)
  assert 'Recording refused:' in text and not pbad.exists();assert_preserved(steady,calls)
 t=Terminal('14-resume-endpoint-override',['resume','--request',str(lost_path),'--endpoint',ENDPOINT],lost_path)
 text=t.finish(1);assert 'resume requires only its saved request path' in text
 assert_preserved(steady,calls);assert len(STATE['requests'])==http_before
 group('new endpoint admission and resume override refusal prevent an unintended target',cases=3)
 t=resume_terminal('15-review-eof',lost_path);terminal_review(t,lost_request);t.eof();text=t.finish(2)
 assert 'Canceled; no record call.' in text;assert_preserved(steady,calls)
 argv=['/usr/bin/node',str(CANDIDATE/'dist/src/household-record.js'),'resume','--request',str(lost_path)]
 piped=subprocess.run(argv,input=b'RECORD\n',stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=CANDIDATE,timeout=10)
 (RUN/'16-piped-confirmation.stdout.log').write_bytes(piped.stdout);(RUN/'16-piped-confirmation.stderr.log').write_bytes(piped.stderr)
 assert piped.returncode==1 and b'interactive input and output terminal is required' in piped.stderr
 STATE['pipedRefusal']={'argv':argv,'exit':piped.returncode,'stdoutSha':sha(piped.stdout),'stderrSha':sha(piped.stderr)}
 assert_preserved(steady,calls);assert len(STATE['requests'])==http_before
 assert lost_path.read_bytes()==lost_bytes and multiline_path.read_bytes()==multiline_bytes
 assert not STATE['proxyErrors']
 group('actual terminal EOF and piped confirmation both cancel or refuse without another connection',recordCalls=calls)
 STATE['finalLedger']=snapshot(LEDGER);STATE['actualRecordRequests']=record_count();STATE['ok']=True
except BaseException as e:
 STATE['ok']=False;STATE['error']=repr(e);STATE['traceback']=traceback.format_exc()
finally:
 for p in CHILDREN:
  if p.poll() is None:
   p.terminate()
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:
    p.kill();p.wait(timeout=5);STATE.setdefault('ownedForcedKills',[]).append(p.pid)
 if SERVICE:
  try:SERVICE.close()
  except BaseException as e:STATE['serviceCloseError']=repr(e);STATE['ok']=False
 if PROXY:
  PROXY.shutdown();PROXY.server_close()
 for t_rec in STATE['terminals']:
  t_rec['pidPresentAfter']=pathlib.Path('/proc/'+str(t_rec['pid'])).exists()
 try:STATE['sourceAfter']=source_audit();STATE['sourceUnchanged']=True
 except BaseException as e:STATE['sourceAuditError']=repr(e);STATE['ok']=False
 STATE['ownedChildrenAfter']=[{'pid':p.pid,'exit':p.poll(),'present':pathlib.Path('/proc/'+str(p.pid)).exists()} for p in CHILDREN]
 STATE['completed']=now()
 if RUN.is_dir():dump(RUN/'receipt.json',STATE)
 print(json.dumps({'ok':STATE['ok'],'groups':STATE['groups'],'actualRecordRequests':STATE.get('actualRecordRequests'),'error':STATE.get('error'),'traceback':STATE.get('traceback'),'sourceUnchanged':STATE.get('sourceUnchanged'),'services':STATE['services'],'terminalChildren':len(STATE['terminals']),'completed':STATE['completed']},ensure_ascii=False),flush=True)
 if not STATE['ok']:sys.exit(1)
