import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createServer, request} from 'node:http';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {Client} from '/tmp/c36a60df2cc1-household-compare/worktree/node_modules/@modelcontextprotocol/sdk/dist/esm/client/index.js';
import {StreamableHTTPClientTransport} from '/tmp/c36a60df2cc1-household-compare/worktree/node_modules/@modelcontextprotocol/sdk/dist/esm/client/streamableHttp.js';

const root='/home/jacob/snap/chromium/common/hamon-household-entry-receiving-db371a37f4c8';
const run=path.join(root,'original-oracle-r1');
const source=path.join(root,'original-source');
const sha=b=>createHash('sha256').update(b).digest('hex');
const log={started:new Date().toISOString(),candidateSourceRead:false,groups:[],requests:[],calls:[]};
let server,serverExit,proxy,client,stdout='',stderr='';
const delay=ms=>new Promise(r=>setTimeout(r,ms));
const json=async(p,v)=>fs.writeFile(p,JSON.stringify(v,null,2)+'\n',{mode:0o600});
const file=async p=>{try{return await fs.readFile(p)}catch(e){if(e.code==='ENOENT')return null;throw e}};
const dataPath=path.join(run,'fixture-ledger.json');
async function assertSource(){
 const pins=JSON.parse(await fs.readFile(path.join(root,'original-source-pins.json'),'utf8'));
 for(const f of pins.files) assert.equal(sha(await fs.readFile(path.join(source,f.path))),f.sha256,f.path);
 return pins.files.length;
}
async function call(name,args,label){
 const before=await file(dataPath);
 const response=await client.callTool({name,arguments:args});
 const after=await file(dataPath);
 log.calls.push({label,name,args,response,beforeSha:before&&sha(before),afterSha:after&&sha(after)});
 return response;
}
function transaction(response){
 assert.notEqual(response.isError,true,JSON.stringify(response));
 const text=response.content.filter(c=>c.type==='text').map(c=>c.text).join('\n');
 return JSON.parse(text);
}
try {
 await fs.mkdir(run,{mode:0o700});
 log.sourceFilesBefore=await assertSource();
 const manual=JSON.parse(await fs.readFile(path.join(root,'manual-fixture.json'),'utf8'));
 const bind=x=>({type:x.type,amountMinor:x.amount,currency:x.currency,date:x.date,category:x.category,note:x.note,idempotencyKey:x.requestKey});
 const expense=bind(manual.expense),income=bind(manual.income);
 await json(path.join(run,'bound-inputs.json'),{expense,income,expectedExpense:{...expense,currency:'JPY',category:'Transport / 東京'},expectedIncome:income});
 const reserve=createServer();reserve.listen(0,'127.0.0.1');await once(reserve,'listening');
 const port=reserve.address().port;await new Promise(r=>reserve.close(r));
 const argv=[path.join(source,'dist/src/index.js')];
 server=spawn('/usr/bin/node',argv,{cwd:source,env:{...process.env,HOUSEHOLD_LEDGER_HOST:'127.0.0.1',HOUSEHOLD_LEDGER_PORT:String(port),HOUSEHOLD_LEDGER_DATA_PATH:dataPath},stdio:['ignore','pipe','pipe']});
 log.server={pid:server.pid,argv:['/usr/bin/node',...argv],host:'127.0.0.1',port,dataPath};
 serverExit=once(server,'exit').then(([code,signal])=>({code,signal,at:new Date().toISOString()}));
 server.stdout.on('data',b=>stdout+=b.toString());server.stderr.on('data',b=>stderr+=b.toString());
 for(let i=0;i<150 && !stdout.includes('listening on http://127.0.0.1:'+port);i++){
  assert.equal(server.exitCode,null,'native server exited before listening');await delay(50);
 }
 assert.ok(stdout.includes('listening on http://127.0.0.1:'+port),'native startup evidence missing');
 const health=await fetch('http://127.0.0.1:'+port+'/healthz');assert.equal(health.status,200);
 assert.deepEqual(await health.json(),{ok:true,service:'household-ledger-mcp'});
 proxy=createServer(async(req,res)=>{
  const chunks=[];for await(const b of req)chunks.push(b);const body=Buffer.concat(chunks);
  let payload;try{payload=JSON.parse(body.toString())}catch{}
  const entry={at:new Date().toISOString(),method:req.method,url:req.url,requestBytes:body.length,requestSha:sha(body),rpc:payload};
  log.requests.push(entry);
  const headers={...req.headers,host:'127.0.0.1:'+port};delete headers.connection;delete headers['transfer-encoding'];
  if(body.length)headers['content-length']=String(body.length);
  const upstream=request({host:'127.0.0.1',port,path:req.url,method:req.method,headers},response=>{
   const out=[];response.on('data',b=>out.push(b));response.on('end',()=>{
    const bytes=Buffer.concat(out);entry.status=response.statusCode;entry.responseBytes=bytes.length;entry.responseSha=sha(bytes);
    const h={...response.headers};delete h['transfer-encoding'];delete h.connection;
    res.writeHead(response.statusCode,h);res.end(bytes);
   });
  });
  upstream.on('error',e=>{entry.error=String(e);if(!res.headersSent)res.writeHead(502);res.end('owned proxy upstream failure');});
  upstream.end(body);
 });
 proxy.listen(0,'127.0.0.1');await once(proxy,'listening');
 log.endpoint='http://127.0.0.1:'+proxy.address().port+'/mcp';
 client=new Client({name:'root-household-original-oracle',version:'1.0.0'},{capabilities:{}});
 await client.connect(new StreamableHTTPClientTransport(new URL(log.endpoint)));
 assert.equal(await file(dataPath),null,'initial fixture unexpectedly exists');
 const txE=transaction(await call('record_transaction',expense,'manual-E1'));
 const expectedE={...expense,currency:'JPY',category:'Transport / 東京'};
 for(const [k,v] of Object.entries(expectedE))assert.deepEqual(txE[k],v,k);
 assert.match(txE.id,/^[a-f0-9-]{36}$/);assert.ok(Number.isFinite(Date.parse(txE.createdAt)));
 const ledgerE=await fs.readFile(dataPath);
 const txI=transaction(await call('record_transaction',income,'manual-I1'));
 for(const [k,v] of Object.entries(income))assert.deepEqual(txI[k],v,k);
 assert.notEqual(txE.id,txI.id);
 const both=JSON.parse(await fs.readFile(dataPath,'utf8'));
 assert.equal(both.transactions.length,2);assert.deepEqual(both.transactions[0],txE);assert.deepEqual(both.transactions[1],txI);
 log.groups.push({name:'native normalization, literal multiline note, leap date and two exact transactions',pass:true,expenseId:txE.id,incomeId:txI.id,firstLedgerSha:sha(ledgerE)});
 const budget=transaction(await call('set_budget',{category:'Reserved / 東京',month:'2026-10',limitMinor:1234,currency:'EUR'},'preserved-budget'));
 const withBudget=await fs.readFile(dataPath);
 assert.deepEqual(JSON.parse(withBudget).transactions,[txE,txI]);
 const stBefore=await fs.stat(dataPath,{bigint:true});
 const retry=transaction(await call('record_transaction',expense,'same-key-exact-retry'));
 assert.deepEqual(retry,txE);
 assert.deepEqual(await fs.readFile(dataPath),withBudget);
 const stAfter=await fs.stat(dataPath,{bigint:true});
 assert.equal(stAfter.mtimeNs,stBefore.mtimeNs);
 log.groups.push({name:'same-key exact retry preserves transaction object, native file bytes and modification time',pass:true,sha256:sha(withBudget),mtimeNs:String(stBefore.mtimeNs)});
 const conflicts=[
 ['amount',{...expense,amountMinor:2751}],
 ['note',{...expense,note:'different receipt'}],
 ['date',{...expense,date:'2026-10-09'}],
 ['currency',{...expense,currency:'USD'}]
 ];
 for(const [label,args]of conflicts){
  const response=await call('record_transaction',args,'same-key-conflict-'+label);
  assert.equal(response.isError,true);assert.match(response.content[0].text,/idempotencyKey already records a different transaction/);
  assert.deepEqual(await fs.readFile(dataPath),withBudget);
 }
 log.groups.push({name:'native same-key changed-field conflicts preserve both records and budget',pass:true,cases:conflicts.length});
 const missing={...expense};delete missing.category;
 const invalid=[
 ['zero',{...expense,amountMinor:0}],['negative',{...expense,amountMinor:-7}],
 ['fractional',{...expense,amountMinor:1.25}],['unsafe',{...expense,amountMinor:9007199254740992}],
 ['string-amount',{...expense,amountMinor:'2750'}],['type',{...expense,type:'transfer'}],
 ['currency',{...expense,currency:'JP'}],['nonexistent-day',{...expense,date:'2023-02-29'}],
 ['unformatted-date',{...expense,date:'2026-2-08'}],['missing-category',missing],
 ['empty-category',{...expense,category:'  '}],['empty-key',{...expense,idempotencyKey:''}],
 ['edge-space-key',{...expense,idempotencyKey:' key '}],['long-key',{...expense,idempotencyKey:'k'.repeat(129)}],
 ['nontext-note',{...expense,note:7}]
 ];
 for(const [label,args] of invalid){
  const response=await call('record_transaction',args,'invalid-'+label);
  assert.equal(response.isError,true,label);assert.deepEqual(await fs.readFile(dataPath),withBudget,label);
 }
 log.groups.push({name:'native admission refusals preserve all existing fixture state',pass:true,cases:invalid.length});
 await json(path.join(run,'golden.json'),{expenseInput:expense,incomeInput:income,expense:txE,income:txI,budget,ledger:JSON.parse(withBudget),ledgerSha256:sha(withBudget)});
 await fs.writeFile(path.join(run,'golden-ledger.json'),withBudget,{mode:0o600});
 const recordRequests=log.requests.filter(x=>x.rpc?.method==='tools/call' && x.rpc.params?.name==='record_transaction');
 assert.equal(recordRequests.length,22);
 log.actualRecordRequests=recordRequests.length;
 log.ok=true;
} catch(e){
 log.ok=false;log.error={name:e.name,message:e.message,stack:e.stack};
} finally {
 if(client)try{await client.close()}catch(e){log.clientCloseError=String(e);}
 if(proxy){proxy.closeIdleConnections();await new Promise(r=>proxy.close(r));}
 if(server){
  if(server.exitCode===null&&server.signalCode===null){server.kill('SIGTERM');log.serverShutdown='deliberate owned SIGTERM';}
  log.serverExit=await serverExit;
 }
 try{log.sourceFilesAfter=await assertSource();log.sourceUnchanged=true;}catch(e){log.ok=false;log.sourceAuditError=String(e);}
 log.stdout=stdout;log.stderr=stderr;log.completed=new Date().toISOString();
 await fs.writeFile(path.join(run,'server.stdout.log'),stdout);await fs.writeFile(path.join(run,'server.stderr.log'),stderr);
 await json(path.join(run,'receipt.json'),log);
 console.log(JSON.stringify({ok:log.ok,groups:log.groups,actualRecordRequests:log.actualRecordRequests,error:log.error,server:log.server,serverExit:log.serverExit,sourceUnchanged:log.sourceUnchanged,started:log.started,completed:log.completed}));
 process.exitCode=log.ok?0:1;
}
