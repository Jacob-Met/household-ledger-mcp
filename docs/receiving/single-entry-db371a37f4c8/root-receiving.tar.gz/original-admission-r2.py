import pathlib,json,hashlib,os,subprocess,datetime,shutil,sys,stat
root=pathlib.Path('/home/jacob/snap/chromium/common/hamon-household-entry-receiving-db371a37f4c8')
prod=pathlib.Path('/dev/shm/hamon-household-entry-db371a37f4c8-production')
donor=pathlib.Path('/tmp/c36a60df2cc1-household-compare/worktree/node_modules')
rec={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_read':False}
def sha(b): return hashlib.sha256(b).hexdigest()
def git(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
try:
    fs=shutil.disk_usage(root); ram=shutil.disk_usage('/dev/shm')
    rec['capacity']={'persistent_free':fs.free,'ram_free':ram.free}
    assert fs.free>30*1024*1024,'Insufficient guarded persistent capacity'
    assert root.stat().st_uid==os.getuid()
    rec['freeze_reconciliation']={}
    for fn,expected in [('CONTRACT.md','b6dc4f8c89d01d293bb0ef698a54d4ca6a82fd73beb417abe207bb1c144f533b'),('manual-fixture.json','e00103bc16ae06828a3d0950c72eed3124a4c509c1d3d9480acd213d1f3db009')]:
        b=(root/fn).read_bytes(); assert sha(b)==expected; rec['freeze_reconciliation'][fn]={'bytes':len(b),'sha256':sha(b),'git':git(b)}
    rec['freeze_receipt']=json.loads((root/'freeze-receipt.json').read_text())
    rec['freeze_process_present']=pathlib.Path('/proc/2188937').exists()
    pkt=json.loads((prod/'source-packet.json').read_text())
    assert pkt['base']=='591ab6f5a2d65bf596aeb707dbb635ee981ec926'
    assert pkt['tree']=='bf7d8bedaa3ed02665e56b021f543259b8c4a854'
    tree=pkt['fullTree']; assert not tree['truncated']
    rec['primary_full_tree_reported_sha']=tree['sha']
    all_entries=tree['tree']; nodes={}
    for e in all_entries:
        if e['type']!='tree':
            parts=e['path'].split('/'); d=nodes
            for part in parts[:-1]: d=d.setdefault(part,{})
            d[parts[-1]]=e
    computed={}
    def git_tree(d,path=''):
        entries=[]
        for name,value in d.items():
            if 'type' in value and value.get('type') in ['blob','commit']:
                mode=value['mode'].lstrip('0'); h=value['sha']; is_tree=False
            else:
                h=git_tree(value,path+'/'+name if path else name); mode='40000'; is_tree=True
            entries.append((name.encode()+ (b'/' if is_tree else b''),mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(h)))
        content=b''.join(v for k,v in sorted(entries,key=lambda x:x[0]))
        h=hashlib.sha1(b'tree '+str(len(content)).encode()+b'\0'+content).hexdigest();computed[path]=h;return h
    actual_tree=git_tree(nodes)
    rec['reconstructed_tree']=actual_tree
    assert actual_tree==pkt['tree'],('tree_mismatch',actual_tree,pkt['tree'])
    for e in all_entries:
        if e['type']=='tree': assert computed[e['path']]==e['sha'],('tree_node_mismatch',e['path'])
    rec['all_tree_nodes_match']=True
    leaves={x['path']:x for x in tree['tree'] if x['type']=='blob'}
    assert len(leaves)==116
    source=root/'original-source'; source.mkdir(mode=0o700)
    pins=[]
    for f in pkt['files']:
        p=f['path']; b=f['content'].encode()
        assert not pathlib.PurePosixPath(p).is_absolute() and '..' not in pathlib.PurePosixPath(p).parts
        assert len(b)==f['bytes'] and git(b)==f['git']==leaves[p]['sha']
        q=source/p; q.parent.mkdir(parents=True,exist_ok=True); q.write_bytes(b)
        pins.append({'path':p,'bytes':len(b),'git':git(b),'sha256':sha(b)})
    assert len(pins)==25
    lock=json.loads((source/'package-lock.json').read_text())
    deps=[]
    for package in ['typescript','@modelcontextprotocol/sdk','@types/node']:
        p=donor/package/'package.json'; b=p.read_bytes(); j=json.loads(b)
        key='node_modules/'+package
        assert j['version']==lock['packages'][key]['version'],(package,j['version'],lock['packages'][key]['version'])
        deps.append({'package':package,'version':j['version'],'package_json_path':str(p),'bytes':len(b),'sha256':sha(b),'lock_integrity':lock['packages'][key].get('integrity')})
    (source/'node_modules').symlink_to(donor,target_is_directory=True)
    (root/'original-source-pins.json').write_text(json.dumps({'base':pkt['base'],'tree':pkt['tree'],'full_tree_leaves':len(leaves),'files':pins},indent=2,ensure_ascii=False)+'\n')
    (root/'original-source-packet.json').write_text(json.dumps(pkt,indent=2,ensure_ascii=False)+'\n')
    rec['dependencies']=deps
    rec['source_files']=len(pins); rec['source_bytes']=sum(x['bytes'] for x in pins)
    rec['node']=subprocess.check_output(['/usr/bin/node','--version'],text=True).strip()
    rec['build_argv']=['/usr/bin/node',str(donor/'typescript/bin/tsc'),'-p',str(source/'tsconfig.json')]
    with (root/'original-build.log').open('wb') as log:
        run=subprocess.run(rec['build_argv'],cwd=source,stdout=log,stderr=subprocess.STDOUT,timeout=90)
    rec['build_exit']=run.returncode; assert run.returncode==0
    for f in pins:
        assert sha((source/f['path']).read_bytes())==f['sha256']
    compiled=[]
    for p in sorted((source/'dist').rglob('*')):
        if p.is_file():
            b=p.read_bytes(); compiled.append({'path':str(p.relative_to(source)),'bytes':len(b),'sha256':sha(b)})
    rec['compiled']=compiled; rec['source_unchanged']=True
    rec['completed']=datetime.datetime.now(datetime.timezone.utc).isoformat();rec['ok']=True
except BaseException as e:
    rec['ok']=False;rec['error']=repr(e);rec['traceback']=__import__('traceback').format_exc();rec['completed']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(root/'original-admission-r2-receipt.json').write_text(json.dumps(rec,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:v for k,v in rec.items() if k not in ['compiled','freeze_receipt']},ensure_ascii=False))
if not rec['ok']: sys.exit(1)
