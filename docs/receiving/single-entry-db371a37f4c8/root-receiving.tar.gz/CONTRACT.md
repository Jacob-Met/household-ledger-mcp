# Independent receiving contract: Household Ledger single-entry terminal client

Receiver: estate-db371a37f4c8/root.
Scope: Household Ledger issue #13, consuming the existing PR #8 ledger/MCP/store boundary.
Freeze: this contract and its manual inputs are written before root reads candidate source or author tests. Root has not inspected a candidate implementation. Canonical source names and protocol bindings will be read only after this freeze; any receiving correction must preserve this original record.

## Beneficiary and boundary

A person should be able to enter one income or expense, inspect every normalized native field and the exact intended local endpoint, deliberately confirm it, and recover an uncertain response by reviewing and retrying the same saved request identity. No other ledger, live account, external endpoint, schema, calculation, CSV workflow or owner-controlled state is in scope.

All execution will use newly created private fixture directories and an explicitly launched loopback instance of the unchanged existing native server/store. Never use a configured personal ledger or discover credentials. A transport fault may be introduced by an owned loopback intermediary, with the actual unchanged server processing the actual transaction.

## Manual semantic inputs

Expense E1:
- Native integer amount: 2750, with no inferred decimal or currency conversion.
- Currency input: jpy; expected normalized currency JPY.
- Category input: two leading and two trailing spaces around Transport / 東京; expected normalized category Transport / 東京.
- Date: 2026-10-08.
- Note: Late ride <&> 🌙, then one actual newline, then receipt 7. Preserve literal text.
- Fixed receiving request key when the interface admits one: root-entry-db371a37f4c8-expense-001. If the client generates its key, the generated exact key must be saved before any transaction request and reused unchanged.

Income I1:
- Native integer amount: 92500.
- Currency: USD.
- Category: Consulting & Lab.
- Date: 2024-02-29.
- Note: Paid invoice 東京.
- Separate request identity.

Candidate field names and argument syntax are not assumed. Bind these semantic inputs to the actual original API after source inspection, retaining this record. The independent baseline oracle is the unchanged original ledger/API behavior, never the candidate renderer or author fixture generator.

## Required observations

1. Establish original native admission, exact normalization and persistence for E1 and I1. Distinguish original API behavior from the missing terminal-client beneficiary. Preserve exact original source and input hashes before and after.
2. A review must expose type, exact integer amount, currency, category, date, literal note, saved request identity and intended endpoint in a form the user can assess before confirmation. Cancelling or refusing confirmation sends no transaction and changes no ledger bytes.
3. One explicit confirmed request creates exactly one native transaction with the expected fields. Its saved recovery request already exists when the first transaction is sent.
4. A repeated identical request key and fields returns the original native transaction identity and does not create another record. Compare native results and ledger bytes against the separately executed original boundary.
5. A changed amount or another consequential field under the same key must receive the original conflict disposition; the previously created transaction remains exact.
6. Simulate a lost acknowledgement after the real native commit. The first client invocation makes one transaction attempt, reports an uncertain outcome without inventing success or absence, and retains a readable recovery request. An explicit resume must display that same identity and all exact fields before confirmation. No automatic resend is allowed.
7. Confirming that resume reaches the unchanged native idempotency boundary and yields the existing transaction once; no duplicate ledger entry appears. A cancelled resume performs no additional transaction request.
8. Refuse invalid or ambiguous client input before a transaction whenever the original boundary requires refusal. Independent proposed controls include zero, negative, fractional and unsafe integer amounts; missing required text; unsupported type; malformed date; invalid saved request structure; unsupported recovery version; and an endpoint outside the admitted loopback policy. Record the original admissibility first rather than silently changing original semantics.
9. A recovery-file write failure must stop before transaction delivery. An unreadable, malformed, altered or conflicting recovery request must not silently become a new identity or overwrite prior recovery state. Preserve the relevant bytes and exact native error.
10. Exercise the installed native terminal process and its actual input/output, exit status, child lifecycle and persisted files. Unit or controlled-interface checks alone do not establish terminal usability. Parse or transport adaptations must be disclosed, with original failures preserved.

## Evidence and acceptance

Maintain a separate immutable original source closure, manual fixture file, native oracle output and before/after source proofs. Record actual argv without exposing unrelated environment or credentials. Count real server transaction requests at the existing boundary or intermediary; do not infer absence from an empty UI alone.

The original and candidate must use the same received native semantics. Any runtime correction requires a demonstrated failing original candidate and a focused corrected repeat. Stop optional replay once each concrete risk is resolved. Preserve exact raw failures and distinguish an observer or startup failure from a product result.

GitHub Actions remains held by Jacob's 19:32 UTC instruction, relayed at HAMON #143/comment6067592767. No push, PR creation/update that triggers Actions, merge, dispatch, rerun, workflow bypass or paid replacement is authorized here. Inert ownership comments require the current trigger audit. Qualified source and evidence may be preserved as immutable objects and in persistent native custody; hosted and integration gates remain separate.
