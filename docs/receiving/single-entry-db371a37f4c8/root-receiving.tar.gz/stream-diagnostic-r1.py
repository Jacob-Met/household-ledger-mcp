import pathlib,json,hashlib,os,sys,subprocess,datetime,time,socket,http.client,http.server,threading,pty,select,errno,traceback,stat,shutil,signal
ROOT=pathlib.Path('/home/jacob/snap/chromium/common/hamon-household-entry-receiving-db371a37f4c8')
RUN=ROOT/'stream-diagnostic-r1'
ORIGINAL=ROOT/'original-source'
CANDIDATE=ROOT/'candidate-r1-source'
os.umask(0o077)
STATE={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'groups':[],'requests':[],'terminals':[],'services':[],'proxyErrors':[]}
ACTIVE={'case':None,'path':None,'dropNextRecord':False}
CHILDREN=[]
SERVICE=None
PROXY=None
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,j):p.write_text(json.dumps(j,indent=2,ensure_ascii=False)+'\n')
def snapshot(p):
 try:
  b=p.read_bytes();s=p.stat()
  return {'bytes':len(b),'sha256':sha(b),'mtimeNs':s.st_mtime_ns,'mode':stat.S_IMODE(s.st_mode)}
 except FileNotFoundError:return None
def record_count():return sum(1 for x in STATE['requests'] if x.get('rpc',{}).get('method')=='tools/call' and x['rpc'].get('params',{}).get('name')=='record_transaction')
def source_audit():
 counts={}
 for label,folder,pinsname in [('original',ORIGINAL,'original-source-pins.json'),('candidate',CANDIDATE,'candidate-r1-pins.json')]:
  pins=json.loads((ROOT/pinsname).read_text())['files']
  for f in pins:assert sha((folder/f['path']).read_bytes())==f['sha256'],(label,f['path'])
  counts[label]=len(pins)
 return counts
class NativeService:
 def __init__(self,port=None):
  if port is None:
   with socket.socket() as reserve:
    reserve.bind(('127.0.0.1',0));port=reserve.getsockname()[1]
  self.port=port;self.index=len(STATE['services'])+1
  self.out=RUN/f'native-server-{self.index}.stdout.log';self.err=RUN/f'native-server-{self.index}.stderr.log'
  argv=['/usr/bin/node',str(ORIGINAL/'dist/src/index.js')]
  env=dict(os.environ,HOUSEHOLD_LEDGER_HOST='127.0.0.1',HOUSEHOLD_LEDGER_PORT=str(port),HOUSEHOLD_LEDGER_DATA_PATH=str(LEDGER))
  with self.out.open('wb') as o,self.err.open('wb') as e:self.p=subprocess.Popen(argv,cwd=ORIGINAL,env=env,stdin=subprocess.DEVNULL,stdout=o,stderr=e)
  CHILDREN.append(self.p)
  self.receipt={'pid':self.p.pid,'argv':argv,'port':port,'dataPath':str(LEDGER),'started':now()}
  STATE['services'].append(self.receipt)
  for _ in range(150):
   assert self.p.poll() is None,('native-server-early-exit',self.p.returncode,self.err.read_text())
   if f'listening on http://127.0.0.1:{port}' in self.out.read_text():break
   time.sleep(.05)
  else:raise AssertionError('native startup missing')
  c=http.client.HTTPConnection('127.0.0.1',port,timeout=3);c.request('GET','/healthz');r=c.getresponse();b=r.read();c.close()
  assert r.status==200 and json.loads(b)=={'ok':True,'service':'household-ledger-mcp'}
 def close(self):
  if self.p.poll() is None:self.p.terminate();self.receipt['shutdown']='deliberate owned SIGTERM'
  self.receipt['exit']=self.p.wait(timeout=5);self.receipt['completed']=now()

try:
 RUN.mkdir(mode=0o700)
 LEDGER=RUN/'fixture-ledger.json'
 original=(ROOT/'original-oracle-r1/golden-ledger.json').read_bytes();LEDGER.write_bytes(original)
 SERVICE=NativeService()
 connection=http.client.HTTPConnection('127.0.0.1',SERVICE.port,timeout=4)
 connection.request('GET','/mcp',headers={'Accept':'text/event-stream','MCP-Protocol-Version':'2025-11-25','Content-Length':'0'})
 response=connection.getresponse()
 STATE['originalGet']={'status':response.status,'headers':response.getheaders(),'candidateProcessStarted':False}
 try:
  data=response.read();STATE['originalGet']['completedBody']={'bytes':len(data),'sha256':sha(data)}
 except http.client.IncompleteRead as e:
  STATE['originalGet']['readError']={'type':'IncompleteRead','partialBytes':len(e.partial),'partialSha':sha(e.partial),'expected':e.expected,'traceback':traceback.format_exc()}
 finally:connection.close()
 assert response.status==200
 assert dict((k.lower(),v) for k,v in STATE['originalGet']['headers'])['content-type'].startswith('text/event-stream')
 assert STATE['originalGet'].get('readError',{}).get('partialBytes')==0,'did not reproduce exact original stream behavior'
 assert LEDGER.read_bytes()==original
 r1=json.loads((ROOT/'terminal-r1/receipt.json').read_text())
 errors=[x for x in r1['requests'] if x.get('error')]
 assert len(errors)==6
 assert all(x['method']=='GET' and x['path']=='/mcp' and x['rpc']=={} and x['error']=='IncompleteRead(0 bytes read)' for x in errors)
 posts=[x for x in r1['requests'] if x['method']=='POST']
 assert len(posts)==18 and all('error' not in x for x in posts)
 records=[x for x in posts if x.get('rpc',{}).get('method')=='tools/call' and x['rpc'].get('params',{}).get('name')=='record_transaction']
 assert len(records)==6 and all('status' in x for x in records)
 assert len(r1['terminals'])==34 and all(x.get('exit') in [0,1,2,3] and not x['pidPresentAfter'] for x in r1['terminals'])
 STATE['retainedR1Classification']={'receiptSha':sha((ROOT/'terminal-r1/receipt.json').read_bytes()),'unchangedOverallResult':r1['ok'],'incompleteBackgroundGetStreams':len(errors),'fullyReceivedPostResponses':len(posts),'nativeRecordRequests':len(records),'intentionalLostRecordAcknowledgements':sum(1 for x in records if x.get('fault')),'scope':'Original native GET stream closure reproduced without loading candidate. This does not relabel the retained R1 exit1; native transaction and terminal assertions remain exact.'}
 STATE['ok']=True
except BaseException as e:
 STATE['ok']=False;STATE['error']=repr(e);STATE['traceback']=traceback.format_exc()
finally:
 if SERVICE:SERVICE.close()
 STATE['ownedChildrenAfter']=[{'pid':p.pid,'exit':p.poll(),'present':pathlib.Path('/proc/'+str(p.pid)).exists()} for p in CHILDREN]
 STATE['completed']=now();dump(RUN/'receipt.json',STATE);print(json.dumps(STATE,ensure_ascii=False),flush=True)
 if not STATE['ok']:sys.exit(1)
