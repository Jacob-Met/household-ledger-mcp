import pathlib,json,hashlib,subprocess,datetime,shutil,os,sys
root=pathlib.Path('/home/jacob/snap/chromium/common/hamon-household-entry-receiving-db371a37f4c8')
prod=pathlib.Path('/dev/shm/hamon-household-entry-db371a37f4c8-production')
candidate=root/'candidate-r1-source'
rec={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parent':'591ab6f5a2d65bf596aeb707dbb635ee981ec926','candidate_runtime_read':True,'candidate_test_contents_read':False}
def sha(b):return hashlib.sha256(b).hexdigest()
try:
 rec['free_before']=shutil.disk_usage(root).free;assert rec['free_before']>15*1024*1024
 manifest_bytes=(prod/'candidate-source-pins-r1.json').read_bytes()
 assert sha(manifest_bytes)=='2997fb03586387cc9af8558c5920b6fd3036af7564ebba6a3ef24280c9dc005b'
 manifest=json.loads(manifest_bytes);assert len(manifest['files'])==99
 old=json.loads((root/'original-source-pins.json').read_text());oldpins={x['path']:x for x in old['files']}
 assert candidate.is_dir();sourcepins=[]
 for f in manifest['files']:
  p=f['path'];b=(prod/'candidate'/p).read_bytes();assert sha(b)==f['sha256'] and len(b)==f['bytes'],p
  if not p.startswith('dist/'):
   if p in oldpins:assert f['sha256']==oldpins[p]['sha256'],p
   else:assert p in manifest['newPaths'],p
   q=candidate/p;assert q.read_bytes()==b,p;sourcepins.append(f)
 assert len(sourcepins)==30 and len(manifest['newPaths'])==5
 donor=pathlib.Path('/tmp/c36a60df2cc1-household-compare/worktree/node_modules')
 assert (candidate/'node_modules').resolve()==donor.resolve()
 rec['compiled_basis']='Exact frozen author-compiled artifact; root candidate compile timed out before emission and is not claimed passed.'
 rec['native_root_candidate_build_gate']='unpassed; retained candidate-r2-artifact-admission.json and timeout investigation'
 for f in manifest['files']:
  if f['path'].startswith('dist/'):
   b=(prod/'candidate'/f['path']).read_bytes();assert sha(b)==f['sha256'];q=candidate/f['path'];q.parent.mkdir(parents=True,exist_ok=True);assert not q.exists();q.write_bytes(b)
 for f in manifest['files']:assert sha((candidate/f['path']).read_bytes())==f['sha256'],f['path']
 (root/'candidate-r1-pins.json').write_bytes(manifest_bytes)
 rec['original_files_exact']=25;rec['new_source_files']=5;rec['source_and_compiled_files_exact']=99
 manual=json.loads((root/'manual-fixture.json').read_text())
 variant=dict(manual['expense']);variant['note']='Late ride <&> 🌙 / receipt 7';variant.pop('requestKey')
 binding={'frozenAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'basis':'Independent contract and original native oracle already complete before candidate source read. CLI new documents a single-line note; this additive binding does not replace the frozen multiline expense.','fieldBinding':{'amount':'amountMinor','requestKey':'idempotencyKey'},'newInteractiveExpense':variant,'multilineExpense':'Use exact original native normalized E1 and original identity in a valid version1 recovery fixture; exercise through actual resume PTY.','newInteractiveIncome':{k:v for k,v in manual['income'].items() if k!='requestKey'},'endpointBinding':'Owned loopback proxy chooses actual ephemeral port after native unchanged server startup. Persist endpoint in fixtures before each terminal send.','negativeControls':['Zero, negative, fractional, unsafe integer and malformed required inputs according to original oracle','Existing recovery path refuses write without replacement before connection','Malformed JSON, invalid UTF8, version2, missing key, unnormalized value, unknown field, oversized and nonregular recovery refuse before send','Explicit endpoint outside admitted loopback policy refuses before connection','Lost acknowledgement only after real unchanged native service commit; explicit same-key resume reuses original record']}
 b=(json.dumps(binding,indent=2,ensure_ascii=False)+'\n').encode();(root/'candidate-interface-binding-r1.json').write_bytes(b)
 rec['binding']={'bytes':len(b),'sha256':sha(b)}
 rec['ok']=True
except BaseException as e:
 rec['ok']=False;rec['error']=repr(e);rec['traceback']=__import__('traceback').format_exc()
rec['completed']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(root/'candidate-r1-admission.json').write_text(json.dumps(rec,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(rec,ensure_ascii=False))
if not rec['ok']:sys.exit(1)
