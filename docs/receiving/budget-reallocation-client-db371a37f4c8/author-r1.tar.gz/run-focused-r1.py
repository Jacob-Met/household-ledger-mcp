from pathlib import Path
import os,json,subprocess,time,datetime,hashlib,shutil
r=Path('/dev/shm/hamon-household-reallocation-client-db371a37f4c8-production');d=r/'candidate';e=r/'evidence-author'
mem=int(next(s.split()[1] for s in Path('/proc/meminfo').read_text().splitlines() if s.startswith('MemAvailable:')))*1024
assert shutil.disk_usage(r).free>=256*1024**2 and mem>=2*1024**3
env=os.environ.copy();env['TMPDIR']=str(r/'tmp')
cmd=['node','--test','--test-concurrency=1','dist/test/reallocation-client.test.js','dist/test/reallocation-client-http.test.js']
start=time.time()
with (e/'focused-r1.stdout').open('wb') as out,(e/'focused-r1.stderr').open('wb') as err:
 try:p=subprocess.run(cmd,cwd=d,env=env,stdout=out,stderr=err,timeout=90);code=p.returncode;error=None
 except subprocess.TimeoutExpired:code=None;error='timeout90s'
receipt={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'cwd':str(d),'elapsed':time.time()-start,'exit':code,'error':error}
(e/'focused-r1.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));print((e/'focused-r1.stdout').read_text());print((e/'focused-r1.stderr').read_text())
