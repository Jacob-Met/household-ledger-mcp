from pathlib import Path
import subprocess,os,json,hashlib,time,shutil,datetime
r=Path('/dev/shm/hamon-household-reallocation-client-db371a37f4c8-production');e=r/'evidence-author';e.mkdir(exist_ok=True)
d=r/'candidate';pins=json.loads((r/'original-source-pins.json').read_text())
for f in pins['files']:assert hashlib.sha256((d/f['path']).read_bytes()).hexdigest()==f['sha256'],f['path']
mem=int(next(x.split()[1] for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
assert shutil.disk_usage(r).free>=256*1024**2 and mem>=2*1024**3
donor=Path('/tmp/c36a60df2cc1-household-compare/worktree/node_modules')
link=d/'node_modules'
if not link.exists():link.symlink_to(donor,target_is_directory=True)
assert link.resolve()==donor
(r/'tmp').mkdir(exist_ok=True)
env=os.environ.copy();env['TMPDIR']=str(r/'tmp')
start=time.time()
cmd=['node',str(donor/'typescript/bin/tsc')]
with (e/'compile-r1.stdout').open('wb') as out,(e/'compile-r1.stderr').open('wb') as err:
 try: p=subprocess.run(cmd,cwd=d,env=env,stdout=out,stderr=err,timeout=90);code=p.returncode;error=None
 except subprocess.TimeoutExpired:code=None;error='timeout90s'
result={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'cwd':str(d),'elapsed':time.time()-start,'exit':code,'error':error,'memoryAdmission':mem,'filesystemFreeAfter':shutil.disk_usage(r).free}
(e/'compile-r1.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));print((e/'compile-r1.stdout').read_text());print((e/'compile-r1.stderr').read_text())
