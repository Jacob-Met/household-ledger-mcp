from pathlib import Path
import os,json,subprocess,time,datetime,hashlib,shutil
r=Path('/dev/shm/hamon-household-reallocation-client-db371a37f4c8-production');d=r/'candidate';e=r/'evidence-author'
pins=json.loads((r/'candidate-source-pins-r1.json').read_text())
def verify():
 for f in pins['files']:assert hashlib.sha256((d/f['path']).read_bytes()).hexdigest()==f['sha256'],f['path']
verify()
mem=int(next(s.split()[1] for s in Path('/proc/meminfo').read_text().splitlines() if s.startswith('MemAvailable:')))*1024
admission={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'memory':mem,'free':shutil.disk_usage(r).free,'memoryFloor':1024**3,'scope':'five sequential Node cases, max-old-space-size128 MiB; no browser or compile. Earlier2GiB generic admission refusals retained, no assertion relaxed.'}
(e/'focused-r3-admission.json').write_text(json.dumps(admission,indent=2)+'\n')
if admission['free']<256*1024**2 or mem<1024**3:print('ADMISSION REFUSED',json.dumps(admission));raise SystemExit(2)
env=os.environ.copy();env['TMPDIR']=str(r/'tmp')
cmd=['node','--max-old-space-size=128','--test','--test-concurrency=1','dist/test/reallocation-client.test.js','dist/test/reallocation-client-http.test.js']
start=time.time()
with (e/'focused-r3.stdout').open('wb') as out,(e/'focused-r3.stderr').open('wb') as err:
 try:p=subprocess.run(cmd,cwd=d,env=env,stdout=out,stderr=err,timeout=90);code=p.returncode;error=None
 except subprocess.TimeoutExpired:code=None;error='timeout90s'
verify()
receipt={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'cwd':str(d),'elapsed':time.time()-start,'exit':code,'error':error,'exactSourceFiles':len(pins['files'])}
(e/'focused-r3.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));print((e/'focused-r3.stdout').read_text());print((e/'focused-r3.stderr').read_text())
raise SystemExit(0 if code==0 else 1)
