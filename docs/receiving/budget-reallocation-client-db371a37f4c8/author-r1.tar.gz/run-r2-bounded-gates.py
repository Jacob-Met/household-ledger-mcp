from pathlib import Path
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:comm=(p/'comm').read_text().strip()
 except OSError:continue
 assert comm not in ['cargo','rustc','rust-lld'], 'Concurrent Rust compiler; admission refused'
from pathlib import Path
import json,hashlib,shutil,os,subprocess,time,datetime
r=Path('/dev/shm/hamon-household-reallocation-client-db371a37f4c8-production');d=r/'candidate-r2';e=r/'evidence-author'
mem=int(next(s.split()[1] for s in Path('/proc/meminfo').read_text().splitlines() if s.startswith('MemAvailable:')))*1024
admission={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'memory':mem,'free':shutil.disk_usage(r).free,'buildFloor':1024**3,'scope':'One Node TypeScript compiler capped at256MiB heap; no Rust compiler at admission. Generic2GiB refusals preserved; no quality assertion changed.'}
(e/'compile-r5-admission.json').write_text(json.dumps(admission,indent=2)+'\n')
if admission['free']<256*1024**2 or mem<1024**3:print('ADMISSION REFUSED',json.dumps(admission));raise SystemExit(2)
env=os.environ.copy();env['TMPDIR']=str(r/'tmp')
def run(label,cmd):
 start=time.time()
 with (e/(label+'.stdout')).open('wb') as out,(e/(label+'.stderr')).open('wb') as err:
  try:p=subprocess.run(cmd,cwd=d,env=env,stdout=out,stderr=err,timeout=90);code=p.returncode;error=None
  except subprocess.TimeoutExpired:code=None;error='timeout90s'
 row={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'cwd':str(d),'elapsed':time.time()-start,'exit':code,'error':error}
 (e/(label+'.json')).write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True);print((e/(label+'.stdout')).read_text(),flush=True);print((e/(label+'.stderr')).read_text(),flush=True)
 return code
if run('compile-r5',['node','--max-old-space-size=256',str(d/'node_modules/typescript/bin/tsc')])!=0:raise SystemExit(1)
before=json.loads((r/'candidate-source-pins-r1.json').read_text())
for f in before['files']:
 assert hashlib.sha256((r/'candidate'/f['path']).read_bytes()).hexdigest()==f['sha256']
 if not (f['path'].startswith('test/reallocation-client') or f['path'].startswith('dist/test/reallocation-client')):
  assert hashlib.sha256((d/f['path']).read_bytes()).hexdigest()==f['sha256'],f['path']
files=[]
for p in sorted(d.rglob('*')):
 if p.is_file() and 'node_modules' not in p.parts:
  b=p.read_bytes();files.append({'path':str(p.relative_to(d)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'git':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()})
manifest={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'producer':before['producer'],'sourceRoot':str(d),'state':'candidate-r2; only author fixture corrections; all runtime/guide and producer artifacts identical to R1','files':files}
p=r/'candidate-source-pins-r2.json';assert not p.exists();p.write_text(json.dumps(manifest,indent=2)+'\n')
print('MANIFEST',len(p.read_bytes()),hashlib.sha256(p.read_bytes()).hexdigest(),len(files),flush=True)
mem=int(next(s.split()[1] for s in Path('/proc/meminfo').read_text().splitlines() if s.startswith('MemAvailable:')))*1024
if mem<1024**3 or shutil.disk_usage(r).free<256*1024**2:
 print('FOCUSED ADMISSION REFUSED',mem,flush=True);raise SystemExit(2)
code=run('focused-r5',['node','--max-old-space-size=128','--test','--test-concurrency=1','--test-name-pattern=actual MCP: review/cancel|real producer review','dist/test/reallocation-client.test.js','dist/test/reallocation-client-http.test.js'])
for f in files:assert hashlib.sha256((d/f['path']).read_bytes()).hexdigest()==f['sha256']
print('All109 current source and compiled files unchanged',flush=True);raise SystemExit(0 if code==0 else 1)
