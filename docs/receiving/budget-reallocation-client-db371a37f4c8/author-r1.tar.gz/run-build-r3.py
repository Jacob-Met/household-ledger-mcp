from pathlib import Path
import os,json,shutil,hashlib,datetime,subprocess,time
r=Path('/dev/shm/hamon-household-reallocation-client-db371a37f4c8-production');e=r/'evidence-author'
mem=int(next(s.split()[1] for s in Path('/proc/meminfo').read_text().splitlines() if s.startswith('MemAvailable:')))*1024
a={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'free':shutil.disk_usage(r).free,'memory':mem,'load':os.getloadavg()}
(e/'compile-r3-admission.json').write_text(json.dumps(a))
if a['free']<256*1024**2 or mem<2*1024**3:print('ADMISSION REFUSED',json.dumps(a));raise SystemExit(2)
d=r/'candidate';donor=Path('/tmp/c36a60df2cc1-household-compare/worktree/node_modules')
if not (d/'node_modules').exists():(d/'node_modules').symlink_to(donor,target_is_directory=True)
(r/'tmp').mkdir(exist_ok=True)
env=os.environ.copy();env['TMPDIR']=str(r/'tmp');cmd=['node',str(donor/'typescript/bin/tsc')];start=time.time()
with (e/'compile-r3.stdout').open('wb') as out,(e/'compile-r3.stderr').open('wb') as err:
 try:p=subprocess.run(cmd,cwd=d,env=env,stdout=out,stderr=err,timeout=90);code=p.returncode;error=None
 except subprocess.TimeoutExpired:code=None;error='timeout90s'
result={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'cwd':str(d),'elapsed':time.time()-start,'exit':code,'error':error}
(e/'compile-r3.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));print((e/'compile-r3.stdout').read_text());print((e/'compile-r3.stderr').read_text())
