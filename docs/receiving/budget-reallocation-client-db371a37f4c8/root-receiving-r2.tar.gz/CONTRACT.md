# Independent receiving contract — Household budget reallocation terminal consumer

Receiver: estate-db371a37f4c8/root. This contract is frozen before root reads the new consumer, its tests, or the producer implementation. The author identified an existing issue #11 producer and an exact native original closure; root will verify those pins and bind field names after this freeze. The work is private and provisional until current ownership is reconfirmed. Root has not read a reallocation candidate or producer API body.

## Manual beneficiary and oracle

A household deliberately moves a fixed integer allowance from one existing category to another for one month and one currency. The user must see literal category identities, original amounts, proposed amounts, unchanged group total, month and currency before one explicit commit. No money moves. Existing core ledger, Store, schemas, recording, CSV, month-copy, server hooks and other owners' producer implementation remain outside the consumer edit scope.

Manual fixture semantics, to be bound to the original API:
- Month 2026-10, currency USD.
- Source category Food / 東京: 12000 minor units.
- Destination category Rain reserve <&>: 3300 minor units.
- Explicit move: 2500 minor units.
- Expected source 9500 and destination 5800; selected pair total remains 15300.
- Unrelated same-month USD category Travel: 6000 remains exact.
- Same category Food / 東京 in JPY: 2000 remains exact.
- A separate month and existing transaction will remain exact.
- Literal names, raw native identity, integer units and any native normalized currency must be shown without inference or hidden conversion.

Run the unchanged producer/server first on newly created, private synthetic ledgers. The original preview/commit results and exact native bytes are the receiving oracle. Never use a configured personal ledger, external endpoint, live account or credential.

## Required receiving

1. Verify original native preview, exact transfer calculation, allowed/refused inputs, commit disposition and relevant stale-review behavior before using the consumer.
2. At the real installed terminal, choose the exact month/currency and existing source/destination identities, enter an integer amount, and inspect the complete server preview. No commit occurs before deliberate REALLOCATE. EOF, Ctrl-C or another response performs no commit and preserves ledger bytes.
3. One confirmed fresh preview makes one commit call and has the original native result, preserving unrelated categories, currency groups, months, transactions and native schema behavior.
4. Refuse invalid amounts, indices, same-category transfer, absent/unsupported inputs and unintended endpoints according to the original boundary. Preserve exact original refusals instead of inventing new producer semantics.
5. Change relevant native data after review using an actual independent process or supported original API. The prior review must not silently apply to the new state. Respect the original producer's stale/already-matching semantics; none is a durable retry identity.
6. Lose the response only after the actual unchanged producer commits. The consumer must report an uncertain outcome, make no automatic retry, and direct fresh current-state inspection. Never treat a review token, already-matching result or a repeated amount as durable idempotency. Any later action requires a new explicit review and confirmation.
7. Capture native PTY input/output, actual tool requests, exact saved ledger bytes, source pins before/after, child exits and complete failures. A forwarding observer must stream background MCP SSE and propagate client closure; do not buffer a long-lived GET until EOF.
8. Keep author qualification, independent receiving, final composed-source checks and integration separate. Actions-triggering ref/PR/merge operations remain held. Do not bypass or pass an unrun gate.

No candidate syntax is assumed by this contract. Record any interface binding after direct original-source inspection, preserving these manual values and this original freeze.
