import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import net from 'node:net';
import crypto from 'node:crypto';
import {spawn} from 'node:child_process';
import {Client} from '/tmp/c36a60df2cc1-household-compare/worktree/node_modules/@modelcontextprotocol/sdk/dist/esm/client/index.js';
import {StreamableHTTPClientTransport} from '/tmp/c36a60df2cc1-household-compare/worktree/node_modules/@modelcontextprotocol/sdk/dist/esm/client/streamableHttp.js';
const R='/home/jacob/snap/chromium/common/hamon-household-reallocation-receiving-db371a37f4c8',S=path.join(R,'original-r1-source'),O=path.join(R,'original-native-r1');
fs.mkdirSync(O,{mode:0o700});
const ledger=path.join(O,'ledger.json'),hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const write=(name,value)=>fs.writeFileSync(path.join(O,name),JSON.stringify(value,null,2)+'\n');
const rec={started:new Date().toISOString(),pid:process.pid,source:'unchanged original c83f0a6aee72df86eed17272ee8be6a79b7f941e',groups:[],calls:[],children:[],proxy:[]};
const seed={version:2,transactions:[{id:'root-reallocation-existing-001',type:'expense',amountMinor:850,currency:'USD',date:'2026-10-07',category:'Food / 東京',note:'Original <&> 🌙\nkeep exact',idempotencyKey:'root-reallocation-existing-key',createdAt:'2026-10-07T10:11:12.000Z'}],budgets:[
{category:'Food / 東京',month:'2026-10',limitMinor:12000,currency:'USD',ownerMarker:'keep source'},
{category:'Rain reserve <&>',month:'2026-10',limitMinor:3300,currency:'USD'},
{category:'Travel',month:'2026-10',limitMinor:6000,currency:'USD'},
{category:'Food / 東京',month:'2026-10',limitMinor:2000,currency:'JPY'},
{category:'Food / 東京',month:'2026-11',limitMinor:14000,currency:'USD'},
{category:'Legacy exact',month:'2026-10',limitMinor:500}],receivingMarker:{owner:'estate-db371a37f4c8',meaning:'private synthetic fixture; retain'}};
fs.writeFileSync(ledger,JSON.stringify(seed,null,2)+'\n',{mode:0o600});write('manual-seed.json',seed);
const args={month:'2026-10',currency:' usd ',fromCategory:'Food / 東京',toCategory:'Rain reserve <&>',amountMinor:2500};
const expected={schema:'household-budget-reallocation/1',month:'2026-10',currency:'USD',amountMinor:2500,totalMinor:15300,from:{category:'Food / 東京',beforeMinor:12000,afterMinor:9500},to:{category:'Rain reserve <&>',beforeMinor:3300,afterMinor:5800}};
expected.reviewToken=hash(JSON.stringify([expected.schema,expected.month,expected.currency,2500,15300,'Food / 東京',12000,9500,'Rain reserve <&>',3300,5800]));
write('manual-expected-review.json',expected);
const clients=[],children=[];let active,proxy,phase='setup';
const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
function snap(){const b=fs.readFileSync(ledger),st=fs.statSync(ledger,{bigint:true});return {sha256:hash(b),bytes:b.length,mtimeNs:st.mtimeNs.toString(),mode:Number(st.mode&0o777n),data:JSON.parse(b)};}
function stable(a,b){assert.equal(b.sha256,a.sha256);assert.equal(b.mtimeNs,a.mtimeNs);}
function sameExceptPair(before,after,fromLimit,toLimit){const e=structuredClone(before);e.budgets[0].limitMinor=fromLimit;e.budgets[1].limitMinor=toLimit;assert.deepEqual(after,e);}
async function port(){const s=net.createServer();await new Promise((resolve,reject)=>{s.once('error',reject);s.listen(0,'127.0.0.1',resolve);});const p=s.address().port;await new Promise(resolve=>s.close(resolve));return p;}
async function launch(label){
 const p=await port(),fd=fs.openSync(path.join(O,label+'.log'),'wx');
 const child=spawn('/usr/bin/node',[path.join(S,'dist/src/index.js')],{cwd:S,env:{...process.env,HOUSEHOLD_LEDGER_HOST:'127.0.0.1',HOUSEHOLD_LEDGER_PORT:String(p),HOUSEHOLD_LEDGER_DATA_PATH:ledger},stdio:['ignore',fd,fd]});fs.closeSync(fd);
 const row={label,pid:child.pid,port:p,argv:['/usr/bin/node',path.join(S,'dist/src/index.js')],configuredLedger:ledger};
 row.closed=new Promise(resolve=>child.once('close',(code,signal)=>{row.exitCode=code;row.signal=signal;resolve();}));
 child.once('error',e=>{row.error=String(e);});children.push({child,row});rec.children.push(row);
 for(let i=0;i<100;i++){if(child.exitCode!==null||child.signalCode!==null)throw Error('Native service exited during startup: '+label);try{const r=await fetch('http://127.0.0.1:'+p+'/healthz',{signal:AbortSignal.timeout(350)});if(r.ok){row.health=await r.json();return {child,row,port:p};}}catch{}await pause(75);}
 throw Error('Native service health deadline exceeded: '+label);
}
async function stop(server){if(!server||server.child.exitCode!==null||server.child.signalCode!==null)return;server.row.requestedStop='SIGTERM';server.child.kill('SIGTERM');await Promise.race([server.row.closed,pause(2500)]);if(server.child.exitCode===null&&server.child.signalCode===null){server.row.forcedStop='SIGKILL';server.child.kill('SIGKILL');await server.row.closed;}}
async function connect(p,label){const c=new Client({name:'root-reallocation-original-'+label,version:'1.0.0'},{capabilities:{}});const t=new StreamableHTTPClientTransport(new URL('http://127.0.0.1:'+p+'/mcp'),{requestInit:{redirect:'error'}});clients.push(c);await c.connect(t);return c;}
async function call(c,name,arguments_,errorExpected=false){
 const before=snap(),row={phase,name,arguments:structuredClone(arguments_),before};rec.calls.push(row);
 try{const result=await c.callTool({name,arguments:arguments_},undefined,{timeout:6000});row.result=result;row.after=snap();if(errorExpected){assert.equal(result.isError,true);stable(before,row.after);return result;}assert.ok(!result.isError,JSON.stringify(result));const texts=result.content.filter(x=>x.type==='text');assert.equal(texts.length,1);return JSON.parse(texts[0].text);}
 catch(e){row.exception=String(e);row.after=snap();throw e;}
}
function group(name,details={}){rec.groups.push({name,passed:true,...details});write('ledger-'+String(rec.groups.length).padStart(2,'0')+'.json',snap());}
async function resetPair(c){await call(c,'set_budget',{category:'Food / 東京',month:'2026-10',currency:'USD',limitMinor:12000});await call(c,'set_budget',{category:'Rain reserve <&>',month:'2026-10',currency:'USD',limitMinor:3300});}
async function startLossProxy(target){
 const state={armed:true,commitCalls:0,backgroundGets:0,closedGets:0,errors:[]};
 const p=http.createServer((req,res)=>{
  const pieces=[];req.on('data',b=>pieces.push(b));req.on('end',()=>{
   const body=Buffer.concat(pieces);let parsed;try{parsed=body.length?JSON.parse(body):null;}catch{parsed=null;}
   const row={method:req.method,path:req.url,request:parsed,requestBytes:body.length};rec.proxy.push(row);
   const isCommit=parsed?.method==='tools/call'&&parsed?.params?.name==='commit_budget_reallocation';if(isCommit)state.commitCalls++;
   const up=http.request({host:'127.0.0.1',port:target,path:req.url,method:req.method,headers:{...req.headers,host:'127.0.0.1:'+target}},ur=>{
    row.status=ur.statusCode;row.headers=ur.headers;
    if(req.method==='GET'){state.backgroundGets++;res.writeHead(ur.statusCode,ur.headers);ur.pipe(res);let closed=false;res.once('close',()=>{if(!closed){closed=true;state.closedGets++;row.clientClosed=true;}ur.destroy();up.destroy();});return;}
    const chunks=[];ur.on('data',b=>chunks.push(b));ur.on('end',()=>{
     const output=Buffer.concat(chunks);row.response=output.toString('utf8');row.responseBytes=output.length;row.ledgerAfterNativeResponse=snap();
     if(isCommit&&state.armed){state.armed=false;row.intentionallyLostAfterPersistence=true;res.destroy();return;}
     res.writeHead(ur.statusCode,ur.headers);res.end(output);
    });
   });
   up.on('error',e=>{row.upstreamError=String(e);if(!res.destroyed){state.errors.push(String(e));res.destroy();}});
   req.once('aborted',()=>up.destroy());if(body.length)up.write(body);up.end();
  });
 });
 await new Promise((resolve,reject)=>{p.once('error',reject);p.listen(0,'127.0.0.1',resolve);});
 return {server:p,port:p.address().port,state};
}
try{
 active=await launch('server-r1');let c=await connect(active.port,'main');
 phase='preview-and-applied';const before=snap(),list=await call(c,'get_budgets',{month:'2026-10',currency:' usd '});assert.deepEqual(list,seed.budgets.slice(0,3));
 const review=await call(c,'preview_budget_reallocation',args);assert.deepEqual(review,expected);stable(before,snap());
 const applied=await call(c,'commit_budget_reallocation',{review});assert.deepEqual(applied,{status:'applied',review:expected});sameExceptPair(seed,snap().data,9500,5800);
 group('literal normalized native preview and one persisted pair update',{review,applied,ledger:snap()});

 phase='already-matching';const committed=snap(),matching=await call(c,'commit_budget_reallocation',{review});assert.equal(matching.status,'already_matching');stable(committed,snap());group('current matching values cause no write',{status:matching.status});

 phase='old-review-is-not-durable';await resetPair(c);const restored=snap();const reapplied=await call(c,'commit_budget_reallocation',{review});assert.equal(reapplied.status,'applied');sameExceptPair(restored.data,snap().data,9500,5800);group('restoring before values lets an old valid digest apply again',{meaning:'No durable operation history or durable retry identity is inferred',status:reapplied.status});

 phase='stale-review';await resetPair(c);const staleReview=await call(c,'preview_budget_reallocation',args);const peer=await connect(active.port,'independent-writer');
 await call(peer,'set_budget',{category:'Food / 東京',month:'2026-10',currency:'USD',limitMinor:11999});const changed=snap();const stale=await call(c,'commit_budget_reallocation',{review:staleReview},true);stable(changed,snap());assert.match(stale.content[0].text,/reviewed budget limits changed/);group('actual supported independent writer invalidates selected limits',{refusal:stale});

 phase='unrelated-write';await resetPair(c);const fresh=await call(c,'preview_budget_reallocation',args);await call(peer,'set_budget',{category:'Travel',month:'2026-10',currency:'USD',limitMinor:6100});const unrelated=snap();const result=await call(c,'commit_budget_reallocation',{review:fresh});assert.equal(result.status,'applied');sameExceptPair(unrelated.data,snap().data,9500,5800);group('fresh Store commit preserves unrelated actual writes');

 phase='invalid-inputs';const invalid=[{...args,amountMinor:0},{...args,amountMinor:1.5},{...args,amountMinor:'2500'},{...args,amountMinor:Number.MAX_SAFE_INTEGER+1},{...args,amountMinor:999999},{...args,toCategory:args.fromCategory},{...args,fromCategory:' Food / 東京 '},{...args,month:'2026-13'},{...args,currency:''},{...args,fromCategory:'Legacy exact'},{...args,unrequested:true}];
 for(const a of invalid)await call(c,'preview_budget_reallocation',a,true);
 const bad1=structuredClone(review);bad1.from.afterMinor++;const bad2=structuredClone(review);delete bad2.reviewToken;const bad3=structuredClone(review);bad3.extra=true;
 for(const bad of [bad1,bad2,bad3])await call(c,'commit_budget_reallocation',{review:bad},true);
 group('native invalid request and altered review refusals preserve bytes and mtime',{previewCases:invalid.length,reviewCases:3});

 phase='lost-native-acknowledgement';await resetPair(c);const lossReview=await call(c,'preview_budget_reallocation',args),lossBefore=snap();proxy=await startLossProxy(active.port);const viaProxy=await connect(proxy.port,'lost-ack');
 let uncertainty;try{await call(viaProxy,'commit_budget_reallocation',{review:lossReview});}catch(e){uncertainty=String(e);}assert.ok(uncertainty,'the intentionally lost response must not return a confirmed result');await viaProxy.close();await pause(150);assert.equal(proxy.state.commitCalls,1);
 const response=rec.proxy.find(x=>x.intentionallyLostAfterPersistence);assert.ok(response);const dataLine=response.response.split(/\r?\n/).find(x=>x.startsWith('data:'));const envelope=JSON.parse(dataLine?dataLine.slice(5):response.response);assert.equal(JSON.parse(envelope.result.content[0].text).status,'applied');sameExceptPair(lossBefore.data,snap().data,9500,5800);
 const inspection=await call(c,'get_budgets',{month:'2026-10',currency:'USD'});assert.equal(inspection.find(x=>x.category==='Food / 東京').limitMinor,9500);assert.equal(inspection.find(x=>x.category==='Rain reserve <&>').limitMinor,5800);
 group('actual commit persists before acknowledgement loss; one call; independent fresh inspection',{uncertainty,commitCalls:proxy.state.commitCalls,proxyState:proxy.state,inspection});

 phase='restart-current-equality';const preRestart=snap();await c.close();await peer.close();await stop(active);active=await launch('server-r2');c=await connect(active.port,'after-restart');
 const afterRestart=await call(c,'commit_budget_reallocation',{review:lossReview});assert.equal(afterRestart.status,'already_matching');stable(preRestart,snap());group('new actual service observes the persisted current values without rewriting',{status:afterRestart.status,notDurableIdentity:true});await c.close();

 const sourcePins=JSON.parse(fs.readFileSync(path.join(R,'original-source-pins.json'),'utf8')),compiled=JSON.parse(fs.readFileSync(path.join(R,'original-r1-build-output-pins.json'),'utf8'));
 for(const f of [...sourcePins.files,...compiled])assert.equal(hash(fs.readFileSync(path.join(S,f.path))),f.sha256,f.path);
 rec.sourceFilesUnchanged=sourcePins.files.length;rec.compiledFilesUnchanged=compiled.length;rec.finalLedger=snap();rec.ok=true;
}catch(e){rec.ok=false;rec.error=String(e);rec.stack=e.stack;}
finally{
 for(const c of clients)try{await c.close();}catch{}
 if(proxy){proxy.server.closeAllConnections();await new Promise(resolve=>proxy.server.close(resolve));rec.proxyFinal=proxy.state;}
 for(const x of children)await stop(x);
 for(const row of rec.children){delete row.closed;row.absent=!fs.existsSync('/proc/'+row.pid);}
 rec.completed=new Date().toISOString();write('receipt.json',rec);const b=fs.readFileSync(path.join(O,'receipt.json'));
 console.log(JSON.stringify({ok:rec.ok,error:rec.error,groups:rec.groups.map(x=>x.name),calls:rec.calls.length,children:rec.children,proxyFinal:rec.proxyFinal,receiptBytes:b.length,receiptSha:hash(b),completed:rec.completed}));
}
if(!rec.ok)process.exitCode=1;
