from pathlib import Path
import os,json,hashlib,datetime,shutil
R=Path('/home/jacob/snap/chromium/common/hamon-household-reallocation-receiving-db371a37f4c8')
D=Path('/tmp/c36a60df2cc1-household-compare/worktree/node_modules')
h=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((R/'terminal-r2/receipt.json').read_text())
out={'time':datetime.datetime.now(datetime.UTC).isoformat(),'pid':os.getpid(),'r2Guard':r.get('guard'),'r2Closure':r['childClosure'],'nativeLogs':[],'load':os.getloadavg(),'diskFree':shutil.disk_usage(R).free,'mem':[x for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith(('MemAvailable:','SwapFree:'))]}
for p in (R/'terminal-r2').glob('native-server*log'):
 b=p.read_bytes();out['nativeLogs'].append({'path':str(p),'bytes':len(b),'sha256':h(b),'text':b.decode(errors='replace')})
files=[];links=[]
for p in sorted(D.rglob('*')):
 if p.is_symlink():links.append({'path':str(p.relative_to(D)),'target':os.readlink(p)})
 elif p.is_file():
  b=p.read_bytes();files.append({'path':str(p.relative_to(D)),'bytes':len(b),'sha256':h(b)})
previous=json.loads((R/'dependency-source-pins.json').read_text())
by={f['path']:f for f in files};selected=set()
for f in previous['files']:
 key=f['path'].removeprefix('node_modules/');selected.add(key)
 assert by[key]['bytes']==f['bytes'] and by[key]['sha256']==f['sha256'],key
omitted=[f for f in files if f['path'] not in selected]
manifest={'captured':datetime.datetime.now(datetime.UTC).isoformat(),'donor':str(D),'files':files,'links':links,'priorSelectedManifestSha256':h((R/'dependency-source-pins.json').read_bytes()),'priorSelectedFilesMatched':len(selected),'omittedRegularFileCount':len(omitted),'omittedRegularBytes':sum(f['bytes'] for f in omitted),'historicalLimit':'Earlier2960-file manifests were selected-file closures, not full installed dependency inventories. This new full capture does not retroactively pin the omitted files at earlier execution times.'}
b=(json.dumps(manifest,indent=2)+'\n').encode();p=R/'dependency-full-source-pins-r1.json'
if p.exists():assert p.read_bytes()==b
else:p.write_bytes(b)
out['fullDependencyInventory']={'path':str(p),'bytes':len(b),'sha256':h(b),'regularFiles':len(files),'regularBytes':sum(f['bytes'] for f in files),'links':links,'priorSelectedExact':len(selected),'newlyCaptured':len(omitted),'newlyCapturedBytes':sum(f['bytes'] for f in omitted)}
print(json.dumps(out,ensure_ascii=False,indent=2),flush=True)
