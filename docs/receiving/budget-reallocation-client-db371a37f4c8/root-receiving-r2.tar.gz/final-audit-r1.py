from pathlib import Path
import os,json,hashlib,datetime,subprocess,shutil,traceback,sys
R=Path('/home/jacob/snap/chromium/common/hamon-household-reallocation-receiving-db371a37f4c8')
A=Path('/home/jacob/snap/chromium/common/hamon-household-reallocation-client-db371a37f4c8-custody')
RUN=R/'final-audit-r1'
RUN.mkdir()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda kind,b:hashlib.sha1(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
rec={'started':now(),'pid':os.getpid(),'scope':'Independent final source/tree/patch/dependency/process custody audit; no behavior or compiler rerun'}
def save(path,value):
 b=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
 with path.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
def checkpins(base,entries):
 expected=set()
 for e in entries:
  p=base/e['path'];b=p.read_bytes();expected.add(e['path'])
  assert not p.is_symlink(),str(p)
  assert len(b)==e['bytes'] and sha(b)==e['sha256'],str(p)
  if 'git' in e:assert git('blob',b)==e['git'],str(p)
 actual=set()
 for d,dirs,files in os.walk(base,followlinks=False):
  dirs[:]=[n for n in dirs if not (Path(d)/n).is_symlink()]
  for n in files:actual.add((Path(d)/n).relative_to(base).as_posix())
 assert actual==expected,{'base':str(base),'extra':sorted(actual-expected),'missing':sorted(expected-actual)}
 return {'files':len(entries),'bytes':sum(e['bytes'] for e in entries),'actualSetExact':True}
def treehash(entries):
 root={}
 for e in entries:
  node=root;parts=e['path'].split('/')
  for part in parts[:-1]:node=node.setdefault(part,{})
  assert parts[-1] not in node,e['path']
  node[parts[-1]]=(e['mode'],e['type'],e['sha'])
 def build(node):
  records=[]
  for name,val in node.items():
   if isinstance(val,dict):mode,typ,h='40000','tree',build(val)
   else:mode,typ,h=val
   records.append((name.encode()+ (b'/' if typ=='tree' else b''),mode.lstrip('0').encode()+b' '+name.encode()+b'\0'+bytes.fromhex(h)))
  return git('tree',b''.join(x[1] for x in sorted(records,key=lambda x:x[0])))
 return build(root)
try:
 expected={
  'CONTRACT.md':'62dc69223ea51087557dc789bb48060538afba2503e70bd5852b8fbb8020a593',
  'original-source-pins.json':'2354d594296ec2e890505aa07d9e84105ab3f4d2f8781426b4efda7f6f19de9d',
  'candidate-r1-source-pins.json':'5d1b989a101dff8fed5c3ac254c29e407c6000e252dcf4059d2fe94a5f238e8d',
  'candidate-r2-source-pins.json':'0a9c93ee5792d3df8394e31969a35a7716d971a7d4748eb81b486e5aef4cfde4',
  'original-native-r1/receipt.json':'2040cf4e8b2cacc92efd3fa60283ae7ad48dbf6bb5954e9fb43091ff41e41ea5',
  'terminal-r1/receipt.json':'003751cca934b5473b91ca6f116ac15911487d4185d355e5467d0b0df996488e',
  'terminal-r2/receipt.json':'355cf8105051366c3f89790fb7d06564dc9dfafd908842fe1fb3d2fc81c18f58',
  'terminal-r3/receipt.json':'7451c4b5eb5ef72ae192c1f104087abddd8851bd48ba0a1f819d055298d35abc',
  'candidate-r3-full-dependency-build-receipt.json':'f0ab2e79d363be833898ad8d8ed717b22780143be973bffcf58a1c9bfa58b13e',
  'dependency-full-source-pins-r1.json':'5274e4b46eca7c11a4c894d7963f888852159c9276ec4a5c9a6ef4a02f7acd47'
 }
 for name,h in expected.items():assert sha((R/name).read_bytes())==h,name
 rec['frozenEvidenceExact']=expected
 original=json.loads((R/'original-source-pins.json').read_text())['files']
 outputs=json.loads((R/'original-r1-build-output-pins.json').read_text())
 r1=json.loads((R/'candidate-r1-source-pins.json').read_text())['files']
 final=json.loads((R/'candidate-r2-source-pins.json').read_text())['files']
 rec['sourceAudit']={}
 for name,entries in [('original-r1-source',original+outputs),('candidate-r1-source',r1),('candidate-r2-source',final),('candidate-r3-source-build',final)]:
  rec['sourceAudit'][name]=checkpins(R/name,entries)
 old={e['path']:e for e in r1};new={e['path']:e for e in final}
 diffs=[p for p in sorted(new) if old[p]['sha256']!=new[p]['sha256']]
 expected_diffs=['dist/test/reallocation-client-http.test.js','dist/test/reallocation-client-http.test.js.map','dist/test/reallocation-client.test.js','dist/test/reallocation-client.test.js.map','test/reallocation-client-http.test.ts','test/reallocation-client.test.ts']
 assert diffs==expected_diffs,diffs
 rec['authorR1ToR2OnlyFixtureDifferences']=diffs
 published=json.loads((R/'original-published-tree.json').read_text())
 assert published['truncated']==False
 leaves=[e for e in published['tree'] if e['type']!='tree']
 assert len(leaves)==120
 before_tree=treehash(leaves);assert before_tree=='f039e5d078827746c896e5e167ba95299e48cd17',before_tree
 published_by={e['path']:e for e in leaves}
 for e in original:assert published_by[e['path']]['sha']==e['git'],e['path']
 source=[e for e in final if not e['path'].startswith('dist/')]
 assert len(source)==31
 original_by={e['path']:e for e in original}
 additions=[e for e in source if e['path'] not in original_by]
 assert sorted(e['path'] for e in additions)==['docs/REALLOCATION_CLIENT.md','src/household-reallocate.ts','src/reallocation-client.ts','test/reallocation-client-http.test.ts','test/reallocation-client.test.ts']
 for e in source:
  if e['path'] in original_by:assert e['sha256']==original_by[e['path']]['sha256'],e['path']
  else:assert e['path'] not in published_by,e['path']
 newleaves=leaves+[{'path':e['path'],'mode':'100644','type':'blob','sha':e['git'],'size':e['bytes']} for e in additions]
 after_tree=treehash(newleaves);assert after_tree=='5b88c9f61af7db76ed3489f6be9a3e65d2214ffe',after_tree
 rec['trees']={'baseCommit':'c83f0a6aee72df86eed17272ee8be6a79b7f941e','baseTree':before_tree,'baseLeaves':120,'candidateTree':after_tree,'candidateLeaves':125,'original26Exact':True,'fiveAdditions':additions,'method':'Independent Git binary tree reconstruction from all120 original leaf modes/object IDs plus five native-hashed final sources; no root tree-header trust'}
 save(RUN/'full-product-tree-r2.json',{'tree':after_tree,'entries':sorted(newleaves,key=lambda e:e['path'])})
 patch=(A/'after-producer-r2.patch').read_bytes();assert len(patch)==32697 and sha(patch)=='bfdd32804d2b36e993caafdae6bb1f0b29d27884874c3ee133a8e3358ab926d4'
 (RUN/'after-producer-r2.patch').write_bytes(patch)
 copy=RUN/'patch-source';copy.mkdir()
 for e in original:
  dest=copy/e['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((R/'original-r1-source'/e['path']).read_bytes())
 rec['patch']={'bytes':len(patch),'sha256':sha(patch),'commands':[]}
 for extra in [['--check'],[]]:
  argv=['git','apply']+extra+[str(RUN/'after-producer-r2.patch')]
  cp=subprocess.run(argv,cwd=copy,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15)
  rec['patch']['commands'].append({'argv':argv,'cwd':str(copy),'exit':cp.returncode,'stdout':cp.stdout.decode(),'stderr':cp.stderr.decode()})
  assert cp.returncode==0,rec['patch']['commands'][-1]
 rec['patch']['result']=checkpins(copy,source)
 dep=json.loads((R/'dependency-full-source-pins-r1.json').read_text());donor=Path(dep['donor'])
 actual_files=set();actual_links={}
 for d,dirs,files in os.walk(donor,followlinks=False):
  for n in list(dirs):
   p=Path(d)/n
   if p.is_symlink():actual_links[p.relative_to(donor).as_posix()]=os.readlink(p);dirs.remove(n)
  for n in files:
   p=Path(d)/n;rel=p.relative_to(donor).as_posix()
   if p.is_symlink():actual_links[rel]=os.readlink(p)
   else:actual_files.add(rel)
 assert actual_files=={e['path'] for e in dep['files']}
 assert actual_links=={e['path']:e['target'] for e in dep['links']}
 for e in dep['files']:
  b=(donor/e['path']).read_bytes();assert len(b)==e['bytes'] and sha(b)==e['sha256'],e['path']
 rec['fullDependencyAudit']={'files':len(dep['files']),'regularBytes':sum(e['bytes'] for e in dep['files']),'links':dep['links'],'actualCompleteSetExact':True,'manifestSha256':sha((R/'dependency-full-source-pins-r1.json').read_bytes()),'earlierManifestLimit':dep['historicalLimit']}
 pids={2803467,2827876,2839439,2844659,2844779,2844857,2927958,2928058,2928096,2928177,2928217,2928706,2964157,2964294,3003968,3007486,3007993,3071084,3077076,3077157}
 for name in ['terminal-r1/receipt.json','terminal-r2/receipt.json','terminal-r3/receipt.json']:
  v=json.loads((R/name).read_text())
  for c in v.get('childClosure',[]):pids.add(c['pid'])
 absent=[pid for pid in sorted(pids) if not Path('/proc/'+str(pid)).exists()]
 assert len(absent)==len(pids),sorted(pids-set(absent))
 # Inspect only process namespace markers owned by this packet; read errors for unrelated processes are not authority.
 owned=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit() or int(p.name)==os.getpid():continue
  try:
   cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
  except (OSError,PermissionError):continue
  if str(R) in cmd and ('original-r1-source/dist/src/index.js' in cmd or 'dist/src/household-reallocate.js' in cmd or 'terminal-receiving-' in cmd or 'typescript/bin/tsc' in cmd):
   owned.append({'pid':int(p.name),'cmd':cmd})
 assert not owned,owned
 rec['processClosure']={'knownOwnedPidsAbsent':absent,'namespaceProductOrFixtureProcesses':owned,'note':'Historic native child exits are in immutable run receipts. R2 and some transport wrapper exits were unobserved; present absence does not invent them.'}
 rec['ok']=True
except Exception as e:
 rec['ok']=False;rec['error']=repr(e);rec['traceback']=traceback.format_exc()
finally:
 rec['completed']=now();save(RUN/'receipt.json',rec)
 print(json.dumps({'ok':rec['ok'],'path':str(RUN/'receipt.json'),'sha256':sha((RUN/'receipt.json').read_bytes()),'bytes':(RUN/'receipt.json').stat().st_size,'summary':{k:rec.get(k) for k in ['trees','patch','fullDependencyAudit','processClosure','error']}},ensure_ascii=False),flush=True)
sys.exit(0 if rec['ok'] else 1)
