import pathlib,json,hashlib,os,sys,subprocess,datetime,time,socket,http.client,http.server,threading,pty,select,errno,traceback,stat,shutil,signal,fcntl,termios
ROOT=pathlib.Path('/home/jacob/snap/chromium/common/hamon-household-reallocation-receiving-db371a37f4c8')
RUN=ROOT/'terminal-r3'
ORIGINAL=ROOT/'original-r1-source'
CANDIDATE=ROOT/'candidate-r2-source'
os.umask(0o077)
# Atomic run directory admission outside error-finalization prevents uncertain duplicate launches from overwriting evidence.
RUN.mkdir(mode=0o700)
STATE={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'groups':[],'requests':[],'terminals':[],'services':[],'proxyErrors':[]}
ACTIVE={'case':None,'path':None,'dropNextCommit':False}
CHILDREN=[]
TERMINALS=[]
SERVICE=None
PROXY=None
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,j):p.write_text(json.dumps(j,indent=2,ensure_ascii=False)+'\n')
def snapshot(p):
 try:
  b=p.read_bytes();s=p.stat()
  return {'bytes':len(b),'sha256':sha(b),'mtimeNs':s.st_mtime_ns,'mode':stat.S_IMODE(s.st_mode)}
 except FileNotFoundError:return None
def commit_count():return sum(1 for x in STATE['requests'] if x.get('rpc',{}).get('method')=='tools/call' and x['rpc'].get('params',{}).get('name')=='commit_budget_reallocation')
def source_audit():
 counts={}
 for label,folder,pinsname in [('original',ORIGINAL,'original-source-pins.json'),('candidate',CANDIDATE,'candidate-r2-source-pins.json')]:
  pins=json.loads((ROOT/pinsname).read_text())['files']
  for f in pins:assert sha((folder/f['path']).read_bytes())==f['sha256'],(label,f['path'])
  counts[label]=len(pins)
 return counts
class NativeService:
 def __init__(self,port=None):
  if port is None:
   with socket.socket() as reserve:
    reserve.bind(('127.0.0.1',0));port=reserve.getsockname()[1]
  startup_started=time.monotonic()
  self.port=port;self.index=len(STATE['services'])+1
  self.out=RUN/f'native-server-{self.index}.stdout.log';self.err=RUN/f'native-server-{self.index}.stderr.log'
  argv=['/usr/bin/node',str(ORIGINAL/'dist/src/index.js')]
  env=dict(os.environ,HOUSEHOLD_LEDGER_HOST='127.0.0.1',HOUSEHOLD_LEDGER_PORT=str(port),HOUSEHOLD_LEDGER_DATA_PATH=str(LEDGER))
  with self.out.open('wb') as o,self.err.open('wb') as e:self.p=subprocess.Popen(argv,cwd=ORIGINAL,env=env,stdin=subprocess.DEVNULL,stdout=o,stderr=e)
  CHILDREN.append(self.p)
  self.receipt={'pid':self.p.pid,'argv':argv,'port':port,'dataPath':str(LEDGER),'started':now()}
  STATE['services'].append(self.receipt)
  for _ in range(600):
   assert self.p.poll() is None,('native-server-early-exit',self.p.returncode,self.err.read_text())
   if f'listening on http://127.0.0.1:{port}' in self.out.read_text():break
   time.sleep(.05)
  else:raise AssertionError('native startup missing')
  c=http.client.HTTPConnection('127.0.0.1',port,timeout=3);c.request('GET','/healthz');r=c.getresponse();b=r.read();c.close()
  assert r.status==200 and json.loads(b)=={'ok':True,'service':'household-ledger-mcp'}
  self.receipt['startupSeconds']=round(time.monotonic()-startup_started,6)
  self.receipt['startupObserverLimitSeconds']=30
 def close(self):
  if self.p.poll() is None:self.p.terminate();self.receipt['shutdown']='deliberate owned SIGTERM'
  self.receipt['exit']=self.p.wait(timeout=5);self.receipt['completed']=now()

def wire_result(data):
 text=data.decode('utf8')
 lines=[x[5:].strip() for x in text.splitlines() if x.startswith('data:')]
 wire=json.loads(lines[-1] if lines else text)
 content=wire.get('result',{}).get('content',[])
 if len(content)==1 and content[0].get('type')=='text':
  try:result=json.loads(content[0]['text'])
  except ValueError:result=content[0]['text']
 else:result=None
 return wire,result
def changed_wire(data,wire):
 raw=json.dumps(wire,ensure_ascii=False,separators=(',',':'))
 return (('event: message\ndata: '+raw+'\n\n') if any(x.startswith('data:') for x in data.decode('utf8').splitlines()) else raw).encode()
def own_controlling_tty():
 os.setsid()
 fcntl.ioctl(0,termios.TIOCSCTTY,0)

class Forwarder(http.server.BaseHTTPRequestHandler):
 protocol_version='HTTP/1.1'
 def log_message(self,*args):pass
 def do_GET(self):self.forward()
 def do_POST(self):self.forward()
 def do_DELETE(self):self.forward()
 def forward(self):
  entry={'at':now(),'case':ACTIVE['case'],'method':self.command,'path':self.path}
  upstream=None
  try:
   body=self.rfile.read(int(self.headers.get('Content-Length','0')))
   try:rpc=json.loads(body)
   except (ValueError,UnicodeDecodeError):rpc={}
   entry.update({'rpc':rpc,'requestBytes':len(body),'requestSha':sha(body)})
   is_commit=rpc.get('method')=='tools/call' and rpc.get('params',{}).get('name')=='commit_budget_reallocation'
   if is_commit:
    entry['ledgerBeforeForward']=snapshot(LEDGER)
    entry['ledgerBeforeData']=json.loads(LEDGER.read_bytes())
   STATE['requests'].append(entry)
   if ACTIVE.get('fault')=='redirect':
    entry['observerFault']='307 redirect before native forward';entry['nativeForwarded']=False
    self.send_response(307);self.send_header('Location',STATE['redirectTarget']);self.send_header('Content-Length','0');self.end_headers();return
   headers={k:v for k,v in self.headers.items() if k.lower() not in ['host','connection','transfer-encoding','content-length']}
   headers['Host']=f'127.0.0.1:{SERVICE.port}';headers['Content-Length']=str(len(body))
   upstream=http.client.HTTPConnection('127.0.0.1',SERVICE.port,timeout=20)
   upstream.request(self.command,self.path,body=body,headers=headers)
   r=upstream.getresponse()
   entry['status']=r.status;entry['upstreamHeaders']=r.getheaders()
   if self.command=='GET' and r.status==200 and (r.getheader('Content-Type') or '').startswith('text/event-stream'):
    self.send_response(r.status)
    for k,v in r.getheaders():
     if k.lower() not in ['connection','date','server']:self.send_header(k,v)
    self.end_headers();self.wfile.flush()
    raw_hash=hashlib.sha256();raw_count=0;deadline=time.monotonic()+25
    while True:
     ready,_,_=select.select([self.connection,r.fp],[],[],.05)
     if self.connection in ready:
      peek=self.connection.recv(1,socket.MSG_PEEK)
      if not peek:
       entry['streamClose']='downstream SDK closed; upstream closed in finally';break
      raise AssertionError('unexpected pipelined bytes on SSE connection')
     if r.fp in ready:
      raw=r.fp.read1(65536)
      if not raw:
       entry['streamClose']='upstream EOF';break
      raw_hash.update(raw);raw_count+=len(raw);self.wfile.write(raw);self.wfile.flush()
     if time.monotonic()>deadline:raise TimeoutError('owned SSE observer exceeded bounded lifetime')
    entry['rawStreamBytes']=raw_count;entry['rawStreamSha']=raw_hash.hexdigest()
    self.close_connection=True;return
   data=r.read();entry.update({'status':r.status,'responseBytes':len(data),'responseSha':sha(data),'responseText':data.decode('utf8','replace')})
   if is_commit:
    entry['ledgerAfterUpstream']=snapshot(LEDGER)
    entry['ledgerAfterData']=json.loads(LEDGER.read_bytes())
    wire,result=wire_result(data);entry['nativeResult']=result
   if is_commit and ACTIVE['dropNextCommit']:
    assert entry['nativeResult']['status']=='applied','actual producer did not report applied'
    reviewed=rpc['params']['arguments']['review']
    for side in ['from','to']:
     row=next(x for x in entry['ledgerAfterData']['budgets'] if x['category']==reviewed[side]['category'] and x['month']==reviewed['month'] and x.get('currency','').strip().upper()==reviewed['currency'])
     assert row['limitMinor']==reviewed[side]['afterMinor'],'actual original persistence missing before acknowledgement loss'
    entry['fault']='actual unchanged producer applied; full upstream reply and exact stored pair verified; downstream socket closed before any headers'
    ACTIVE['dropNextCommit']=False;entry['faultAt']=now()
    self.close_connection=True
    try:self.connection.shutdown(socket.SHUT_RDWR)
    except OSError:pass
    self.connection.close();return
   tool=rpc.get('params',{}).get('name')
   if (ACTIVE.get('fault')=='bad_preview_token' and tool=='preview_budget_reallocation') or (ACTIVE.get('fault')=='bad_commit_ack' and tool=='commit_budget_reallocation'):
    wire,result=wire_result(data)
    if ACTIVE['fault']=='bad_preview_token':result['reviewToken']='0'*64
    else:result['review']['from']['afterMinor']+=1
    wire['result']['content'][0]['text']=json.dumps(result,ensure_ascii=False,separators=(',',':'))
    data=changed_wire(data,wire);entry['observerFault']=ACTIVE['fault'];entry['deliveredResponseText']=data.decode('utf8');entry['deliveredResponseSha']=sha(data)
   self.send_response(r.status)
   for k,v in r.getheaders():
    if k.lower() not in ['transfer-encoding','connection','content-length']:self.send_header(k,v)
   self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
  except BaseException as e:
   entry['error']=repr(e);STATE['proxyErrors'].append({'case':entry['case'],'error':repr(e),'traceback':traceback.format_exc()})
   self.close_connection=True
  finally:
   if upstream:upstream.close()
class Terminal:
 def __init__(self,label,args,path=None):
  ACTIVE['case']=label;ACTIVE['path']=str(path) if path else None
  self.label=label;self.raw=bytearray();self.cursor=0
  self.master,slave=pty.openpty()
  argv=['/usr/bin/node',str(CANDIDATE/'dist/src/household-reallocate.js')]+args
  self.p=subprocess.Popen(argv,cwd=CANDIDATE,stdin=slave,stdout=slave,stderr=slave,preexec_fn=own_controlling_tty,close_fds=True)
  os.close(slave);CHILDREN.append(self.p)
  self.receipt={'label':label,'pid':self.p.pid,'argv':argv,'started':now(),'events':[]}
  STATE['terminals'].append(self.receipt);self.closed=False;TERMINALS.append(self)
 def pump(self,seconds=.1):
  ready,_,_=select.select([self.master],[],[],seconds)
  if ready:
   try:b=os.read(self.master,65536)
   except OSError as e:
    if e.errno==errno.EIO:return False
    raise
   if b:self.raw.extend(b);return True
  return False
 def until(self,text,timeout=12):
  needle=text.encode();deadline=time.monotonic()+timeout
  while needle not in self.raw[self.cursor:]:
   self.pump(.05)
   if self.p.poll() is not None and needle not in self.raw[self.cursor:]:
    self.pump(0);raise AssertionError((self.label,'exited before prompt',text,self.p.returncode,self.raw.decode('utf8','replace')))
   if time.monotonic()>deadline:raise AssertionError((self.label,'timeout',text,self.raw.decode('utf8','replace')))
  i=self.raw.find(needle,self.cursor);self.cursor=i+len(needle)
  self.receipt['events'].append({'at':now(),'observed':text,'byteOffset':i})
  return self.text()
 def text(self):return self.raw.decode('utf8','strict').replace('\r\n','\n')
 def send(self,line):
  os.write(self.master,(line+'\n').encode())
  self.receipt['events'].append({'at':now(),'input':line})
 def eof(self):os.write(self.master,b'\x04');self.receipt['events'].append({'at':now(),'inputControl':'EOF'})
 def finish(self,expected,timeout=22):
  deadline=time.monotonic()+timeout
  while self.p.poll() is None:
   self.pump(.05)
   if time.monotonic()>deadline:raise AssertionError((self.label,'did not exit',self.text()))
  while self.pump(0):pass
  code=self.p.wait();self.receipt['exit']=code;self.receipt['completed']=now()
  self.receipt['transcriptSha']=sha(self.raw);self.receipt['transcriptBytes']=len(self.raw)
  (RUN/(self.label+'.pty.log')).write_bytes(self.raw)
  dump(RUN/(self.label+'.terminal.json'),self.receipt)
  os.close(self.master);self.closed=True
  assert code==expected,(self.label,'exit',code,expected,self.text())
  return self.text()

def commits():return commit_count()
def stable(before):
 assert snapshot(LEDGER)==before,('ledger bytes/mtime/mode changed',before,snapshot(LEDGER))
def baseline():
 LEDGER.write_bytes(BASE)
def expected_review(fb=12000,tb=3300,amount=2500):
 r={'schema':'household-budget-reallocation/1','month':'2026-10','currency':'USD','amountMinor':amount,'totalMinor':fb+tb,'from':{'category':'Food / 東京','beforeMinor':fb,'afterMinor':fb-amount},'to':{'category':'Rain reserve <&>','beforeMinor':tb,'afterMinor':tb+amount}}
 r['reviewToken']=sha(json.dumps([r['schema'],r['month'],r['currency'],amount,fb+tb,r['from']['category'],fb,fb-amount,r['to']['category'],tb,tb+amount],ensure_ascii=False,separators=(',',':')).encode())
 return r
PROMPTS=['Month (YYYY-MM): ','Three-letter currency: ','Move allowance FROM budget number: ','Move allowance TO budget number: ','Amount in positive INTEGER minor units: ']
CONFIRM='Type REALLOCATE to commit this exact review once; anything else cancels: '
def begin(label,values=None,endpoint=None,fields=5):
 ACTIVE.update({'case':label,'path':None,'dropNextCommit':False,'fault':None})
 t=Terminal(label,['--endpoint',endpoint or ENDPOINT])
 t.endpoint=endpoint or ENDPOINT
 values=values or ['2026-10',' usd ','1','2','2500']
 for prompt,value in zip(PROMPTS[:fields],values[:fields]):t.until(prompt);t.send(value)
 return t
def review(t,expected):
 t.until(CONFIRM)
 text=t.text()
 marker='Review monthly budget allowance (integer minor units; no money or transaction changes):\n'
 start=text.index(marker)
 lines=text[start:].split(CONFIRM)[0].splitlines()[1:]
 fields={}
 for line in lines:
  if line.startswith('The token is '):break
  key,value=line.strip().split(': ',1);fields[key]=json.loads(value)
 assert fields.pop('endpoint')==t.endpoint
 assert fields==expected,('complete review differs from original oracle',fields,expected)
 t.receipt['review']=fields;t.receipt['foregroundProcessGroup']=os.tcgetpgrp(t.master)
 assert os.tcgetpgrp(t.master)==t.p.pid,'PTY is not controlling the candidate process group'
 return fields
def interrupt(t):
 assert os.tcgetpgrp(t.master)==t.p.pid
 os.write(t.master,b'\x03')
 t.receipt['events'].append({'at':now(),'inputControl':'actual Ctrl-C byte 0x03 to foreground terminal group','foregroundGroup':t.p.pid})
def applied(text):
 line=next(x for x in text.splitlines() if x.startswith('Applied the reviewed pair of limits. '))
 return json.loads(line.removeprefix('Applied the reviewed pair of limits. '))
def pair_only(before,from_limit,to_limit):
 expect=json.loads(before);expect['budgets'][0]['limitMinor']=from_limit;expect['budgets'][1]['limitMinor']=to_limit
 assert json.loads(LEDGER.read_bytes())==expect
def mutate(label,kind):
 argv=['/usr/bin/node',str(ROOT/'native-fixture-change-r3.mjs'),str(LEDGER),kind]
 p=subprocess.Popen(argv,cwd=ORIGINAL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 CHILDREN.append(p);out,err=p.communicate(timeout=12)
 (RUN/(label+'.writer.stdout.log')).write_bytes(out);(RUN/(label+'.writer.stderr.log')).write_bytes(err)
 assert p.returncode==0,(label,p.returncode,err)
 STATE.setdefault('independentWriters',[]).append({'label':label,'argv':argv,'pid':p.pid,'exit':p.returncode,'stdoutSha':sha(out),'stderrSha':sha(err),'source':'unchanged original LedgerStore/setBudget API in another actual process'})
def group(name,**facts):
 STATE['groups'].append({'name':name,'pass':True,**facts});print(json.dumps(STATE['groups'][-1],ensure_ascii=False),flush=True)
 dump(RUN/('ledger-'+str(len(STATE['groups'])).zfill(2)+'.json'),{'snapshot':snapshot(LEDGER),'data':json.loads(LEDGER.read_bytes())})
class RedirectProbe(http.server.BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_POST(self):
  STATE.setdefault('redirectFollowed',[]).append({'method':self.command,'path':self.path,'at':now()})
  self.send_response(500);self.send_header('Content-Length','0');self.end_headers()
 def do_GET(self):self.do_POST()
REDIRECT=None
TERMINALS=globals().get('TERMINALS',[])
try:
 STATE['sourceBefore']=source_audit()
 STATE['priorR2StartupNegative']={'receiptSha256':'355cf8105051366c3f89790fb7d06564dc9dfafd908842fe1fb3d2fc81c18f58','groups':0,'terminals':0,'commits':0,'nativeStdoutAndStderrEmpty':True,'observedChildExit':-15,'wrapperExit':'unobserved after expired session','correction':'Only isolated fixture startup observation increased from7.5 to30seconds; no product or assertion changes'}
 mem={x.split(':')[0]:int(x.split(':')[1].split()[0])*1024 for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')}
 STATE['guard']={'memoryAvailable':mem['MemAvailable'],'diskFree':shutil.disk_usage(ROOT).free}
 assert mem['MemAvailable']>=768*1024*1024 and STATE['guard']['diskFree']>=12*1024*1024
 LEDGER=RUN/'fixture-ledger.json'
 BASE=(ROOT/'original-native-r1/manual-seed.json').read_bytes();baseline()
 GOLD=expected_review();assert GOLD==json.loads((ROOT/'original-native-r1/manual-expected-review.json').read_text())
 SERVICE=NativeService()
 PROXY=http.server.ThreadingHTTPServer(('127.0.0.1',0),Forwarder);PROXY.daemon_threads=True
 threading.Thread(target=PROXY.serve_forever,daemon=True).start()
 ENDPOINT=f'http://127.0.0.1:{PROXY.server_port}/mcp';STATE['endpoint']=ENDPOINT
 REDIRECT=http.server.ThreadingHTTPServer(('127.0.0.1',0),RedirectProbe);REDIRECT.daemon_threads=True
 threading.Thread(target=REDIRECT.serve_forever,daemon=True).start()
 STATE['redirectTarget']=f'http://127.0.0.1:{REDIRECT.server_port}/mcp'

 STATE['retainedR1']={'receiptSha256': '003751cca934b5473b91ca6f116ac15911487d4185d355e5467d0b0df996488e', 'overall': 'failed at observer metadata NameError after four completed cancellation/EOF/Ctrl-C children', 'completedAssertionJourneys': ['01-full-review-cancel', '02-eof-before-connection', '03-eof-at-review', '04-ctrl-c-at-review'], 'allFourExits': 2, 'commitCalls': 0, 'proxyErrors': [], 'candidateR1R2RuntimeSame': True, 'thoseJourneysNotRepeated': True}

 before=LEDGER.read_bytes();n=commits();t=begin('05-one-explicit-commit');review(t,GOLD);t.send('REALLOCATE');out=t.finish(0)
 assert applied(out)==GOLD and commits()==n+1;pair_only(before,9500,5800)
 group('one actual terminal confirmation persists exactly the original native pair')

 baseline();n=commits();t=begin('06-actual-stale-refusal');review(t,GOLD);mutate('06-selected-change','stale');changed=snapshot(LEDGER);t.send('REALLOCATE');out=t.finish(3)
 assert 'UNCONFIRMED:' in out and 'reviewed budget limits changed; no allowance moved.' in out
 stable(changed);assert commits()==n+1
 group('actual separate-process selected change is refused with honest unconfirmed result')

 baseline();n=commits();t=begin('07-current-matching');review(t,GOLD);mutate('07-independent-matching','matching');matching=snapshot(LEDGER);t.send('REALLOCATE');out=t.finish(0)
 assert 'Current limits already match this review; no write.' in out
 assert 'does not prove who applied them or that this request ran before.' in out
 stable(matching);assert commits()==n+1
 group('another process sets matching values; client reports current equality without execution-history claim')

 baseline();before=LEDGER.read_bytes();n=commits();t=begin('08-unrelated-change');review(t,GOLD);mutate('08-unrelated-change','unrelated');edited=LEDGER.read_bytes();t.send('REALLOCATE');out=t.finish(0)
 assert applied(out)==GOLD;pair_only(edited,9500,5800);assert commits()==n+1
 group('fresh native commit preserves actual unrelated process edit and all other fixture data')

 baseline();before=LEDGER.read_bytes();n=commits();t=begin('09-real-lost-ack');review(t,GOLD);ACTIVE['dropNextCommit']=True;t.send('REALLOCATE');out=t.finish(3)
 assert 'UNCONFIRMED:' in out and 'No automatic retry. Inspect current budgets before any new review' in out
 assert 'repeating the amount can move allowance again.' in out
 pair_only(before,9500,5800);time.sleep(.15);assert commits()==n+1
 faults=[x for x in STATE['requests'] if x.get('fault')]
 assert len(faults)==1 and faults[0]['nativeResult']['status']=='applied'
 group('actual upstream commit completed before lost acknowledgement; exactly one attempt', fault=faults[0])

 persisted=snapshot(LEDGER);SERVICE.close();SERVICE=NativeService();n=commits();t=begin('10-restart-fresh-review');fresh=expected_review(9500,5800,2500);review(t,fresh)
 assert 'category="Food / 東京" limitMinor=9500' in t.text() and 'category="Rain reserve <&>" limitMinor=5800' in t.text()
 assert fresh['reviewToken']!=GOLD['reviewToken'];assert fresh['from']['afterMinor']==7000 and fresh['to']['afterMinor']==8300
 t.send('cancel');t.finish(2);stable(persisted);assert commits()==n
 group('restarted service supplies actual current values and a fresh different review; no implicit recovery replay')

 baseline();before=snapshot(LEDGER);n=commits();t=begin('11-invalid-preview-response',fields=4);ACTIVE['fault']='bad_preview_token';t.until(PROMPTS[4]);t.send('2500');out=t.finish(1)
 assert 'Preview content digest does not match' in out;stable(before);assert commits()==n
 group('changed delivered preview digest is refused before confirmation or commit')

 baseline();before=LEDGER.read_bytes();n=commits();t=begin('12-mismatched-commit-response');review(t,GOLD);ACTIVE['fault']='bad_commit_ack';t.send('REALLOCATE');out=t.finish(3)
 assert 'UNCONFIRMED:' in out and 'No automatic retry.' in out;pair_only(before,9500,5800);assert commits()==n+1
 group('actual persisted commit with mismatched delivered echo remains unconfirmed; one attempt')

 baseline();invalid=[
  ('13-invalid-month',['2026-13'],1),
  ('14-invalid-currency',['2026-10','US'],2),
  ('15-invalid-index',['2026-10','USD','0'],3),
  ('16-same-category',['2026-10','USD','1','1'],4),
  ('17-fractional-amount',['2026-10','USD','1','2','1.5'],5),
  ('18-insufficient-allowance',['2026-10','USD','1','2','999999'],5),
  ('19-absent-month',['2026-12','USD'],2),
 ]
 for label,values,fields in invalid:
  before=snapshot(LEDGER);n=commits();t=begin(label,values=values,fields=fields);out=t.finish(1);stable(before);assert commits()==n
 group('seven actual invalid or unavailable choices refuse without a commit', children=len(invalid))

 bad_endpoints=['http://localhost:'+str(PROXY.server_port)+'/mcp','https://127.0.0.1:'+str(PROXY.server_port)+'/mcp','http://127.0.0.1:'+str(PROXY.server_port)+'/mcp?unexpected=1']
 for i,endpoint in enumerate(bad_endpoints):
  before=snapshot(LEDGER);n=len(STATE['requests']);t=begin('20-endpoint-'+str(i),endpoint=endpoint,fields=0);t.finish(1);stable(before);assert len(STATE['requests'])==n
 group('unintended host, protocol and query endpoints refuse before any HTTP', children=len(bad_endpoints))

 before=snapshot(LEDGER);n=commits();t=begin('21-redirect-refusal',fields=1);ACTIVE['fault']='redirect';t.until(PROMPTS[1]);t.send('USD');out=t.finish(1)
 stable(before);assert commits()==n and not STATE.get('redirectFollowed')
 group('actual loopback HTTP redirect is not followed', target=STATE['redirectTarget'])

 ACTIVE['case']='22-piped-input';ACTIVE['fault']=None;before=snapshot(LEDGER);n=len(STATE['requests'])
 argv=['/usr/bin/node',str(CANDIDATE/'dist/src/household-reallocate.js'),'--endpoint',ENDPOINT]
 p=subprocess.run(argv,cwd=CANDIDATE,input=b'2026-10\nUSD\n1\n2\n2500\nREALLOCATE\n',capture_output=True,timeout=10)
 (RUN/'22-piped-input.stdout.log').write_bytes(p.stdout);(RUN/'22-piped-input.stderr.log').write_bytes(p.stderr)
 assert p.returncode==1 and b'Interactive input and output terminals are required' in p.stderr;stable(before);assert len(STATE['requests'])==n
 group('piped confirmation input is refused before connection', exit=p.returncode)

 STATE['sourceAfter']=source_audit();STATE['ok']=True
except BaseException as e:
 STATE['ok']=False;STATE['error']=repr(e);STATE['traceback']=traceback.format_exc()
finally:
 for t in TERMINALS:
  if not t.closed:
   if t.p.poll() is None:t.p.terminate()
   try:t.p.wait(timeout=4)
   except subprocess.TimeoutExpired:t.p.kill();t.p.wait(timeout=4)
   while t.pump(0):pass
   t.receipt.update({'cleanupExit':t.p.returncode,'cleanupAt':now(),'transcriptSha':sha(t.raw)})
   (RUN/(t.label+'.pty.log')).write_bytes(t.raw);dump(RUN/(t.label+'.terminal.json'),t.receipt)
   os.close(t.master);t.closed=True
 time.sleep(.2)
 if PROXY:PROXY.shutdown();PROXY.server_close()
 if REDIRECT:REDIRECT.shutdown();REDIRECT.server_close()
 for p in CHILDREN:
  if p.poll() is None:p.terminate()
  try:p.wait(timeout=4)
  except subprocess.TimeoutExpired:p.kill();p.wait(timeout=4)
 if SERVICE:
  try:SERVICE.close()
  except BaseException as e:STATE.setdefault('cleanupErrors',[]).append(repr(e))
 STATE['childClosure']=[{'pid':p.pid,'exit':p.returncode,'absent':not pathlib.Path('/proc/'+str(p.pid)).exists()} for p in CHILDREN]
 if STATE['proxyErrors']:STATE['ok']=False;STATE['proxyErrorFailure']=True
 try:STATE['finalSourceAudit']=source_audit()
 except BaseException as e:STATE['ok']=False;STATE['sourceAuditError']=repr(e)
 STATE['completed']=now()
 dump(RUN/'receipt.json',STATE)
 b=(RUN/'receipt.json').read_bytes()
 print(json.dumps({'ok':STATE.get('ok'),'error':STATE.get('error'),'groups':len(STATE['groups']),'terminals':len(STATE['terminals']),'commitRequests':commits(),'proxyErrors':STATE['proxyErrors'],'children':STATE['childClosure'],'receiptBytes':len(b),'receiptSha256':sha(b),'completed':STATE['completed']}),flush=True)
if not STATE.get('ok'):raise SystemExit(1)
