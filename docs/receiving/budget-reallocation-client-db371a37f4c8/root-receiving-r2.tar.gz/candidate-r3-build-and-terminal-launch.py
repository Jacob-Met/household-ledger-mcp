from pathlib import Path
import os,sys,json,hashlib,datetime,subprocess,shutil,time,traceback,ast
R=Path('/home/jacob/snap/chromium/common/hamon-household-reallocation-receiving-db371a37f4c8')
h=lambda b:hashlib.sha256(b).hexdigest();D=Path('/tmp/c36a60df2cc1-household-compare/worktree/node_modules')
full=json.loads((R/'dependency-full-source-pins-r1.json').read_text())
assert h((R/'dependency-full-source-pins-r1.json').read_bytes())=='5274e4b46eca7c11a4c894d7963f888852159c9276ec4a5c9a6ef4a02f7acd47'
assert not (R/'terminal-r3').exists() and not (R/'candidate-r3-source-build').exists()
r2=json.loads((R/'terminal-r2/receipt.json').read_text())
assert r2['ok'] is False and r2['error']=="AssertionError('native startup missing')" and not r2['terminals']
assert all(x['absent'] for x in r2['childClosure'])
s=(R/'terminal-receiving-r2.py').read_text()
assert h(s.encode())=='7d024544bf68fe80fda752d2ddd854b8b71e18e59201d28c9a75df86e0adc59b'
for a,b in [("RUN=ROOT/'terminal-r2'","RUN=ROOT/'terminal-r3'"),("'native-fixture-change-r2.mjs'","'native-fixture-change-r3.mjs'"),("for _ in range(150):","for _ in range(600):")]:
 assert s.count(a)==1,(a,s.count(a));s=s.replace(a,b)
s=s.replace("  self.port=port;self.index=len(STATE['services'])+1","  startup_started=time.monotonic()\n  self.port=port;self.index=len(STATE['services'])+1")
needle="  assert r.status==200 and json.loads(b)=={'ok':True,'service':'household-ledger-mcp'}"
assert s.count(needle)==1;s=s.replace(needle,needle+"\n  self.receipt['startupSeconds']=round(time.monotonic()-startup_started,6)\n  self.receipt['startupObserverLimitSeconds']=30")
s=s.replace(" STATE['sourceBefore']=source_audit()"," STATE['sourceBefore']=source_audit()\n STATE['priorR2StartupNegative']={'receiptSha256':'355cf8105051366c3f89790fb7d06564dc9dfafd908842fe1fb3d2fc81c18f58','groups':0,'terminals':0,'commits':0,'nativeStdoutAndStderrEmpty':True,'observedChildExit':-15,'wrapperExit':'unobserved after expired session','correction':'Only isolated fixture startup observation increased from7.5 to30seconds; no product or assertion changes'}")
ast.parse(s)
writer=(R/'native-fixture-change-r2.mjs').read_text();assert writer.count('/terminal-r2/')==1;writer=writer.replace('/terminal-r2/','/terminal-r3/')
for rel,content in [('terminal-receiving-r3.py',s),('native-fixture-change-r3.mjs',writer)]:
 p=R/rel
 with p.open('xb') as f:f.write(content.encode());f.flush();os.fsync(f.fileno())
rec={'started':datetime.datetime.now(datetime.UTC).isoformat(),'pid':os.getpid(),'reason':'Close newly discovered selected-only dependency inventory gap with full3898-file/3-link pre/post pinning and one final artifact-equivalent native compile; no settled behavior tests repeated','dependencyManifestSha256':h((R/'dependency-full-source-pins-r1.json').read_bytes()),'priorSelectedMatched':2960,'newlyPinnedFiles':938,'terminalDriverSha256':h(s.encode())}
proc=None
def audit():
 for f in full['files']:
  b=(D/f['path']).read_bytes();assert len(b)==f['bytes'] and h(b)==f['sha256'],f['path']
 for f in full['links']:assert os.readlink(D/f['path'])==f['target'],f['path']
 return {'regularFiles':len(full['files']),'links':len(full['links'])}
try:
 mem={x.split(':')[0]:int(x.split(':')[1].split()[0])*1024 for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')}
 rec['guard']={'memoryAvailable':mem['MemAvailable'],'diskFree':shutil.disk_usage(R).free,'load':os.getloadavg(),'maxOldSpaceMiB':256,'nice':10}
 assert mem['MemAvailable']>=1024*1024*1024 and rec['guard']['diskFree']>=40*1024*1024
 rec['dependencyBefore']=audit();O=R/'candidate-r3-source-build';O.mkdir(mode=0o700)
 pins=json.loads((R/'candidate-r2-source-pins.json').read_text())
 for f in pins['files']:
  b=(R/'candidate-r2-source'/f['path']).read_bytes();assert h(b)==f['sha256']
  if not f['path'].startswith('dist/'):
   p=O/f['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 (O/'node_modules').symlink_to(D,target_is_directory=True)
 argv=['/usr/bin/nice','-n','10','/usr/bin/node','--max-old-space-size=256',str(D/'typescript/bin/tsc'),'-p',str(O/'tsconfig.json')];rec['argv']=argv;t=time.monotonic()
 with (R/'candidate-r3-full-dependency-build.log').open('xb') as log:
  proc=subprocess.Popen(argv,cwd=O,stdout=log,stderr=subprocess.STDOUT);rec['compilerPid']=proc.pid
  try:rec['compilerExit']=proc.wait(timeout=60)
  except subprocess.TimeoutExpired:proc.kill();rec['compilerExit']=proc.wait(timeout=5);raise
 rec['seconds']=round(time.monotonic()-t,6);assert rec['compilerExit']==0
 for f in pins['files']:assert h((O/f['path']).read_bytes())==f['sha256'],f['path']
 rec['dependencyAfter']=audit();rec['all109FilesExact']=True;rec['compilerAbsent']=not Path('/proc/'+str(proc.pid)).exists();rec['ok']=True
except BaseException as e:
 rec['ok']=False;rec['error']=repr(e);rec['traceback']=traceback.format_exc()
finally:
 if proc and proc.poll() is None:proc.kill();proc.wait(timeout=5)
 rec['completed']=datetime.datetime.now(datetime.UTC).isoformat();b=(json.dumps(rec,indent=2)+'\n').encode()
 with (R/'candidate-r3-full-dependency-build-receipt.json').open('xb') as f:f.write(b)
 print(json.dumps(rec|{'receiptBytes':len(b),'receiptSha256':h(b)}),flush=True)
if not rec['ok']:raise SystemExit(1)
print(json.dumps({'next':'Only unfinished native terminal receiving','driver':str(R/'terminal-receiving-r3.py'),'driverSha256':h(s.encode()),'fixtureStartupLimitSeconds':30,'sameCandidateRuntime':True}),flush=True)
os.execv(sys.executable,[sys.executable,str(R/'terminal-receiving-r3.py')])
