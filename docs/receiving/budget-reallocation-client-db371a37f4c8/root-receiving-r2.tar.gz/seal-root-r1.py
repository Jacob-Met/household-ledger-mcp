from pathlib import Path
import os,json,hashlib,datetime,tarfile,gzip,io,subprocess,traceback,sys,stat
R=Path('/home/jacob/snap/chromium/common/hamon-household-reallocation-receiving-db371a37f4c8')
PUB=R/'publication'
PUB.mkdir()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
rec={'started':now(),'pid':os.getpid(),'receiving':'accepted for owner composition/native adoption; installed aggregation not claimed','archiveContainsDependencyBytes':False}
def write_new(p,b):
 with p.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
try:
 audit=(R/'final-audit-r1/receipt.json').read_bytes()
 assert sha(audit)=='79ede0cea8ba39a9c6aa1ca789f4a2f3e496e468989abcd8e872c21fb3c8b6b5'
 assert json.loads(audit)['ok']
 files=[];omitted=[]
 for d,dirs,names in os.walk(R,followlinks=False):
  dirs.sort();names.sort()
  for n in list(dirs):
   p=Path(d)/n
   if p==PUB:dirs.remove(n);continue
   if p.is_symlink():omitted.append({'path':p.relative_to(R).as_posix(),'target':os.readlink(p),'reason':'External native dependency donor; full inventory included separately'});dirs.remove(n)
  for n in names:
   p=Path(d)/n;rel=p.relative_to(R).as_posix()
   if p.is_symlink():omitted.append({'path':rel,'target':os.readlink(p),'reason':'Symbolic link omitted from sealed regular-file packet'});continue
   assert p.is_file(),rel
   b=p.read_bytes()
   files.append({'path':rel,'bytes':len(b),'mode':oct(stat.S_IMODE(p.stat().st_mode)),'sha256':sha(b),'gitBlob':git(b)})
 files.sort(key=lambda e:e['path'])
 manifest={'created':now(),'owner':'estate-db371a37f4c8','files':files,'omittedSymlinks':omitted,'archivePolicy':'All regular files in receiving namespace except publication outputs; dependency links omitted, no dereference. Tar timestamps/uid/gid normalized; exact content and source mode preserved. MANIFEST.json contains these exact bytes.'}
 mb=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
 write_new(PUB/'root-packet-file-manifest.json',mb)
 archive=PUB/'household-reallocation-root-receiving.tar.gz'
 with archive.open('xb') as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=9) as gz:
   with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
    for e in files:
     p=R/e['path'];b=p.read_bytes();assert sha(b)==e['sha256'],e['path']
     info=tarfile.TarInfo(e['path']);info.size=len(b);info.mode=int(e['mode'],8);info.mtime=0;info.uid=0;info.gid=0;info.uname='';info.gname=''
     tar.addfile(info,io.BytesIO(b))
    info=tarfile.TarInfo('MANIFEST.json');info.size=len(mb);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(mb))
  raw.flush();os.fsync(raw.fileno())
 expected={e['path']:e for e in files}
 with tarfile.open(archive,'r:gz') as tar:
  members=tar.getmembers();assert len(members)==len(files)+1
  assert len({m.name for m in members})==len(members)
  for member in members:
   assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
   b=tar.extractfile(member).read()
   if member.name=='MANIFEST.json':assert b==mb
   else:
    e=expected.pop(member.name);assert len(b)==e['bytes'] and sha(b)==e['sha256'] and git(b)==e['gitBlob'],member.name
  assert not expected
 b=archive.read_bytes()
 cp=subprocess.run(['git','hash-object',str(archive)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10)
 assert cp.returncode==0 and cp.stdout.decode().strip()==git(b),cp.stderr.decode()
 rb=(R/'ROOT.md').read_bytes()
 rec.update({'ok':True,'archive':str(archive),'archiveBytes':len(b),'archiveSha256':sha(b),'archiveGitBlob':git(b),'archiveMembers':len(files)+1,'regularPayloadFiles':len(files),'uncompressedPayloadBytes':sum(e['bytes'] for e in files)+len(mb),'manifestBytes':len(mb),'manifestSha256':sha(mb),'omittedSymlinks':omitted,'allMembersRoundtripExact':True,'nativeGitHashObjectExit':cp.returncode,'reportBytes':len(rb),'reportSha256':sha(rb),'finalAuditSha256':sha(audit),'acceptedProductTree':'5b88c9f61af7db76ed3489f6be9a3e65d2214ffe','afterProducerPatchSha256':'bfdd32804d2b36e993caafdae6bb1f0b29d27884874c3ee133a8e3358ab926d4'})
except Exception as e:
 rec.update({'ok':False,'error':repr(e),'traceback':traceback.format_exc()})
finally:
 rec['completed']=now()
 write_new(PUB/'SEAL.json',(json.dumps(rec,ensure_ascii=False,indent=2)+'\n').encode())
 print(json.dumps(rec,ensure_ascii=False),flush=True)
sys.exit(0 if rec['ok'] else 1)
