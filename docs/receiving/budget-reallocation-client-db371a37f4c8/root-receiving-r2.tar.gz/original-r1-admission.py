from pathlib import Path
import os,json,hashlib,datetime,shutil,subprocess,time,traceback
R=Path('/home/jacob/snap/chromium/common/hamon-household-reallocation-receiving-db371a37f4c8')
SOURCE=Path('/dev/shm/hamon-household-reallocation-client-db371a37f4c8-production/original')
PINS=SOURCE.parent/'original-source-pins.json'
DEPS=Path('/dev/shm/hamon-household-entry-db371a37f4c8-production/dependency-source-pins.json')
OUT=R/'original-r1-source'
h=lambda b:hashlib.sha256(b).hexdigest()
git=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
rec={'started':datetime.datetime.now(datetime.UTC).isoformat(),'pid':os.getpid(),'role':'independent original-only receiving; candidate and tests unread'}
proc=None
try:
 assert h(PINS.read_bytes())=='2354d594296ec2e890505aa07d9e84105ab3f4d2f8781426b4efda7f6f19de9d'
 assert h(DEPS.read_bytes())=='fc989762b3363bf781a61c689f5c97dbeebaea59a56b8f2311c5cc926a957d71'
 assert h((R/'CONTRACT.md').read_bytes())=='62dc69223ea51087557dc789bb48060538afba2503e70bd5852b8fbb8020a593'
 pins=json.loads(PINS.read_text());tree=json.loads((R/'original-published-tree.json').read_text())
 assert not tree['truncated'] and tree['sha']==pins['publishedTree']
 leaves={p['path']:p for p in tree['tree'] if p['type']=='blob'}
 deps=json.loads(DEPS.read_text());donor=Path(deps['donor'])
 if not (donor/'typescript/bin/tsc').is_file() and (donor/'node_modules/typescript/bin/tsc').is_file():donor=donor/'node_modules'
 assert (donor/'typescript/bin/tsc').is_file()
 mem={s.split(':')[0]:int(s.split(':')[1].split()[0])*1024 for s in Path('/proc/meminfo').read_text().splitlines() if s.startswith('MemAvailable:')}
 active=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   exe=(p/'exe').resolve().name;cwd=str((p/'cwd').resolve())
   if exe in ['cargo','rustc'] and 'hamon-resonance' in cwd:active.append({'pid':int(p.name),'exe':exe,'cwd':cwd})
  except OSError:pass
 rec['guard']={'load':os.getloadavg(),'cpus':os.cpu_count(),'memoryAvailable':mem['MemAvailable'],'diskFree':shutil.disk_usage(R).free,'activeOwnedCompilers':active,'compilerNice':10}
 assert mem['MemAvailable']>=1500*1024*1024 and shutil.disk_usage(R).free>=40*1024*1024 and os.getloadavg()[0]<32 and not active,'native compiler guard not met'
 OUT.mkdir(mode=0o700)
 for f in pins['files']:
  src=SOURCE/f['path'];b=src.read_bytes();assert src.is_file() and not src.is_symlink()
  assert len(b)==f['bytes'] and h(b)==f['sha256'] and git(b)==f['git'],f['path']
  assert leaves[f['path']]['sha']==f['git'] and leaves[f['path']]['size']==len(b),f['path']
  dest=OUT/f['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 (R/'original-source-pins.json').write_bytes(PINS.read_bytes())
 (R/'dependency-source-pins.json').write_bytes(DEPS.read_bytes())
 dep_files=[]
 for f in deps['files']:
  p=donor/f['path']
  if not p.is_file() and f['path'].startswith('node_modules/'):p=donor.parent/f['path']
  b=p.read_bytes();assert len(b)==f['bytes'] and h(b)==f['sha256'],str(p)
  dep_files.append(str(p))
 lock=json.loads((OUT/'package-lock.json').read_text())
 package_checks=[]
 for f in deps['packages']:
  path=f['path'];p=donor.parent/path/'package.json' if path.startswith('node_modules/') else donor/path/'package.json'
  info=json.loads(p.read_text());expected=lock['packages'][path]['version']
  assert info['version']==expected==f['lockedVersion']==f['installedVersion'],path
  package_checks.append({'path':path,'version':expected})
 rec['dependencyDonor']=str(donor);rec['dependencyFilesExact']=len(dep_files);rec['lockedPackages']=package_checks;rec['sourceFilesExact']=len(pins['files']);rec['sourceBytes']=sum(x['bytes'] for x in pins['files'])
 (OUT/'node_modules').symlink_to(donor,target_is_directory=True)
 argv=['/usr/bin/nice','-n','10','/usr/bin/node',str(donor/'typescript/bin/tsc'),'-p',str(OUT/'tsconfig.json')]
 rec['argv']=argv;begin=time.monotonic()
 with (R/'original-r1-build.log').open('wb') as log:
  proc=subprocess.Popen(argv,cwd=OUT,stdout=log,stderr=subprocess.STDOUT);rec['compilerPid']=proc.pid
  try:code=proc.wait(timeout=75)
  except subprocess.TimeoutExpired:
   proc.kill();rec['compilerExit']=proc.wait(timeout=5);raise
 rec['compilerExit']=code;rec['compilerSeconds']=round(time.monotonic()-begin,6);assert code==0,'native tsc failed'
 outputs=[]
 for p in sorted((OUT/'dist').rglob('*')):
  if p.is_file():
   b=p.read_bytes();outputs.append({'path':str(p.relative_to(OUT)),'bytes':len(b),'sha256':h(b),'git':git(b)})
 assert outputs
 for f in pins['files']:
  assert h((SOURCE/f['path']).read_bytes())==f['sha256']
  assert h((OUT/f['path']).read_bytes())==f['sha256']
 (R/'original-r1-build-output-pins.json').write_text(json.dumps(outputs,indent=2)+'\n')
 rec['compiledFiles']=len(outputs);rec['sourceUnchanged']=True;rec['compilerAbsent']=not Path('/proc/'+str(proc.pid)).exists();rec['ok']=True
except BaseException as e:
 rec['ok']=False;rec['error']=repr(e);rec['traceback']=traceback.format_exc()
finally:
 if proc is not None and proc.poll() is None:proc.kill();rec['cleanupCompilerExit']=proc.wait(timeout=5)
 rec['completed']=datetime.datetime.now(datetime.UTC).isoformat()
 b=(json.dumps(rec,indent=2)+'\n').encode();(R/'original-r1-admission-receipt.json').write_bytes(b)
 print(json.dumps({k:v for k,v in rec.items() if k!='lockedPackages'}|{'receiptBytes':len(b),'receiptSha':h(b),'lockedPackagesCount':len(rec.get('lockedPackages',[]))}),flush=True)
if not rec['ok']:raise SystemExit(1)
