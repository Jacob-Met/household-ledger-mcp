import {LedgerStore,setBudget} from './original-r1-source/dist/src/ledger.js';
const [file,kind]=process.argv.slice(2);
if(!file.startsWith('/home/jacob/snap/chromium/common/hamon-household-reallocation-receiving-db371a37f4c8/terminal-r1/'))throw Error('private receiving fixture only');
const store=new LedgerStore(file);
await store.update(data=>{
 if(kind==='stale')return setBudget(data,'Food / 東京','2026-10',11999,'USD');
 if(kind==='unrelated')return setBudget(data,'Travel','2026-10',6100,'USD');
 if(kind==='matching'){setBudget(data,'Food / 東京','2026-10',9500,'USD');return setBudget(data,'Rain reserve <&>','2026-10',5800,'USD');}
 throw Error('unsupported exact fixture operation');
});
console.log(JSON.stringify({kind,ledger:file,budgets:(await store.load()).budgets}));
