from pathlib import Path
import hashlib,json,os,datetime,subprocess,shutil,traceback,time
R=Path('/home/jacob/snap/chromium/common/hamon-household-reallocation-receiving-db371a37f4c8')
A=Path('/dev/shm/hamon-household-reallocation-client-db371a37f4c8-production')
P=A/'candidate-source-pins-r2.json';h=lambda b:hashlib.sha256(b).hexdigest()
rec={'started':datetime.datetime.now(datetime.UTC).isoformat(),'pid':os.getpid(),'purpose':'exact final candidate admission and independent bounded native TypeScript build; no product tests repeated'}
proc=None
try:
 b=P.read_bytes();assert h(b)=='0a9c93ee5792d3df8394e31969a35a7716d971a7d4748eb81b486e5aef4cfde4'
 pins=json.loads(b);r1=json.loads((R/'candidate-r1-source-pins.json').read_text())
 old={f['path']:f for f in r1['files']};new={f['path']:f for f in pins['files']}
 assert old.keys()==new.keys()
 diffs=[{'path':p,'r1':old[p]['sha256'],'r2':new[p]['sha256']} for p in old if old[p]['sha256']!=new[p]['sha256']]
 assert len(diffs)==6
 assert all(x['path'].startswith(('test/','dist/test/')) for x in diffs)
 rec['r1ToR2Differences']=diffs;rec['runtimeAndGuideAndProducerExactR1']=True
 orig=json.loads((R/'original-source-pins.json').read_text())
 for f in orig['files']:assert new[f['path']]['sha256']==f['sha256']
 mem={x.split(':')[0]:int(x.split(':')[1].split()[0])*1024 for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')}
 active=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   exe=(p/'exe').resolve().name;cwd=str((p/'cwd').resolve())
   if exe in ['cargo','rustc'] and 'hamon-resonance' in cwd:active.append({'pid':int(p.name),'exe':exe,'cwd':cwd})
  except OSError:pass
 rec['guard']={'memoryAvailable':mem['MemAvailable'],'diskFree':shutil.disk_usage(R).free,'load':os.getloadavg(),'maxOldSpaceMiB':256,'nice':10,'activeOwnedRustCompilers':active}
 assert mem['MemAvailable']>=1024*1024*1024 and rec['guard']['diskFree']>=40*1024*1024 and not active,'bounded native compiler admission refused'
 OUT=R/'candidate-r2-source';OUT.mkdir(mode=0o700)
 for f in pins['files']:
  raw=(A/'candidate-r2'/f['path']).read_bytes();assert len(raw)==f['bytes'] and h(raw)==f['sha256'],f['path']
  if not f['path'].startswith('dist/'):
   dest=OUT/f['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
 donor=Path('/tmp/c36a60df2cc1-household-compare/worktree/node_modules')
 (OUT/'node_modules').symlink_to(donor,target_is_directory=True)
 (R/'candidate-r2-source-pins.json').write_bytes(b)
 argv=['/usr/bin/nice','-n','10','/usr/bin/node','--max-old-space-size=256',str(donor/'typescript/bin/tsc'),'-p',str(OUT/'tsconfig.json')]
 rec['argv']=argv;t=time.monotonic()
 with (R/'candidate-r2-independent-build.log').open('wb') as log:
  proc=subprocess.Popen(argv,cwd=OUT,stdout=log,stderr=subprocess.STDOUT);rec['compilerPid']=proc.pid
  try:rec['compilerExit']=proc.wait(timeout=60)
  except subprocess.TimeoutExpired:proc.kill();rec['compilerExit']=proc.wait(timeout=5);raise
 rec['compilerSeconds']=round(time.monotonic()-t,6);assert rec['compilerExit']==0
 for f in pins['files']:
  assert h((OUT/f['path']).read_bytes())==f['sha256'],f['path']
  assert h((A/'candidate-r2'/f['path']).read_bytes())==f['sha256'],f['path']
 rec['all109FilesReproduced']=True;rec['original26SourceExact']=True;rec['compilerAbsent']=not Path('/proc/'+str(proc.pid)).exists();rec['ok']=True
except BaseException as e:rec['ok']=False;rec['error']=repr(e);rec['traceback']=traceback.format_exc()
finally:
 if proc and proc.poll() is None:proc.kill();proc.wait(timeout=5)
 rec['completed']=datetime.datetime.now(datetime.UTC).isoformat()
 data=(json.dumps(rec,indent=2)+'\n').encode();(R/'candidate-r2-independent-build-receipt.json').write_bytes(data)
 print(json.dumps(rec|{'receiptBytes':len(data),'receiptSha256':h(data)}),flush=True)
negative=json.loads((R/'terminal-r1/receipt.json').read_text())
print(json.dumps({'retainedTerminalR1':{'ok':negative['ok'],'error':negative['error'],'sha256':h((R/'terminal-r1/receipt.json').read_bytes()),'terminals':[{'label':x['label'],'pid':x['pid'],'exit':x.get('exit'),'foregroundGroup':x.get('foregroundProcessGroup'),'controls':[e for e in x['events'] if 'inputControl' in e]} for x in negative['terminals']],'finalSourceAudit':negative['finalSourceAudit'],'childClosure':negative['childClosure']}}),flush=True)
if not rec['ok']:raise SystemExit(1)
