import pathlib,hashlib,json,subprocess,datetime,time,os,signal,traceback
BASE=pathlib.Path('/run/user/1000/snap.chromium/hamon-household-installed-entry-root-db371a37f4c8')
assert all(not pathlib.Path('/proc',str(pid)).exists() for pid in [3584980,3585050,3585064,3585087,3585125,3585235]),'prior owned execution still exists'
driver=BASE/'installed-terminal-receiving-r3.py'
assert hashlib.sha256(driver.read_bytes()).hexdigest()=='67e3188e95abd2d4de913c15e5340b66fec7a7031ce2d86b2f70ded34279b985'
assert not (BASE/'terminal-r2').exists()
outdir=BASE/'terminal-wrapper-r2'
outdir.mkdir(mode=0o700)
receipt={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wrapperPid':os.getpid(),'argv':['python3','-B',str(driver),'--run'],'driverSha256':hashlib.sha256(driver.read_bytes()).hexdigest(),'timeoutSeconds':150}
p=None
try:
 with (outdir/'driver.stdout').open('wb') as out,(outdir/'driver.stderr').open('wb') as err:
  p=subprocess.Popen(receipt['argv'],stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
  receipt['driverPid']=p.pid
  (outdir/'launch.json').write_text(json.dumps(receipt,indent=2)+'\n')
  try:receipt['driverExit']=p.wait(timeout=150)
  except subprocess.TimeoutExpired:
   receipt['timeout']=True;p.send_signal(signal.SIGINT)
   receipt['interruptForOwnedFinally']=True;receipt['driverExit']=p.wait(timeout=25)
 native=BASE/'terminal-r2/receipt.json'
 receipt['nativeReceiptPresent']=native.is_file()
 if native.is_file():
  b=native.read_bytes();r=json.loads(b)
  receipt.update({'nativeReceiptBytes':len(b),'nativeReceiptSha256':hashlib.sha256(b).hexdigest(),'nativePassed':r.get('passed'),'groups':r.get('groups'),'childClosure':r.get('processClosure')})
 receipt['passed']=receipt.get('driverExit')==0 and receipt.get('nativePassed') is True and not receipt.get('timeout')
except BaseException as e:
 receipt['passed']=False;receipt['error']=repr(e);receipt['traceback']=traceback.format_exc()
finally:
 receipt['driverAbsent']=bool(p and p.poll() is not None and not pathlib.Path('/proc',str(p.pid)).exists())
 receipt['completed']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 (outdir/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt),flush=True)
raise SystemExit(0 if receipt['passed'] else 1)
