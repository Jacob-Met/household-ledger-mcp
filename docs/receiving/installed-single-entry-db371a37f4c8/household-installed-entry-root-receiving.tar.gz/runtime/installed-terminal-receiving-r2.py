#!/usr/bin/env python3
"""Independent installed dispatch receiver; root reviewed revision of staged-only R1."""
import pathlib,json,hashlib,os,sys,subprocess,datetime,time,socket,http.client,http.server,threading,pty,select,errno,traceback,stat,shutil,signal,argparse,uuid
BASE=pathlib.Path('/run/user/1000/snap.chromium/hamon-household-installed-entry-root-db371a37f4c8')
INSTALL=BASE/'installation'; PACKAGE=INSTALL/'node_modules/household-ledger-mcp'
BIN=INSTALL/'node_modules/.bin/household-record'; CWD=BASE/'unrelated-cwd'; LINK=CWD/'record-via-local-link'
ADMISSION=BASE/'admission-r4.json'
ADMISSION_SHA='84f0fa3a775a6f3d4cf0358dde663d880d05d1cff425f8f5a3f2420403b964d2'
SOURCE_MANIFEST=BASE/'input/candidate-source-manifest-r1.json'
INSTALL_MANIFEST=BASE/'input/installed-candidate-manifest-r1.json'
CHILDREN=[]; TERMINALS=[]; STATE={'services':[],'terminals':[],'requests':[],'connections':[],'proxyErrors':[],'groups':[]}
ACTIVE={'case':'admission','path':None}; SERVICE=None; PROXY=None
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,j):p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
def snapshot(p):
 try:
  b=p.read_bytes();s=p.stat();return {'bytes':len(b),'sha256':sha(b),'mtimeNs':s.st_mtime_ns,'mode':stat.S_IMODE(s.st_mode)}
 except FileNotFoundError:return None
def record_count():return sum(1 for x in STATE['requests'] if x.get('rpc',{}).get('method')=='tools/call' and x['rpc'].get('params',{}).get('name')=='record_transaction')
def source_audit():
 assert sha(SOURCE_MANIFEST.read_bytes())=='f60bbdd638c2687ddc4b7e496f125ff6f18683f124f8cf87053d4a7156d9047c','source manifest changed'
 m=json.loads(SOURCE_MANIFEST.read_bytes());r=BASE/'source';rows=[]
 assert sorted(str(p.relative_to(r)) for p in r.rglob('*') if p.is_file() or p.is_symlink())==sorted(x['path'] for x in m['files']),'source copied set changed'
 for x in m['files']:
  p=r/x['path'];assert not p.is_symlink(),('unexpected source link',str(p))
  b=p.read_bytes();assert sha(b)==x['sha256'] and len(b)==x['bytes'] and stat.S_IMODE(p.stat().st_mode)==x['mode'],('source-pin',str(p))
  rows.append({'path':x['path'],'sha256':sha(b),'bytes':len(b),'mode':stat.S_IMODE(p.stat().st_mode)})
 return {'manifestSha256':sha(SOURCE_MANIFEST.read_bytes()),'root':str(r),'authorRoot':m['root'],'files':rows}
def installed_audit():
 assert sha(INSTALL_MANIFEST.read_bytes())=='782e461f86a96c586488de4f74d72aa35e9f30a5870e67549fdb832c2c007d68','installed manifest changed'
 m=json.loads(INSTALL_MANIFEST.read_bytes());rows=[]
 for p in sorted(INSTALL.rglob('*')):
  if p.is_symlink():rows.append({'path':str(p.relative_to(INSTALL)),'type':'link','target':os.readlink(p)})
  elif p.is_file():
   b=p.read_bytes();rows.append({'path':str(p.relative_to(INSTALL)),'type':'file','sha256':sha(b),'bytes':len(b),'mode':stat.S_IMODE(p.stat().st_mode)})
 expected=[{k:v for k,v in x.items() if k!='git'} for x in m['files']]
 assert sorted(rows,key=lambda x:x['path'])==sorted(expected,key=lambda x:x['path']),'installed copied set, bytes, modes or links changed'
 return {'root':str(INSTALL),'files':rows,'ownerManifestSha256':sha(INSTALL_MANIFEST.read_bytes())}
def connection_request():
 p=pathlib.Path(ACTIVE['path']);b=p.read_bytes();r=json.loads(b)
 assert stat.S_IMODE(p.stat().st_mode)==0o600 and r==EXPECTED_REQUEST
 return {'path':str(p),'snapshot':snapshot(p),'request':r}
class ObservedServer(http.server.ThreadingHTTPServer):
 daemon_threads=True
 def get_request(self):
  c,a=super().get_request();row={'at':now(),'case':ACTIVE['case'],'peer':a}
  STATE['connections'].append(row)
  try:
   assert ACTIVE['path'] is not None,'connection in passive phase'
   row['requestBeforeConnection']=connection_request()
  except BaseException as e:
   row['error']=repr(e);STATE['proxyErrors'].append(row);c.close();raise
  return c,a
def freeze_terminal(t):
 (RUN/(t.label+'.pty.log')).write_bytes(t.raw)
 dump(RUN/(t.label+'.terminal.json'),t.receipt)
def assert_ledger_preserved(before,after):
 assert len(after['transactions'])==len(before['transactions'])+1
 assert after['transactions'][:len(before['transactions'])]==before['transactions']
 assert {k:v for k,v in after.items() if k!='transactions'}=={k:v for k,v in before.items() if k!='transactions'}
def command(label,argv):
 ACTIVE['case']=label;ACTIVE['path']=None
 p=subprocess.Popen(argv,cwd=CWD,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
 CHILDREN.append(p);out,err=p.communicate(timeout=15)
 (RUN/(label+'.stdout')).write_bytes(out);(RUN/(label+'.stderr')).write_bytes(err)
 row={'argv':argv,'cwd':str(CWD),'pid':p.pid,'exit':p.returncode,'stdoutSha256':sha(out),'stderrSha256':sha(err)}
 STATE.setdefault('commands',[]).append(row);assert p.returncode==0,(label,row,out,err)
 return out,err


class NativeService:
 def __init__(self,port=None):
  if port is None:
   with socket.socket() as reserve:
    reserve.bind(('127.0.0.1',0));port=reserve.getsockname()[1]
  self.port=port;self.index=len(STATE['services'])+1
  self.out=RUN/f'native-server-{self.index}.stdout.log';self.err=RUN/f'native-server-{self.index}.stderr.log'
  argv=['/usr/bin/node',str(PACKAGE/'dist/src/index.js')]
  env=dict(os.environ,HOUSEHOLD_LEDGER_HOST='127.0.0.1',HOUSEHOLD_LEDGER_PORT=str(port),HOUSEHOLD_LEDGER_DATA_PATH=str(LEDGER))
  with self.out.open('wb') as o,self.err.open('wb') as e:self.p=subprocess.Popen(argv,cwd=PACKAGE,env=env,stdin=subprocess.DEVNULL,stdout=o,stderr=e,start_new_session=True)
  CHILDREN.append(self.p)
  self.receipt={'pid':self.p.pid,'argv':argv,'port':port,'dataPath':str(LEDGER),'started':now()}
  STATE['services'].append(self.receipt)
  for _ in range(600):
   assert self.p.poll() is None,('native-server-early-exit',self.p.returncode,self.err.read_text())
   if f'listening on http://127.0.0.1:{port}' in self.out.read_text():break
   time.sleep(.05)
  else:raise AssertionError('native startup missing')
  c=http.client.HTTPConnection('127.0.0.1',port,timeout=3);c.request('GET','/healthz');r=c.getresponse();b=r.read();c.close()
  assert r.status==200 and json.loads(b)=={'ok':True,'service':'household-ledger-mcp'}
 def close(self):
  if self.p.poll() is None:self.p.terminate();self.receipt['shutdown']='deliberate owned SIGTERM'
  self.receipt['exit']=self.p.wait(timeout=5);self.receipt['completed']=now()

class Forwarder(http.server.BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, *args):
        pass

    def do_GET(self):
        self.forward()

    def do_POST(self):
        self.forward()

    def do_DELETE(self):
        self.forward()

    def forward(self):
        entry = {'at': now(), 'case': ACTIVE['case'], 'method': self.command, 'path': self.path}
        upstream = None
        try:
            body = self.rfile.read(int(self.headers.get('Content-Length', '0')))
            raw_id = uuid.uuid4().hex
            entry['rawId'] = raw_id
            entry['requestHeaders'] = list(self.headers.items())
            (RUN / (raw_id + '.http-request-body')).write_bytes(body)
            try:
                rpc = json.loads(body)
            except (ValueError, UnicodeDecodeError):
                rpc = {}
            entry.update({'rpc': rpc, 'requestBytes': len(body), 'requestSha': sha(body)})
            is_record = rpc.get('method') == 'tools/call' and rpc.get('params', {}).get('name') == 'record_transaction'
            if is_record:
                p = pathlib.Path(ACTIVE['path'])
                entry['recoveryBeforeForward'] = snapshot(p)
                assert entry['recoveryBeforeForward'] is not None, 'recovery missing before native forward'
                recovery = json.loads(p.read_bytes())
                assert recovery['transaction'] == rpc['params']['arguments']
                entry['recoveryPath'] = str(p)
                entry['ledgerBeforeForward'] = snapshot(LEDGER)
            STATE['requests'].append(entry)
            headers = {k: v for k, v in self.headers.items() if k.lower() not in ['host', 'connection', 'transfer-encoding', 'content-length']}
            headers['Host'] = f'127.0.0.1:{SERVICE.port}'
            headers['Content-Length'] = str(len(body))
            upstream = http.client.HTTPConnection('127.0.0.1', SERVICE.port, timeout=20)
            upstream.request(self.command, self.path, body=body, headers=headers)
            r = upstream.getresponse()
            entry['status'] = r.status
            entry['upstreamHeaders'] = r.getheaders()
            if self.command == 'GET' and r.status == 200 and (r.getheader('Content-Type') or '').startswith('text/event-stream'):
                self.send_response(r.status)
                for k, v in r.getheaders():
                    if k.lower() not in ['connection', 'date', 'server']:
                        self.send_header(k, v)
                self.end_headers()
                self.wfile.flush()
                raw_hash = hashlib.sha256()
                raw_count = 0
                deadline = time.monotonic() + 25
                while True:
                    ready, _, _ = select.select([self.connection, r.fp], [], [], 0.05)
                    if self.connection in ready:
                        peek = self.connection.recv(1, socket.MSG_PEEK)
                        if not peek:
                            entry['streamClose'] = 'downstream SDK closed; upstream closed in finally'
                            break
                        raise AssertionError('unexpected pipelined bytes on SSE connection')
                    if r.fp in ready:
                        raw = r.fp.read1(65536)
                        if not raw:
                            entry['streamClose'] = 'upstream EOF'
                            break
                        (RUN / (raw_id + '.http-stream')).open('ab').write(raw)
                        raw_hash.update(raw)
                        raw_count += len(raw)
                        self.wfile.write(raw)
                        self.wfile.flush()
                    if time.monotonic() > deadline:
                        raise TimeoutError('owned SSE observer exceeded bounded lifetime')
                entry['rawStreamBytes'] = raw_count
                entry['rawStreamSha'] = raw_hash.hexdigest()
                self.close_connection = True
                return
            data = r.read()
            (RUN / (raw_id + '.http-response-body')).write_bytes(data)
            entry.update({'status': r.status, 'responseBytes': len(data), 'responseSha': sha(data), 'responseText': data.decode('utf8', 'replace')})
            if is_record:
                entry['ledgerAfterUpstream'] = snapshot(LEDGER)
                ledger = json.loads(LEDGER.read_text())
                entry['matchingStoredTransactions'] = [x for x in ledger['transactions'] if x.get('idempotencyKey') == rpc['params']['arguments']['idempotencyKey']]
            self.send_response(r.status)
            for k, v in r.getheaders():
                if k.lower() not in ['transfer-encoding', 'connection', 'content-length']:
                    self.send_header(k, v)
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except BaseException as e:
            entry['error'] = repr(e)
            STATE['proxyErrors'].append({'case': entry['case'], 'error': repr(e), 'traceback': traceback.format_exc()})
            self.close_connection = True
        finally:
            if upstream:
                upstream.close()

class Terminal:
 def __init__(self,label,args,path=None,argv0=BIN):
  ACTIVE['case']=label;ACTIVE['path']=str(path) if path else None
  self.label=label;self.raw=bytearray();self.cursor=0
  self.master,slave=pty.openpty()
  argv=[str(argv0)]+args
  self.p=subprocess.Popen(argv,cwd=CWD,stdin=slave,stdout=slave,stderr=slave,start_new_session=True,close_fds=True)
  os.close(slave);CHILDREN.append(self.p)
  self.receipt={'label':label,'pid':self.p.pid,'argv':argv,'cwd':str(CWD),'realTarget':str(pathlib.Path(argv[0]).resolve()),'started':now(),'events':[]}
  STATE['terminals'].append(self.receipt);self.closed=False;TERMINALS.append(self)
 def pump(self,seconds=.1):
  ready,_,_=select.select([self.master],[],[],seconds)
  if ready:
   try:b=os.read(self.master,65536)
   except OSError as e:
    if e.errno==errno.EIO:return False
    raise
   if b:self.raw.extend(b);return True
  return False
 def until(self,text,timeout=12):
  needle=text.encode();deadline=time.monotonic()+timeout
  while needle not in self.raw[self.cursor:]:
   self.pump(.05)
   if self.p.poll() is not None and needle not in self.raw[self.cursor:]:
    self.pump(0);raise AssertionError((self.label,'exited before prompt',text,self.p.returncode,self.raw.decode('utf8','replace')))
   if time.monotonic()>deadline:raise AssertionError((self.label,'timeout',text,self.raw.decode('utf8','replace')))
  i=self.raw.find(needle,self.cursor);self.cursor=i+len(needle)
  self.receipt['events'].append({'at':now(),'observed':text,'byteOffset':i})
  return self.text()
 def text(self):return self.raw.decode('utf8','strict').replace('\r\n','\n')
 def send(self,line):
  os.write(self.master,(line+'\n').encode())
  self.receipt['events'].append({'at':now(),'input':line})
 def eof(self):os.write(self.master,b'\x04');self.receipt['events'].append({'at':now(),'inputControl':'EOF'})
 def finish(self,expected,timeout=22):
  deadline=time.monotonic()+timeout
  while self.p.poll() is None:
   self.pump(.05)
   if time.monotonic()>deadline:raise AssertionError((self.label,'did not exit',self.text()))
  while self.pump(0):pass
  code=self.p.wait();self.receipt['exit']=code;self.receipt['completed']=now()
  self.receipt['transcriptSha']=sha(self.raw);self.receipt['transcriptBytes']=len(self.raw)
  (RUN/(self.label+'.pty.log')).write_bytes(self.raw)
  dump(RUN/(self.label+'.terminal.json'),self.receipt)
  os.close(self.master);self.closed=True
  assert code==expected,(self.label,'exit',code,expected,self.text())
  return self.text()

def terminal_review(t,request):
 t.until('Type RECORD to send this exact request once; anything else cancels: ')
 text=t.text();start=text.index('Review one recording (amountMinor is an integer, not a decimal amount):\n')
 review=text[start:].split('Type RECORD to send this exact request once; anything else cancels: ')[0]
 fields={}
 for line in review.splitlines()[1:]:
  k,v=line.strip().split(': ',1);fields[k]=json.loads(v)
 assert fields==request,('complete reviewed request mismatch',fields,request)
 t.receipt['reviewedRequest']=fields
 return fields

def confirmed(text):
 line=next(x for x in text.splitlines() if x.startswith('Confirmed recording: '))
 return json.loads(line.removeprefix('Confirmed recording: '))


def main():
 global RUN,LEDGER,SERVICE,PROXY,ENDPOINT,EXPECTED_REQUEST
 ap=argparse.ArgumentParser();ap.add_argument('--run',action='store_true',required=True);ap.parse_args()
 assert sha(ADMISSION.read_bytes())==ADMISSION_SHA,'root admission changed'
 assert PACKAGE.is_dir() and CWD.is_dir()
 target=(PACKAGE/'dist/src/household-record.js').resolve()
 assert BIN.is_symlink() and LINK.is_symlink() and BIN.resolve()==target and LINK.resolve()==target
 assert os.access(BIN,os.X_OK) and target.read_bytes().startswith(b'#!/usr/bin/env node\n')
 before_source=source_audit();before_install=installed_audit()
 mem=int(next(x.split()[1] for x in pathlib.Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemAvailable:')))*1024
 assert mem>=2*1024**3,('memory admission',mem)
 free=shutil.disk_usage(BASE).free;assert free>=(256+8)*1024**2,('run capacity admission with unchanged256MiB reserve',free)
 RUN=BASE/'terminal-r1'
 assert not RUN.exists(),'existing run is never replayed'
 RUN.mkdir(mode=0o700)  # Deliberately outside try/finally: do not claim or alter an existing run.
 LEDGER=RUN/'ledger.json'
 STATE.update({'started':now(),'driverSha256':sha(pathlib.Path(__file__).read_bytes()),'stagedR1Sha256':'def3f3753bbc34518c6e6cac88ab1aa296b98cc842446690cbf3c949bdda4b42','rootReviewChanges':['audit admitted copied source and installed sets/modes/links against exact manifests','30s startup bound justified by prior native receiving','preserve256MiB runtime reserve and2GiB memory guard'],'admissionSha256':ADMISSION_SHA,'memAvailable':mem,'availableBytes':free,
  'argvIdentities':{'bin':str(BIN),'localLink':str(LINK),'realTarget':str(target),'cwd':str(CWD)},
  'sourceBefore':before_source,'installedBefore':before_install})
 fixture={'version':2,'transactions':[{'id':'root-installed-existing-001','type':'expense','amountMinor':850,'currency':'USD','date':'2026-10-07','category':'Supplies','note':'Keep original <&> 🌙\nexact','idempotencyKey':'root-installed-existing-key','createdAt':'2026-10-07T10:11:12.000Z'}],
  'budgets':[{'category':'Supplies','month':'2026-10','limitMinor':4500,'currency':'USD','ownerMarker':'keep'}],
  'receivingMarker':{'owner':'estate-db371a37f4c8','meaning':'private synthetic installed-entry fixture'}}
 try:
  dump(LEDGER,fixture);initial=LEDGER.read_bytes();(RUN/'ledger-before.json').write_bytes(initial);initial_snap=snapshot(LEDGER)
  SERVICE=NativeService()
  PROXY=ObservedServer(('127.0.0.1',0),Forwarder);threading.Thread(target=PROXY.serve_forever,daemon=True).start()
  ENDPOINT='http://127.0.0.1:'+str(PROXY.server_address[1])+'/mcp'
  help_out,help_err=command('os-help',[str(BIN),'--help'])
  assert b'household-record' in help_out and b'resume' in help_out and b'Direction (income or expense): ' not in help_out
  passive="""const {createRequire,syncBuiltinESMExports}=await import('node:module');
const require=createRequire(import.meta.url);const forbidden=()=>{throw Error('passive import attempted input/network')};
require('node:net').Socket.prototype.connect=forbidden;
require('node:readline').createInterface=forbidden;
require('node:readline/promises').createInterface=forbidden;
process.stdin.resume=forbidden;syncBuiltinESMExports();
await import(process.argv[1]);console.log('PASS passive import');"""
  out,err=command('passive-import',['/usr/bin/node','--input-type=module','-e',passive,target.as_uri()])
  assert out==b'PASS passive import\n' and not err
  assert not STATE['connections'] and not STATE['requests'] and LEDGER.read_bytes()==initial
  assert not list(RUN.glob('*.request.json'))
  STATE['groups'].append('actual OS help and guarded passive import: no prompt, request, or HTTP')
  request_path=RUN/'installed.request.json'
  t=Terminal('new-cancel',['new','--endpoint',ENDPOINT,'--request',str(request_path)],request_path,argv0=BIN)
  prompts=['Direction (income or expense): ','Amount in positive INTEGER minor units: ','Three-letter currency: ','Date (YYYY-MM-DD): ','Category: ','Note (single line; blank to omit): ']
  for prompt,value in zip(prompts,['expense','2750','JPY','2026-10-08','Transport / 東京','Installed entry <&> 🌙']):t.until(prompt);t.send(value)
  t.until('Review one recording (amountMinor is an integer, not a decimal amount):\n')
  # Review parser still waits for the explicit RECORD prompt before any response is sent.
  EXPECTED_REQUEST=json.loads(request_path.read_bytes())
  assert set(EXPECTED_REQUEST)=={'version','endpoint','transaction'} and EXPECTED_REQUEST['version']==1 and EXPECTED_REQUEST['endpoint']==ENDPOINT
  tx=EXPECTED_REQUEST['transaction'];assert set(tx)=={'type','amountMinor','currency','date','category','note','idempotencyKey'}
  assert {k:v for k,v in tx.items() if k!='idempotencyKey'}=={'type':'expense','amountMinor':2750,'currency':'JPY','date':'2026-10-08','category':'Transport / 東京','note':'Installed entry <&> 🌙'}
  assert isinstance(tx['idempotencyKey'],str) and tx['idempotencyKey'].strip()
  terminal_review(t,EXPECTED_REQUEST)
  saved=request_path.read_bytes();saved_snap=snapshot(request_path);assert saved_snap['mode']==0o600
  assert not STATE['connections'] and record_count()==0 and LEDGER.read_bytes()==initial
  (RUN/'saved-request-observed.json').write_bytes(saved);dump(RUN/'saved-request-before-any-connection.json',saved_snap)
  t.send('CANCEL');t.finish(2)
  assert not STATE['connections'] and record_count()==0 and snapshot(LEDGER)==initial_snap
  assert request_path.read_bytes()==saved and snapshot(request_path)==saved_snap
  STATE['groups'].append('new OS command saved complete mode0600 request before any connection; full review then cancel recorded zero')
  t=Terminal('resume-confirm',['resume','--request',str(request_path)],request_path,argv0=BIN)
  terminal_review(t,EXPECTED_REQUEST);assert record_count()==0
  t.send('RECORD');first=confirmed(t.finish(0))
  assert record_count()==1
  after=json.loads(LEDGER.read_bytes());assert_ledger_preserved(fixture,after)
  added=[x for x in after['transactions'] if x.get('idempotencyKey')==tx['idempotencyKey']]
  assert len(added)==1 and all(added[0][k]==v for k,v in tx.items())
  assert first==added[0] and isinstance(first['id'],str)
  once=LEDGER.read_bytes();once_snap=snapshot(LEDGER);(RUN/'ledger-after-first.json').write_bytes(once)
  assert request_path.read_bytes()==saved and snapshot(request_path)==saved_snap
  STATE['groups'].append('explicit resume through installed OS bin records exactly one native transaction')
  t=Terminal('local-link-resume',['resume','--request',str(request_path)],request_path,argv0=LINK)
  terminal_review(t,EXPECTED_REQUEST);assert record_count()==1
  t.send('RECORD');second=confirmed(t.finish(0))
  assert record_count()==2 and second==first and second['id']==first['id']
  assert LEDGER.read_bytes()==once and snapshot(LEDGER)==once_snap
  assert request_path.read_bytes()==saved and snapshot(request_path)==saved_snap
  (RUN/'ledger-after-second.json').write_bytes(LEDGER.read_bytes())
  STATE.update({'originalId':first['id'],'firstConfirmation':first,'secondConfirmation':second,'requestSnapshot':saved_snap,'ledgerAfterFirst':once_snap,'ledgerAfterSecond':snapshot(LEDGER)})
  assert not STATE['proxyErrors']
  STATE['groups'].append('other local link explicitly resumes same saved key/endpoint and returns original ID; ledger bytes and mtime exact')
  STATE['passed']=True
 except BaseException as e:
  STATE['passed']=False;STATE['error']=repr(e);STATE['traceback']=traceback.format_exc()
 finally:
  for p in CHILDREN:
   if p.poll() is None:
    try:os.killpg(p.pid,signal.SIGTERM)
    except ProcessLookupError:pass
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
  if PROXY:PROXY.shutdown();PROXY.server_close()
  for t in TERMINALS:
   if not t.closed:
    while t.pump(0):pass
    t.receipt.update({'exit':t.p.poll(),'completed':now(),'failureCleanup':True});freeze_terminal(t)
    os.close(t.master);t.closed=True
  if SERVICE:SERVICE.receipt.update({'exit':SERVICE.p.poll(),'completed':now(),'shutdown':'deliberate owned cleanup'})
  STATE['processClosure']=[{'pid':p.pid,'exit':p.poll(),'procAbsent':not pathlib.Path('/proc',str(p.pid)).exists()} for p in CHILDREN]
  try:
   STATE['sourceAfter']=source_audit();STATE['installedAfter']=installed_audit()
   assert STATE['sourceAfter']==before_source and STATE['installedAfter']==before_install
   assert all(x['procAbsent'] and x['exit'] is not None for x in STATE['processClosure'])
  except BaseException as e:STATE['passed']=False;STATE['finalAuditError']=repr(e)
  STATE['finished']=now();dump(RUN/'receipt.json',STATE)
  print(json.dumps({'passed':STATE.get('passed',False),'receipt':str(RUN/'receipt.json'),'groups':STATE['groups']},ensure_ascii=False))
 return 0 if STATE.get('passed') else 1
if __name__=='__main__':sys.exit(main())
