import pathlib,hashlib,json,subprocess,datetime,time,os,signal,traceback
BASE=pathlib.Path('/run/user/1000/snap.chromium/hamon-household-installed-entry-root-db371a37f4c8')
driver=BASE/'installed-terminal-receiving-r2.py'
assert hashlib.sha256(driver.read_bytes()).hexdigest()=='6de5071a43b06950b9f4716418f3926e7d5ae3f549a63a5e2333e36e8cf2be90'
assert not (BASE/'terminal-r1').exists()
outdir=BASE/'terminal-wrapper-r1'
outdir.mkdir(mode=0o700)
receipt={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wrapperPid':os.getpid(),'argv':['python3','-B',str(driver),'--run'],'driverSha256':hashlib.sha256(driver.read_bytes()).hexdigest(),'timeoutSeconds':150}
p=None
try:
 with (outdir/'driver.stdout').open('wb') as out,(outdir/'driver.stderr').open('wb') as err:
  p=subprocess.Popen(receipt['argv'],stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
  receipt['driverPid']=p.pid
  (outdir/'launch.json').write_text(json.dumps(receipt,indent=2)+'\n')
  try:receipt['driverExit']=p.wait(timeout=150)
  except subprocess.TimeoutExpired:
   receipt['timeout']=True;p.send_signal(signal.SIGINT)
   receipt['interruptForOwnedFinally']=True;receipt['driverExit']=p.wait(timeout=25)
 native=BASE/'terminal-r1/receipt.json'
 receipt['nativeReceiptPresent']=native.is_file()
 if native.is_file():
  b=native.read_bytes();r=json.loads(b)
  receipt.update({'nativeReceiptBytes':len(b),'nativeReceiptSha256':hashlib.sha256(b).hexdigest(),'nativePassed':r.get('passed'),'groups':r.get('groups'),'childClosure':r.get('processClosure')})
 receipt['passed']=receipt.get('driverExit')==0 and receipt.get('nativePassed') is True and not receipt.get('timeout')
except BaseException as e:
 receipt['passed']=False;receipt['error']=repr(e);receipt['traceback']=traceback.format_exc()
finally:
 receipt['driverAbsent']=bool(p and p.poll() is not None and not pathlib.Path('/proc',str(p.pid)).exists())
 receipt['completed']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 (outdir/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt),flush=True)
raise SystemExit(0 if receipt['passed'] else 1)
