# Save a transaction statement

The terminal client saves a transaction CSV returned by the local Household Ledger service. It checks the receipt and complete CSV structure before publishing a new file. The service must include the `export_transactions_csv` tool described in [transaction export](TRANSACTION_EXPORT.md).

Build the project using its existing locked dependencies:

```sh
npm ci
npm run build
```

Start your configured local ledger service using the normal project instructions. In another terminal, choose an output filename in an existing directory:

```sh
node dist/src/household-export.js --output october-expenses.csv --type expense --from 2026-10-01 --to 2026-10-31
```

The default endpoint is `http://127.0.0.1:3000/mcp`. Select another local service port with `--url`, for example:

```sh
node dist/src/household-export.js --url http://127.0.0.1:3001/mcp --output food.csv --category "Food"
```

## Options

| Option | Meaning |
| --- | --- |
| `--output PATH` | Required destination for a new file. Its directory must exist. |
| `--url URL` | A loopback HTTP `/mcp` endpoint, using `127.0.0.1`, `localhost`, or `[::1]`. |
| `--type income` or `--type expense` | The existing transaction type selection. |
| `--category TEXT` | The service's existing exact category selection. |
| `--from YYYY-MM-DD` | Inclusive first date. |
| `--to YYYY-MM-DD` | Inclusive last date. |
| `--help` | Show help without contacting a service or creating a file. |

Both `--option value` and `--option=value` are accepted. Use the equals form if a value begins with `--`. Duplicate options, unknown options and missing values refuse. The service retains its existing date validation, category semantics and record order. Currency/query filtering and pagination are not client options.

## Successful output

A successful command exits with status 0 and prints one JSON receipt containing `saved: true`, the absolute output `path`, `rowCount`, `byteCount` and `sha256`. It does not print transactions or notes to the terminal. The CSV is UTF-8 without an added byte-order mark; its bytes match the service's receipt exactly.

The fixed columns are `id,type,amountMinor,currency,date,category,note,idempotencyKey,createdAt`. All cells are quoted, quotes within values are doubled, and records end with CRLF. Embedded newlines, Unicode, whitespace and formula-like text remain literal field contents. When opening the CSV in a spreadsheet, import text fields as text to preserve that literal interpretation. Amounts are integer minor units with the original currency field; the statement performs no conversion or account-balance calculation. It is not the CSV import format or a complete ledger backup.

An empty selection is a valid header-only CSV. The current service admits up to 5,000 selected transactions and 1,048,576 CSV bytes, inclusive. A larger selection refuses as a whole; use narrower existing selectors.

## Preservation and failures

The client never writes the ledger. It calls the read-only export tool once, checks the received format, UTF-8 representation, byte count, SHA-256 and logical nine-column CSV record count, and then saves the verified bytes. These checks validate the received statement; the server is responsible for selecting a complete, consistent ledger snapshot.

Existing files, directories, symlinks and hardlink aliases are never replaced. The explicit output argument controls the destination; the filename in the server receipt cannot redirect publication. Choose another filename to export again.

Publication uses a private temporary directory beside the output. The complete file is written, flushed and closed before a new hardlink publishes it at the chosen name. This requires a filesystem that supports hardlinks; there is no overwrite or non-atomic fallback. The directory is normally removed after publication. If cleanup fails after a successful publication, the JSON receipt additionally names `cleanupDirectory`; the published CSV is complete and the named temporary directory contains its redundant staging copy.

Invalid receipts, service refusals, unsupported destinations and failed writes exit with status 1 and a JSON error on standard error. They do not publish a successful statement. Initialization and the single export request each have a 30-second timeout. There is no automatic retry, redirect following, credential discovery, account login or remote endpoint support.

The reusable functions `exportStatement`, `saveStatement` and `validateStatementReply` are exported from `src/export-client.ts`. A caller of `exportStatement` may supply a bounded `timeoutMs` from 1 to 120,000. Existing package commands and dependencies remain unchanged; invoke the compiled client using the explicit command above.
