import { realpathSync } from "node:fs";
import { fileURLToPath } from "node:url";

/** Compare file identity through links without making ordinary imports execute. */
export function isMainModule(moduleUrl: string, entryPath: string | undefined = process.argv[1]): boolean {
  if (!entryPath) return false;
  try {
    return realpathSync(entryPath) === realpathSync(fileURLToPath(moduleUrl));
  } catch {
    // Eval and embedding callers may supply an argument that is not a file.
    return false;
  }
}
