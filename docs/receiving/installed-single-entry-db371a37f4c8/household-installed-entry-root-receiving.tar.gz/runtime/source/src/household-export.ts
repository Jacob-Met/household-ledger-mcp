#!/usr/bin/env node
import { isMainModule } from "./entrypoint.js";
import { DEFAULT_EXPORT_URL, exportStatement, statementEndpoint, type StatementSelectors } from "./export-client.js";

export const EXPORT_USAGE = `Save a Household Ledger transaction statement to a new CSV file.

Usage: node dist/src/household-export.js --output NEW_FILE [options]

  --output PATH       Required; existing files are never replaced
  --url URL           Local HTTP MCP endpoint (default ${DEFAULT_EXPORT_URL})
  --type TYPE         income or expense
  --category TEXT     Existing exact category selection
  --from YYYY-MM-DD   Inclusive first date
  --to YYYY-MM-DD     Inclusive last date
  --help              Show this help without contacting a service

The output directory must exist. A JSON receipt identifies the saved CSV.
CSV preserves literal text, including formula-like fields; review it as data.
`;

export type ExportOptions = { outputPath: string; url: string; selectors: StatementSelectors };

export function parseExportArguments(argv: readonly string[]): ExportOptions | { help: true } {
  if (argv.length === 1 && (argv[0] === "--help" || argv[0] === "-h")) return { help: true };
  const values = new Map<string, string>();
  const allowed = new Set(["output", "url", "type", "category", "from", "to"]);
  for (let i = 0; i < argv.length; i++) {
    const token = argv[i];
    const split = token.indexOf("=");
    const flag = split === -1 ? token : token.slice(0, split);
    const key = flag.startsWith("--") ? flag.slice(2) : "";
    if (!allowed.has(key)) throw new Error("Unknown option: " + flag);
    if (values.has(key)) throw new Error("Duplicate option: " + flag);
    let value: string;
    if (split !== -1) value = token.slice(split + 1);
    else {
      const next = argv[++i];
      if (next === undefined || next.startsWith("--")) throw new Error("Missing value for " + flag + "; use --option=value for a value beginning with --");
      value = next;
    }
    values.set(key, value);
  }
  const outputPath = values.get("output");
  if (!outputPath || outputPath.includes("\0")) throw new Error("--output requires an explicit new file path");
  const url = statementEndpoint(values.get("url")).href;
  const type = values.get("type");
  if (type !== undefined && type !== "income" && type !== "expense") throw new Error("--type must be income or expense");
  const selectors: StatementSelectors = {};
  if (type !== undefined) selectors.type = type;
  for (const key of ["category", "from", "to"] as const) {
    if (values.has(key)) selectors[key] = values.get(key)!;
  }
  return { outputPath, url, selectors };
}

export async function runExportCli(argv: readonly string[]): Promise<number> {
  try {
    const options = parseExportArguments(argv);
    if ("help" in options) { process.stdout.write(EXPORT_USAGE); return 0; }
    const saved = await exportStatement(options);
    process.stdout.write(JSON.stringify({ saved: true, ...saved }) + "\n");
    return 0;
  } catch (error) {
    const message = error instanceof Error ? error.message : "Export failed";
    process.stderr.write(JSON.stringify({ saved: false, error: message }) + "\n");
    return 1;
  }
}

if (isMainModule(import.meta.url)) {
  process.exitCode = await runExportCli(process.argv.slice(2));
}
