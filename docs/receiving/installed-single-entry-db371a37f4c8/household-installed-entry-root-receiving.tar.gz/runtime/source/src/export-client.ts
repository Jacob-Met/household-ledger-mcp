/** Native MCP statement consumer. The server continues to own ledger selection. */
import { createHash } from "node:crypto";
import { link, mkdtemp, open, rm } from "node:fs/promises";
import { dirname, join, resolve } from "node:path";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";

const MAX_ROWS = 5000;
const MAX_BYTES = 1048576;
const HEADER = '"id","type","amountMinor","currency","date","category","note","idempotencyKey","createdAt"\r\n';
export const DEFAULT_EXPORT_URL = "http://127.0.0.1:3000/mcp";

export interface StatementSelectors {
  type?: "income" | "expense";
  category?: string;
  from?: string;
  to?: string;
}

export interface VerifiedStatement {
  csv: string;
  rowCount: number;
  byteCount: number;
  sha256: string;
}

export interface SavedStatement {
  path: string;
  rowCount: number;
  byteCount: number;
  sha256: string;
  /** A complete output was published, but this private staging directory remains. */
  cleanupDirectory?: string;
}

function record(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function invalid(message: string): never {
  throw new Error("Statement refused: " + message);
}

/** Count logical records, including quoted embedded CR/LF, without rewriting text. */
function countCsvRows(csv: string): number {
  if (!csv.startsWith(HEADER)) invalid("unexpected CSV header");
  let at = HEADER.length;
  let rows = 0;
  while (at < csv.length) {
    for (let column = 0; column < 9; column++) {
      if (csv[at++] !== '"') invalid("CSV fields must be quoted");
      let closed = false;
      while (at < csv.length) {
        if (csv[at++] !== '"') continue;
        if (csv[at] === '"') { at++; continue; }
        closed = true;
        break;
      }
      if (!closed) invalid("incomplete quoted CSV field");
      if (column < 8) {
        if (csv[at++] !== ",") invalid("CSV record must have nine columns");
      } else {
        if (csv.slice(at, at + 2) !== "\r\n") invalid("CSV record must end with CRLF");
        at += 2;
      }
    }
    if (++rows > MAX_ROWS) invalid("CSV exceeds the 5000-row limit");
  }
  return rows;
}

/** Admit only the existing export tool's complete single-text success receipt. */
export function validateStatementReply(reply: unknown): VerifiedStatement {
  if (!record(reply) || !Array.isArray(reply.content) || reply.content.length !== 1) {
    invalid("expected one MCP text result");
  }
  const content = reply.content[0];
  if (!record(content) || content.type !== "text" || typeof content.text !== "string") {
    invalid("expected one MCP text result");
  }
  if (reply.isError === true) {
    // The CLI JSON-encodes errors; terminal controls and newlines are not executed.
    invalid("the ledger service rejected the export: " + content.text.slice(0, 1000));
  }
  if (reply.isError !== undefined && reply.isError !== false) invalid("invalid MCP error flag");
  if (content.text.length > MAX_BYTES * 6 + 2048) invalid("receipt exceeds the supported size");
  let value: unknown;
  try { value = JSON.parse(content.text); } catch { invalid("receipt is not JSON"); }
  if (!record(value) || value.format !== "csv" || value.filename !== "household-transactions.csv" ||
      value.mediaType !== "text/csv; charset=utf-8" || typeof value.csv !== "string") {
    invalid("unexpected statement format");
  }
  if (!Number.isSafeInteger(value.rowCount) || (value.rowCount as number) < 0 || (value.rowCount as number) > MAX_ROWS) {
    invalid("invalid row count");
  }
  if (!Number.isSafeInteger(value.byteCount) || (value.byteCount as number) < HEADER.length ||
      (value.byteCount as number) > MAX_BYTES || value.csv.length > MAX_BYTES) {
    invalid("invalid byte count");
  }
  if (typeof value.sha256 !== "string" || !/^[0-9a-f]{64}$/.test(value.sha256)) invalid("invalid SHA-256");
  const bytes = Buffer.from(value.csv, "utf8");
  if (bytes.toString("utf8") !== value.csv) invalid("CSV cannot be represented losslessly as UTF-8");
  if (bytes.length !== value.byteCount) invalid("CSV byte count does not match its receipt");
  if (createHash("sha256").update(bytes).digest("hex") !== value.sha256) invalid("CSV SHA-256 does not match its receipt");
  if (countCsvRows(value.csv) !== value.rowCount) invalid("CSV row count does not match its receipt");
  return { csv: value.csv, rowCount: value.rowCount as number, byteCount: value.byteCount as number, sha256: value.sha256 };
}

function outputDestination(path: string): string {
  if (typeof path !== "string" || path.length === 0 || path.includes("\0")) {
    throw new Error("An explicit output file path is required");
  }
  return resolve(path);
}

/** Publish a fully written file with an atomic, no-replace hard link. */
export async function saveStatement(reply: unknown, outputPath: string): Promise<SavedStatement> {
  const statement = validateStatementReply(reply);
  const destination = outputDestination(outputPath);
  const staging = await mkdtemp(join(dirname(destination), ".household-export-"));
  let failure: unknown;
  let failed = false;
  try {
    const temporary = join(staging, "statement.csv");
    const file = await open(temporary, "wx", 0o600);
    try {
      await file.writeFile(Buffer.from(statement.csv, "utf8"));
      await file.sync();
    } finally { await file.close(); }
    // link fails if ANY destination entry already exists, including a symlink.
    // Both names are on the same filesystem; there is no overwrite fallback.
    await link(temporary, destination);
  } catch (error) { failure = error; failed = true; }
  let cleanupDirectory: string | undefined;
  try { await rm(staging, { recursive: true, force: true }); }
  catch { cleanupDirectory = staging; }
  if (failed) {
    if (cleanupDirectory) throw new Error("Statement was not saved; temporary directory remains at " + cleanupDirectory, { cause: failure });
    throw failure;
  }
  return {
    path: destination, rowCount: statement.rowCount, byteCount: statement.byteCount, sha256: statement.sha256,
    ...(cleanupDirectory ? { cleanupDirectory } : {}),
  };
}

export function statementEndpoint(value: string = DEFAULT_EXPORT_URL): URL {
  let endpoint: URL;
  try { endpoint = new URL(value); } catch { throw new Error("The MCP URL must be an absolute local HTTP URL"); }
  if (endpoint.protocol !== "http:" || !["127.0.0.1", "[::1]", "localhost"].includes(endpoint.hostname) ||
      endpoint.username || endpoint.password || endpoint.search || endpoint.hash || endpoint.pathname !== "/mcp") {
    throw new Error("Use a loopback HTTP /mcp URL without credentials, query or fragment");
  }
  return endpoint;
}

function selectedArguments(selectors: StatementSelectors): Record<string, unknown> {
  if (!record(selectors)) throw new Error("Statement selectors must be an object");
  const args: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(selectors)) {
    if (!["type", "category", "from", "to"].includes(key)) {
      throw new Error("Unsupported statement selector or value: " + key);
    }
    if (value === undefined) continue; // Optional typed properties may be absent.
    if (typeof value !== "string") throw new Error("Unsupported statement selector or value: " + key);
    if (key === "type" && value !== "income" && value !== "expense") throw new Error("Type must be income or expense");
    args[key] = value;
  }
  return args;
}

export async function exportStatement(options: {
  outputPath: string;
  url?: string;
  selectors?: StatementSelectors;
  /** Bounds initialization and the single export request; no automatic retry. */
  timeoutMs?: number;
}): Promise<SavedStatement> {
  outputDestination(options.outputPath);
  const endpoint = statementEndpoint(options.url);
  const args = selectedArguments(options.selectors ?? {});
  const timeout = options.timeoutMs ?? 30000;
  if (!Number.isSafeInteger(timeout) || timeout < 1 || timeout > 120000) throw new Error("Invalid request timeout");
  const client = new Client({ name: "household-statement-export", version: "0.1.0" }, { capabilities: {} });
  const transport = new StreamableHTTPClientTransport(endpoint, {
    requestInit: { redirect: "error" },
    fetch: (url, init) => fetch(url, { ...init, redirect: "error" }),
    reconnectionOptions: { maxRetries: 0, maxReconnectionDelay: 1000, initialReconnectionDelay: 1000, reconnectionDelayGrowFactor: 1 },
  });
  let reply: unknown;
  try {
    await client.connect(transport, { timeout, maxTotalTimeout: timeout });
    reply = await client.callTool({ name: "export_transactions_csv", arguments: args }, undefined, { timeout, maxTotalTimeout: timeout });
  } finally {
    // Finish transport cleanup before publishing a user-visible file.
    await client.close();
  }
  return saveStatement(reply, options.outputPath);
}
