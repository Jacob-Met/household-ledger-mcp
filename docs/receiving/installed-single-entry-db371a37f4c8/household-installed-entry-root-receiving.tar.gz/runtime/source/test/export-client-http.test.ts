import { test, type TestContext } from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { once } from "node:events";
import { createHash } from "node:crypto";
import { createServer as httpServer, type Server as HttpServer } from "node:http";
import { createServer } from "node:net";
import { mkdtemp, readFile, readdir, rm, stat, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { CallToolRequestSchema } from "@modelcontextprotocol/sdk/types.js";
import { exportStatement } from "../src/export-client.js";
import { listTransactions, validateLedgerData, type Transaction } from "../src/ledger.js";
import { readStatementCsv } from "./transaction-export-csv-reader.js";

const cli = fileURLToPath(new URL("../src/household-export.js", import.meta.url));
const serverFile = fileURLToPath(new URL("../src/index.js", import.meta.url));
const sourceFixture = new URL("../../test/fixtures/transaction-export-ledger.json", import.meta.url);
const columns = ["id", "type", "amountMinor", "currency", "date", "category", "note", "idempotencyKey", "createdAt"];
const header = '"id","type","amountMinor","currency","date","category","note","idempotencyKey","createdAt"\r\n';
const hash = (data: string | Buffer): string => createHash("sha256").update(data).digest("hex");
type Exit = { code: number | null; signal: NodeJS.Signals | null; stdout: string; stderr: string };

async function directory(t: TestContext): Promise<string> {
  const dir = await mkdtemp(join(tmpdir(), "household-export-http-"));
  t.after(() => rm(dir, { recursive: true, force: true }));
  return dir;
}

async function runCli(args: string[]): Promise<Exit> {
  const child = spawn(process.execPath, [cli, ...args], { stdio: ["ignore", "pipe", "pipe"] });
  let stdout = "", stderr = "";
  child.stdout.on("data", value => { stdout += value; });
  child.stderr.on("data", value => { stderr += value; });
  const timer = setTimeout(() => child.kill("SIGTERM"), 15000);
  try {
    const [code, signal] = await once(child, "close") as [number | null, NodeJS.Signals | null];
    return { code, signal, stdout, stderr };
  } finally { clearTimeout(timer); }
}

async function launch(t: TestContext, ledger: string): Promise<string> {
  const probe = createServer();
  probe.listen(0, "127.0.0.1");
  await once(probe, "listening");
  const address = probe.address();
  assert.ok(address && typeof address !== "string");
  const port = address.port;
  await new Promise<void>((resolve, reject) => probe.close(error => error ? reject(error) : resolve()));
  const child = spawn(process.execPath, [serverFile], {
    env: { ...process.env, HOUSEHOLD_LEDGER_HOST: "127.0.0.1", HOUSEHOLD_LEDGER_PORT: String(port), HOUSEHOLD_LEDGER_DATA_PATH: ledger },
    stdio: ["ignore", "pipe", "pipe"],
  });
  let stderr = "";
  child.stderr.on("data", value => { stderr += value; });
  t.after(async () => {
    if (child.exitCode === null && child.signalCode === null) {
      const closed = once(child, "close"); child.kill("SIGTERM"); await closed;
    }
    assert.equal(stderr, "");
  });
  await new Promise<void>((resolve, reject) => {
    let stdout = "";
    const timer = setTimeout(() => reject(new Error("Native service startup timed out: " + stderr)), 10000);
    child.once("error", error => { clearTimeout(timer); reject(error); });
    child.once("exit", code => { clearTimeout(timer); reject(new Error("Native service exited before listening: " + code + " " + stderr)); });
    child.stdout.on("data", value => {
      stdout += value;
      if (stdout.includes("listening on")) { clearTimeout(timer); resolve(); }
    });
  });
  return "http://127.0.0.1:" + port + "/mcp";
}

function expectedRows(snapshot: ReturnType<typeof validateLedgerData>, args: Parameters<typeof listTransactions>[1]): string[][] {
  return [columns, ...listTransactions(snapshot, args).transactions.map(transaction => columns.map(key => {
    const value = transaction[key as keyof Transaction];
    return value === undefined ? "" : String(value);
  }))];
}

test("compiled CLI exports selected literal records through the native HTTP service and repeats exactly", async t => {
  const dir = await directory(t), ledger = join(dir, "ledger.json");
  const original = await readFile(sourceFixture);
  const snapshot = validateLedgerData(JSON.parse(original.toString("utf8")));
  await writeFile(ledger, original);
  const before = await stat(ledger);
  const url = await launch(t, ledger);
  const selections = [
    { flags: [] as string[], args: {} },
    { flags: ["--type", "expense", "--from", "2026-10-03", "--to", "2026-10-04"], args: { type: "expense" as const, from: "2026-10-03", to: "2026-10-04" } },
    { flags: ["--category", '食費, "週末"'], args: { category: '食費, "週末"' } },
    { flags: ["--category", " Food "], args: { category: " Food " } },
    { flags: ["--category", "never-matching"], args: { category: "never-matching" } },
  ];
  for (const [i, selection] of selections.entries()) {
    const output = join(dir, "statement # " + i + " %.csv");
    const run = await runCli(["--url", url, "--output", output, ...selection.flags]);
    assert.equal(run.code, 0, JSON.stringify(run));
    assert.equal(run.signal, null);
    assert.equal(run.stderr, "");
    const receipt = JSON.parse(run.stdout);
    const saved = await readFile(output);
    assert.deepEqual(readStatementCsv(saved.toString("utf8")), expectedRows(snapshot, selection.args));
    assert.deepEqual(receipt, { saved: true, path: output, rowCount: expectedRows(snapshot, selection.args).length - 1, byteCount: saved.length, sha256: hash(saved) });
    assert.deepEqual(await readFile(ledger), original);
    assert.equal((await stat(ledger)).mtimeMs, before.mtimeMs);
  }
  const repeat = join(dir, "repeat.csv");
  assert.equal((await runCli(["--url", url, "--output", repeat])).code, 0);
  assert.deepEqual(await readFile(repeat), await readFile(join(dir, "statement # 0 %.csv")));
  assert.equal((await readdir(dir)).some(name => name.startsWith(".household-export-")), false);
});

test("actual CLI existing-output and source-file refusals preserve both files", async t => {
  const dir = await directory(t), ledger = join(dir, "ledger.json"), output = join(dir, "existing.csv");
  const original = await readFile(sourceFixture);
  await writeFile(ledger, original);
  await writeFile(output, "owned prior output\n");
  const before = await stat(ledger), outputBefore = await stat(output);
  const url = await launch(t, ledger);
  for (const path of [output, ledger]) {
    const result = await runCli(["--url", url, "--output", path]);
    assert.equal(result.code, 1, JSON.stringify(result));
    assert.equal(result.stdout, "");
    assert.equal(JSON.parse(result.stderr).saved, false);
  }
  assert.deepEqual(await readFile(ledger), original);
  assert.equal((await stat(ledger)).mtimeMs, before.mtimeMs);
  assert.equal(await readFile(output, "utf8"), "owned prior output\n");
  assert.equal((await stat(output)).mtimeMs, outputBefore.mtimeMs);
});

test("native whole-result limits and invalid selectors refuse without partial output", async t => {
  const dir = await directory(t), ledger = join(dir, "ledger.json");
  const transactions = Array.from({ length: 5001 }, (_, i) => ({
    id: "row-" + i, type: "expense", amountMinor: 1, currency: "USD", date: "2026-10-08", category: i === 5000 ? "Only" : "Food",
  }));
  const original = Buffer.from(JSON.stringify({ version: 1, transactions, budgets: [] }) + "\n");
  await writeFile(ledger, original);
  const url = await launch(t, ledger);
  for (const flags of [[], ["--from", "2026-02-30"]]) {
    const output = join(dir, "refused.csv");
    const result = await runCli(["--url", url, "--output", output, ...flags]);
    assert.equal(result.code, 1, JSON.stringify(result));
    assert.equal(result.stdout, "");
    await assert.rejects(stat(output), { code: "ENOENT" });
  }
  const output = join(dir, "selected.csv");
  const result = await runCli(["--url", url, "--output", output, "--category", "Only"]);
  assert.equal(result.code, 0, JSON.stringify(result));
  assert.equal(JSON.parse(result.stdout).rowCount, 1);
  assert.deepEqual(await readFile(ledger), original);
});

test("missing ledger exports a header without creating the ledger or its parent", async t => {
  const dir = await directory(t), ledger = join(dir, "absent", "ledger.json"), output = join(dir, "empty.csv");
  const url = await launch(t, ledger);
  const result = await runCli(["--url", url, "--output", output]);
  assert.equal(result.code, 0, JSON.stringify(result));
  assert.equal(await readFile(output, "utf8"), header);
  assert.equal(JSON.parse(result.stdout).rowCount, 0);
  await assert.rejects(stat(join(dir, "absent")), { code: "ENOENT" });
});

async function serve(t: TestContext, server: HttpServer): Promise<string> {
  server.listen(0, "127.0.0.1");
  await once(server, "listening");
  t.after(async () => {
    server.closeAllConnections();
    await new Promise<void>((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
  });
  const address = server.address();
  assert.ok(address && typeof address !== "string");
  return "http://127.0.0.1:" + address.port + "/mcp";
}

test("real SDK fault responses refuse publication and each client makes one export call", async t => {
  const dir = await directory(t);
  let calls = 0;
  const server = httpServer(async (req, res) => {
    const chunks: Buffer[] = [];
    for await (const chunk of req) chunks.push(Buffer.from(chunk));
    const body = chunks.length ? JSON.parse(Buffer.concat(chunks).toString("utf8")) : undefined;
    const mcp = new Server({ name: "statement-receipt-fault", version: "1" }, { capabilities: { tools: {} } });
    mcp.setRequestHandler(CallToolRequestSchema, async request => {
      assert.equal(request.params.name, "export_transactions_csv");
      assert.deepEqual(request.params.arguments, {});
      calls++;
      return { content: [{ type: "text", text: JSON.stringify({ format: "csv", filename: "household-transactions.csv",
        mediaType: "text/csv; charset=utf-8", csv: header, byteCount: Buffer.byteLength(header), rowCount: 0, sha256: "0".repeat(64) }) }] };
    });
    const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined });
    try { await mcp.connect(transport); await transport.handleRequest(req, res, body); }
    finally { await transport.close(); }
  });
  const url = await serve(t, server);
  const result = await runCli(["--url", url, "--output", join(dir, "not-created.csv")]);
  assert.equal(result.code, 1, JSON.stringify(result));
  assert.match(JSON.parse(result.stderr).error, /SHA-256/);
  assert.equal(calls, 1);
  await assert.rejects(exportStatement({
    url, outputPath: join(dir, "also-not-created.csv"),
    selectors: { type: undefined, category: undefined, from: undefined, to: undefined },
  }), /SHA-256/);
  assert.equal(calls, 2);
  assert.deepEqual(await readdir(dir), []);
});

test("an unresponsive service times out and redirects are not followed", async t => {
  const dir = await directory(t);
  const unresponsive = httpServer(req => req.resume());
  const silentUrl = await serve(t, unresponsive);
  await assert.rejects(exportStatement({ url: silentUrl, outputPath: join(dir, "timeout.csv"), timeoutMs: 200 }));
  let followed = 0;
  const redirect = httpServer((req, res) => {
    req.resume();
    if (req.url === "/mcp") { res.writeHead(307, { location: "/redirected" }); res.end(); }
    else { followed++; res.writeHead(500); res.end(); }
  });
  const redirectUrl = await serve(t, redirect);
  await assert.rejects(exportStatement({ url: redirectUrl, outputPath: join(dir, "redirect.csv"), timeoutMs: 2000 }));
  assert.equal(followed, 0);
  assert.deepEqual(await readdir(dir), []);
});

test("CLI help and malformed options complete without a service or output", async t => {
  const dir = await directory(t);
  const help = await runCli(["--help"]);
  assert.equal(help.code, 0, JSON.stringify(help));
  assert.match(help.stdout, /--output/);
  assert.equal(help.stderr, "");
  const invalid = await runCli(["--output", join(dir, "no.csv"), "--limit", "1"]);
  assert.equal(invalid.code, 1);
  assert.equal(invalid.stdout, "");
  assert.match(JSON.parse(invalid.stderr).error, /Unknown option/);
  assert.deepEqual(await readdir(dir), []);
});
