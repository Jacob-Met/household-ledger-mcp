import assert from "node:assert/strict";
import { spawn, execFile } from "node:child_process";
import { once } from "node:events";
import { access, cp, mkdtemp, rm, writeFile } from "node:fs/promises";
import { createServer } from "node:net";
import { dirname, join } from "node:path";
import { test } from "node:test";
import { fileURLToPath, pathToFileURL } from "node:url";
import { promisify } from "node:util";

const execFileAsync = promisify(execFile);
const compiledSource = fileURLToPath(new URL("../src/", import.meta.url));

async function encodedEntry() {
  // Keep the copied module below this package so its locked SDK can resolve.
  const dir = await mkdtemp(join(dirname(compiledSource), "entry point # % "));
  await cp(compiledSource, join(dir, "src"), { recursive: true });
  return { dir, entry: join(dir, "src", "index.js"), data: join(dir, "ledger.json") };
}

test("HTTP entrypoint launches from a native path containing spaces, # and %", { timeout: 15000 }, async () => {
  const fixture = await encodedEntry();
  const probe = createServer();
  probe.listen(0, "127.0.0.1");
  await once(probe, "listening");
  const address = probe.address();
  assert.ok(address && typeof address === "object");
  const port = address.port;
  await new Promise<void>((resolve, reject) => probe.close(error => error ? reject(error) : resolve()));
  const child = spawn(process.execPath, [fixture.entry], {
    env: {
      ...process.env,
      HOUSEHOLD_LEDGER_DATA_PATH: fixture.data,
      HOUSEHOLD_LEDGER_HOST: "127.0.0.1",
      HOUSEHOLD_LEDGER_PORT: String(port),
    },
    stdio: ["ignore", "pipe", "pipe"],
  });
  const exited = new Promise<void>(resolve => {
    child.once("close", () => resolve());
    child.once("error", () => resolve());
  });
  let stdout = "";
  let stderr = "";
  child.stdout.on("data", chunk => { stdout += String(chunk); });
  child.stderr.on("data", chunk => { stderr += String(chunk); });
  try {
    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => finish(new Error(`startup timed out: ${stderr}`)), 5000);
      const onError = (error: Error) => finish(error);
      const onExit = (code: number | null) => finish(new Error(`server exited ${code}: ${stderr}`));
      const onData = () => { if (stdout.includes("listening on")) finish(); };
      const finish = (error?: Error) => {
        clearTimeout(timer);
        child.off("error", onError);
        child.off("exit", onExit);
        child.stdout.off("data", onData);
        if (error) reject(error); else resolve();
      };
      child.once("error", onError);
      child.once("exit", onExit);
      child.stdout.on("data", onData);
    });
    const response = await fetch(`http://127.0.0.1:${port}/healthz`, { signal: AbortSignal.timeout(3000) });
    assert.equal(response.status, 200);
    assert.deepEqual(await response.json(), { ok: true, service: "household-ledger-mcp" });
    assert.equal(stderr, "");
    await assert.rejects(access(fixture.data), { code: "ENOENT" });
  } finally {
    if (child.exitCode === null && child.signalCode === null) child.kill();
    await exited;
    await rm(fixture.dir, { recursive: true, force: true });
  }
});

test("importing the HTTP module from another entrypoint does not launch a server", { timeout: 15000 }, async () => {
  const fixture = await encodedEntry();
  try {
    const consumer = join(fixture.dir, "import consumer # %.mjs");
    await writeFile(consumer, `const subject = await import(${JSON.stringify(pathToFileURL(fixture.entry).href)});\nconsole.log(typeof subject.main);\n`);
    const result = await execFileAsync(process.execPath, [consumer], {
      env: { ...process.env, HOUSEHOLD_LEDGER_DATA_PATH: fixture.data, HOUSEHOLD_LEDGER_HOST: "0.0.0.0" },
      timeout: 5000,
    });
    assert.equal(result.stdout.trim(), "function");
    assert.equal(result.stderr, "");
    await assert.rejects(access(fixture.data), { code: "ENOENT" });
  } finally {
    await rm(fixture.dir, { recursive: true, force: true });
  }
});

test("eval can import the HTTP module when process.argv[1] is absent", { timeout: 15000 }, async () => {
  const fixture = await encodedEntry();
  try {
    const script = `if (process.argv[1] !== undefined) throw new Error("unexpected entry argument");\nconst subject = await import(${JSON.stringify(pathToFileURL(fixture.entry).href)});\nconsole.log(typeof subject.main);\n`;
    const result = await execFileAsync(process.execPath, ["--input-type=module", "--eval", script], {
      env: { ...process.env, HOUSEHOLD_LEDGER_DATA_PATH: fixture.data, HOUSEHOLD_LEDGER_HOST: "0.0.0.0" },
      timeout: 5000,
    });
    assert.equal(result.stdout.trim(), "function");
    assert.equal(result.stderr, "");
    await assert.rejects(access(fixture.data), { code: "ENOENT" });
  } finally {
    await rm(fixture.dir, { recursive: true, force: true });
  }
});
