import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { access, mkdtemp, readFile, rm, symlink, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { test } from "node:test";
import { fileURLToPath, pathToFileURL } from "node:url";

const compiledSource = fileURLToPath(new URL("../src/", import.meta.url));
const serverEntry = join(compiledSource, "index.js");
const exportEntry = join(compiledSource, "household-export.js");

async function invoke(args: string[], dataPath: string) {
  const child = spawn(process.execPath, args, {
    env: { ...process.env, HOUSEHOLD_LEDGER_HOST: "127.0.0.1", HOUSEHOLD_LEDGER_PORT: "0", HOUSEHOLD_LEDGER_DATA_PATH: dataPath },
    stdio: ["ignore", "pipe", "pipe"],
  });
  let stdout = "", stderr = "";
  child.stdout.on("data", chunk => { stdout += String(chunk); });
  child.stderr.on("data", chunk => { stderr += String(chunk); });
  return await new Promise<{ code: number | null; stdout: string; stderr: string }>((resolve, reject) => {
    const timer = setTimeout(() => { child.kill(); reject(new Error("entrypoint did not finish within 5 seconds")); }, 5000);
    child.once("error", error => { clearTimeout(timer); reject(error); });
    child.once("close", code => { clearTimeout(timer); resolve({ code, stdout, stderr }); });
  });
}

async function linkedSource() {
  const dir = await mkdtemp(join(dirname(compiledSource), "bin paths # % "));
  const linked = join(dir, "linked source");
  // A directory link supports Windows without symlink-creation privileges and
  // keeps relative imports valid with --preserve-symlinks-main.
  await symlink(compiledSource, linked, process.platform === "win32" ? "junction" : "dir");
  return { dir, linked, data: join(dir, "private-ledger.json") };
}

test("the advertised server bin has a Node executable header after compilation", async () => {
  const packageFile = fileURLToPath(new URL("../../package.json", import.meta.url));
  const metadata = JSON.parse(await readFile(packageFile, "utf8"));
  assert.equal(metadata.bin["household-ledger-mcp"], "dist/src/index.js");
  assert.match(await readFile(serverEntry, "utf8"), /^#!\/usr\/bin\/env node\r?\n/);
});

for (const flags of [[], ["--preserve-symlinks-main"]]) {
  const mode = flags.length ? "preserved main links" : "ordinary Node links";
  test("linked server reaches application admission with " + mode, { timeout: 15000 }, async () => {
    const fixture = await linkedSource();
    try {
      const result = await invoke([...flags, join(fixture.linked, "index.js")], fixture.data);
      assert.equal(result.code, 1, JSON.stringify(result));
      assert.equal(result.stdout, "");
      assert.match(result.stderr, /HOUSEHOLD_LEDGER_PORT must be 1\.\.65535/);
      await assert.rejects(access(fixture.data), { code: "ENOENT" });
    } finally { await rm(fixture.dir, { recursive: true, force: true }); }
  });

  test("linked export command displays help with " + mode, { timeout: 15000 }, async () => {
    const fixture = await linkedSource();
    try {
      const result = await invoke([...flags, join(fixture.linked, "household-export.js"), "--help"], fixture.data);
      assert.equal(result.code, 0, JSON.stringify(result));
      assert.match(result.stdout, /Save a Household Ledger transaction statement to a new CSV file/);
      assert.match(result.stdout, /--output PATH/);
      assert.equal(result.stderr, "");
      await assert.rejects(access(fixture.data), { code: "ENOENT" });
    } finally { await rm(fixture.dir, { recursive: true, force: true }); }
  });
}

for (const missing of [false, true]) {
  test("both entry modules remain passive when argv[1] is " + (missing ? "nonresolvable" : "absent"), { timeout: 15000 }, async () => {
    const fixture = await linkedSource();
    try {
      const script = [
        missing ? "process.argv[1] = " + JSON.stringify(join(fixture.dir, "not a real entry # %.js")) + ";" : "delete process.argv[1];",
        "const server = await import(" + JSON.stringify(pathToFileURL(serverEntry).href) + ");",
        "const exporter = await import(" + JSON.stringify(pathToFileURL(exportEntry).href) + ");",
        'console.log(JSON.stringify([typeof server.main, typeof exporter.runExportCli]));',
      ].join("\n");
      const result = await invoke(["--input-type=module", "--eval", script], fixture.data);
      assert.equal(result.code, 0, JSON.stringify(result));
      assert.deepEqual(JSON.parse(result.stdout), ["function", "function"]);
      assert.equal(result.stderr, "");
      await assert.rejects(access(fixture.data), { code: "ENOENT" });
    } finally { await rm(fixture.dir, { recursive: true, force: true }); }
  });
}

test("a different real entry file can import both commands without running them", { timeout: 15000 }, async () => {
  const fixture = await linkedSource();
  try {
    const consumer = join(fixture.dir, "passive consumer # %.mjs");
    await writeFile(consumer, [
      "const server = await import(" + JSON.stringify(pathToFileURL(serverEntry).href) + ");",
      "const exporter = await import(" + JSON.stringify(pathToFileURL(exportEntry).href) + ");",
      'console.log(JSON.stringify([typeof server.main, typeof exporter.runExportCli]));',
    ].join("\n"));
    const result = await invoke([consumer], fixture.data);
    assert.equal(result.code, 0, JSON.stringify(result));
    assert.deepEqual(JSON.parse(result.stdout), ["function", "function"]);
    assert.equal(result.stderr, "");
    await assert.rejects(access(fixture.data), { code: "ENOENT" });
  } finally { await rm(fixture.dir, { recursive: true, force: true }); }
});
