import { test } from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { link, mkdtemp, readFile, readdir, rm, stat, symlink, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { saveStatement, statementEndpoint, validateStatementReply } from "../src/export-client.js";
import { parseExportArguments } from "../src/household-export.js";

const COLUMNS = ["id", "type", "amountMinor", "currency", "date", "category", "note", "idempotencyKey", "createdAt"];
const row = (values: string[]): string => values.map(value => '"' + value.replace(/"/g, '""') + '"').join(",") + "\r\n";
const HEADER = row(COLUMNS);
const literal = ["receipt-1", "expense", "9007199254740991", "USD", "2026-10-08", " Food ", '=SUM(1,2)\r\n"quoted" 🍵\0', "source-1", "2026-10-08T10:00:00.000Z"];
const hash = (bytes: string | Buffer): string => createHash("sha256").update(bytes).digest("hex");
function report(csv = HEADER + row(literal), rowCount = 1): Record<string, unknown> {
  return { format: "csv", filename: "household-transactions.csv", mediaType: "text/csv; charset=utf-8", csv,
    rowCount, byteCount: Buffer.byteLength(csv), sha256: hash(csv) };
}
const envelope = (value: unknown): unknown => ({ content: [{ type: "text", text: JSON.stringify(value) }] });

test("receipt admission preserves literal data and counts logical quoted records", () => {
  const csv = HEADER + row(literal) + row([...literal.slice(0, 6), "\n\r\r\n,\"\"", ...literal.slice(7)]);
  assert.deepEqual(validateStatementReply(envelope(report(csv, 2))), { csv, rowCount: 2, byteCount: Buffer.byteLength(csv), sha256: hash(csv) });
  assert.equal(validateStatementReply(envelope(report(HEADER, 0))).rowCount, 0);
});

test("the current row and byte limits are inclusive", () => {
  const small = ["id", "expense", "1", "USD", "2026-10-08", "Food", "", "", ""];
  const many = HEADER + row(small).repeat(5000);
  assert.equal(validateStatementReply(envelope(report(many, 5000))).rowCount, 5000);
  const bytes = 1048576 - Buffer.byteLength(HEADER + row(small));
  const exact = HEADER + row([...small.slice(0, 6), "a".repeat(bytes), ...small.slice(7)]);
  assert.equal(validateStatementReply(envelope(report(exact))).byteCount, 1048576);
  assert.throws(() => validateStatementReply(envelope(report(exact + "x"))), /byte count/);
  assert.throws(() => validateStatementReply(envelope(report(many + row(small), 5001))), /row count/);
});

test("wrong metadata, corrupted bytes and malformed MCP envelopes refuse", () => {
  const original = report();
  for (const change of [
    { format: "json" }, { filename: "../ledger.json" }, { mediaType: "text/plain" },
    { rowCount: -1 }, { rowCount: 1.5 }, { rowCount: "1" }, { rowCount: 0 },
    { byteCount: 0 }, { byteCount: 100 }, { byteCount: "100" },
    { sha256: "a".repeat(64) }, { sha256: String(original.sha256).toUpperCase() }, { csv: 3 },
  ]) assert.throws(() => validateStatementReply(envelope({ ...original, ...change })));
  for (const bad of [null, [], {}, { content: [] }, { content: [{ type: "image" }] },
    { content: [{ type: "text", text: "{}" }, { type: "text", text: "{}" }] },
    { content: [{ type: "text", text: "{" }] },
    { isError: "false", content: [{ type: "text", text: JSON.stringify(original) }] }]) {
    assert.throws(() => validateStatementReply(bad));
  }
  assert.throws(() => validateStatementReply({ isError: true, content: [{ type: "text", text: "narrow selection" }] }), /narrow selection/);
});

test("a matching hash cannot make incomplete or structurally invalid CSV valid", () => {
  for (const csv of [
    HEADER + row(literal).slice(0, -2),
    HEADER + row(literal) + "\r\n",
    HEADER + row(literal.slice(0, -1)),
    HEADER + row([...literal, "extra"]),
    HEADER + row(literal).replace('"receipt-1"', "receipt-1"),
    HEADER.replace('"id"', '"ID"') + row(literal),
    HEADER + '"unterminated',
  ]) assert.throws(() => validateStatementReply(envelope(report(csv))));
  assert.throws(() => validateStatementReply(envelope(report(HEADER + row([...literal.slice(0, 6), "\ud800", ...literal.slice(7)])))), /losslessly/);
});

test("saving publishes the exact verified bytes and preserves existing entries", async t => {
  const dir = await mkdtemp(join(tmpdir(), "household-export-save-"));
  t.after(() => rm(dir, { recursive: true, force: true }));
  const path = join(dir, "chosen name # % 🍵.csv");
  const receipt = await saveStatement(envelope(report()), path);
  assert.deepEqual(await readFile(path), Buffer.from(String(report().csv), "utf8"));
  assert.deepEqual(receipt, { path, rowCount: 1, byteCount: report().byteCount, sha256: report().sha256 });
  const before = await stat(path);
  await assert.rejects(saveStatement(envelope(report(HEADER, 0)), path), { code: "EEXIST" });
  assert.equal((await stat(path)).mtimeMs, before.mtimeMs);
  assert.equal(hash(await readFile(path)), receipt.sha256);
  assert.deepEqual(await readdir(dir), ["chosen name # % 🍵.csv"]);
});

test("a ledger, its hardlink and symlinks are never replaced", async t => {
  const dir = await mkdtemp(join(tmpdir(), "household-export-existing-"));
  t.after(() => rm(dir, { recursive: true, force: true }));
  const ledger = join(dir, "ledger.json"), alias = join(dir, "alias.csv"), shortcut = join(dir, "shortcut.csv");
  const original = Buffer.from('{"version":1,"transactions":[],"budgets":[]}\n');
  await writeFile(ledger, original);
  await link(ledger, alias);
  for (const target of [ledger, alias, dir]) await assert.rejects(saveStatement(envelope(report()), target), { code: "EEXIST" });
  try {
    await symlink(ledger, shortcut, "file");
    await assert.rejects(saveStatement(envelope(report()), shortcut), { code: "EEXIST" });
    const dangling = join(dir, "dangling.csv");
    await symlink(join(dir, "absent-target"), dangling, "file");
    await assert.rejects(saveStatement(envelope(report()), dangling), { code: "EEXIST" });
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== "EPERM") throw error;
    t.diagnostic("Windows host does not grant symlink creation; file and hardlink preservation executed");
  }
  assert.deepEqual(await readFile(ledger), original);
  assert.deepEqual(await readFile(alias), original);
  assert.equal((await readdir(dir)).some(name => name.startsWith(".household-export-")), false);
});

test("invalid receipts and missing output directories produce no partial statement", async t => {
  const dir = await mkdtemp(join(tmpdir(), "household-export-refusal-"));
  t.after(() => rm(dir, { recursive: true, force: true }));
  await assert.rejects(saveStatement(envelope({ ...report(), sha256: "0".repeat(64) }), join(dir, "invalid.csv")));
  await assert.rejects(saveStatement(envelope(report()), join(dir, "missing", "statement.csv")), { code: "ENOENT" });
  await assert.rejects(saveStatement(envelope(report()), ""));
  assert.deepEqual(await readdir(dir), []);
});

test("competing publishers produce one whole statement and never overwrite the winner", async t => {
  const dir = await mkdtemp(join(tmpdir(), "household-export-race-"));
  t.after(() => rm(dir, { recursive: true, force: true }));
  const path = join(dir, "same.csv");
  const attempts = await Promise.allSettled([
    saveStatement(envelope(report()), path),
    saveStatement(envelope(report(HEADER, 0)), path),
  ]);
  const successes = attempts.filter((value): value is PromiseFulfilledResult<Awaited<ReturnType<typeof saveStatement>>> => value.status === "fulfilled");
  assert.equal(successes.length, 1);
  const rejected = attempts.find(value => value.status === "rejected") as PromiseRejectedResult;
  assert.equal(rejected.reason.code, "EEXIST");
  assert.equal(hash(await readFile(path)), successes[0].value.sha256);
  assert.deepEqual(await readdir(dir), ["same.csv"]);
});

test("argument parsing preserves explicit selections and refuses ambiguous input", () => {
  assert.deepEqual(parseExportArguments(["--help"]), { help: true });
  assert.deepEqual(parseExportArguments(["-h"]), { help: true });
  assert.deepEqual(parseExportArguments(["--output", "chosen.csv", "--type", "expense", "--category=--literal=🍵", "--from", "2026-10-01", "--to", "2026-10-31"]), {
    outputPath: "chosen.csv", url: "http://127.0.0.1:3000/mcp", selectors: { type: "expense", category: "--literal=🍵", from: "2026-10-01", to: "2026-10-31" },
  });
  for (const args of [[], ["--output"], ["--output", "--from", "2026-10-01"], ["--output="],
    ["--output", "a", "--output", "b"], ["--output", "a", "--limit", "1"],
    ["--help", "--output", "a"], ["--output", "a", "--type", "other"],
    ["--output", "a", "extra"], ["--output", "a\0b"]]) assert.throws(() => parseExportArguments(args));
});

test("endpoint selection stays within the existing local service contract", () => {
  for (const url of ["http://127.0.0.1:1234/mcp", "http://localhost/mcp", "http://[::1]:3001/mcp"]) assert.equal(statementEndpoint(url).href, url);
  for (const url of ["https://127.0.0.1/mcp", "http://example.com/mcp", "http://127.0.0.1/mcp?key=x", "http://127.0.0.1/mcp#x",
    "http://user:password@127.0.0.1/mcp", "http://127.0.0.1/elsewhere", "relative"]) assert.throws(() => statementEndpoint(url));
});
