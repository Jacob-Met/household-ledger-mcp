from pathlib import Path
import os,json,hashlib,tarfile,shutil,datetime,stat,traceback,sys
BASE=Path('/dev/shm/hamon-household-installed-entry-root-db371a37f4c8')
BASE.mkdir()
OWNER=Path('/home/jacob/snap/chromium/common/hamon-household-installed-record-db371a37f4c8')
AUTH=Path('/dev/shm/hamon-household-installed-record-db371a37f4c8-receiving')
PRIOR=Path('/home/jacob/snap/chromium/common/hamon-household-entry-receiving-db371a37f4c8/candidate-r3-source-build')
CONTRACT=Path('/home/jacob/snap/chromium/common/hamon-household-installed-entry-receiving-db371a37f4c8/CONTRACT.md')
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
rec={'started':now(),'pid':os.getpid(),'root':str(BASE),'reason':'Independent admission of owner package plus accepted entry delta into a private RAM copy of the actual npm installation; no install/build/behavior replay'}
try:
 assert sha(CONTRACT.read_bytes())=='32430e477670ce9207af7796ee88e11e37abf81575434a4552adcd1f3a8f9bab'
 mem=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024
 free=shutil.disk_usage(BASE).free
 assert mem>=768*1024*1024 and free>=256*1024*1024,('RAM-copy guard',mem,free)
 rec['guard']={'memoryAvailable':mem,'ramFree':free,'minimumMemory':768*1024*1024,'minimumRamFree':256*1024*1024,'persistentFree':shutil.disk_usage(CONTRACT.parent).free,'persistentWrites':'Only final small receiving packet after closure; source/runtime/fixtures in RAM'}
 inp=BASE/'input';inp.mkdir()
 expected={
  AUTH/'installed-candidate-manifest-r1.json':'782e461f86a96c586488de4f74d72aa35e9f30a5870e67549fdb832c2c007d68',
  AUTH/'candidate-source-manifest-r1.json':'f60bbdd638c2687ddc4b7e496f125ff6f18683f124f8cf87053d4a7156d9047c',
  OWNER/'input/owner-package.tgz':'bbe5d540d0a5c579135d71f80bc2f11573581c54308feee50cc7ea57e272c67b',
  OWNER/'packages/candidate-final/household-ledger-mcp-0.1.0.tgz':'a2faaa7dc271badaa70e178cb501293f02b47dc8ede01a757c082e6f914b07a8',
  OWNER/'input/dependency-full-source-pins-r1.json':'5274e4b46eca7c11a4c894d7963f888852159c9276ec4a5c9a6ef4a02f7acd47'
 }
 rec['inputs']=[]
 for p,h in expected.items():
  b=p.read_bytes();assert sha(b)==h,str(p)
  dest=inp/('candidate-final.tgz' if p.name=='household-ledger-mcp-0.1.0.tgz' else p.name)
  dest.write_bytes(b);rec['inputs'].append({'source':str(p),'copy':str(dest),'bytes':len(b),'sha256':h})
 (inp/'CONTRACT.md').write_bytes(CONTRACT.read_bytes())
 ep=json.loads((OWNER/'input/entry-source-pins.json').read_text())
 for e in ep['files']:
  b=(PRIOR/e['path']).read_bytes();assert len(b)==e['bytes'] and sha(b)==e['sha256'],('previous accepted entry',e['path'])
 (inp/'accepted-entry-source-pins.json').write_bytes((OWNER/'input/entry-source-pins.json').read_bytes())
 oldentry={e['path']:e for e in ep['files']}
 srcpins=json.loads((inp/'candidate-source-manifest-r1.json').read_text())
 source=Path(srcpins['root']);srcmap={e['path']:e for e in srcpins['files']}
 destsource=BASE/'source';destsource.mkdir()
 for e in srcpins['files']:
  p=source/e['path'];b=p.read_bytes()
  assert not p.is_symlink() and len(b)==e['bytes'] and sha(b)==e['sha256'] and git(b)==e['git'],e['path']
  q=destsource/e['path'];q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
 with tarfile.open(inp/'owner-package.tgz','r:gz') as t:
  ownermembers=t.getmembers();assert len(ownermembers)==208
  owner={}
  for m in ownermembers:
   assert m.isfile() and m.name.startswith('package/') and '..' not in Path(m.name).parts
   owner[m.name[8:]]=t.extractfile(m).read()
 assert len(owner)==208
 assert all(sha((destsource/p).read_bytes())==sha(b) for p,b in owner.items() if p!='package.json')
 op=json.loads(owner['package.json']);np=json.loads((destsource/'package.json').read_text())
 assert np['bin'].pop('household-record')=='dist/src/household-record.js' and np==op
 additions=set(srcmap)-set(owner)
 entry_add=set(ep['newPaths'])
 for p in ep['newPaths']:
  if p.endswith('.ts'):
   stem='dist/'+p[:-3]
   entry_add.update(stem+s for s in ['.js','.js.map','.d.ts'])
 assert additions==entry_add|{'package-lock.json','validation/installed-record.mjs'},sorted(additions)
 differences=[]
 for p in sorted(entry_add):
  current=(destsource/p).read_bytes();old=(PRIOR/p).read_bytes()
  if current!=old:differences.append(p)
  if p in ['src/household-record.ts','dist/src/household-record.js']:
   assert current==b'#!/usr/bin/env node\n'+old,p
  elif p=='docs/RECORD_CLIENT.md':assert current.startswith(old) and len(current)>len(old),p
  elif p=='dist/src/household-record.js.map':
   a=json.loads(old);b=json.loads(current);am=a.pop('mappings');bm=b.pop('mappings')
   assert a==b and bm==';'+am,('only shebang source-map offset',p)
  else:assert current==old,p
 beforelock=json.loads((OWNER/'baseline/package-lock.json').read_text())
 afterlock=json.loads((destsource/'package-lock.json').read_text())
 assert afterlock['packages']['']['bin'].pop('household-record')=='dist/src/household-record.js'
 assert beforelock==afterlock,'only additive lock root bin'
 with tarfile.open(inp/'candidate-final.tgz','r:gz') as t:
  members=t.getmembers();assert len(members)==226
  packed=set()
  for m in members:
   assert m.isfile() and m.name.startswith('package/') and '..' not in Path(m.name).parts
   p=m.name[8:];b=t.extractfile(m).read();packed.add(p)
   assert len(b)==srcmap[p]['bytes'] and sha(b)==srcmap[p]['sha256'],p
  assert packed==set(srcmap)-{'package-lock.json'}
 ip=json.loads((inp/'installed-candidate-manifest-r1.json').read_text())
 installed=Path(ip['root']);copy=BASE/'installation';copy.mkdir()
 dep=json.loads((inp/'dependency-full-source-pins-r1.json').read_text());deps={e['path']:e for e in dep['files']}
 expected_paths=set();dependency_count=0;copybytes=0;links=[]
 for e in ip['files']:
  p=installed/e['path'];q=copy/e['path'];q.parent.mkdir(parents=True,exist_ok=True);expected_paths.add(e['path'])
  if e['type']=='link':
   assert p.is_symlink() and os.readlink(p)==e['target'],e['path']
   q.symlink_to(e['target']);links.append(e);continue
  assert e['type']=='file' and not p.is_symlink()
  b=p.read_bytes();assert len(b)==e['bytes'] and sha(b)==e['sha256'] and git(b)==e['git'],e['path']
  assert stat.S_IMODE(p.stat().st_mode)==e['mode'],e['path']
  shutil.copy2(p,q);copybytes+=len(b)
  if e['path'].startswith('node_modules/household-ledger-mcp/'):
   rel=e['path'].removeprefix('node_modules/household-ledger-mcp/')
   assert rel in packed and sha(b)==srcmap[rel]['sha256'],rel
  elif e['path'].startswith('node_modules/') and e['path']!='node_modules/.package-lock.json':
   rel=e['path'].removeprefix('node_modules/');pin=deps[rel]
   assert len(b)==pin['bytes'] and sha(b)==pin['sha256'],rel
   dependency_count+=1
 for e in links:
  q=copy/e['path'];assert q.resolve().is_relative_to(copy),e['path']
 actual=set()
 for d,dirs,names in os.walk(copy,followlinks=False):
  for n in list(dirs):
   q=Path(d)/n
   if q.is_symlink():actual.add(q.relative_to(copy).as_posix());dirs.remove(n)
  for n in names:actual.add((Path(d)/n).relative_to(copy).as_posix())
 assert actual==expected_paths and dependency_count==3643
 for e in ip['files']:
  q=copy/e['path']
  if e['type']=='link':assert os.readlink(q)==e['target']
  else:assert sha(q.read_bytes())==e['sha256'] and stat.S_IMODE(q.stat().st_mode)==e['mode']
 recordbin=copy/'node_modules/.bin/household-record';assert os.access(recordbin,os.X_OK) and recordbin.resolve()==copy/'node_modules/household-ledger-mcp/dist/src/household-record.js'
 unrelated=BASE/'unrelated-cwd';unrelated.mkdir()
 link=unrelated/'record-via-local-link';link.symlink_to(recordbin)
 assert link.resolve()==recordbin.resolve()
 rec.update({'ok':True,'contractSha256':sha(CONTRACT.read_bytes()),'previousAcceptedEntry99Exact':True,'ownerPackageMembers':208,'ownerMembersUnchanged':207,'onlyOwnerChange':'package.json additive household-record bin; all other fields equal','candidateSources':len(srcmap),'candidatePackageMembers':226,'candidateSourceAdditions':sorted(additions),'differencesWithinAcceptedEntry':differences,'sourceMapOnlyShebangLine':True,'lockOnlyAdditiveRecordBin':True,'installedEntries':len(expected_paths),'installedBytes':copybytes,'runtimeDependencyRegularFiles':dependency_count,'completeCopiedSetAndModesExact':True,'links':links,'osExecutable':str(recordbin),'localLink':str(link),'realTarget':str(recordbin.resolve()),'cwd':str(unrelated),'keptAuthorInstallationUnmodified':True})
except Exception as e:rec.update({'ok':False,'error':repr(e),'traceback':traceback.format_exc()})
finally:
 rec['completed']=now()
 b=(json.dumps(rec,ensure_ascii=False,indent=2)+'\n').encode()
 with (BASE/'admission-r1.json').open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 print(json.dumps({'ok':rec.get('ok'),'receipt':str(BASE/'admission-r1.json'),'sha256':sha(b),'summary':{k:rec.get(k) for k in ['candidateSources','candidatePackageMembers','installedEntries','installedBytes','runtimeDependencyRegularFiles','osExecutable','error']}},ensure_ascii=False),flush=True)
sys.exit(0 if rec.get('ok') else 1)
