import os,json,hashlib,tarfile,io,stat,datetime,shutil,base64,sys,signal
from pathlib import Path
base=Path("/home/jacob/snap/chromium/common/hamon-household-installed-record-db371a37f4c8")
ram=Path("/dev/shm/hamon-household-installed-record-db371a37f4c8-receiving")
pub=base/"publication-author-r1"
assert not pub.exists(), "prior persistent seal had no filesystem effects"
free=shutil.disk_usage(base).free
mi={x.split(":")[0]:int(x.split()[1])*1024 for x in Path("/proc/meminfo").read_text().splitlines()}
assert mi["MemAvailable"] >= 1024*1024*1024, ("memory admission refused",mi["MemAvailable"])
signal.alarm(900)
def sha(b): return hashlib.sha256(b).hexdigest()
def git(b): return hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()
sm=ram/"candidate-source-manifest-r1.json"
im=ram/"installed-candidate-manifest-r1.json"
assert sha(sm.read_bytes())=="f60bbdd638c2687ddc4b7e496f125ff6f18683f124f8cf87053d4a7156d9047c"
assert sha(im.read_bytes())=="782e461f86a96c586488de4f74d72aa35e9f30a5870e67549fdb832c2c007d68"
source=json.loads(sm.read_text()); installed=json.loads(im.read_text())
def verify(m):
 root=Path(m["root"])
 wanted=set()
 for row in m["files"]:
  p=root/row["path"];wanted.add(row["path"])
  if row.get("type")=="link":
   assert p.is_symlink() and os.readlink(p)==row["target"],str(p)
  else:
   assert p.is_file() and not p.is_symlink(),str(p)
   b=p.read_bytes()
   assert len(b)==row["bytes"] and sha(b)==row["sha256"],str(p)
   if "git" in row: assert git(b)==row["git"],str(p)
 actual=set()
 for d,ds,fs in os.walk(root,followlinks=False):
  for n in list(ds):
   p=Path(d)/n
   if p.is_symlink():
    ds.remove(n)
    if p.name!="node_modules": actual.add(str(p.relative_to(root)))
  for n in fs: actual.add(str((Path(d)/n).relative_to(root)))
 assert actual==wanted,{"extra":sorted(actual-wanted),"missing":sorted(wanted-actual)}
 return len(wanted)
before={"source":verify(source),"installed":verify(installed)}
owner=base/"input/owner-package.tgz"
assert sha(owner.read_bytes())=="bbe5d540d0a5c579135d71f80bc2f11573581c54308feee50cc7ea57e272c67b"
n=0
with tarfile.open(owner,"r:gz") as t:
 for x in t.getmembers():
  if not x.isfile(): continue
  p=x.name.removeprefix("package/")
  if p=="package.json": continue
  assert t.extractfile(x).read()==(base/"candidate"/p).read_bytes(),p
  n+=1
assert n==207,n
assert (base/"candidate/src/household-record.ts").read_bytes().removeprefix(b"#!/usr/bin/env node\n")== (base/"baseline/src/household-record.ts").read_bytes()
assert (base/"candidate/src/record-client.ts").read_bytes()==(base/"baseline/src/record-client.ts").read_bytes()
items={}
def add(label,p):
 assert label not in items and p.is_file() and not p.is_symlink(),(label,str(p))
 items[label]=p
scoped=["package.json","package-lock.json","src/household-record.ts","src/record-client.ts","docs/RECORD_CLIENT.md"]
for which in ["baseline","candidate"]:
 for rel in scoped: add("source/"+which+"/"+rel,base/which/rel)
add("source/candidate/validation/installed-record.mjs",base/"candidate/validation/installed-record.mjs")
for subtree in ["input","evidence","packages"]:
 for p in sorted((base/subtree).rglob("*")):
  if p.is_file() and not p.is_symlink(): add("author/"+str(p.relative_to(base)),p)
excluded=[]
for d,ds,fs in os.walk(ram,followlinks=False):
 ds[:]=[n for n in ds if n not in ["installation","npm-cache"]]
 for n in sorted(fs):
  p=Path(d)/n; rel=str(p.relative_to(ram))
  if p.is_symlink():
   excluded.append({"path":rel,"type":"link","target":os.readlink(p),"reason":"receipt-local alias; identity retained without executable archive link"})
  elif rel=="retirement-r1/closed-baseline-installation.tar.gz":
   excluded.append({"path":rel,"bytes":p.stat().st_size,"sha256":sha(p.read_bytes()),"reason":"duplicate generated dependency contents omitted; exact original manifest and retirement receipt included"})
  else:add("receiving/"+rel,p)
files=[]
for label,p in sorted(items.items()):
 b=p.read_bytes()
 files.append({"path":label,"nativePath":str(p),"bytes":len(b),"sha256":sha(b),"git":git(b),"mode":stat.S_IMODE(p.stat().st_mode)})
report="# Installed household-record: native package qualification\n\nThis is the narrow installed-command extension of accepted single-entry custody `4b135480d48089cc4aa08f25c0f8b0ee79b4d0e4`. It lets a household user invoke `household-record` through npm's generated local executable link, or an explicitly created local link, from an unrelated working directory. Recording, saved-request, endpoint, idempotency and confirmation semantics are unchanged.\n\n## Source and owner boundary\n\nThe starting package is 99cea's offered native successor `2b59c5cd3f9aeb2b0c34633f1b295c22720a6b2f`, tree `9779a33ceb9aaaf689bed769dff24fd4611af9d1`. Its 241,470-byte, 208-member npm package has SHA256 `bbe5d540d0a5c579135d71f80bc2f11573581c54308feee50cc7ea57e272c67b`. The package/server/export owner remains responsible for that source and helper; ce7/61749 retain canonical and aggregate adoption. Issue 13 reservation comment 6071644680 identifies this additive consumer seam.\n\nThe five changed source paths after composing the offered package with the frozen entry contribution are:\n\n- `package.json`: add the `household-record` bin mapping.\n- `package-lock.json`: add that root-package bin mapping while preserving the inherited server-bin string.\n- `src/household-record.ts`: add only `#!/usr/bin/env node`.\n- `docs/RECORD_CLIENT.md`: append installed-use instructions and POSIX/Windows qualification boundaries.\n- `validation/installed-record.mjs`: maintain the six installed-dispatch checks.\n\nRemoving the one interpreter directive reproduces the complete frozen CLI body. The existing realpath guard and recording core are unchanged. The final source manifest contains 227 files. All 207 owner package members other than package.json are preserved exactly. The standalone source patch is 8,615 bytes, SHA256 `dc503015ced5c9ce48c5719d6d30deac374255d818ef6c802c7c45d8abe05a52`. No snapshot ancestry is proposed as canonical repository ancestry.\n\n## Actual package and install\n\nThe final native `npm pack` artifact is 264,193 bytes and 226 members, SHA256 `a2faaa7dc271badaa70e178cb501293f02b47dc8ede01a757c082e6f914b07a8`. The complete package is included. The source package-lock is separately retained because npm omits package-lock from the tarball.\n\nNative runtime was Linux x86_64, Node 22.22.1 and npm 9.2.0. The actual final installation used:\n\n```text\n/usr/bin/npm install --omit=dev --offline --ignore-scripts --package-lock=false --no-audit --no-fund --prefix /dev/shm/hamon-household-installed-record-db371a37f4c8-receiving/installation /home/jacob/snap/chromium/common/hamon-household-installed-record-db371a37f4c8/packages/candidate-final/household-ledger-mcp-0.1.0.tgz\n```\n\nThe receiving project was runtime-only; this did not alter product metadata. npm completed with exit 0 in 2.060 seconds, reporting one package changed. The installed manifest pins 3,874 file/link entries, including every final package member and 3,643 runtime dependency regular files matching the complete donor manifest. Installation bytes and links were unchanged across the author receiver.\n\nThis was an actual npm installation in an owned RAM prefix. It is qualification of native OS/shebang and link dispatch, not durable user activation, a global PATH change, a running production ledger or an installed service. Windows generated-command execution remains unqualified. Existing owners retain durable integration.\n\n## Author native observations\n\nThe same maintained receiver first ran against the original npm-installed baseline. It failed at the first OS spawn with ENOENT because the original package did not expose household-record. No child executed and no HTTP request occurred. The raw summary's `children: 1` counts one attempted spawn, not an actual child; the full process record has exit null and code ENOENT.\n\nAgainst the final installed package, all six groups passed in one run, using six actual CLI child processes and zero HTTP requests:\n\n1. OS execution through npm's installed link from an unrelated Japanese-named working directory.\n2. Execution through a second local link with identical, single-dispatch help.\n3. Node execution through that second link.\n4. Piped new invocation refused before contacting the observer or creating a request file.\n5. Passive import exported the function without starting the CLI or contacting the observer.\n6. Invalid arguments refused, preserving the caller's sentinel and exact directory contents.\n\nThe maintained receiver is SHA256 `909941ebae327c977f34442713619539e9f418c8f93f5cb867c803539604fdb6`. The passed receipt is SHA256 `84200367aba234d27d6da0c63f8833917363599ff84676b5e268f55543349692`; its loopback observer closed. These author groups intentionally do not repeat the original accepted single-entry matrices, full lost-ack receiving or producer behavior. Root's separately frozen contract `32430e477670ce9207af7796ee88e11e37abf81575434a4552adcd1f3a8f9bab` owns the independent installed real-terminal cancellation/confirmation/same-request-resume gate, supplied in a separate packet.\n\n## Dependency and execution history\n\nThe original 2,960-file dependency manifest was a selected regular-file closure, not a full installed inventory. Full capture found 938 further regular files (3,486,806 bytes) and three bin links, totaling 3,898 regular files. Every previously selected file matched. Full manifest SHA256 is `5274e4b46eca7c11a4c894d7963f888852159c9276ec4a5c9a6ef4a02f7acd47`. This current capture makes no retrospective hash claim for the omitted files at older gates.\n\nThe initial incomplete copy caused a missing TypeScript launcher failure; an alternate launcher attempt then produced nine missing Response-member diagnostics. Both failed receipts and outputs are retained. After the complete copy, the candidate typecheck passed with exit 0 in 9.8526 seconds, empty stdout/stderr, unchanged locked tool versions and a 256 MiB Node heap limit. The receipt is SHA256 `688d91457d6b54f70872bda750cbe3fc47c6f61389d9fae41a027854811fdc8c`.\n\nRecovery later found these completed receipts. A proposed duplicate stage stopped at an existing-directory assertion before any compiler launch; no completed product gate was repeated. An earlier cleanup attempt refused to recursively remove a symlink, deleting no dependency content; its alias refusal is retained.\n\nPersistent installation upgrade was refused at 235,524,096 free bytes, below the 256 MiB floor plus margin. The admitted final install therefore used an existing owned RAM placement. Root's later independent RAM admission separately encountered actual EDQUOT because filesystem free did not imply uid quota room. That root staging negative is not an author product result and remains in the root packet.\n\n## Scoped retirement and custody\n\nAfter exact closure checks, only our redundant generated persistent dependency copy and closed baseline installation were retired. This freed 88,494,080 actual bytes. All 482 retained source/package/evidence files, all 3,898 donor regular files and three donor link targets matched before/after; no active matching process existed. The final installed RAM tree was untouched.\n\nThe closed baseline was archived and all 3,866 members roundtripped before retirement: 3,864,499 bytes, SHA256 `ea8048daf72228f0d8945ad82e1f6ee1f361ac9cccb7f1642d85641d86cdc247`. This narrow delivery includes its exact manifest and retirement receipt, not another copy of those dependency files. The local retirement archive remains separately retained. Source dependency links now point read-only to the unchanged existing donor; no shared cache or peer file was removed.\n\nThis archive includes scoped before/after source texts, the maintained receiver and patch, all four package stages, complete source/installed/dependency manifests, native command logs and failures, and retirement receipts. It omits node_modules contents, live installed-tree copies, npm caches and the duplicate closed-baseline dependency archive. Archive members and all input source hashes were verified before/after sealing. It contains no workflows at repository root and proposes no automatic Actions invocation.\n"

report += "\n## Final delivery placement\n\nThe first persistent seal refused at 218,025,984 free bytes before creating a directory or writing a file; its guard was 256 MiB plus 32 MiB headroom. Native process 3382167 was observed finished. This final archive was constructed and roundtrip-verified in the sealing process's memory under a fresh 1 GiB MemAvailable floor, without a new filesystem allocation. Its immutable bytes are intended for Git object custody. No tmpfs quota, identity, source, installed file or test predicate was changed.\n"
memory={"AUTHOR.md":report.encode(),"persistent-seal-admission-refused.json":(json.dumps({"observedPid":3382167,"observedFinished":True,"freeBytes":218025984,"floorBytes":268435456,"headroomBytes":33554432,"phase":"before mkdir or write","productRun":False,"sourceUnmodified":True},indent=2)+"\n").encode()}
native_argv=Path("/proc/self/cmdline").read_bytes().split(b"\0")
assert b"-c" in native_argv
memory["sealing-script.py"]=native_argv[native_argv.index(b"-c")+1]
memory["memory-sealer-argv-negative-r1.json"]=(json.dumps({"pid":3390825,"observedFinished":True,"error":"AssertionError at fixed argv index, because python used -u before -c","phase":"in-process metadata construction after read-only input verification","filesystemWrites":False,"productRun":False,"correction":"find the actual -c argument before preserving script source"},indent=2)+"\n").encode()
for label,b in memory.items():
 files.append({"path":label,"nativePath":None,"bytes":len(b),"sha256":sha(b),"git":git(b),"mode":0o644})
manifest={"created":datetime.datetime.now(datetime.timezone.utc).isoformat(),"scope":"author installed command only; independent terminal receiving separate","sourceManifestSha256":sha(sm.read_bytes()),"installedManifestSha256":sha(im.read_bytes()),"before":before,"unchangedOwnerPackageMembers":n,"files":sorted(files,key=lambda r:r["path"]),"excluded":excluded,"noDependencyCopies":True,"delivery":"in-process archive under memory guard; no filesystem allocation"}
mb=(json.dumps(manifest,indent=2,ensure_ascii=False)+"\n").encode()
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode="w:gz",compresslevel=6) as t:
 for label,p in sorted(items.items()):t.add(p,arcname=label,recursive=False)
 for label,b in sorted({**memory,"manifest.json":mb}.items()):
  ti=tarfile.TarInfo(label);ti.size=len(b);ti.mode=0o644
  t.addfile(ti,io.BytesIO(b))
raw=buf.getvalue()
with tarfile.open(fileobj=io.BytesIO(raw),mode="r:gz") as t:
 members=t.getmembers(); expected={r["path"]:r for r in files}
 assert len(members)==len(expected)+1
 for x in members:
  assert x.isfile()
  b=t.extractfile(x).read()
  if x.name=="manifest.json":assert b==mb
  else:
   e=expected[x.name];assert len(b)==e["bytes"] and sha(b)==e["sha256"] and git(b)==e["git"],x.name
for row in files:
 if row["nativePath"] is None:continue
 b=Path(row["nativePath"]).read_bytes()
 assert len(b)==row["bytes"] and sha(b)==row["sha256"],row["path"]
after={"source":verify(source),"installed":verify(installed)}
seal={"finished":datetime.datetime.now(datetime.timezone.utc).isoformat(),"archive":{"name":"household-installed-record-author.tar.gz","bytes":len(raw),"sha256":sha(raw),"git":git(raw),"members":len(members)},"manifest":{"bytes":len(mb),"sha256":sha(mb),"git":git(mb)},"report":{"bytes":len(memory["AUTHOR.md"]),"sha256":sha(memory["AUTHOR.md"]),"git":git(memory["AUTHOR.md"])},"allArchiveMembersVerified":True,"allPayloadSourcesBeforeAfterExact":True,"sourceAndInstalledBefore":before,"sourceAndInstalledAfter":after,"sourceUnchanged":True,"freeFilesystemObserved":free,"memAvailableBefore":mi["MemAvailable"],"memoryFloor":1073741824,"noFilesystemAllocation":True,"noProductRun":True,"sealingPid":os.getpid()}
b64=base64.b64encode(raw).decode()
print("READY "+json.dumps({"seal":seal,"encodedLength":len(b64),"chunkChars":128000}),flush=True)
for line in sys.stdin:
 args=line.strip().split()
 if not args:continue
 if args[0]=="chunk":
  idx=int(args[1]);chunk=b64[idx*128000:(idx+1)*128000]
  print("CHUNK "+json.dumps({"index":idx,"chars":len(chunk),"data":chunk}),flush=True)
 elif args[0]=="meta":print("META "+json.dumps({"seal":seal,"manifest":manifest,"report":report}),flush=True)
 elif args[0]=="close":print("CLOSED",flush=True);break
 else:print("UNKNOWN",flush=True)
