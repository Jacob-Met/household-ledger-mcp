# Independent receiving: Household Ledger CSV import

**Disposition: ACCEPT** for the native contribution at `07e223b5da19cea0f048219d8c85689fcc1ba83f`, tree `76cd2cc60b10dabdd301d32a53da4b833015193d`, directly over cashflow parent `a799c917a8a20e293baae576ae8b03bdd1b63b49`.

The reviewed repository is [household-ledger-mcp](https://github.com/Jacob-Met/household-ledger-mcp). This packet qualifies the isolated native source contribution. Canonical-main integration and production deployment are not claimed.

## Result and scope

Eight independent HTTP scope groups qualify, together with one deterministic native Store queue control. The two HTTP runs made **68 actual MCP tool calls across 13 initialized private sessions**. Every session used the existing compiled server, its installed SDK dependencies, an explicit private ledger path and an unused loopback port. All owned children exited and private test data was removed. Source and build fingerprints stayed unchanged.

[review-result.json](review-result.json) provides the coverage accounting. The raw request/result traces and durable ledger snapshots are retained in the receipts below.

| Boundary | Independent evidence |
| --- | --- |
| Exact normalized preview, quoted comma and CRLF note, doubled quotes, emoji and distinct Unicode identities; physical starting lines 2, 4 and 5 | Corrected HTTP receipt: quoted-CSV group |
| Original IDs, creation timestamps and notes returned on same-process and restart retry; byte hash, inode and nanosecond modification time unchanged | Corrected HTTP receipt: quoted-CSV group |
| Maximum safe integer minor units, separate currency totals, and simultaneously maximum gross income/expense with zero net | Original HTTP receipt: exact-money group |
| Different accepted LF/CRLF bytes require different tokens; mismatched token refuses; distinct lone surrogates with identical UTF-8 replacement bytes are both refused | Original HTTP receipt: token-identity group |
| Omitted note versus explicit empty note follows native identity rules; conflict preview exposes the exact original and returns no commit token | Original HTTP receipt: note-presence group |
| Native write after preview causes whole-batch refusal, including an unrelated proposed addition; a later valid import succeeds | Corrected HTTP receipt: stale-preview group |
| Concurrent identical imports retain one durable set and return original receipts; conflicting overlapping imports have one complete winner and no losing partial rows | Corrected HTTP receipt: concurrent-imports group |
| Concurrent import, native recording and denominated budget writes preserve every disjoint change | Original HTTP receipt: mixed-queue group |
| Unsafe integer, duplicate source keys, invalid date, unsupported header, malformed quotes and overflowing gross total refuse without writing; header-only preview cannot commit | Corrected HTTP receipt: full-batch-refusal group |
| A held public Store.update predecessor deterministically queues an import through another Store instance for the same private file; matching reclassification, CSV-order receipts, following native write and budget are preserved | Native Store queue receipt |

The last control uses the actual compiled importer and Store exports in one process, without monkeypatching them. It is a deterministic queue control, separately identified from the real HTTP sessions. No cross-process writer lock is claimed.

## Source reception

[source-receiving.json](source-receiving.json) verifies all **83 tracked files** against the frozen Git objects and author manifest. All **75 unaffected parent leaves** are preserved. Reversing only the authorized additions in index.ts, README.md and the tool-roster test reconstructs the exact parent bytes. Store, cashflow, stdio and the existing cashflow tests remain unchanged.

[frozen-manifest.mjs](frozen-manifest.mjs) pins all 27 source, package, compiled JavaScript, declaration and source-map files used by the receiver. The original five-tool absence control is retained as historical evidence against owner parent `402061a5af29d4d3095a09ca55ef9b2fc5c2bbd0`; the current candidate's eight-tool roster includes cashflow.

## Reviewer correction retained

The original [HTTP receipt](independent-http-receipt.json) reports four successes and four checks interrupted by the reviewer's incorrect expectation that a transaction-only ledger must use version 2. The unchanged native `emptyLedger()` deliberately starts at legacy version 1; denominated budgets introduce version 2.

This was a receiver error. Product source was not changed. [harness-correction.json](harness-correction.json) records the exact correction. The four unaffected successes remain at their original receipt. Only the four interrupted groups were rerun, and all four passed in [independent-http-final-receipt.json](independent-http-final-receipt.json). The original script and failure are preserved unchanged.

The raw Unicode refusal trace includes intentionally ill-formed UTF-16 inputs represented with JSON escapes. Preserve the original receipt bytes when copying this packet.

## Artifacts and replay

The packet retains the executed baseline, HTTP and queue scripts; literal fixtures; source verification; exact source/build fingerprints; raw receipts; correction record; disposition; and SHA256SUMS.json. Scripts point to the isolated native checkout and private receiver directory identified in their headers. Preserve this frozen packet when replaying them; use a separately named private receiver directory for new receipts.

The successful evidence demonstrates native content binding, validation, same-process serialization and durable idempotent replay. The token is not authentication, proof of human review or a ledger lock. This receiving made no production ledger, service, repository-content or provider mutation.
