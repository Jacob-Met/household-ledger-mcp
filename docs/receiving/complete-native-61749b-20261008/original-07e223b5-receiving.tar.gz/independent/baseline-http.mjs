import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';
import { join } from 'node:path';
import { mkdir, mkdtemp, readFile, writeFile, rm } from 'node:fs/promises';
import { createServer } from 'node:net';
import { createHash } from 'node:crypto';
import { spawn, execFileSync } from 'node:child_process';
import { once } from 'node:events';

const native = '/Users/me/hamon-household-import-a219f250962c';
const review = '/Users/me/household-import-review-a219f250962c';
const require = createRequire(join(native, 'package.json'));
const { Client } = require('@modelcontextprotocol/sdk/client/index.js');
const { StreamableHTTPClientTransport } = require('@modelcontextprotocol/sdk/client/streamableHttp.js');
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
const baseline = '402061a5af29d4d3095a09ca55ef9b2fc5c2bbd0';
await mkdir(review, { recursive: true, mode: 0o700 });
const temporary = await mkdtemp(join(review, 'baseline-private-'));
const ledger = join(temporary, 'ledger.json');
const sourceFiles = ['src/index.ts', 'src/ledger.ts', 'dist/src/index.js', 'dist/src/ledger.js', 'package-lock.json'];
const before = Object.fromEntries(await Promise.all(sourceFiles.map(async path => [path, sha256(await readFile(join(native, path)))])));
assert.equal(before['src/index.ts'], '258edce55c0d6e4bf49a49779b895914baf20fa41e13a15d194ccf24508d54ad');
assert.equal(before['src/ledger.ts'], '743eb94413383d8872b2eb4670d2813c2924d78cf9ae0d2b479432f9e8ae8c07');
assert.equal(execFileSync('git', ['-C', native, 'rev-parse', baseline + '^{tree}'], { encoding: 'utf8' }).trim(), 'c12ea46ff3d917a0bdcea6a5106f88f3574bbfaa');

const probe = createServer();
probe.listen(0, '127.0.0.1');
await once(probe, 'listening');
const port = probe.address().port;
await new Promise((resolve, reject) => probe.close(error => error ? reject(error) : resolve()));
const child = spawn(process.execPath, [join(native, 'dist/src/index.js')], {
  cwd: temporary,
  env: { PATH: process.env.PATH, HOUSEHOLD_LEDGER_DATA_PATH: ledger, HOUSEHOLD_LEDGER_HOST: '127.0.0.1', HOUSEHOLD_LEDGER_PORT: String(port) },
  stdio: ['ignore', 'pipe', 'pipe'],
});
let stdout = '', stderr = '', client;
child.stdout.on('data', value => { stdout += String(value); });
child.stderr.on('data', value => { stderr += String(value); });
const receipt = {
  schema: 'household.csv-import.baseline-http.v1',
  at: new Date().toISOString(),
  source_commit: baseline,
  source_tree: 'c12ea46ff3d917a0bdcea6a5106f88f3574bbfaa',
  node: process.version,
  source_and_dist_before: before,
  checks: [],
  scope: 'Original accepted owner-composition compiled MCP server, isolated loopback process and private absent ledger; no canonical-main or deployment claim.',
};
let failure;
try {
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('startup timeout: ' + stderr)), 6000);
    child.once('error', error => { clearTimeout(timer); reject(error); });
    child.once('exit', code => { clearTimeout(timer); reject(new Error('server exited before readiness: ' + code + ' ' + stderr)); });
    const ready = chunk => { if (String(chunk).includes('listening on')) { clearTimeout(timer); resolve(); } };
    child.stdout.on('data', ready);
    if (stdout.includes('listening on')) { clearTimeout(timer); resolve(); }
  });
  const origin = new URL('http://127.0.0.1:' + port);
  const health = await fetch(new URL('/healthz', origin));
  assert.equal(health.status, 200);
  client = new Client({ name: 'independent-csv-baseline-receiver', version: '1' }, { capabilities: {} });
  await client.connect(new StreamableHTTPClientTransport(new URL('/mcp', origin)));
  const catalogue = await client.listTools();
  const names = catalogue.tools.map(tool => tool.name).sort();
  assert(names.includes('record_transaction'));
  assert(!names.includes('preview_transaction_import'));
  assert(!names.includes('commit_transaction_import'));
  receipt.checks.push({ name: 'actual initialized tools/list lacks both requested import capabilities', tool_names: names, passed: true });
  const csv = 'idempotencyKey,type,amountMinor,currency,date,category,note\nbaseline-source-1,expense,123,usd,2026-10-08,Food,"quoted note"\n';
  for (const name of ['preview_transaction_import', 'commit_transaction_import']) {
    let observation;
    try {
      const result = await client.callTool({ name, arguments: { csv, ...(name.startsWith('commit') ? { reviewToken: 'baseline-unavailable' } : {}) } });
      observation = { kind: 'tool-result', isError: result.isError === true, content: result.content };
      assert.equal(result.isError, true);
      assert.match(JSON.stringify(result.content), /unknown tool|not found|unrecognized|unsupported/i);
    } catch (error) {
      if (error?.code === 'ERR_ASSERTION') throw error;
      observation = { kind: 'protocol-error', message: String(error.message), code: error.code };
      assert.match(String(error.message), /unknown tool|not found|unrecognized|unsupported/i);
    }
    receipt.checks.push({ name: 'original MCP refuses ' + name, observation, passed: true });
  }
  let exists = true;
  try { await readFile(ledger); } catch (error) { assert.equal(error.code, 'ENOENT'); exists = false; }
  assert.equal(exists, false);
  receipt.checks.push({ name: 'baseline absence/refusal controls create no ledger or transactions', passed: true });
} catch (error) {
  failure = error;
  receipt.failure = String(error.stack ?? error);
} finally {
  await client?.close().catch(error => { receipt.client_close_error = String(error.message); });
  if (child.exitCode === null && child.signalCode === null) {
    const exited = once(child, 'exit');
    child.kill('SIGTERM');
    await Promise.race([exited, new Promise((_, reject) => setTimeout(() => reject(new Error('owned child stop timed out')), 6000))]);
  }
  receipt.child_exit = { code: child.exitCode, signal: child.signalCode };
  receipt.source_and_dist_after = Object.fromEntries(await Promise.all(sourceFiles.map(async path => [path, sha256(await readFile(join(native, path)))])));
  receipt.source_and_dist_unchanged = JSON.stringify(before) === JSON.stringify(receipt.source_and_dist_after);
  receipt.server_stderr = stderr;
  receipt.private_data_removed = false;
  await rm(temporary, { recursive: true, force: true });
  receipt.private_data_removed = true;
  receipt.passed = !failure && receipt.source_and_dist_unchanged && receipt.checks.length === 4;
  await writeFile(join(review, 'baseline-http-receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
  console.log(JSON.stringify(receipt));
}
if (!receipt.passed) process.exitCode = 1;
