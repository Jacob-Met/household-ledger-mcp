export const headers = 'idempotencyKey,type,amountMinor,currency,date,category';
export const quotedUnicode = {
  csv: headers + ',note\r\n' +
    '"bank-🧾-e\u0301",expense,17," usd ",2024-02-29," Food, café ","line one,\r\nline two ""quoted"" 🦊"\r\n' +
    'bank-café,income,23,eUr,2026-10-08," Salary ",""\r\n' +
    'bank-cafe\u0301,expense,31,eur,2026-10-08," Food ",literal\\n\r\n',
  expected: [
    { idempotencyKey: 'bank-🧾-e\u0301', type: 'expense', amountMinor: 17, currency: 'USD', date: '2024-02-29', category: 'Food, café', note: 'line one,\r\nline two "quoted" 🦊' },
    { idempotencyKey: 'bank-café', type: 'income', amountMinor: 23, currency: 'EUR', date: '2026-10-08', category: 'Salary', note: '' },
    { idempotencyKey: 'bank-cafe\u0301', type: 'expense', amountMinor: 31, currency: 'EUR', date: '2026-10-08', category: 'Food', note: 'literal\\n' },
  ],
};

// These are literal fixtures with independently written expected values. This
// helper emits only unquoted, single-line rows; quoted CSV behavior is above.
export function csvRow(key, amount = 7, extras = {}) {
  const input = { idempotencyKey: key, type: 'expense', amountMinor: amount, currency: 'USD', date: '2026-10-08', category: 'Food', ...extras };
  const row = [input.idempotencyKey, input.type, input.amountMinor, input.currency, input.date, input.category].join(',');
  return { input, row, csv: headers + '\n' + row + '\n' };
}

export function batch(...rows) { return headers + '\n' + rows.map(row => typeof row === 'string' ? row : row.row).join('\n') + '\n'; }

export const maxSafe = {
  csv: headers + '\nmax-safe,expense,9007199254740991,USD,2026-10-08,Food\n',
  expected: { idempotencyKey: 'max-safe', type: 'expense', amountMinor: 9007199254740991, currency: 'USD', date: '2026-10-08', category: 'Food' },
};

export const malformedRows = [
  ['unsafe rounded integer', '9007199254740993'],
  ['unsafe integer boundary', '9007199254740992'],
  ['decimal', '1.1'],
  ['exponent', '1e3'],
  ['zero', '0'],
  ['negative', '-1'],
  ['nonfinite', 'Infinity'],
].map(([label, amount]) => ({ label, csv: csvRow('invalid-' + label.replaceAll(' ', '-'), amount).csv }));

export const invalidCalendars = ['2025-02-29', '2026-04-31', '2026-00-10', '2026-13-10', '2026-10-00', '2026-10-32'];
