import assert from 'node:assert/strict';
import { join } from 'node:path';
import { receivingRun, unpack, sha256 } from './receiving-runtime.mjs';
import { headers, quotedUnicode, csvRow, batch, maxSafe } from './independent-fixtures.mjs';
import { expectedHashes, frozenSource } from './frozen-manifest.mjs';

function inputOf(transaction) {
  return Object.fromEntries(['idempotencyKey', 'type', 'amountMinor', 'currency', 'date', 'category', 'note']
    .filter(key => Object.hasOwn(transaction, key)).map(key => [key, transaction[key]]));
}
async function preview(session, csv) {
  const result = unpack(await session.call('preview_transaction_import', { csv }));
  assert.equal(result.schema, 'household-transaction-import/1');
  assert.equal(result.sourceSha256, sha256(Buffer.from(csv, 'utf8')));
  assert.equal(typeof result.canCommit, 'boolean');
  if (result.canCommit) {
    assert.equal(typeof result.reviewToken, 'string');
    assert(result.reviewToken.length >= 32);
  } else assert.equal(result.reviewToken, null);
  assert.equal(result.counts.total, result.rows.length);
  assert.equal(result.counts.total, result.counts.add + result.counts.alreadyRecorded + result.counts.conflict);
  return result;
}
async function commit(session, csv, reviewToken) {
  return session.call('commit_transaction_import', { csv, reviewToken });
}
function refusal(result) { assert.equal(result.isError, true, JSON.stringify(result)); return result.content; }
function commitReceipt(result, csv, transactions, added, alreadyRecorded, totals) {
  assert.equal(result.schema, 'household-transaction-import/1');
  assert.equal(result.sourceSha256, sha256(Buffer.from(csv, 'utf8')));
  assert.equal(result.added, added);
  assert.equal(result.alreadyRecorded, alreadyRecorded);
  assert.deepEqual(result.transactions, transactions);
  assert.deepEqual(result.totals, totals);
}
async function transactionInputs(session) {
  const snapshot = await session.snapshot();
  assert.equal(snapshot.data.version, 2);
  return snapshot.data.transactions.map(inputOf);
}

await receivingRun('independent-http', expectedHashes, async context => {
  context.receipt.frozen_source = frozenSource;

  await context.check('Quoted CSV, CRLF notes, Unicode identities, normalization, and exact durable retry', async () => {
    const session = await context.session('quoted-unicode');
    assert.equal(session.record.tool_names.length, 8);
    assert.equal(new Set(session.record.tool_names).size, 8);
    for (const tool of ['get_budgets', 'list_transactions', 'monthly_summary', 'record_transaction', 'set_budget', 'preview_transaction_import', 'commit_transaction_import']) assert(session.record.tool_names.includes(tool));
    const before = await session.snapshot();
    const shown = await preview(session, quotedUnicode.csv);
    assert.equal(shown.canCommit, true);
    assert.deepEqual(shown.counts, { total: 3, add: 3, alreadyRecorded: 0, conflict: 0 });
    assert.deepEqual(shown.rows.map(row => row.input), quotedUnicode.expected);
    assert.deepEqual(shown.rows.map(row => row.line), [2, 4, 5]);
    assert.deepEqual(shown.rows.map(row => row.action), ['add', 'add', 'add']);
    for (const row of shown.rows) assert(!Object.hasOwn(row, 'existingTransaction'));
    const totals = [
      { currency: 'EUR', incomeMinor: 23, expenseMinor: 31, netMinor: -8 },
      { currency: 'USD', incomeMinor: 0, expenseMinor: 17, netMinor: -17 },
    ];
    assert.deepEqual(shown.totals, { allRows: totals, additions: totals });
    assert.deepEqual(await session.snapshot(), before, 'Preview must not create a ledger');
    const committed = unpack(await commit(session, quotedUnicode.csv, shown.reviewToken));
    const first = await session.snapshot();
    assert.deepEqual(await transactionInputs(session), quotedUnicode.expected);
    assert.equal(new Set(first.data.transactions.map(tx => tx.id)).size, 3);
    for (const tx of first.data.transactions) {
      assert.equal(typeof tx.createdAt, 'string');
      assert(Number.isFinite(Date.parse(tx.createdAt)));
    }
    commitReceipt(committed, quotedUnicode.csv, first.data.transactions, 3, 0, totals);
    const retried = unpack(await commit(session, quotedUnicode.csv, shown.reviewToken));
    commitReceipt(retried, quotedUnicode.csv, first.data.transactions, 0, 3, []);
    assert.deepEqual(await session.snapshot(), first, 'Exact retry must preserve bytes, inode, timestamps and original transactions');
    const path = session.ledger;
    await context.close(session);
    const restarted = await context.session('quoted-unicode-restart', path);
    const afterRestart = unpack(await commit(restarted, quotedUnicode.csv, shown.reviewToken));
    commitReceipt(afterRestart, quotedUnicode.csv, first.data.transactions, 0, 3, []);
    assert.deepEqual(await restarted.snapshot(), first, 'Restart retry must preserve exact original durable state');
    return { preview: shown, first_commit: committed, same_process_retry: retried, restarted_retry: afterRestart, durable: first };
  });

  await context.check('Largest safe integer amount is exact and currency totals stay separate', async () => {
    const session = await context.session('exact-money');
    const euro = csvRow('euro-max-safe', '9007199254740991', { currency: 'EUR', type: 'income' });
    const dollars = csvRow('dollar-income-max-safe', '9007199254740991', { type: 'income' });
    const csv = batch(maxSafe.csv.trimEnd().split('\n')[1], euro, dollars);
    const shown = await preview(session, csv);
    const expectedTotals = [
      { currency: 'EUR', incomeMinor: 9007199254740991, expenseMinor: 0, netMinor: 9007199254740991 },
      { currency: 'USD', incomeMinor: 9007199254740991, expenseMinor: 9007199254740991, netMinor: 0 },
    ];
    assert.deepEqual(shown.totals, { allRows: expectedTotals, additions: expectedTotals });
    const committed = unpack(await commit(session, csv, shown.reviewToken));
    const stored = await session.snapshot();
    assert.deepEqual(stored.data.transactions.map(inputOf), [maxSafe.expected, { ...euro.input, amountMinor: 9007199254740991 }, { ...dollars.input, amountMinor: 9007199254740991 }]);
    for (const tx of stored.data.transactions) assert.equal(BigInt(tx.amountMinor), 9007199254740991n);
    commitReceipt(committed, csv, stored.data.transactions, 3, 0, expectedTotals);
    return { preview: shown, durable: stored, independent_expected_per_currency: { USD: { income: '9007199254740991', expense: '9007199254740991', net: '0' }, EUR: { income: '9007199254740991', expense: '0', net: '9007199254740991' } } };
  });

  await context.check('Token refuses a different accepted CSV byte sequence and malformed Unicode cannot share custody', async () => {
    const session = await context.session('token-identity');
    const a = csvRow('byte-token', 17).csv;
    const b = a.replaceAll('\n', '\r\n');
    const pa = await preview(session, a);
    const pb = await preview(session, b);
    assert.notEqual(pa.reviewToken, pb.reviewToken, 'Distinct accepted CSV byte sequences need distinct tokens');
    const before = await session.snapshot();
    refusal(await commit(session, b, pa.reviewToken));
    assert.deepEqual(await session.snapshot(), before);
    refusal(await commit(session, a, 'invalid-independent-token'));
    assert.deepEqual(await session.snapshot(), before);
    unpack(await commit(session, b, pb.reviewToken));
    const afterValid = await session.snapshot();
    const csvA = headers + ',note\nbad-unicode,expense,11,USD,2026-10-08,Food,"\ud800"\n';
    const csvB = headers + ',note\nbad-unicode,expense,11,USD,2026-10-08,Food,"\ud801"\n';
    assert.notEqual(csvA, csvB);
    assert.deepEqual(Buffer.from(csvA, 'utf8'), Buffer.from(csvB, 'utf8'), 'Negative pair must expose UTF-8 replacement equivalence');
    const ra = await session.call('preview_transaction_import', { csv: csvA });
    const rb = await session.call('preview_transaction_import', { csv: csvB });
    refusal(ra);
    refusal(rb);
    assert.deepEqual(await session.snapshot(), afterValid, 'Invalid/cross-source checks must not write');
    return { lf_token: pa.reviewToken, crlf_token: pb.reviewToken, lone_surrogate_a: ra, lone_surrogate_b: rb, durable: afterValid };
  });

  await context.check('Omitted note versus empty note preserves original native idempotency semantics', async () => {
    const session = await context.session('note-presence');
    const item = csvRow('note-key', 19);
    const emptyNote = headers + ',note\n' + item.row + ',""\n';
    const beforeConflict = await preview(session, emptyNote);
    const original = unpack(await session.call('record_transaction', item.input));
    const before = await session.snapshot();
    const matching = await preview(session, item.csv);
    assert.equal(matching.canCommit, true);
    assert.deepEqual(matching.counts, { total: 1, add: 0, alreadyRecorded: 1, conflict: 0 });
    assert.equal(matching.rows[0].action, 'already_recorded');
    assert.deepEqual(matching.rows[0].input, item.input);
    assert.deepEqual(matching.rows[0].existingTransaction, original);
    assert.deepEqual(matching.totals.additions, []);
    const matched = unpack(await commit(session, item.csv, matching.reviewToken));
    commitReceipt(matched, item.csv, [original], 0, 1, []);
    assert.deepEqual(await session.snapshot(), before);
    const conflict = await preview(session, emptyNote);
    assert.equal(conflict.canCommit, false);
    assert.equal(conflict.reviewToken, null);
    assert.deepEqual(conflict.counts, { total: 1, add: 0, alreadyRecorded: 0, conflict: 1 });
    assert.equal(conflict.rows[0].action, 'conflict');
    assert.deepEqual(conflict.rows[0].input, { ...item.input, note: '' });
    assert.deepEqual(conflict.rows[0].existingTransaction, original);
    assert.equal(typeof conflict.rows[0].reason, 'string');
    assert.deepEqual(conflict.totals, { allRows: [{ currency: 'USD', incomeMinor: 0, expenseMinor: 19, netMinor: -19 }], additions: [] });
    refusal(await commit(session, emptyNote, beforeConflict.reviewToken));
    assert.deepEqual(await session.snapshot(), before, 'Adding an empty note is a conflict, not a silent rewrite');
    return { native_original: original, matching_preview: matching, matching_commit: matched, conflicting_preview: conflict, durable: before };
  });

  await context.check('Stale preview rechecks a native competing write and rejects the entire addition set', async () => {
    const session = await context.session('stale-preview');
    const unrelated = csvRow('must-not-leak', 31);
    const taken = csvRow('taken-after-preview', 41);
    const csv = batch(unrelated, taken);
    const shown = await preview(session, csv);
    unpack(await session.call('record_transaction', { ...taken.input, amountMinor: 43 }));
    const current = await session.snapshot();
    refusal(await commit(session, csv, shown.reviewToken));
    assert.deepEqual(await session.snapshot(), current);
    assert.equal(current.data.transactions.length, 1);
    const afterFailure = csvRow('queue-still-usable', 47);
    const good = await preview(session, afterFailure.csv);
    unpack(await commit(session, afterFailure.csv, good.reviewToken));
    assert.deepEqual(await transactionInputs(session), [{ ...taken.input, amountMinor: 43 }, afterFailure.input]);
    return { preview_before_competitor: shown, before_refusal: current, after_later_success: await session.snapshot() };
  });

  await context.check('Concurrent exact imports return one durable set, then concurrent conflict has one whole-batch winner', async () => {
    const session = await context.session('concurrent-imports');
    const sameA = csvRow('same-a', 3), sameB = csvRow('same-b', 5);
    const csv = batch(sameA, sameB);
    const shown = await preview(session, csv);
    const exact = await Promise.all([commit(session, csv, shown.reviewToken), commit(session, csv, shown.reviewToken)]);
    const exactResults = exact.map(unpack);
    assert.deepEqual(await transactionInputs(session), [sameA.input, sameB.input]);
    const exactDurable = await session.snapshot();
    assert.deepEqual(exactResults.map(result => result.added).sort(), [0, 2]);
    for (const result of exactResults) commitReceipt(result, csv, exactDurable.data.transactions, result.added, 2 - result.added,
      result.added ? [{ currency: 'USD', incomeMinor: 0, expenseMinor: 8, netMinor: -8 }] : []);
    const ax = csvRow('conflict-shared', 11), onlyA = csvRow('only-a', 13);
    const bx = csvRow('conflict-shared', 17), onlyB = csvRow('only-b', 19);
    const ca = batch(ax, onlyA), cb = batch(bx, onlyB);
    const [pa, pb] = await Promise.all([preview(session, ca), preview(session, cb)]);
    const outcomes = await Promise.all([commit(session, ca, pa.reviewToken), commit(session, cb, pb.reviewToken)]);
    assert.equal(outcomes.filter(result => result.isError === true).length, 1, 'Exactly one conflicting batch must refuse');
    const aWon = outcomes[0].isError !== true;
    const winner = unpack(outcomes[aWon ? 0 : 1]);
    refusal(outcomes[aWon ? 1 : 0]);
    assert.deepEqual(await transactionInputs(session), [sameA.input, sameB.input, ...(aWon ? [ax.input, onlyA.input] : [bx.input, onlyB.input])]);
    const durable = await session.snapshot();
    assert.equal(new Set(durable.data.transactions.map(tx => tx.idempotencyKey)).size, 4);
    assert.deepEqual(durable.data.transactions.slice(0, 2), exactDurable.data.transactions);
    commitReceipt(winner, aWon ? ca : cb, durable.data.transactions.slice(2), 2, 0,
      [{ currency: 'USD', incomeMinor: 0, expenseMinor: aWon ? 24 : 36, netMinor: aWon ? -24 : -36 }]);
    return { exact_concurrent_outcomes: exact, exact_durable: exactDurable, conflicting_outcomes: outcomes, winner: aWon ? 'A' : 'B', durable };
  });

  await context.check('Queued import and existing native transaction/budget writes retain every disjoint change', async () => {
    const session = await context.session('mixed-queue');
    unpack(await session.call('set_budget', { category: 'Food', month: '2026-10', limitMinor: 2000, currency: 'USD' }));
    const before = await session.snapshot();
    const a = csvRow('mixed-import-a', 53), b = csvRow('mixed-import-b', 59), native = csvRow('mixed-native', 61);
    const [pa, pb] = await Promise.all([preview(session, a.csv), preview(session, b.csv)]);
    const results = await Promise.all([
      commit(session, a.csv, pa.reviewToken),
      commit(session, b.csv, pb.reviewToken),
      session.call('record_transaction', native.input),
      session.call('set_budget', { category: 'Housing', month: '2026-10', limitMinor: 3000, currency: 'EUR' }),
    ]);
    results.forEach(unpack);
    const final = await session.snapshot();
    const order = rows => [...rows].sort((left, right) => left.idempotencyKey.localeCompare(right.idempotencyKey));
    assert.deepEqual(order(final.data.transactions.map(inputOf)), order([a.input, b.input, native.input]));
    assert.equal(final.data.budgets.length, 2);
    assert(final.data.budgets.some(item => JSON.stringify(item) === JSON.stringify(before.data.budgets[0])));
    assert(final.data.budgets.some(item => item.category === 'Housing' && item.currency === 'EUR' && item.limitMinor === 3000));
    assert.equal(final.data.version, before.data.version);
    return { before, outcomes: results, durable: final };
  });

  await context.check('Unsafe amount, repeated source key, and invalid calendar refuse the whole batch without writes', async () => {
    const session = await context.session('full-batch-refusal');
    const valid = csvRow('valid-before-bad', 67);
    const invalid = [
      batch(valid, csvRow('unsafe-integer', '9007199254740993')),
      batch(valid, valid),
      batch(valid, csvRow(valid.input.idempotencyKey, 71)),
      batch(valid, csvRow('invalid-calendar', 73, { date: '2025-02-29' })),
      headers + ',source\n' + valid.row + ',bank\n',
      headers + ',note\n' + valid.row + ',"unterminated\n',
      batch(csvRow('overflow-first', '9007199254740991'), csvRow('overflow-last', 1)),
    ];
    const before = await session.snapshot();
    const empty = await preview(session, headers + '\n');
    assert.equal(empty.canCommit, false);
    assert.equal(empty.reviewToken, null);
    assert.deepEqual(empty.counts, { total: 0, add: 0, alreadyRecorded: 0, conflict: 0 });
    assert.deepEqual(empty.rows, []);
    assert.deepEqual(empty.totals, { allRows: [], additions: [] });
    assert.deepEqual(await session.snapshot(), before);
    const refused = [];
    for (const csv of invalid) {
      refused.push(refusal(await session.call('preview_transaction_import', { csv })));
      assert.deepEqual(await session.snapshot(), before);
    }
    const accepted = await preview(session, valid.csv);
    unpack(await commit(session, valid.csv, accepted.reviewToken));
    assert.deepEqual(await transactionInputs(session), [valid.input]);
    return { refusals: refused, final_valid_durable: await session.snapshot() };
  });
});
