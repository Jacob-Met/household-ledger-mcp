import assert from 'node:assert/strict';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { receivingRun, fileSnapshot, native } from './receiving-runtime.mjs';
import { csvRow, batch } from './independent-fixtures.mjs';
import { expectedHashes, frozenSource } from './frozen-manifest.mjs';

await receivingRun('independent-store-queue', expectedHashes, async context => {
  context.receipt.schema = 'household.csv-import.independent-store-queue.v1';
  context.receipt.frozen_source = frozenSource;
  context.receipt.scope = 'Deterministic same-process queue control using actual compiled importer and LedgerStore exports. A public async Store.update predecessor holds admission; no source monkeypatch, cross-process writer, HTTP simulation, or deployment claim. Actual HTTP controls are recorded separately.';
  assert.equal(context.receipt.git_identity.head, frozenSource.commit);
  const { LedgerStore, recordTransaction, setBudget } = await import(pathToFileURL(join(native, 'dist/src/ledger.js')).href);
  const { previewTransactionImport, commitTransactionImport } = await import(pathToFileURL(join(native, 'dist/src/transaction-import.js')).href);
  await context.check('Held native predecessor forces matching reclassification and preserves following native write through two Store instances', async () => {
    const path = join(context.root, 'held-queue.json');
    const writer = new LedgerStore(path);
    const receiving = new LedgerStore(context.root + '/./held-queue.json');
    const matching = csvRow('held-existing-match', 79);
    const addition = csvRow('held-import-addition', 83);
    const following = csvRow('held-following-native', 89);
    const csv = batch(addition, matching);
    const shown = await previewTransactionImport(receiving, { csv });
    assert.deepEqual(shown.counts, { total: 2, add: 2, alreadyRecorded: 0, conflict: 0 });
    assert.equal(shown.canCommit, true);
    assert.deepEqual(await fileSnapshot(path), { exists: false });

    let release, entered;
    const gate = new Promise(resolve => { release = resolve; });
    const entry = new Promise(resolve => { entered = resolve; });
    const events = [];
    const held = writer.update(async data => {
      events.push('predecessor_entered');
      entered();
      await gate;
      const original = recordTransaction(data, matching.input);
      setBudget(data, 'Travel', '2026-10', 8000, 'EUR');
      events.push('predecessor_mutation_finished');
      return original;
    });
    await Promise.race([entry, held.then(() => { throw new Error('Predecessor completed without its held entry'); })]);

    let importSettled = false, nativeSettled = false;
    events.push('import_called_while_held');
    const imported = commitTransactionImport(receiving, { csv, reviewToken: shown.reviewToken }).then(
      result => { importSettled = true; events.push('import_persisted'); return result; },
      error => { importSettled = true; events.push('import_refused'); throw error; },
    );
    events.push('following_native_called_while_held');
    const after = writer.update(data => recordTransaction(data, following.input)).then(
      result => { nativeSettled = true; events.push('following_native_persisted'); return result; },
      error => { nativeSettled = true; events.push('following_native_refused'); throw error; },
    );
    const all = Promise.allSettled([held, imported, after]);
    let whileHeld, outcomes;
    try {
      await new Promise(resolve => setImmediate(resolve));
      whileHeld = { import_settled: importSettled, following_native_settled: nativeSettled, ledger: await fileSnapshot(path) };
      assert.deepEqual(whileHeld, { import_settled: false, following_native_settled: false, ledger: { exists: false } });
      events.push('held_guard_verified');
    } finally {
      events.push('release_predecessor');
      release();
      outcomes = await all;
    }
    assert.deepEqual(outcomes.map(outcome => outcome.status), ['fulfilled', 'fulfilled', 'fulfilled']);
    const [original, committed, later] = outcomes.map(outcome => outcome.value);
    const durable = await fileSnapshot(path);
    assert.equal(committed.added, 1);
    assert.equal(committed.alreadyRecorded, 1);
    assert.deepEqual(committed.totals, [{ currency: 'USD', incomeMinor: 0, expenseMinor: 83, netMinor: -83 }]);
    assert.deepEqual(committed.transactions[1], original, 'The queued exact match must retain its original native receipt');
    assert.equal(committed.transactions[0].idempotencyKey, addition.input.idempotencyKey);
    assert.deepEqual(durable.data.transactions, [original, committed.transactions[0], later]);
    assert.deepEqual(durable.data.budgets, [{ category: 'Travel', month: '2026-10', limitMinor: 8000, currency: 'EUR' }]);
    assert.equal(durable.data.version, 2);
    assert.equal(new Set(durable.data.transactions.map(tx => tx.id)).size, 3);
    assert(events.indexOf('import_persisted') < events.indexOf('following_native_persisted'));
    const replay = await commitTransactionImport(receiving, { csv, reviewToken: shown.reviewToken });
    assert.equal(replay.added, 0);
    assert.equal(replay.alreadyRecorded, 2);
    assert.deepEqual(replay.transactions, committed.transactions, 'Replay preserves CSV-order receipts despite native storage order');
    assert.deepEqual(replay.totals, []);
    assert.deepEqual(await fileSnapshot(path), durable, 'Replay after the queued native write does not rewrite the file');
    return { preview_before_predecessor: shown, while_held: whileHeld, events, original, committed, later, replay, durable };
  });
});
