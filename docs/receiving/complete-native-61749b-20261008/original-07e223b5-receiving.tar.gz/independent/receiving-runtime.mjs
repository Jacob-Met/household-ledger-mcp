import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { join } from 'node:path';
import { mkdir, mkdtemp, readFile, writeFile, readdir, rm, stat } from 'node:fs/promises';
import { createServer } from 'node:net';
import { createHash } from 'node:crypto';
import { spawn, execFileSync } from 'node:child_process';
import { once } from 'node:events';

export const native = '/Users/me/hamon-household-import-a219f250962c';
export const review = '/Users/me/household-import-review-a219f250962c';
export const sha256 = value => createHash('sha256').update(value).digest('hex');
const require = createRequire(join(native, 'package.json'));
const { Client } = require('@modelcontextprotocol/sdk/client/index.js');
const { StreamableHTTPClientTransport } = require('@modelcontextprotocol/sdk/client/streamableHttp.js');

export function unpack(result) {
  assert.notEqual(result.isError, true, JSON.stringify(result.content));
  assert.equal(result.content.length, 1);
  assert.equal(result.content[0].type, 'text');
  return JSON.parse(result.content[0].text);
}

export async function fingerprints() {
  const paths = ['package.json', 'package-lock.json', 'tsconfig.json'];
  async function walk(prefix) {
    for (const entry of await readdir(join(native, prefix), { withFileTypes: true })) {
      const path = prefix + '/' + entry.name;
      if (entry.isDirectory()) await walk(path);
      else if (entry.isFile()) paths.push(path);
      else throw new Error('Unexpected runtime symlink: ' + path);
    }
  }
  await walk('src');
  await walk('dist/src');
  return Object.fromEntries(await Promise.all(paths.sort().map(async path => [path, sha256(await readFile(join(native, path)))])));
}

export function gitIdentity() {
  const read = expression => execFileSync('git', ['-C', native, 'rev-parse', expression], { encoding: 'utf8' }).trim();
  return { head: read('HEAD'), tree: read('HEAD^{tree}') };
}

export async function fileSnapshot(path) {
  try {
    const bytes = await readFile(path);
    const info = await stat(path, { bigint: true });
    return { exists: true, sha256: sha256(bytes), bytes: bytes.length, inode: String(info.ino), modified_ns: String(info.mtimeNs), data: JSON.parse(bytes) };
  } catch (error) {
    if (error.code === 'ENOENT') return { exists: false };
    throw error;
  }
}

function argumentReceipt(args) {
  if (typeof args.csv !== 'string' || args.csv.length <= 12288) return args;
  return { ...args, csv: { omitted_large_input: true, utf16_units: args.csv.length, utf8_bytes: Buffer.byteLength(args.csv), sha256: sha256(args.csv) } };
}

export async function openSession(root, label, ledger) {
  const probe = createServer();
  probe.listen(0, '127.0.0.1');
  await once(probe, 'listening');
  const port = probe.address().port;
  await new Promise((resolve, reject) => probe.close(error => error ? reject(error) : resolve()));
  const child = spawn(process.execPath, [join(native, 'dist/src/index.js')], {
    cwd: root,
    env: { PATH: process.env.PATH, HOUSEHOLD_LEDGER_DATA_PATH: ledger, HOUSEHOLD_LEDGER_HOST: '127.0.0.1', HOUSEHOLD_LEDGER_PORT: String(port) },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let stdout = '', stderr = '', client;
  const traces = [];
  const record = { label, port, process_id: child.pid, traces };
  child.stdout.on('data', value => { stdout += String(value); });
  child.stderr.on('data', value => { stderr += String(value); });
  async function close() {
    await client?.close();
    if (child.exitCode === null && child.signalCode === null) {
      let timer;
      const exited = once(child, 'exit');
      child.kill('SIGTERM');
      try {
        await Promise.race([exited, new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('Owned child did not stop')), 6000); })]);
      } finally { clearTimeout(timer); }
    }
    record.child_exit = { code: child.exitCode, signal: child.signalCode };
    record.stderr = stderr;
    assert.equal(stderr, '');
  }
  try {
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('Owned server startup timeout: ' + stderr)), 6000);
      child.once('error', error => { clearTimeout(timer); reject(error); });
      child.once('exit', code => { clearTimeout(timer); reject(new Error('Owned server exited before readiness: ' + code + ': ' + stderr)); });
      child.stdout.on('data', chunk => { if (String(chunk).includes('listening on')) { clearTimeout(timer); resolve(); } });
      if (stdout.includes('listening on')) { clearTimeout(timer); resolve(); }
    });
    const origin = new URL('http://127.0.0.1:' + port);
    assert.equal((await fetch(new URL('/healthz', origin))).status, 200);
    client = new Client({ name: 'independent-household-csv-receiver', version: '1' }, { capabilities: {} });
    await client.connect(new StreamableHTTPClientTransport(new URL('/mcp', origin)));
    record.tool_names = (await client.listTools()).tools.map(tool => tool.name).sort();
    return {
      record, ledger, close,
      async call(name, args) {
        const trace = { index: traces.length, name, arguments: argumentReceipt(args) };
        traces.push(trace);
        try { return trace.result = await client.callTool({ name, arguments: args }); }
        catch (error) { trace.error = String(error.stack ?? error); throw error; }
      },
      snapshot: () => fileSnapshot(ledger),
    };
  } catch (error) { await close(); throw error; }
}

export async function receivingRun(name, expected, body) {
  await mkdir(review, { recursive: true, mode: 0o700 });
  const before = await fingerprints();
  for (const [path, hash] of Object.entries(expected)) assert.equal(before[path], hash, 'Source pin: ' + path);
  const root = await mkdtemp(join(review, name + '-private-'));
  const receipt = {
    schema: 'household.csv-import.independent-http.v1',
    at: new Date().toISOString(), node: process.version, git_identity: gitIdentity(),
    scope: 'Isolated native compiled MCP server; private ledgers; same-process Store queue. No canonical-main, production deployment, authentication, or cross-process-lock claim.',
    source_and_dist_before: before, checks: [], sessions: [],
  };
  const active = new Set();
  const context = {
    root, receipt,
    async session(label, ledger = join(root, label + '.json')) {
      const session = await openSession(root, label, ledger);
      active.add(session);
      receipt.sessions.push(session.record);
      return session;
    },
    async close(session) { await session.close(); active.delete(session); },
    async check(label, fn) {
      const item = { name: label };
      const prior = new Set(active);
      receipt.checks.push(item);
      try { item.observation = await fn(); item.passed = true; }
      catch (error) { item.passed = false; item.error = String(error.stack ?? error); }
      finally {
        for (const session of [...active].filter(value => !prior.has(value))) {
          try { await session.close(); active.delete(session); }
          catch (error) { item.passed = false; item.cleanup_error = String(error.stack ?? error); }
        }
      }
    },
  };
  try { await body(context); }
  catch (error) { receipt.failure = String(error.stack ?? error); }
  finally {
    for (const session of active) {
      try { await session.close(); }
      catch (error) { (receipt.cleanup_errors ??= []).push(String(error.stack ?? error)); }
    }
    receipt.source_and_dist_after = await fingerprints();
    receipt.source_and_dist_unchanged = JSON.stringify(before) === JSON.stringify(receipt.source_and_dist_after);
    await rm(root, { recursive: true, force: true });
    receipt.private_data_removed = true;
    receipt.passed = receipt.checks.length > 0 && receipt.checks.every(check => check.passed) && !receipt.failure && !receipt.cleanup_errors && receipt.source_and_dist_unchanged;
    const bytes = JSON.stringify(receipt, null, 2) + '\n';
    await writeFile(join(review, name + '-receipt.json'), bytes);
    console.log(JSON.stringify({ kind: 'receiving-receipt', name, sha256: sha256(bytes), receipt }));
  }
  if (!receipt.passed) process.exitCode = 1;
  return receipt;
}
