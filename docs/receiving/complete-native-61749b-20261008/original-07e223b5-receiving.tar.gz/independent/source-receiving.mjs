import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { execFileSync } from 'node:child_process';
import { native, review, fingerprints, sha256 } from './receiving-runtime.mjs';

const commit = '07e223b5da19cea0f048219d8c85689fcc1ba83f';
const tree = '76cd2cc60b10dabdd301d32a53da4b833015193d';
const parent = 'a799c917a8a20e293baae576ae8b03bdd1b63b49';
const parentTree = 'f1b8e0a1d3242fee9630482a068578d708ae7079';
const git = (...args) => execFileSync('git', ['-C', native, ...args]);
const meta = (...args) => git(...args).toString('utf8').trim();
assert.equal(meta('rev-parse', 'HEAD'), commit);
assert.equal(meta('rev-parse', 'HEAD^{tree}'), tree);
assert.equal(meta('rev-parse', 'HEAD^'), parent);
assert.equal(meta('rev-parse', 'HEAD^^{tree}'), parentTree);
assert.equal(meta('status', '--porcelain'), '');
const manifest = JSON.parse(await readFile(native + '-receiving/source-freeze.json', 'utf8'));
const seams = JSON.parse(await readFile(native + '-receiving/additive-seams.json', 'utf8'));
const leaves = rev => new Map(git('ls-tree', '-r', '-z', rev).toString('utf8').split('\0').filter(Boolean).map(line => {
  const [info, path] = line.split('\t'); const [mode, type, blob] = info.split(' ');
  assert.equal(mode, '100644'); assert.equal(type, 'blob'); return [path, blob];
}));
const oldTree = leaves(parent), newTree = leaves(commit);
assert.equal(newTree.size, 83);
assert.equal(manifest.files.length, 83);
for (const item of manifest.files) {
  assert.equal(newTree.get(item.path), item.git_blob);
  const bytes = await readFile(join(native, item.path));
  assert.equal(bytes.length, item.bytes);
  assert.equal(sha256(bytes), item.sha256);
  assert.deepEqual(bytes, git('show', commit + ':' + item.path));
}
const changed = [...newTree.keys()].filter(path => oldTree.get(path) !== newTree.get(path)).sort();
assert.deepEqual(changed, ['README.md','docs/TRANSACTION_IMPORT.md','src/index.ts','src/transaction-csv.ts','src/transaction-import.ts','test/mcp.test.ts','test/transaction-import-http.test.ts','test/transaction-import.test.ts'].sort());
assert([...oldTree.keys()].every(path => newTree.has(path)));
const preserved = [...oldTree.keys()].filter(path => oldTree.get(path) === newTree.get(path));
assert.equal(preserved.length, 75);
assert(preserved.includes('src/ledger.ts'));
assert(preserved.includes('src/cashflow.ts'));
assert(preserved.includes('src/stdio.ts'));
assert(preserved.includes('test/cashflow.test.ts'));
assert(preserved.includes('test/http-cashflow.test.ts'));
assert.deepEqual(seams.edits.map(edit => edit.path).sort(), ['README.md','src/index.ts','test/mcp.test.ts']);
const reversed = [];
for (const edit of seams.edits) {
  let text = (await readFile(join(native, edit.path))).toString('utf8');
  for (const [before, after] of [...edit.operations].reverse()) {
    assert.equal(text.split(after).length, 2, 'Exactly one additive receiving seam: ' + edit.path);
    text = text.replace(after, before);
  }
  const original = git('show', parent + ':' + edit.path);
  assert.deepEqual(Buffer.from(text, 'utf8'), original, 'Unrelated bytes outside additive seams: ' + edit.path);
  reversed.push({ path: edit.path, restored_parent_sha256: sha256(original), operations: edit.operations.length });
}
const runtime = await fingerprints();
for (const item of manifest.files.filter(file => file.path.startsWith('src/') || ['package.json','package-lock.json','tsconfig.json'].includes(file.path))) {
  assert.equal(runtime[item.path], item.sha256);
}
const frozenSource = { repository: manifest.repository, commit, tree, parent, parent_tree: parentTree, original_owner_parent: '402061a5af29d4d3095a09ca55ef9b2fc5c2bbd0', qualification: 'Native after-owner source contribution; canonical-main integration and deployment not claimed.' };
const result = { schema: 'household.import.independent-source-receiving.v1', at: new Date().toISOString(), passed: true, ...frozenSource, verified_tracked_leaves: newTree.size, preserved_parent_leaves: preserved.length, changed_paths: changed, exact_reverse_seams: reversed, runtime_hashes: runtime };
await writeFile(join(review, 'frozen-manifest.mjs'), 'export const expectedHashes = ' + JSON.stringify(runtime, null, 2) + ';\nexport const frozenSource = ' + JSON.stringify(frozenSource, null, 2) + ';\n', { flag: 'wx' });
const bytes = JSON.stringify(result, null, 2) + '\n';
await writeFile(join(review, 'source-receiving.json'), bytes, { flag: 'wx' });
console.log(JSON.stringify({ kind: 'source-receiving', sha256: sha256(bytes), receipt: result }));
