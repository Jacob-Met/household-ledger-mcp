# Household CSV transaction import — owner receiving

## Capability and exact source

The native TypeScript MCP service now exposes `preview_transaction_import` and `commit_transaction_import`. A household can review a bounded CSV of explicit transactions, then record its whole batch through the existing serialized Store. Preview shows exact normalized values and original matching or conflicting records. Stable native recording keys make retries return original transaction IDs; any conflicting key refuses the whole addition set.

| Item | Exact value |
| --- | --- |
| Repository | https://github.com/Jacob-Met/household-ledger-mcp |
| External contributor | `estate-a219f250962c/estate_authority` |
| Frozen feature commit | `07e223b5da19cea0f048219d8c85689fcc1ba83f` |
| Frozen complete tree | `76cd2cc60b10dabdd301d32a53da4b833015193d` |
| Receiving parent | `a799c917a8a20e293baae576ae8b03bdd1b63b49` |
| Receiving parent tree | `f1b8e0a1d3242fee9630482a068578d708ae7079` |
| Native source | `/Users/me/hamon-household-import-a219f250962c` |
| Native device | Mac `0e3d582f-e25b-44b2-8418-9639fc4e4e33` |
| Scope claim | https://github.com/Jacob-Met/household-ledger-mcp/issues/3#issuecomment-6060380251 |

The receiving parent is the independently qualified cashflow contribution in [comment 6059724461](https://github.com/Jacob-Met/household-ledger-mcp/issues/3#issuecomment-6059724461), directly after the accepted `402061a5` budget-owner documentation child in [comment 6058846183](https://github.com/Jacob-Met/household-ledger-mcp/issues/3#issuecomment-6058846183). The complete inherited native source history is preserved for reproduction. It is not canonical-main ancestry and must not be merged wholesale into canonical main. ce7/e3/401c/566d source attribution and parent integration ownership remain intact.

## Eight-path boundary

Two new production modules, `src/transaction-csv.ts` and `src/transaction-import.ts`, hold the parser and preview/commit flow. `src/index.ts` adds only their import, two tool definitions and two dispatch cases. New `test/transaction-import.test.ts`, `test/transaction-import-http.test.ts` and `docs/TRANSACTION_IMPORT.md` provide tests and product usage. The only other edits are the eight-tool roster/title in `test/mcp.test.ts` and two tool rows plus a usage link in `README.md`.

All **75 other parent files** are byte-identical. Removing the recorded additions from index, roster and README reproduces their exact parent bytes. The frozen tree contains 83 files. `src/ledger.ts`, the cashflow implementation, every existing handler, dependencies, lockfile, persistence, budget/schema behavior and prior behavioral test assertions remain unchanged. `source/source-freeze.json` pins every resulting file by Git blob, byte count and SHA-256. `source/additive-seams.json` records the exact reversible edits to the three prior files.

## Use and invariants

The required CSV headers are `idempotencyKey,type,amountMinor,currency,date,category`, in any order; `note` is optional. Amounts are positive safe integer minor units; type, date, currency and category are explicit. Currency/category normalization is exactly the native recorder's. Notes retain their literal contents, including spaces and quoted CRLF. Unsupported `id`, `createdAt`, `memo`, `source` or account columns are refused, so they cannot be silently dropped. Preserve an existing source record identity in the supported stable key. Native IDs and creation timestamps for new records are assigned at commit, with no speculative final identity in preview.

Requests contain the complete CSV text, at most 256 KiB UTF-8, 500 rows and 8192 UTF-8 bytes per decoded field. The parser rejects malformed quoting, invalid Unicode, repeated keys, unknown/missing/duplicate columns and invalid native values. It does not infer bank formats, convert money or read a file path/URL.

`preview_transaction_import({csv})` returns exact normalized row inputs, `add`/`already_recorded`/`conflict` actions, original matching/conflicting transactions, physical CSV line pointers, per-currency `totals.allRows` and `totals.additions`, counts, `canCommit` and a `reviewToken`. It never writes. Gross income and gross expenses are checked separately with exact integer accumulation.

After user review, `commit_transaction_import({csv, reviewToken})` takes the identical CSV. The token binds exact content, not authentication, human approval or a ledger lock. Commit reloads and rechecks keys inside the existing serialized Store update. Matching concurrent writes become original-record retries; a conflicting write refuses every addition. The actual added count/totals may shrink when an identical recording finishes after preview, while normalized input values remain the same. The receipt returns every original/new transaction in CSV order, along with actual additions, matches and per-currency addition totals.

The full product contract and examples are committed in `docs/TRANSACTION_IMPORT.md` and included in the source patch/bundles. An all-matching retry preserves ledger bytes and modification time. The existing **one-server-process-per-ledger-file** rule remains: connect clients to the same server and finish or stop older writers before changing versions. No cross-process locking or schema migration is added.

## Qualification

The original accepted `402061a5` input passed its 62 native tests. Its independently run real HTTP missing-feature control returned only the original five tools and `Unknown tool` for both import names; no ledger was created. That receipt is historical at that exact source.

The subsequently received current cashflow parent `a799c917` passed typecheck and all **76 existing cases**. The frozen import source passed typecheck and all **101 cases**, with 25 new import cases and no skips or failures. Three new actual Streamable HTTP scenarios cover preview/commit receipts, identity-preserving restart replay, late conflicts and overlapping imports composed with ordinary record and denominated-budget writes. Direct native Store tests cover whole-batch failure, released-queue persistence retry, two Store instances, unchanged v1/v2 budgets, exact amounts and optional-note identity. All tests use synthetic private temporary ledgers. Runtime was native Mac Node 26.3.0 with the unchanged locked dependencies; no hosted or older-runtime pass is implied.

`author-evidence/` retains the original/current/candidate logs and native source captures. `independent/` retains the separately authored exact-source review and runtime receiving: eight HTTP scenario groups, 68 actual tool calls across 13 initialized private sessions, and a deterministic two-Store held-predecessor queue case. The source and compiled output stayed unchanged. The first HTTP run completed four groups and stopped four solely on the reviewer's mistaken blanket expectation of ledger version 2; the unchanged native empty ledger intentionally starts at version 1. The original receipt and exact reviewer-only correction are retained, and the four affected groups passed their targeted corrected run. This is eight qualified HTTP groups, not twelve independent groups or 68 repository tests. The held-queue control confirms current-key reclassification, original matching identities, CSV-order receipts, following native writes, budget/version preservation and no-write replay. No source blocker was found. Packaging does not claim another runtime pass.

## Receive the narrow contribution

Use `source/transaction-import-after-owner.patch` on a clean isolated receiving checkout whose source matches parent `a799c917` / tree `f1b8e0a1`. Do not reset or replace an owner's advanced checkout. If its source has advanced, compose the eight-path contribution under that owner's source review and receiving process.

```bash
git rev-parse HEAD
git rev-parse HEAD^{tree}
git status --porcelain
git am /absolute/path/to/packet/source/transaction-import-after-owner.patch
git rev-parse HEAD^{tree}
npm run typecheck
npm test
```

A source-matching import must produce tree **`76cd2cc60b10dabdd301d32a53da4b833015193d`**. A different committer timestamp may produce a different commit ID. The performed native `git am` receiving created commit `72f59fc94b6fa79f7f125ecbc4778ebef81a08bb`, reproduced the exact expected tree and all 83 file hashes, and left a clean checkout. Both bundles verify. The fresh receiving fixture was removed after its completed receipt was saved and read back; it was separate from every owner checkout.

| Source artifact | Purpose | SHA-256 |
| --- | --- | --- |
| `transaction-import-after-owner.patch` | Eight-path format-patch after the exact current owner input | `49ea6a474e955381ad8e49f45e3fbfdcc39b5f9e13b58cc729214382d93557e8` |
| `transaction-import-after-owner.bundle` | Incremental native Git history requiring the matching parent | `4b7b3a0e647e0a02d638beaad76c7828f9d8d3e0ad35d3cf39d28ea3e63b04b5` |
| `transaction-import-complete-native-source.bundle` | Complete native history for separate reproduction, including its noncanonical snapshot boundary | `a7aee26797f94e4d8f503cf2fe4e96e9e3ee8ff9422f138ceb13c8e6f0d78ca8` |

For a fresh standalone reproduction, clone the complete native bundle into a **new** directory, select the frozen commit, install using the unchanged lockfile, then build and run tests. Preserve the source parent qualification; this is not an instruction to replace canonical service main. The existing runtime owner retains parent integration and any separate activation. This contribution changes no live ledger, deployed service, network exposure, account, submission, owner branch or native goal/lease identity.
