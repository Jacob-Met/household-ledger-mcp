import { test } from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { CopyClientError, readCopyPreview, readCopyRequest, runBudgetCopy, terminalValue, type BudgetToolClient } from "../src/budget-copy-client.js";
import { parseCopyArgs } from "../src/household-budget-copy.js";

const request = { fromMonth: "2026-10", toMonth: "2026-11", currency: "USD" };
const names = ["groceries", "旅行\n予定 🧭", "zero"];
function preview() {
  const limits = [12500, 70, 0];
  const review = { schema: "household-budget-copy/1", ...request, rows: names.map((category, i) =>
    ({ category, limitMinor: limits[i], expectedTargetLimitMinor: i === 0 ? limits[i] : null })) };
  return { schema: review.schema, ...request, canCommit: true, counts: { total: 3, add: 2, alreadyPresent: 1, conflict: 0 },
    rows: names.map((category, i) => ({ category, limitMinor: limits[i], action: i === 0 ? "already_present" : "add",
      destination: i === 0 ? [{ category, month: request.toMonth, currency: "USD", limitMinor: limits[i] }] : [] })),
    review, reviewToken: createHash("sha256").update(JSON.stringify(review)).digest("hex") };
}
const reply = (value: unknown) => ({ content: [{ type: "text", text: JSON.stringify(value) }] });
function receipt(p = preview()) {
  return { schema: p.schema, ...request, reviewToken: p.reviewToken, added: 2, alreadyPresent: 1,
    budgets: p.rows.map(row => ({ category: row.category, month: request.toMonth, currency: "USD", limitMinor: row.limitMinor })) };
}
function fixture(p: unknown = preview(), result: unknown = receipt()) {
  const calls: Array<{ name: string; arguments: Record<string, unknown> }> = [];
  const output: string[] = [];
  const client: BudgetToolClient = { async callTool(call) {
    calls.push(structuredClone(call)); return reply(call.name === "preview_budget_copy" ? p : result);
  }};
  return { calls, output, client, io: { async write(text: string) { output.push(text); },
    async confirm() { assert.ok(output.join("").includes("zero")); return "COPY 2026-11 USD"; } } };
}

test("complete literal review precedes one exact reviewed commit and a checked receipt", async () => {
  const f = fixture(); const result = await runBudgetCopy(f.client, request, f.io);
  assert.deepEqual(result, { status: "completed", commitCalls: 1, added: 2, alreadyPresent: 1 });
  assert.deepEqual(f.calls.map(c => c.name), ["preview_budget_copy", "commit_budget_copy"]);
  assert.deepEqual(f.calls[1].arguments, { review: preview().review, reviewToken: preview().reviewToken });
  const output = f.output.join("");
  for (const value of names) assert.ok(output.includes(terminalValue(value)));
  assert.ok(output.includes("limitMinor=0")); assert.ok(output.includes("Current destination:"));
});
test("cancel, EOF and inexact confirmation never send a commit", async () => {
  for (const answer of [null, "", "no", "COPY 2026-12 USD", " COPY 2026-11 USD"]) {
    const f = fixture(); f.io.confirm = async () => answer as string;
    assert.equal((await runBudgetCopy(f.client, request, f.io)).status, "cancelled");
    assert.equal(f.calls.length, 1);
  }
});
test("noninteractive preview and conflict output do not ask or commit", async () => {
  const f = fixture(); f.io.confirm = async () => { throw new Error("must not prompt"); };
  assert.equal((await runBudgetCopy(f.client, request, f.io, true)).status, "preview_only");
  assert.equal(f.calls.length, 1);
  const p = preview(); p.canCommit = false; p.counts = { total: 3, add: 1, alreadyPresent: 1, conflict: 1 };
  Object.assign(p.rows[1], { action: "conflict", reason: "Different limit", destination: [
    { category: names[1], month: request.toMonth, currency: "USD", limitMinor: 999 }] });
  Object.assign(p, { review: null, reviewToken: null });
  const g = fixture(p); g.io.confirm = f.io.confirm;
  assert.equal((await runBudgetCopy(g.client, request, g.io)).status, "conflict");
  assert.equal(g.calls.length, 1); assert.match(g.output.join(""), /999/);
});
test("changed selection, incomplete rows/counts, token drift and duplicate identity refuse before confirmation", async () => {
  const changes: Array<(p: ReturnType<typeof preview>) => void> = [
    p => { p.toMonth = "2026-12"; },
    p => { p.rows.pop(); },
    p => { p.counts.total = 2; },
    p => { p.reviewToken = "a".repeat(64); },
    p => { p.review.rows[1].limitMinor = 900; },
    p => { p.rows[1].category = p.rows[0].category; },
    p => { p.rows[0].destination[0].limitMinor = 900; },
  ];
  for (const change of changes) {
    const p = preview(); change(p); const f = fixture(p);
    f.io.confirm = async () => { throw new Error("invalid preview prompted"); };
    await assert.rejects(runBudgetCopy(f.client, request, f.io), CopyClientError);
    assert.equal(f.calls.length, 1);
  }
  assert.throws(() => readCopyPreview(preview(), { ...request, categories: ["zero"] }), /changed or omitted/);
});
test("lost, rejected or malformed commit responses remain unconfirmed with no automatic retry", async () => {
  for (const mode of ["lost", "error", "counts", "target", "missing", "denomination"]) {
    const f = fixture(); const original = f.client.callTool;
    f.client.callTool = async call => {
      if (call.name !== "commit_budget_copy") return original(call);
      f.calls.push(structuredClone(call));
      if (mode === "lost") throw new Error("connection lost");
      if (mode === "error") return { isError: true, content: [{ type: "text", text: "source changed" }] };
      const r = receipt();
      if (mode === "counts") r.added = 900;
      if (mode === "target") r.budgets[1].limitMinor = 900;
      if (mode === "missing") r.budgets.pop();
      if (mode === "denomination") r.budgets[1].currency = "UſD";
      return reply(r);
    };
    await assert.rejects(runBudgetCopy(f.client, request, f.io), (e: unknown) =>
      e instanceof CopyClientError && e.commitAttempted && /not confirmed/.test(e.message));
    assert.equal(f.calls.length, 2); assert.ok(!f.output.join("").includes("Copy confirmed"));
  }
});
test("failed preview output sends no commit; failed receipt output retains the known server confirmation", async () => {
  const f = fixture(); f.io.write = async () => { throw new Error("closed output"); };
  await assert.rejects(runBudgetCopy(f.client, request, f.io), /closed output/); assert.equal(f.calls.length, 1);
  const g = fixture(); g.io.write = async text => {
    if (text.startsWith("Copy confirmed")) throw new Error("closed output");
    g.output.push(text);
  };
  await assert.rejects(runBudgetCopy(g.client, request, g.io), (e: unknown) => e instanceof CopyClientError &&
    e.commitAttempted && /server confirmed/.test(e.message));
  assert.equal(g.calls.length, 2);
});
test("terminal identity representation escapes controls and bidi without losing exact text", () => {
  const raw = "food\u001b[2J\n\u0085\u202e🧭";
  const safe = terminalValue(raw);
  assert.equal(JSON.parse(safe), raw);
  assert.ok(!/[\u001b\u0085\u202e\n]/.test(safe));
});
test("request and CLI admission preserve explicit local endpoint and selected identity", () => {
  assert.deepEqual(readCopyRequest({ ...request, currency: "usd", categories: [" zero ", "旅行"] }),
    { ...request, categories: ["zero", "旅行"] });
  assert.throws(() => readCopyRequest({ ...request, categories: ["zero", " zero "] }), /distinct/);
  assert.throws(() => readCopyRequest({ ...request, categories: ["\ud800"] }), /Unicode/);
  const base = ["--endpoint", "http://127.0.0.1:3456/mcp", "--from-month", "2026-10", "--to-month", "2026-11", "--currency", "usd"];
  assert.deepEqual(parseCopyArgs([...base, "--category", "zero", "--preview"])?.request, { ...request, categories: ["zero"] });
  assert.equal(parseCopyArgs(["--help"]), null);
  for (const endpoint of ["https://127.0.0.1/mcp", "http://example.invalid/mcp", "http://u:p@127.0.0.1/mcp", "http://127.0.0.1/mcp?x=1", "http://127.0.0.1/mcp#x", "http://127.0.0.1/other"]) {
    assert.throws(() => parseCopyArgs(["--endpoint", endpoint, ...base.slice(2)]), /Endpoint/);
  }
  assert.throws(() => parseCopyArgs([...base, "--currency", "EUR"]), /Repeated/);
  assert.throws(() => parseCopyArgs([...base, "--yes"]), /Unknown/);
});
test("actual CLI help is offline and a pipe cannot authorize a mutation", () => {
  const cli = fileURLToPath(new URL("../src/household-budget-copy.js", import.meta.url));
  const help = spawnSync(process.execPath, [cli, "--help"], { encoding: "utf8" });
  assert.equal(help.status, 0); assert.match(help.stdout, /No automatic commit retry/); assert.equal(help.stderr, "");
  const piped = spawnSync(process.execPath, [cli, "--endpoint", "http://127.0.0.1:1/mcp", "--from-month", "2026-10",
    "--to-month", "2026-11", "--currency", "USD"], { input: "COPY 2026-11 USD\n", encoding: "utf8" });
  assert.equal(piped.status, 1); assert.equal(piped.stdout, ""); assert.match(piped.stderr, /requires terminal/);
  assert.doesNotMatch(piped.stderr, /fetch|ECONN|connect/);
});
