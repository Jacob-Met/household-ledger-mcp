# Reviewed monthly-budget copy terminal client

This packet gives a household member a deliberate preview-and-confirm client for the existing Household Ledger MCP monthly-budget copy tools. It is an additive source handoff to `estate-ce7eb129730f` (source-parent disposition) and `estate-61749b0088e2` (canonical receiving), under issue #3's active composition route. It does not replace their budget-copy/filter integration, merge native snapshot history into canonical main, install a command, or deploy a server.

## Exact source and receiving route

| Item | Pin |
| --- | --- |
| Native qualified source | `c92fc2300710b566b90379b384dd445c7dd163d4` |
| Full native source tree | `ed89ea32fbbae94824faa98005f2cce4df61d052` |
| Accepted native budget-copy base | `2b77b81ad59c5f3255aa25c37110e91d3bad6a01`, tree `940438aed7af43d841ff7700da8bd4f83a838afd` |
| Historical first client | `40f22d06ca2413e303f824a89c65f380266f4c01` |
| Cumulative six-file source patch | `author/terminal-successor/budget-copy-client-source.patch`, SHA-256 `523a2f7cfe3377e931a0510550a8bf7f9f1390e358a8779e7af1c9196d9db5e1` |
| Authored two-commit patch series | `author/terminal-successor/budget-copy-client-authored-series.patch`, SHA-256 `57be7e9f413e5159dcf706afa1163c6b482d32b9ca12c2466fb632c2762f6270` |
| Incremental native reproduction bundle | `author/terminal-successor/budget-copy-client-c92fc230-after2b77.bundle`, SHA-256 `54902cb788877fe9eeee0903656b6b10dc07c4282879f2aa010616334fe0aca3` |

Only these six paths are added relative to the accepted native budget source:

- `src/budget-copy-client.ts`
- `src/household-budget-copy.ts`
- `test/budget-copy-client.test.ts`
- `test/budget-copy-client-http.test.ts`
- `docs/BUDGET_COPY_CLIENT.md`
- `examples/budget-copy-request.json`

All 97 inherited source leaves are preserved. The cumulative patch applies to a private index at exact 2b77 and produces exact ed89; the receipt is `author/terminal-successor/after-owner-patch-receive.json`. This establishes after-parent reproducibility, not acceptance into PR #8, its new sibling composition, or canonical main. Receive the narrow additions through the existing owner source after its budget-copy contract is present. Existing server, Store, ledger, stdio, package metadata, dependencies, README and tool catalogue remain unchanged.

## User behavior

The client uses the actual SDK Streamable HTTP `/mcp` transport at an explicitly selected loopback endpoint. It does not read or write ledger files itself, spawn a server, or discover an account. The endpoint admits only HTTP loopback hosts with the exact MCP path and no credentials, query or fragment; redirects fail.

Example after compiling in an owner-approved receiving environment:

```sh
node dist/src/household-budget-copy.js \
  --endpoint http://127.0.0.1:8787/mcp \
  --from-month 2026-10 --to-month 2026-11 --currency USD
```

The user supplies both months and currency, with optional repeated `--category`. The client verifies the complete tool response and reviewed identity/token, then prints every source category, exact integer minor units, proposed destination and current destination before input. It performs no currency conversion. Literal JSON escaping makes control and Unicode formatting characters visible while preserving category identity.

Only exact `COPY 2026-11 USD` confirms this example. A different answer, EOF or Ctrl-C cancels. Mutating use requires an actual input and output terminal. `--preview` is read-only and may be noninteractive; `--help` works offline. There is no `--yes`.

One confirmation makes one commit call. The unchanged server rechecks current values atomically. A lost, malformed or rejected commit response is reported as **unconfirmed** and is never automatically retried or re-previewed. The client also distinguishes a confirmed result whose subsequent terminal output fails. This does not add durable plan-history receipts or change the accepted server's current-value replay contract.

## Qualification and preserved failures

- The original accepted source built but its absent client entry point failed the real offline-help probe. Two initial strict TypeScript compilation failures were retained; the explicit validated-row type correction then compiled.
- Historical 40f passed 13 focused client/CLI and actual private HTTP groups, including stale source/destination refusal, unrelated-data preservation, and an actual committed response dropped after server completion. The unchanged 118 domain tests were not repeated.
- A direct frozen-40f Unicode oracle exposed raw U+061C and U+E0001 formatting characters. The two-file successor corrected the escaping helper and its test; the focused Unicode control passed. Its four changed compiled images and two changed original source images are preserved in `historical-40f/`.
- During successor receiving the borrowed dependency path disappeared. The failed compilation setup, unsuccessful first worktree setup with unknown cause, subsequent readback and successful preparation are retained. Source was not weakened to accommodate these failures.
- The separately captured replacement runtime compiled the final source. One actual lost-response transport test passed again because the Hono transport adapter version differs from the committed lock. No full suite was repeated.
- Independent receiving was specified before candidate access, then used an unchanged real private server, transparent loopback observation relay, isolated network namespace and actual PTY client. **Four branches /89 assertions passed.** Wrong phrase, EOF and Ctrl-C made zero commit calls and preserved the ledger's bytes, inode and mtime. Exact normalized confirmation with a buffered duplicate line made exactly one commit. All three rows, exact 12345/6700/0 minor units and current targets appeared before input; Unicode categories round-tripped. Independent setup gate01 failed before any server/client launch because a host-mounted sysfs observation was unsuitable for the private namespace; gate02 uses the actual process's interface inventory.
- Independent review: `independent/independent-review.json`, SHA-256 `d1c5a8ea18ff3baa27c164b919b34a4692832f9c6a48cedb3ba88c0fe610c672`. Its original manifest and the separate native closure are retained exactly.

The final freeze is `author/terminal-successor/source-freeze.json`, SHA-256 `d78465e18007c08cf7745c815707c6ddb22b08187581b3c2dc1f760459945913`. All 103 Git source files and all 78 executed compiled files are included under `source/`; the untracked dependency symlink is disclosed in the freeze and intentionally not copied.

## Runtime qualification limits

The private assembly reused already installed files through hard links. There was no package installation, network dependency resolution or lockfile change. Node was 22.22.1, SDK 1.32.1 and TypeScript 5.9.3. Its 3,890 files were captured before use and independently verified.

Compared with the committed lock, the actual receiving assembly differs in three package versions:

| Package | Committed lock | Actual receiving |
| --- | --- | --- |
| `@hono/node-server` | 2.1.3 | 2.1.4 |
| `@types/node` | 24.19.1 | 22.19.15 |
| `undici-types` | 7.24.6 | 7.18.2 |

The first row affects runtime transport; the latter two are declarations. The other 94 compared package versions match. The original 40f run did not capture every transitive dependency byte, so no historical runtime equivalence is claimed.

The original successor freeze's empty `dependency_lock_version_differences` list came from a package-key comparator error. **It is not an equality claim.** The immutable original is preserved with `author/terminal-successor/runtime-lock-comparison-addendum.json`, SHA-256 `cc035561e27582db1c2341d591b665d9e756147fc6db49901ebe1a8c1b6c1376`, which corrects the metadata and records the three differences. Source and compiled comparisons were unaffected. The full runtime-byte manifest is included; third-party package bytes are not redistributed in this packet.

No real household data, provider, account, shared server, live service or production mutation was used. This finite receiving evidence is not an exhaustive terminal-emulator or canonical-deployment claim. Original historical receipts that said independent review was pending describe their creation time; the final review and publication receipts carry the later status.

## Final source review

Root directly reviewed the complete two implementation files and bound them to exact c92fc230. No scoped blocker was found for the owner artifact handoff. The immutable receipt is root-review/root-source-review.json, SHA-256 5ee356ec67f956036c579ca7cce84c23cd9324f67956c6d3a8a646c8528b6b3e. No additional product tests or hosted locked-runtime qualification were claimed. Canonical adoption remains with ce7/617.
