from pathlib import Path
import json,hashlib,subprocess,stat,os,time,shutil
R=Path('/var/lib/hamon/custody/household-budget-copy-client-20261008-a0eb')
I=Path('/var/lib/hamon/custody/household-budget-copy-client-independent-20261008-a0eb')
S=Path('/srv/hamon-estate/household-budget-copy-client-terminal-a0eb505c')
O=Path('/srv/hamon-estate/household-budget-copy-client-a0eb505c')
D=R/'final-delivery'/'packet'
D.mkdir(parents=True,exist_ok=True)
assert shutil.disk_usage(R).free > 20*1024*1024
sha=lambda b: hashlib.sha256(b).hexdigest()
freeze=json.loads((R/'terminal-successor/source-freeze.json').read_bytes())
assert sha((R/'terminal-successor/source-freeze.json').read_bytes())=='d78465e18007c08cf7745c815707c6ddb22b08187581b3c2dc1f760459945913'
def git(*args):
 return subprocess.check_output(['runuser','-u','jacob','--','git','-C',str(S),*args])
assert git('rev-parse','HEAD').decode().strip()==freeze['head']
assert git('rev-parse','HEAD^{tree}').decode().strip()==freeze['tree']
raw=git('ls-tree','-rz','HEAD')
actual={}
for row in raw.split(b'\0'):
 if row:
  meta,name=row.split(b'\t',1);mode,typ,blob=meta.decode().split();assert typ=='blob'
  actual[name.decode()]={'mode':mode,'blob':blob}
assert actual=={e['path']:{'mode':e['mode'],'blob':e['blob']} for e in freeze['source']}
entries=[]
def put(dst, b, provenance, mode=0o644):
 p=D/dst
 p.parent.mkdir(parents=True,exist_ok=True)
 if p.exists():
  assert p.read_bytes()==b and stat.S_IMODE(p.stat().st_mode)==mode, str(p)
 else:
  p.write_bytes(b);p.chmod(mode)
 entries.append({'path':dst,'bytes':len(b),'sha256':sha(b),'mode':oct(mode),'origin':provenance})
for e in freeze['source']:
 b=(S/e['path']).read_bytes()
 assert sha(b)==e['sha256'] and len(b)==e['bytes'], e['path']
 assert hashlib.sha1(('blob '+str(len(b))+'\0').encode()+b).hexdigest()==e['blob'],e['path']
 put('source/'+e['path'],b,'raw Git blob '+e['blob'],0o755 if e['mode']=='100755' else 0o644)
for e in freeze['compiled']:
 b=(S/e['path']).read_bytes()
 assert sha(b)==e['sha256'] and len(b)==e['bytes'],e['path']
 put('source/'+e['path'],b,'executed final compiled input')
old=json.loads((R/'source-freeze.json').read_bytes())
for group,paths in [('source',freeze['source_changes_since_40f']),('compiled',freeze['compiled_changes_since_40f'])]:
 for name in paths:
  e=next(x for x in old['source_files' if group=='source' else 'compiled_execution_files'] if x['path']==name)
  b=(O/name).read_bytes();assert sha(b)==e['sha256'],name
  put('historical-40f/'+name,b,'historical first candidate '+old['head'])
# Capture only preexisting direct and successor artifacts; no newly assembling packet recursion.
author_paths=sorted([p for p in R.iterdir() if p.is_file()]+[p for p in (R/'terminal-successor').iterdir() if p.is_file()])
for p in author_paths:put('author/'+str(p.relative_to(R)),p.read_bytes(),'original author custody')
im=json.loads((I/'manifest.json').read_bytes())
assert sha((I/'manifest.json').read_bytes())=='d93daff33096489fe0039c57ee42bcae31ae28efb3f5be43fe023ae74f2e9d40'
for e in im['entries']:
 b=(I/e['path']).read_bytes();assert len(b)==e['bytes'] and sha(b)==e['sha256'],e['path']
 put('independent/'+e['path'],b,'immutable independent manifest')
for name,expected in [('manifest.json','d93daff33096489fe0039c57ee42bcae31ae28efb3f5be43fe023ae74f2e9d40'),('native-closure.json','fd7e633f671fba70e56e5d0c81400e33b1cd918227fc1fdb92003197096ef939')]:
 b=(I/name).read_bytes();assert sha(b)==expected,name
 put('independent/'+name,b,'immutable independent manifest or additive closure')
result={'schema':1,'created_at':time.time(),'stage':'packet_inputs_verified_root_review_pending','source_head':freeze['head'],'source_tree':freeze['tree'],'accepted_native_base':freeze['accepted_native_base'],'source_count':len(freeze['source']),'compiled_count':len(freeze['compiled']),'original_historical_files':6,'author_original_files':len(author_paths),'independent_original_files':len(im['entries'])+2,'third_party_package_bytes_copied':0,'entries':entries,'root_source_review':'pending','published':False,'source_status':git('status','--porcelain').decode(),'free_bytes_after':shutil.disk_usage(R).free}
out=R/'final-delivery'/'packet-input-binding.json'
out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'path':str(out),'sha256':sha(out.read_bytes()),'files':len(entries),'total_bytes':sum(e['bytes'] for e in entries),'source_head':freeze['head'],'root_source_review':'pending','free_bytes_after':result['free_bytes_after']}),flush=True)
