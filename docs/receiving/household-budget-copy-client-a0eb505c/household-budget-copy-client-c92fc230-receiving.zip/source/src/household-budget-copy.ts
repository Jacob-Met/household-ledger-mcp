#!/usr/bin/env node
/** Explicit local MCP client; never opens a ledger file or spawns another writer. */
import { pathToFileURL } from "node:url";
import { createInterface } from "node:readline";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";
import { CopyClientError, readCopyRequest, runBudgetCopy, terminalValue, type CopyRequest } from "./budget-copy-client.js";

export const HELP = `Review and copy monthly budget limits through an existing local MCP service.

node dist/src/household-budget-copy.js --endpoint http://127.0.0.1:3000/mcp \\
  --from-month 2026-10 --to-month 2026-11 --currency USD [--category NAME ...] [--preview]

--preview prints the complete review without asking or sending a commit.
Without --preview, both input and output must be terminals. Review every row,
then type the displayed COPY phrase. Any other answer or EOF cancels.
No automatic commit retry is performed. No ledger file is opened by this client.
Use one existing server process per ledger file. Limits are minor units.
`;

export function parseCopyArgs(args: string[]): { endpoint: URL; request: CopyRequest; previewOnly: boolean } | null {
  if (args.length === 1 && args[0] === "--help") return null;
  const values = new Map<string, string>();
  const categories: string[] = [];
  let previewOnly = false;
  for (let i = 0; i < args.length; i++) {
    const key = args[i];
    if (key === "--preview") {
      if (previewOnly) throw new CopyClientError("Repeated --preview.");
      previewOnly = true; continue;
    }
    if (!["--endpoint", "--from-month", "--to-month", "--currency", "--category"].includes(key))
      throw new CopyClientError("Unknown option: " + terminalValue(key));
    const value = args[++i];
    if (value === undefined || value.startsWith("--")) throw new CopyClientError("Missing value for " + key);
    if (key === "--category") categories.push(value);
    else {
      if (values.has(key)) throw new CopyClientError("Repeated option: " + key);
      values.set(key, value);
    }
  }
  let endpoint: URL;
  try { endpoint = new URL(values.get("--endpoint") ?? ""); }
  catch { throw new CopyClientError("Supply an explicit local HTTP --endpoint ending in /mcp."); }
  if (endpoint.protocol !== "http:" || !["127.0.0.1", "[::1]", "localhost"].includes(endpoint.hostname) ||
    endpoint.username || endpoint.password || endpoint.pathname !== "/mcp" || endpoint.search || endpoint.hash)
    throw new CopyClientError("Endpoint must be local HTTP /mcp with no credentials, query or fragment.");
  const request = readCopyRequest({ fromMonth: values.get("--from-month"), toMonth: values.get("--to-month"),
    currency: values.get("--currency"), ...(categories.length ? { categories } : {}) });
  return { endpoint, request, previewOnly };
}

function write(text: string): Promise<void> {
  return new Promise((resolve, reject) => process.stdout.write(text, error => error ? reject(error) : resolve()));
}
function confirm(prompt: string): Promise<string | null> {
  return new Promise(resolve => {
    const terminal = createInterface({ input: process.stdin, output: process.stdout });
    let answered = false;
    terminal.once("close", () => { if (!answered) resolve(null); });
    terminal.once("SIGINT", () => terminal.close());
    terminal.question(prompt, answer => { answered = true; terminal.close(); resolve(answer); });
  });
}

export async function budgetCopyMain(args = process.argv.slice(2)): Promise<number> {
  let client: Client | undefined;
  try {
    const parsed = parseCopyArgs(args);
    if (!parsed) { await write(HELP); return 0; }
    if (!parsed.previewOnly && (!process.stdin.isTTY || !process.stdout.isTTY))
      throw new CopyClientError("Interactive copy requires terminal input and output; use --preview for a read-only noninteractive review.");
    client = new Client({ name: "household-budget-copy-client", version: "1" }, { capabilities: {} });
    await client.connect(new StreamableHTTPClientTransport(parsed.endpoint, { requestInit: { redirect: "error" } }));
    await write("Service: " + parsed.endpoint.href + "\n");
    const result = await runBudgetCopy(client, parsed.request, { write, confirm }, parsed.previewOnly);
    return result.status === "conflict" ? 2 : 0;
  } catch (error) {
    process.stderr.write((error instanceof CopyClientError ? error.message : "Request failed: " + terminalValue(error instanceof Error ? error.message : String(error))) + "\n");
    return error instanceof CopyClientError && error.commitAttempted ? 3 : 1;
  } finally {
    if (client) await client.close().catch(() => undefined);
  }
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  void budgetCopyMain().then(code => { process.exitCode = code; });
}
