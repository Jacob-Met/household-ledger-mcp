/** Terminal consumer of the existing reviewed budget-copy MCP tools. */
import { createHash } from "node:crypto";
import type { BudgetCopyPreview, BudgetCopyReview } from "./budget-copy.js";

export interface CopyRequest { fromMonth: string; toMonth: string; currency: string; categories?: string[] }
export interface BudgetToolClient {
  callTool(request: { name: string; arguments: Record<string, unknown> }): Promise<unknown>;
}
export interface ReviewIO {
  write(text: string): Promise<void>;
  confirm(prompt: string): Promise<string | null>;
}
export type CopyOutcome =
  | { status: "preview_only" | "cancelled" | "conflict"; commitCalls: 0 }
  | { status: "completed"; commitCalls: 1; added: number; alreadyPresent: number };
export class CopyClientError extends Error {
  constructor(message: string, readonly commitAttempted = false) { super(message); }
}
const SCHEMA = "household-budget-copy/1";
const MAX_BYTES = 256 * 1024;
const MONTH = /^\d{4}-(0[1-9]|1[0-2])$/;

function requireValue(value: unknown, message: string): asserts value {
  if (!value) throw new CopyClientError(message);
}
function object(value: unknown, keys: string[], label: string): Record<string, unknown> {
  requireValue(value !== null && typeof value === "object" && !Array.isArray(value), label + " must be an object.");
  const result = value as Record<string, unknown>;
  requireValue(Object.keys(result).every(k => keys.includes(k)), label + " has unsupported fields.");
  return result;
}
function integer(value: unknown): value is number {
  return typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
}
function category(value: unknown): value is string {
  return typeof value === "string" && value.trim().length > 0 && value === value.trim() &&
    Buffer.byteLength(value, "utf8") <= 8192 && Buffer.from(value, "utf8").toString("utf8") === value;
}
function same(a: unknown, b: unknown): boolean { return JSON.stringify(a) === JSON.stringify(b); }

export function readCopyRequest(raw: unknown): CopyRequest {
  const value = object(raw, ["fromMonth", "toMonth", "currency", "categories"], "Request");
  requireValue(typeof value.fromMonth === "string" && MONTH.test(value.fromMonth), "Source month must be YYYY-MM.");
  requireValue(typeof value.toMonth === "string" && MONTH.test(value.toMonth), "Destination month must be YYYY-MM.");
  requireValue(value.fromMonth !== value.toMonth, "Source and destination months must differ.");
  requireValue(typeof value.currency === "string" && /^[A-Za-z]{3}$/.test(value.currency.trim()), "Choose an explicit three-letter currency.");
  const request: CopyRequest = { fromMonth: value.fromMonth, toMonth: value.toMonth, currency: value.currency.trim().toUpperCase() };
  if (Object.hasOwn(value, "categories")) {
    requireValue(Array.isArray(value.categories) && value.categories.length > 0 && value.categories.length <= 500, "Select 1–500 category names.");
    const categories = value.categories.map(value => typeof value === "string" ? value.trim() : value);
    requireValue(categories.every(category), "Category names must be nonempty valid Unicode, at most 8192 UTF-8 bytes each.");
    requireValue(new Set(categories).size === categories.length, "Category names must be distinct after trimming.");
    request.categories = categories;
  }
  requireValue(Buffer.byteLength(JSON.stringify(request), "utf8") <= MAX_BYTES, "Request exceeds 256 KiB.");
  return request;
}

/** Render control/bidi characters visibly; the escaped JSON string retains exact identity. */
export function terminalValue(value: unknown): string {
  return JSON.stringify(value).replace(/[\p{Cc}\p{Cf}\u2028\u2029]/gu,
    c => c.split("").map(unit => "\\u" + unit.charCodeAt(0).toString(16).padStart(4, "0")).join(""));
}
function toolPayload(raw: unknown): unknown {
  const reply = raw as { isError?: unknown; content?: unknown };
  requireValue(reply !== null && typeof reply === "object" && Array.isArray(reply.content) &&
    reply.content.length === 1, "Server did not return one complete text result.");
  const block = reply.content[0] as { type?: unknown; text?: unknown };
  requireValue(block?.type === "text" && typeof block.text === "string", "Server result is not complete JSON text.");
  requireValue(Buffer.byteLength(block.text, "utf8") <= MAX_BYTES, "Server result exceeds 256 KiB.");
  if (reply.isError === true) throw new CopyClientError("Server reported: " + terminalValue(block.text));
  requireValue(reply.isError === undefined || reply.isError === false, "Server error status is invalid.");
  try { return JSON.parse(block.text); } catch { throw new CopyClientError("Server result is not valid JSON."); }
}

export function readCopyPreview(raw: unknown, request: CopyRequest): BudgetCopyPreview {
  const value = object(raw, ["schema", "fromMonth", "toMonth", "currency", "canCommit", "counts", "rows", "review", "reviewToken"], "Preview");
  requireValue(value.schema === SCHEMA && value.fromMonth === request.fromMonth && value.toMonth === request.toMonth &&
    value.currency === request.currency, "Preview changed the requested month or currency.");
  requireValue(Array.isArray(value.rows) && value.rows.length > 0 && value.rows.length <= 500, "Preview must contain every selected budget (1–500).");
  const rows = value.rows.map(rawRow => {
    const row = object(rawRow, ["category", "limitMinor", "action", "destination", "reason"], "Preview row");
    requireValue(category(row.category) && integer(row.limitMinor), "Preview budget identity or limit is invalid.");
    requireValue(["add", "already_present", "conflict"].includes(row.action as string), "Preview row action is invalid.");
    requireValue(Array.isArray(row.destination) && row.destination.length <= 2, "Preview destination is invalid.");
    const destination = row.destination.map(rawTarget => {
      const target = object(rawTarget, ["category", "month", "limitMinor", "currency"], "Destination");
      requireValue(typeof target.category === "string" && target.category.trim() === row.category &&
        target.month === request.toMonth && integer(target.limitMinor), "Destination does not match the reviewed identity.");
      requireValue(target.currency === undefined || (typeof target.currency === "string" && /^[A-Za-z]{3}$/.test(target.currency.trim()) &&
        target.currency.trim().toUpperCase() === request.currency), "Destination denomination is invalid.");
      return target;
    });
    const matching = destination.length === 1 && destination[0].category === row.category &&
      destination[0].currency !== undefined && destination[0].limitMinor === row.limitMinor;
    requireValue(row.action === "conflict" ? typeof row.reason === "string" && row.reason.length > 0 :
      row.reason === undefined && (row.action === "add" ? destination.length === 0 : matching),
      "Preview action disagrees with its destination.");
    return { category: row.category, limitMinor: row.limitMinor, action: row.action, destination };
  });
  const names = rows.map(row => row.category);
  requireValue(new Set(names).size === names.length, "Preview repeated a category.");
  requireValue(!request.categories || same(names, request.categories), "Preview changed or omitted selected categories.");
  const counts = { total: rows.length, add: rows.filter(r => r.action === "add").length,
    alreadyPresent: rows.filter(r => r.action === "already_present").length, conflict: rows.filter(r => r.action === "conflict").length };
  const gotCounts = object(value.counts, ["total", "add", "alreadyPresent", "conflict"], "Preview counts");
  requireValue(Object.entries(counts).every(([key, count]) => gotCounts[key] === count), "Preview counts do not cover its rows.");
  requireValue(value.canCommit === (counts.conflict === 0), "Preview approval disagrees with its rows.");
  if (value.canCommit) {
    const expected: BudgetCopyReview = { schema: SCHEMA, fromMonth: request.fromMonth, toMonth: request.toMonth,
      currency: request.currency, rows: rows.map(row => ({ category: row.category as string, limitMinor: row.limitMinor as number,
        expectedTargetLimitMinor: row.action === "already_present" ? row.limitMinor as number : null })) };
    requireValue(same(value.review, expected), "The commit review differs from the displayed values.");
    requireValue(value.reviewToken === createHash("sha256").update(JSON.stringify(expected)).digest("hex"), "Review token does not bind the displayed values.");
  } else requireValue(value.review === null && value.reviewToken === null, "A conflicting preview cannot contain a commit review.");
  return value as unknown as BudgetCopyPreview;
}

export function renderCopyPreview(preview: BudgetCopyPreview): string {
  const lines = [
    "Review monthly budget copy",
    "Source: " + preview.fromMonth + "  Destination: " + preview.toMonth + "  Currency: " + preview.currency,
    "Limits are exact integer minor units; no currency conversion.",
    "Rows: " + preview.counts.total + "  Add: " + preview.counts.add + "  Already present: " + preview.counts.alreadyPresent + "  Conflicts: " + preview.counts.conflict,
  ];
  for (const [i, row] of preview.rows.entries()) {
    lines.push((i + 1) + ". " + terminalValue(row.category) + "  limitMinor=" + row.limitMinor + "  action=" + row.action);
    lines.push("   Current destination: " + terminalValue(row.destination));
    if (row.reason) lines.push("   Reason: " + terminalValue(row.reason));
  }
  lines.push("Content token: " + (preview.reviewToken ?? "none (conflict)"));
  lines.push("Current values will be checked again by the server. This preview does not reserve the ledger.");
  return lines.join("\n") + "\n";
}

function readCopyReceipt(raw: unknown, preview: BudgetCopyPreview): { added: number; alreadyPresent: number } {
  const value = object(raw, ["schema", "fromMonth", "toMonth", "currency", "reviewToken", "added", "alreadyPresent", "budgets"], "Commit receipt");
  requireValue(value.schema === SCHEMA && value.fromMonth === preview.fromMonth && value.toMonth === preview.toMonth &&
    value.currency === preview.currency && value.reviewToken === preview.reviewToken, "Commit receipt does not identify the reviewed copy.");
  requireValue(integer(value.added) && integer(value.alreadyPresent) && value.added + value.alreadyPresent === preview.rows.length,
    "Commit receipt has incomplete counts.");
  requireValue(value.added <= preview.counts.add, "Commit receipt added a previously present budget.");
  requireValue(Array.isArray(value.budgets) && value.budgets.length === preview.rows.length, "Commit receipt is incomplete.");
  for (const [i, rawBudget] of value.budgets.entries()) {
    const budget = object(rawBudget, ["category", "month", "limitMinor", "currency"], "Committed budget");
    requireValue(budget.category === preview.rows[i].category && budget.month === preview.toMonth &&
      budget.limitMinor === preview.rows[i].limitMinor && typeof budget.currency === "string" && /^[A-Za-z]{3}$/.test(budget.currency.trim()) &&
      budget.currency.trim().toUpperCase() === preview.currency, "Commit receipt changed a reviewed budget.");
  }
  return { added: value.added, alreadyPresent: value.alreadyPresent };
}

export async function runBudgetCopy(client: BudgetToolClient, input: unknown, io: ReviewIO, previewOnly = false): Promise<CopyOutcome> {
  const request = readCopyRequest(input);
  const preview = readCopyPreview(toolPayload(await client.callTool({ name: "preview_budget_copy", arguments: { ...request } })), request);
  await io.write(renderCopyPreview(preview));
  if (!preview.canCommit) {
    await io.write("No commit sent: resolve the conflicts and deliberately preview again.\n");
    return { status: "conflict", commitCalls: 0 };
  }
  if (previewOnly) { await io.write("Preview only. No commit sent.\n"); return { status: "preview_only", commitCalls: 0 }; }
  const phrase = "COPY " + preview.toMonth + " " + preview.currency;
  const answer = await io.confirm("Type " + terminalValue(phrase) + " to copy these reviewed budgets, or anything else to cancel: ");
  if (answer !== phrase) { await io.write("Cancelled. No commit sent.\n"); return { status: "cancelled", commitCalls: 0 }; }
  let receipt: { added: number; alreadyPresent: number };
  try {
    receipt = readCopyReceipt(toolPayload(await client.callTool({ name: "commit_budget_copy",
      arguments: { review: preview.review, reviewToken: preview.reviewToken } })), preview);
  } catch (error) {
    throw new CopyClientError("Commit outcome is not confirmed. No automatic retry was made. Inspect the destination budgets before deciding on a new preview. Detail: " +
      terminalValue(error instanceof Error ? error.message : String(error)), true);
  }
  try { await io.write("Copy confirmed: added " + receipt.added + ", already present " + receipt.alreadyPresent + ".\n"); }
  catch { throw new CopyClientError("The server confirmed the copy, but writing its receipt failed. No automatic retry was made; inspect destination budgets before a new action.", true); }
  return { status: "completed", commitCalls: 1, ...receipt };
}
