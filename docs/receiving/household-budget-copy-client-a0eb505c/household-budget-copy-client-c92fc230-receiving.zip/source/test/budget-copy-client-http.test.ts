import { test } from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { once } from "node:events";
import { mkdtemp, readFile, writeFile, stat, rm } from "node:fs/promises";
import { createServer as createNetServer } from "node:net";
import { createServer } from "node:http";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";
import { CopyClientError, runBudgetCopy, terminalValue } from "../src/budget-copy-client.js";

const request = { fromMonth: "2026-10", toMonth: "2026-11", currency: "USD" };
const sourceBudgets = [
  { category: "groceries", month: "2026-10", limitMinor: 12500, currency: "USD" },
  { category: "旅行\n予定 🧭", month: "2026-10", limitMinor: 7000, currency: "USD" },
  { category: "zero", month: "2026-10", limitMinor: 0, currency: "USD" },
  { category: "groceries", month: "2026-10", limitMinor: 90, currency: "EUR" },
];
const transaction = { id: "existing-record", type: "expense", amountMinor: 5, currency: "CHF", date: "2026-09-30",
  category: "unrelated", note: "keep literal", idempotencyKey: "existing:fixture", createdAt: "2026-10-01T00:00:00.000Z" };
const initial = { version: 2, transactions: [transaction], budgets: [...sourceBudgets,
  { category: "groceries", month: "2026-11", limitMinor: 12500, currency: "USD" },
  { category: "groceries", month: "2026-11", limitMinor: 80, currency: "EUR" }] };
async function snapshot(path: string) {
  const info = await stat(path, { bigint: true });
  return { text: await readFile(path, "utf8"), inode: info.ino, mtime: info.mtimeNs };
}
async function launch() {
  const dir = await mkdtemp(join(tmpdir(), "household-copy-client-a0eb-"));
  const path = join(dir, "fictional-ledger.json");
  await writeFile(path, JSON.stringify(initial, null, 2) + "\n");
  const portProbe = createNetServer(); portProbe.listen(0, "127.0.0.1"); await once(portProbe, "listening");
  const address = portProbe.address(); assert.ok(address && typeof address !== "string");
  const port = address.port; await new Promise<void>((resolve, reject) => portProbe.close(error => error ? reject(error) : resolve()));
  const child = spawn(process.execPath, [fileURLToPath(new URL("../src/index.js", import.meta.url))], {
    env: { ...process.env, HOUSEHOLD_LEDGER_DATA_PATH: path, HOUSEHOLD_LEDGER_HOST: "127.0.0.1", HOUSEHOLD_LEDGER_PORT: String(port) },
    stdio: ["ignore", "pipe", "pipe"],
  });
  let errors = ""; child.stderr.on("data", chunk => { errors += String(chunk); });
  const clients: Client[] = [];
  const origin = "http://127.0.0.1:" + port + "/mcp";
  const calls: Array<{ name: string; arguments: unknown }> = [];
  let dropNextCommit = false;
  const proxy = createServer(async (req, res) => {
    try {
      const chunks: Buffer[] = []; for await (const chunk of req) chunks.push(Buffer.from(chunk));
      const body = Buffer.concat(chunks).toString("utf8");
      const decoded = body ? JSON.parse(body) as { method?: string; params?: { name?: string; arguments?: unknown } } : {};
      const name = decoded.method === "tools/call" ? decoded.params?.name : undefined;
      if (name) calls.push({ name, arguments: decoded.params?.arguments });
      const headers: Record<string, string> = {};
      for (const key of ["content-type", "accept", "mcp-protocol-version", "mcp-session-id", "last-event-id"]) {
        const value = req.headers[key]; if (typeof value === "string") headers[key] = value;
      }
      const upstream = await fetch(origin, { method: req.method, headers, ...(body ? { body } : {}), redirect: "error" });
      const text = await upstream.text();
      // The unchanged native server has completed its response before this
      // private transport drops delivery. No product writer/I/O is replaced.
      if (name === "commit_budget_copy" && dropNextCommit) { dropNextCommit = false; res.destroy(); return; }
      const responseHeaders: Record<string, string> = {};
      for (const key of ["content-type", "mcp-session-id"]) {
        const value = upstream.headers.get(key); if (value) responseHeaders[key] = value;
      }
      res.writeHead(upstream.status, responseHeaders); res.end(text);
    } catch (error) { if (!res.headersSent) res.writeHead(502); res.end(String(error)); }
  });
  async function stop() {
    try {
      for (const client of clients) await client.close().catch(() => undefined);
      if (proxy.listening) { proxy.closeAllConnections(); await new Promise<void>(resolve => proxy.close(() => resolve())); }
    } finally {
      if (child.exitCode === null && child.signalCode === null) { const ended = once(child, "exit"); child.kill("SIGTERM"); await ended; }
      await rm(dir, { recursive: true, force: true });
    }
    assert.equal(errors, "", "private unchanged server emitted errors");
  }
  try {
    await new Promise<void>((resolve, reject) => {
      let output = ""; const timer = setTimeout(() => reject(new Error("private server startup timed out")), 20000);
      child.once("error", e => { clearTimeout(timer); reject(e); });
      child.once("exit", code => { clearTimeout(timer); reject(new Error("private server exit " + code)); });
      child.stdout.on("data", chunk => {
        output += String(chunk); if (output.includes("listening on")) { clearTimeout(timer); resolve(); }
      });
    });
    proxy.listen(0, "127.0.0.1"); await once(proxy, "listening");
    const proxyAddress = proxy.address(); assert.ok(proxyAddress && typeof proxyAddress !== "string");
    const endpoint = "http://127.0.0.1:" + proxyAddress.port + "/mcp";
    async function connect() {
      const client = new Client({ name: "private-copy-client-receiver", version: "1" }, { capabilities: {} });
      clients.push(client); await client.connect(new StreamableHTTPClientTransport(new URL(endpoint)));
      return client;
    }
    return { path, endpoint, calls, connect, dropCommitResponse() { dropNextCommit = true; }, stop };
  } catch (error) { await stop(); throw error; }
}
const io = (answer: string | null = "COPY 2026-11 USD") => {
  const lines: string[] = [];
  return { lines, async write(text: string) { lines.push(text); }, async confirm() { return answer; } };
};
async function tool(client: Client, name: string, args: Record<string, unknown>) {
  const response = await client.callTool({ name, arguments: args });
  assert.equal(response.isError, undefined, JSON.stringify(response));
  const content = response.content as Array<{ type: string; text: string }>;
  return JSON.parse(content[0].text);
}

test("real private MCP preview/cancel and explicit copy preserve exact fields; a fresh review of matching targets does not rewrite", async () => {
  const service = await launch();
  try {
    const client = await service.connect(); const before = await snapshot(service.path);
    const cancelled = io(null);
    assert.equal((await runBudgetCopy(client, request, cancelled)).status, "cancelled");
    assert.deepEqual(await snapshot(service.path), before);
    assert.deepEqual(service.calls.map(c => c.name), ["preview_budget_copy"]);
    const output = io();
    const result = await runBudgetCopy(client, request, output);
    assert.deepEqual(result, { status: "completed", commitCalls: 1, added: 2, alreadyPresent: 1 });
    for (const row of sourceBudgets.slice(0, 3)) assert.ok(output.lines.join("").includes(terminalValue(row.category)));
    const saved = JSON.parse((await snapshot(service.path)).text);
    assert.deepEqual(saved.transactions, [transaction]);
    assert.deepEqual(saved.budgets.filter((b: { month: string }) => b.month === "2026-10"), sourceBudgets);
    assert.deepEqual(saved.budgets.filter((b: { month: string; currency: string }) => b.month === "2026-11" && b.currency === "USD"),
      sourceBudgets.slice(0, 3).map(b => ({ ...b, month: "2026-11" })));
    assert.deepEqual(saved.budgets.find((b: { month: string; currency: string }) => b.month === "2026-11" && b.currency === "EUR"), initial.budgets[5]);
    const complete = await snapshot(service.path);
    assert.deepEqual(await runBudgetCopy(client, request, io()), { status: "completed", commitCalls: 1, added: 0, alreadyPresent: 3 });
    assert.deepEqual(await snapshot(service.path), complete);
    assert.equal(service.calls.filter(c => c.name === "commit_budget_copy").length, 2);
  } finally { await service.stop(); }
});

test("real stale source and destination errors do not become success; an unrelated ordinary write survives a valid copy", async () => {
  const service = await launch();
  try {
    const client = await service.connect(); const other = await service.connect();
    for (const change of [
      { category: "zero", month: "2026-10", limitMinor: 9, currency: "USD" },
      { category: "旅行\n予定 🧭", month: "2026-11", limitMinor: 123, currency: "USD" },
    ]) {
      if (change.month === "2026-11") await tool(other, "set_budget", { category: "zero", month: "2026-10", limitMinor: 0, currency: "USD" });
      const output = io(); let afterChange: Awaited<ReturnType<typeof snapshot>> | undefined;
      output.confirm = async () => { await tool(other, "set_budget", change); afterChange = await snapshot(service.path); return "COPY 2026-11 USD"; };
      await assert.rejects(runBudgetCopy(client, request, output), (e: unknown) => e instanceof CopyClientError && e.commitAttempted && /not confirmed/.test(e.message));
      assert.deepEqual(await snapshot(service.path), afterChange);
      assert.ok(!output.lines.join("").includes("Copy confirmed"));
    }
    await tool(other, "set_budget", { category: "旅行\n予定 🧭", month: "2026-11", limitMinor: 7000, currency: "USD" });
    const output = io(); let unrelated: unknown;
    output.confirm = async () => {
      unrelated = await tool(other, "record_transaction", { type: "income", amountMinor: 35, currency: "EUR", date: "2026-11-02",
        category: "gift", idempotencyKey: "later:unrelated" });
      await tool(other, "set_budget", { category: "zero", month: "2026-11", limitMinor: 33, currency: "CHF" });
      return "COPY 2026-11 USD";
    };
    assert.deepEqual(await runBudgetCopy(client, request, output), { status: "completed", commitCalls: 1, added: 1, alreadyPresent: 2 });
    const saved = JSON.parse((await snapshot(service.path)).text);
    assert.deepEqual(saved.transactions, [transaction, unrelated]);
    assert.ok(saved.budgets.some((b: { category: string; currency: string; limitMinor: number }) => b.category === "zero" && b.currency === "CHF" && b.limitMinor === 33));
  } finally { await service.stop(); }
});

test("a real committed response lost in private transport produces uncertainty and exactly one commit, not a retry", async () => {
  const service = await launch();
  try {
    const client = await service.connect(); const output = io(); service.dropCommitResponse();
    await assert.rejects(runBudgetCopy(client, request, output), (e: unknown) =>
      e instanceof CopyClientError && e.commitAttempted && /not confirmed/.test(e.message));
    assert.deepEqual(service.calls.map(c => c.name), ["preview_budget_copy", "commit_budget_copy"]);
    const saved = JSON.parse((await snapshot(service.path)).text);
    assert.equal(saved.budgets.filter((b: { month: string; currency: string }) => b.month === "2026-11" && b.currency === "USD").length, 3);
    const afterCommit = await snapshot(service.path);
    const fresh = await service.connect(); const check = io();
    assert.equal((await runBudgetCopy(fresh, request, check, true)).status, "preview_only");
    assert.match(check.lines.join(""), /Already present: 3/);
    assert.equal(service.calls.filter(c => c.name === "commit_budget_copy").length, 1);
    assert.deepEqual(await snapshot(service.path), afterCommit);
  } finally { await service.stop(); }
});

test("the actual noninteractive preview CLI consumes the private unchanged server and leaves the ledger byte-exact", async () => {
  const service = await launch();
  try {
    const before = await snapshot(service.path);
    const child = spawn(process.execPath, [fileURLToPath(new URL("../src/household-budget-copy.js", import.meta.url)),
      "--endpoint", service.endpoint, "--from-month", "2026-10", "--to-month", "2026-11", "--currency", "USD", "--preview"],
      { stdio: ["ignore", "pipe", "pipe"] });
    let stdout = "", stderr = "";
    child.stdout.on("data", c => { stdout += String(c); }); child.stderr.on("data", c => { stderr += String(c); });
    const [code] = await once(child, "exit");
    assert.equal(code, 0, stderr); assert.equal(stderr, "");
    assert.match(stdout, /Preview only. No commit sent/);
    for (const row of sourceBudgets.slice(0, 3)) assert.ok(stdout.includes(terminalValue(row.category)));
    assert.deepEqual(service.calls.map(c => c.name), ["preview_budget_copy"]);
    assert.deepEqual(await snapshot(service.path), before);
  } finally { await service.stop(); }
});
