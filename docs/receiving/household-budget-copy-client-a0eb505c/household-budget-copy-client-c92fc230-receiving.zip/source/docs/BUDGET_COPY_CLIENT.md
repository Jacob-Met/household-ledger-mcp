# Review and copy budgets from a terminal

This optional client uses the existing `preview_budget_copy` and `commit_budget_copy` MCP tools. It connects to one already-running local Household Ledger server and opens no ledger file. The server must include the qualified budget-copy contribution described in [BUDGET_COPY.md](BUDGET_COPY.md).

Build through the existing project command, then run:

```sh
npm run build
node dist/src/household-budget-copy.js \
  --endpoint http://127.0.0.1:3000/mcp \
  --from-month 2026-10 --to-month 2026-11 --currency USD
```

The endpoint is explicit local HTTP at `/mcp`, without credentials, query or fragment. No default server, endpoint discovery, authentication flow, direct file access or second writer is started. Keep the existing one-server-process-per-ledger-file rule. This contribution does not change package entry points or install a global command.

Use repeated `--category NAME` arguments to choose specific source budgets. Omit them to use the native tool's complete currency selection and unassigned-budget rules. Source and destination months must differ. Names are trimmed in the request just as the existing tool does; the complete preview retains the resulting exact category identity.

## Review before confirmation

The client prints every selected category, its exact integer minor-unit limit, current destination records, proposed action and any conflict. It prints the selected months/currency, complete counts and content token. Control and bidirectional formatting characters are visibly JSON-escaped in labels so they cannot rewrite terminal output; no category is silently renamed.

The client checks that the complete preview and token agree before asking. Conflicts cannot be confirmed. With valid rows, type exactly the displayed phrase, for example:

```text
COPY 2026-11 USD
```

Any other answer, EOF or Ctrl-C at the prompt cancels without sending a commit. Both input and output must be terminals. There is no `--yes` or piped-confirmation mode. For an explicit read-only review, including scripts:

```sh
node dist/src/household-budget-copy.js --endpoint http://127.0.0.1:3000/mcp \
  --from-month 2026-10 --to-month 2026-11 --currency USD --preview
```

`--help` works offline. The example request in `examples/budget-copy-request.json` documents the corresponding tool inputs; the CLI accepts the explicit flags, not a local JSON file.

## One deliberate commit

Confirmation sends exactly the displayed review and its token once. The existing server rechecks all current source and destination values inside its serialized writer. The client does not reserve budgets, overwrite a conflict, infer a currency, convert limits, or add new persistence. A matching current repeat keeps the native no-write behavior.

A complete matching server receipt reports actual added/already-present counts. Those may differ from the preview if an identical destination appeared meanwhile. An unrelated transaction or other-currency budget remains the server's unchanged responsibility.

A lost connection, a server error or a malformed receipt after the commit call is **unconfirmed**, not a claim that nothing happened. The client sends no automatic retry and does not automatically re-preview. Inspect the destination using the existing tools, then decide whether a new review is appropriate. The native service has current-value checks, not a durable plan-history receipt; its original limitations remain.

Exit statuses are 0 for confirmed copy, deliberate cancellation, help or preview; 1 for pre-commit admission/transport failure; 2 for a displayed conflict; and 3 for an unconfirmed commit or a confirmed receipt that could not be written to output. Cancellation is also stated explicitly in terminal output.

## Receiving and ownership

This six-new-path client starts at qualified native `2b77b81ad59c5f3255aa25c37110e91d3bad6a01`, tree `940438aed7af43d841ff7700da8bd4f83a838afd`. All 97 existing source/evidence files remain exact. The source-parent ce7 and canonical receiver 617 retain foundation/adoption and their current budget-plus-filter composition. CSV-import client #9, monthly-review #10 and statement-export #7 retain their separate scopes.

Focused controls use fictional temporary ledgers, the actual unchanged native HTTP server and maintained MCP client. A private loopback relay drops one already-completed commit response to verify truthful uncertainty and exactly one call. No live financial data, account, provider, installed service or deployment is used. The existing 118 domain controls are not rerun or relabeled as this new client qualification. Receive only this additive client delta through the established owner route; native snapshot ancestry is reproduction evidence, not a canonical-main merge.
