#!/usr/bin/env python3
"""One private real-PTY consumer control. Product and SDK source stay unchanged."""
from pathlib import Path
import argparse, base64, errno, fcntl, hashlib, http.client, http.server, json
import os, pty, re, select, signal, socket, struct, subprocess, sys, tempfile, termios, threading, time, traceback

def emit(path, value):
    Path(path).write_bytes((json.dumps(value, ensure_ascii=True, indent=2) + "\n").encode())

def relay(args):
    lock = threading.Lock()
    class Handler(http.server.BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"
        def log_message(self, *unused): pass
        def service(self):
            received = time.monotonic_ns()
            try:
                if self.path != "/mcp": raise ValueError("private relay admits only /mcp")
                size = int(self.headers.get("Content-Length", "0"))
                if not 0 <= size <= 300000: raise ValueError("private request bound")
                body = self.rfile.read(size)
                request = json.loads(body) if body else {}
                headers = {k: self.headers[k] for k in
                    ["Content-Type", "Accept", "Mcp-Protocol-Version", "Mcp-Session-Id", "Last-Event-Id"]
                    if self.headers.get(k) is not None}
                conn = http.client.HTTPConnection("127.0.0.1", args.upstream_port, timeout=10)
                try:
                    conn.request(self.command, "/mcp", body=body or None, headers=headers)
                    upstream = conn.getresponse()
                    payload = upstream.read()
                    status, content_type = upstream.status, upstream.getheader("Content-Type")
                finally:
                    conn.close()
                if request.get("method") == "tools/call":
                    envelope = None
                    for line in payload.decode("utf-8").splitlines():
                        candidate = line[6:] if line.startswith("data: ") else line
                        if candidate.startswith("{"):
                            try: envelope = json.loads(candidate)
                            except json.JSONDecodeError: pass
                    record = {"received_ns": received, "responded_ns": time.monotonic_ns(),
                        "name": request.get("params", {}).get("name"),
                        "arguments": request.get("params", {}).get("arguments"),
                        "status": status, "envelope": envelope}
                    with lock:
                        with open(args.trace, "a", encoding="utf-8") as out:
                            out.write(json.dumps(record, ensure_ascii=True) + "\n")
                self.send_response(status)
                if content_type: self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(payload)))
                self.send_header("Connection", "close")
                self.end_headers(); self.wfile.write(payload)
                self.close_connection = True
            except Exception as error:
                raw = ("private relay error: " + type(error).__name__).encode()
                self.send_response(502); self.send_header("Content-Length", str(len(raw)))
                self.send_header("Connection", "close"); self.end_headers(); self.wfile.write(raw)
                self.close_connection = True
        do_POST = service
        do_GET = service
        do_DELETE = service
    server = http.server.ThreadingHTTPServer(("127.0.0.1", args.relay_port), Handler)
    print("PRIVATE_RELAY_READY", flush=True)
    server.serve_forever()

def free_port():
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0)); return sock.getsockname()[1]

def snapshot(path):
    raw = path.read_bytes(); st = path.stat()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
        "mtime_ns": st.st_mtime_ns, "inode": st.st_ino,
        "data": json.loads(raw), "raw_base64": base64.b64encode(raw).decode()}

def source_binding(source, freeze_path, expected_freeze, expected_head):
    raw = freeze_path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == expected_freeze, "freeze bytes drift"
    freeze = json.loads(raw)
    assert freeze["head"] == expected_head, "wrong frozen head"
    result = {"head": freeze["head"], "tree": freeze["tree"], "freeze_sha256": expected_freeze, "files": []}
    for kind in ["source", "compiled"]:
        for row in freeze[kind]:
            relative = Path(row["path"])
            assert not relative.is_absolute() and ".." not in relative.parts
            path = source / relative; data = path.read_bytes()
            digest = hashlib.sha256(data).hexdigest()
            assert digest == row["sha256"] and len(data) == row["bytes"], str(relative)
            if kind == "source":
                mode = "100755" if path.stat().st_mode & 0o111 else "100644"
                assert mode == row["mode"], str(relative) + " mode"
                blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
                assert blob == row["blob"], str(relative) + " Git blob"
            result["files"].append({"path": row["path"], "sha256": digest, "bytes": len(data), "kind": kind})
    result["source_files"] = len(freeze["source"])
    result["compiled_files"] = len(freeze["compiled"])
    result["dependency_target"] = str((source / "node_modules").resolve(strict=True))
    return result

def wait_line(process, marker, timeout=12):
    chunks = bytearray(); deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if process.poll() is not None: raise AssertionError("owned process exited before readiness")
        ready, _, _ = select.select([process.stdout], [], [], 0.1)
        if ready:
            data = os.read(process.stdout.fileno(), 8192)
            if not data: raise AssertionError("owned readiness pipe closed")
            chunks.extend(data)
            if marker in chunks: return bytes(chunks)
    raise AssertionError("owned process readiness timeout")

def stop(process):
    if process is None: return None
    if process.poll() is None:
        os.killpg(process.pid, signal.SIGTERM)
        try: process.wait(timeout=4)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL); process.wait(timeout=4)
    return process.returncode

def read_trace(path):
    return [json.loads(line) for line in path.read_text().splitlines()] if path.exists() else []

def pty_bytes(fd, timeout):
    ready, _, _ = select.select([fd], [], [], timeout)
    if not ready: return None
    try: return os.read(fd, 65536)
    except OSError as error:
        if error.errno == errno.EIO: return b""
        raise

def main(args):
    source = Path(args.source); output = Path(args.output)
    output.mkdir(parents=True, exist_ok=False)
    result = {"started_at": time.time(), "uid": os.getuid(), "network_namespace": os.readlink("/proc/self/ns/net"),
        "source": str(source), "head": args.head, "branches": [], "assertions": [], "status": "running"}
    server = proxy = None; server_error = proxy_error = None
    active_pid = None; active_fd = None; temporary = None
    def check(name, condition, detail=None):
        result["assertions"].append({"name": name, "passed": bool(condition), "detail": detail})
        if not condition: raise AssertionError(name)
    try:
        source_before = source_binding(source, Path(args.freeze), args.freeze_sha256, args.head)
        emit(output / "source-binding-before.json", source_before)
        runtime_raw = Path(args.freeze).with_name("runtime-recovery.json").read_bytes()
        check("exact_runtime_manifest", hashlib.sha256(runtime_raw).hexdigest() == "87f5f0112e9c7057bd975ccf619ae35ac69969337a0f769e6c220b9d132a2a82")
        runtime = json.loads(runtime_raw); runtime_root = Path(runtime["runtime"])
        check("source_uses_pinned_runtime", Path(source_before["dependency_target"]) == runtime_root / "node_modules")
        for row in runtime["entries"]:
            raw = (runtime_root / row["path"]).read_bytes()
            assert len(raw) == row["bytes"] and hashlib.sha256(raw).hexdigest() == row["sha256"], row["path"]
        emit(output / "runtime-binding.json", {"manifest_sha256": hashlib.sha256(runtime_raw).hexdigest(),
            "files_verified": len(runtime["entries"]), "runtime": str(runtime_root),
            "lock_comparison_sha256": hashlib.sha256(Path(args.freeze).with_name("runtime-lock-comparison-addendum.json").read_bytes()).hexdigest()})
        check("receiver_runs_as_nonroot", os.getuid() == 1000)
        interfaces = sorted(name for _, name in socket.if_nameindex())
        check("private_namespace_has_only_loopback", interfaces == ["lo"], interfaces)
        temporary = tempfile.TemporaryDirectory(prefix="fictional-pty-", dir=output)
        work = Path(temporary.name); ledger = work / "fictional-ledger.json"; trace = output / "actual-mcp-calls.jsonl"
        names = ["Groceries", "Travel\u061c route", "Shared\U000e0001 kit\n\u2615"]
        limits = [12345, 6700, 0]
        source_budgets = [{"category": n, "month": "2026-10", "limitMinor": v, "currency": "USD"} for n, v in zip(names, limits)]
        unrelated_source = {"category": "Groceries", "month": "2026-10", "limitMinor": 321, "currency": "EUR"}
        matching = dict(source_budgets[0], month="2026-11")
        unrelated_target = {"category": "Groceries", "month": "2026-11", "limitMinor": 654, "currency": "EUR"}
        transaction = {"id": "fictional-pty-keep", "type": "expense", "amountMinor": 314, "currency": "CHF",
            "date": "2026-09-25", "category": "Outside copy", "note": "Literal fictional receiver record",
            "idempotencyKey": "fictional:pty:keep", "createdAt": "2026-09-25T12:00:00.000Z"}
        initial = {"version": 2, "transactions": [transaction], "budgets": source_budgets + [unrelated_source, matching, unrelated_target]}
        emit(ledger, initial)
        emit(output / "fictional-input.json", initial)
        server_port, relay_port = free_port(), free_port()
        while relay_port == server_port: relay_port = free_port()
        check("distinct_private_ports", server_port != relay_port)
        env = dict(os.environ, HOUSEHOLD_LEDGER_DATA_PATH=str(ledger), HOUSEHOLD_LEDGER_HOST="127.0.0.1",
            HOUSEHOLD_LEDGER_PORT=str(server_port))
        server_error = open(output / "server-stderr.log", "wb")
        server = subprocess.Popen(["/usr/bin/node", str(source / "dist/src/index.js")], cwd=source, env=env,
            stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=server_error, start_new_session=True)
        ready = wait_line(server, b"listening on"); (output / "server-readiness.log").write_bytes(ready)
        proxy_error = open(output / "relay-stderr.log", "wb")
        proxy = subprocess.Popen([sys.executable, "-B", str(Path(__file__).resolve()), "--relay",
            "--upstream-port", str(server_port), "--relay-port", str(relay_port), "--trace", str(trace)],
            stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=proxy_error, start_new_session=True)
        (output / "relay-readiness.log").write_bytes(wait_line(proxy, b"PRIVATE_RELAY_READY"))
        endpoint = "http://127.0.0.1:" + str(relay_port) + "/mcp"
        argv = ["/usr/bin/node", str(source / "dist/src/household-budget-copy.js"), "--endpoint", endpoint,
            "--from-month", "2026-10", "--to-month", "2026-11", "--currency", "uSd"]
        for name in names: argv += ["--category", name]
        cases = [
            ("inexact_phrase", b"COPY 2026-11 USD \n", False),
            ("terminal_eof", b"\x04", False),
            ("partial_then_ctrl_c", b"COPY 2026-11 \x03", False),
            ("exact_with_buffered_duplicate", b"COPY 2026-11 USD\nCOPY 2026-11 USD\n", True),
        ]
        for name, answer, confirms in cases:
            before = snapshot(ledger); call_offset = len(read_trace(trace)); transcript = bytearray()
            started_ns = time.monotonic_ns()
            active_pid, active_fd = pty.fork()
            if active_pid == 0:
                try:
                    os.chdir(source)
                    child_env = dict(os.environ, TERM="xterm-256color", NO_COLOR="1")
                    os.execve(argv[0], argv, child_env)
                except Exception:
                    os._exit(127)
            fcntl.ioctl(active_fd, termios.TIOCSWINSZ, struct.pack("HHHH", 50, 160, 0, 0))
            deadline = time.monotonic() + 15
            prompt = b"or anything else to cancel: "
            while prompt not in transcript and time.monotonic() < deadline:
                data = pty_bytes(active_fd, 0.1)
                if data == b"": break
                if data: transcript.extend(data)
            check(name + ": actual prompt reached", prompt in transcript)
            prompt_ns = time.monotonic_ns()
            prefix = bytes(transcript); (output / (name + "-before-input.pty")).write_bytes(prefix)
            (output / (name + "-before-input.txt")).write_text(prefix.decode("utf-8"))
            preview_calls = read_trace(trace)[call_offset:]
            check(name + ": only one preview before input", [r["name"] for r in preview_calls] == ["preview_budget_copy"])
            envelope = preview_calls[0]["envelope"]
            preview = json.loads(envelope["result"]["content"][0]["text"])
            check(name + ": requested normalized identity", preview["fromMonth"] == "2026-10" and preview["toMonth"] == "2026-11" and preview["currency"] == "USD")
            check(name + ": actual preview has all exact source values", [(r["category"], r["limitMinor"]) for r in preview["rows"]] == list(zip(names, limits)))
            text = prefix.decode("utf-8").replace("\r\n", "\n")
            row_lines = [line for line in text.splitlines() if re.match(r"^\d+\. ", line)]
            destinations = [line[len("   Current destination: "):] for line in text.splitlines() if line.startswith("   Current destination: ")]
            displayed = []
            for line in row_lines:
                match = re.fullmatch(r"\d+\. (.+)  limitMinor=(\d+)  action=(\w+)", line)
                check(name + ": complete parsable row", bool(match), line)
                displayed.append((json.loads(match.group(1)), int(match.group(2)), match.group(3)))
            check(name + ": every displayed row exact before confirmation", displayed == [(r["category"], r["limitMinor"], r["action"]) for r in preview["rows"]])
            check(name + ": every current destination exact before confirmation", [json.loads(x) for x in destinations] == [r["destination"] for r in preview["rows"]])
            check(name + ": exact normalized phrase is shown", 'Type "COPY 2026-11 USD"' in text)
            check(name + ": format controls are visible escaped identities", "\u061c" not in text and "\U000e0001" not in text and len(displayed) == 3)
            check(name + ": entire preview precedes prompt", text.index("Content token: ") < text.index('Type "COPY 2026-11 USD"'))
            check(name + ": no ledger write while waiting", snapshot(ledger) == before)
            sent_ns = time.monotonic_ns(); os.write(active_fd, answer)
            deadline = time.monotonic() + 15; wait_status = None
            while time.monotonic() < deadline:
                data = pty_bytes(active_fd, 0.1)
                if data: transcript.extend(data)
                pid, status = os.waitpid(active_pid, os.WNOHANG)
                if pid:
                    wait_status = status
                    while True:
                        data = pty_bytes(active_fd, 0.05)
                        if not data: break
                        transcript.extend(data)
                    break
            check(name + ": client exits promptly", wait_status is not None)
            exit_code = os.waitstatus_to_exitcode(wait_status)
            os.close(active_fd); active_fd = None; active_pid = None
            check(name + ": documented zero exit", exit_code == 0, exit_code)
            after = snapshot(ledger); calls = read_trace(trace)[call_offset:]
            check(name + ": source-owned server survives terminal action", server.poll() is None and proxy.poll() is None)
            check(name + ": preview responded before typed input", preview_calls[0]["responded_ns"] <= prompt_ns <= sent_ns)
            output_text = bytes(transcript).decode("utf-8")
            if confirms:
                check(name + ": exactly one actual commit despite duplicate buffered line", [r["name"] for r in calls] == ["preview_budget_copy", "commit_budget_copy"])
                check(name + ": commit follows explicit input", calls[1]["received_ns"] >= sent_ns)
                check(name + ": actual commit is exact reviewed plan", calls[1]["arguments"] == {"review": preview["review"], "reviewToken": preview["reviewToken"]})
                expected = dict(initial, budgets=initial["budgets"] + [dict(source_budgets[1], month="2026-11"), dict(source_budgets[2], month="2026-11")])
                check(name + ": exact complete copy and unrelated data preserved", after["data"] == expected)
                check(name + ": actual durable file changed", after["sha256"] != before["sha256"])
                check(name + ": one confirmed receipt", output_text.count("Copy confirmed: added 2, already present 1.") == 1)
            else:
                check(name + ": no actual commit request", [r["name"] for r in calls] == ["preview_budget_copy"])
                check(name + ": bytes inode mtime version and unrelated state exact", after == before)
                check(name + ": explicit cancellation receipt", "Cancelled. No commit sent." in output_text)
            (output / (name + ".pty")).write_bytes(transcript)
            (output / (name + ".txt")).write_text(output_text)
            branch = {"name": name, "before": before, "after": after, "calls": calls, "exit_code": exit_code,
                "started_ns": started_ns, "prompt_ns": prompt_ns, "input_sent_ns": sent_ns, "input_hex": answer.hex()}
            emit(output / (name + ".json"), branch); result["branches"].append({"name": name, "exit_code": exit_code, "calls": [r["name"] for r in calls]})
        after_binding = source_binding(source, Path(args.freeze), args.freeze_sha256, args.head)
        check("all_frozen_source_and_compiled_inputs_unchanged", after_binding == source_before)
        emit(output / "source-binding-after.json", after_binding)
        result["status"] = "passed"
    except Exception:
        result["status"] = "failed"; result["error"] = traceback.format_exc()
    finally:
        if active_pid is not None:
            try: os.killpg(active_pid, signal.SIGTERM)
            except ProcessLookupError: pass
            deadline = time.monotonic() + 3
            while time.monotonic() < deadline:
                try:
                    reaped, _ = os.waitpid(active_pid, os.WNOHANG)
                    if reaped: break
                except ChildProcessError: break
                time.sleep(0.02)
            else:
                try: os.killpg(active_pid, signal.SIGKILL)
                except ProcessLookupError: pass
                try: os.waitpid(active_pid, 0)
                except ChildProcessError: pass
        if active_fd is not None: os.close(active_fd)
        result["relay_exit_on_owned_cleanup"] = stop(proxy)
        result["server_exit_on_owned_cleanup"] = stop(server)
        if server_error: server_error.close()
        if proxy_error: proxy_error.close()
        if temporary: temporary.cleanup()
        result["owned_fixture_removed"] = temporary is None or not Path(temporary.name).exists()
        result["owned_processes_closed"] = all(p is None or p.poll() is not None for p in [server, proxy])
        result["finished_at"] = time.time()
        result["assertions_passed"] = sum(x["passed"] for x in result["assertions"])
        result["assertions_total"] = len(result["assertions"])
        emit(output / "result.json", result)
    print(json.dumps({"status": result["status"], "branches": result["branches"], "passed": result["assertions_passed"],
        "total": result["assertions_total"], "output": str(output), "owned_processes_closed": result["owned_processes_closed"],
        "owned_fixture_removed": result["owned_fixture_removed"]}), flush=True)
    if result["status"] != "passed": raise SystemExit(1)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--relay", action="store_true")
    parser.add_argument("--upstream-port", type=int); parser.add_argument("--relay-port", type=int)
    parser.add_argument("--trace"); parser.add_argument("--source"); parser.add_argument("--freeze")
    parser.add_argument("--freeze-sha256"); parser.add_argument("--head"); parser.add_argument("--output")
    args = parser.parse_args()
    relay(args) if args.relay else main(args)
