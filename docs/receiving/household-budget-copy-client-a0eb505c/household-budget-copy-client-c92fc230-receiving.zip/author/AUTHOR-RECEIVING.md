# Household Ledger budget-copy terminal client — owner receiving

This is an additive terminal client for the existing monthly-budget-copy tools. A household member can choose months/currency/categories, read every proposed limit and current destination, then explicitly confirm or cancel. The client connects to one existing local MCP HTTP service; it never opens a ledger or starts another writer.

## Exact source and ownership

- Frozen native source: `40f22d06ca2413e303f824a89c65f380266f4c01`.
- Source tree: `4e823d20d137d048cb7256edfc50f9b5878e2f62`.
- Sole native parent: accepted budget-copy `2b77b81ad59c5f3255aa25c37110e91d3bad6a01`, tree `940438aed7af43d841ff7700da8bd4f83a838afd`.
- Exactly six new paths; all 97 parent files stay byte-identical. Native source has 103 leaves.
- Source freeze: SHA-256 `f236c81ef9256b0215901e23e7b46ae5e2575eedc719125eaad028965206c9a8`.
- External contributor: `chatgpt-a0eb505c4971/integration_review`; native claim 4837.

ce7 retains source-parent disposition and estate-61749b0088e2 retains canonical receiving, including the reserved budget-plus-filter composition on PR8. This native snapshot ancestry is reproduction evidence. Receive the six-path patch through that existing owner source after the accepted budget-copy tools are present. Do not merge the artifact branch or native snapshot history wholesale into main.

The existing budget-copy module, server, Store, stdio, dependencies, package entry points, README and all prior assertions are unchanged. CSV import-client9, monthly-review10 and export7 retain their separate scopes. No canonical adoption, installed service, live ledger, provider/account action or deployment is claimed.

## Scope and behavior

`src/budget-copy-client.ts`, `src/household-budget-copy.ts`, two focused test modules, `docs/BUDGET_COPY_CLIENT.md` and `examples/budget-copy-request.json` are the complete source delta.

The CLI accepts an explicit loopback HTTP `/mcp` endpoint and original tool selectors. It validates complete preview counts/rows/destinations and the exact bound review/token before displaying every row. Values remain integer minor units with no currency conversion; control/bidirectional formatting characters are visibly JSON-escaped. A conflict cannot be confirmed.

The mutation flow requires terminal input/output and exactly `COPY <destination-month> <normalized-currency>`. Other answers, EOF or Ctrl-C at the prompt cancel. `--preview` is explicitly read-only and works noninteractively; `--help` is offline. No `--yes`, client-side writer, scheduler or retry is added.

One deliberate confirmation sends the original reviewed content/token once. The unchanged server rechecks current values inside its serialized writer. The client validates the complete success receipt. After a lost response, server error or malformed commit receipt it states that the outcome is unconfirmed and makes no automatic retry or automatic new preview. The inherited lack of durable plan-history receipts remains explicit.

## Author qualification, preserved as executed

Node22.22.1, the existing TypeScript5.9.3, SDK1.32.1 and Node declarations24.19.1 were used on the ThinkPad. Dependencies were reused, not installed or copied.

The unchanged parent compiles and the requested CLI is absent: actual direct invocation exits1 with MODULE_NOT_FOUND. The first candidate strict compile found a validated-row TypeScript inference issue; both identical compile diagnostics are preserved. An explicit returned row shape corrected the new client only. The final build exits0.

Exactly 13 focused cases pass, with no failures, skips or cancellations. They include:
- Complete literal review before one exact commit; cancellation, EOF, wrong confirmation and preview/conflict no-commit controls.
- Malformed/changed selection, counts, token, review, destination and receipt refusal; visible terminal control representation; truthful pre/post-commit output failure handling.
- Actual CLI offline help and non-TTY admission.
- The unchanged native server, maintained SDK and fictional private ledgers: preview/cancel, exact copy, matching no-write repeat, stale source/destination, unrelated ordinary writes and actual CLI preview.
- One private loopback relay drops a response only after the real unchanged server completes the commit. The client reports uncertainty; exactly one commit is observed; a later explicitly requested read-only preview sees matching saved targets without another commit.

The final log SHA-256 is `2d955049c8ef7de4f0aee3b374f8896b0a9393397c34fa7f8f9ddbfd68f15da8`. All 78 compiled execution files are pinned in the freeze. The original 118 domain tests were not rerun or relabeled.

The source status is clean for tracked files and honestly includes one untracked `node_modules` dependency symlink. No ignore-rule change conceals it.

## Patch receiving and remaining review

The format-patch SHA-256 is `712f5b2788943753ee10d060c310129ce455417e34b52bca446346d88430257c`; it contains six additions only. Applying it to a private Git index at exact2b77 reproduces tree4e823d20 exactly. The incremental bundle is16,264bytes, SHA-256 `cc30e45e968e4df02b26ab57ad3e123cc6c082d35e298cda5c6ce0f7c5a83192`, and requires the original parent. Receiving receipt SHA-256 `8e2ff1e392bdf93a107feefbfd391fd6b82916e1585cc2d97827da347215d2fe`.

At this author-packet preparation point, independent actual PTY receiving and root source review are pending. Their later exact receipts must be added separately before final qualification/publication; this statement is not a prospective pass. GitHub mutation ownership is held by root. No source or owner branch was published by this step.
