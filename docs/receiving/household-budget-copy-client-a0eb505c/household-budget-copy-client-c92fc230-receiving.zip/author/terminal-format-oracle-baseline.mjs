import assert from "node:assert/strict";
import { terminalValue } from "/srv/hamon-estate/household-budget-copy-client-a0eb505c/dist/src/budget-copy-client.js";
const input = "category\u061c\u200d\u{e0001}\u202e\n🧭";
const rendered = terminalValue(input);
assert.equal(JSON.parse(rendered), input, "visible representation must roundtrip exact identity");
assert.equal(/[\p{Cc}\p{Cf}\u2028\u2029]/u.test(rendered), false, "no raw control or formatting codepoint may reach terminal output");
console.log(JSON.stringify({ checks: 2, passed: 2, rendered }));
