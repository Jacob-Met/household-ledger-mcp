import assert from "node:assert/strict";
import { test } from "node:test";
import { promises as fs } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve, sep } from "node:path";
import { pathToFileURL } from "node:url";
import { createHash } from "node:crypto";
import net from "node:net";
import ts from "/Users/me/Developer/household-budget-copy-20261008-a0eb/node_modules/typescript/lib/typescript.js";

const sourceRoot = "/Users/me/Developer/household-budget-copy-20261008-a0eb";
const reviewRoot = "/Users/me/Developer/household-budget-copy-independent-20261008-a0eb";
const digest = data => createHash("sha256").update(data).digest("hex");
const sourcePins = {
  "src/budget-copy.ts": "772d8086f9e336d995ad2496c5cbaf27fd13a874fc8b11c057494e7dd3b6b5f7",
  "src/ledger.ts": "743eb94413383d8872b2eb4670d2813c2924d78cf9ae0d2b479432f9e8ae8c07",
};
for (const [path, expected] of Object.entries(sourcePins)) {
  assert.equal(digest(await fs.readFile(join(sourceRoot, path))), expected);
}
const configText = await fs.readFile(join(sourceRoot, "tsconfig.json"), "utf8");
const config = JSON.parse(configText);
assert.equal(config.extends, undefined);
const converted = ts.convertCompilerOptionsFromJson(config.compilerOptions, sourceRoot);
assert.equal(converted.errors.length, 0);
const emitted = new Map();
const host = ts.createCompilerHost(converted.options);
host.writeFile = (name, text) => emitted.set(resolve(name), Buffer.from(text));
const program = ts.createProgram(Object.keys(sourcePins).map(path => join(sourceRoot, path)), converted.options, host);
const emission = program.emit();
assert.equal(emission.emitSkipped, false);
assert.equal(emission.diagnostics.length, 0);
const compiledBindings = {};
for (const path of ["dist/src/ledger.js", "dist/src/budget-copy.js"]) {
  const actual = await fs.readFile(join(sourceRoot, path));
  const expected = emitted.get(resolve(sourceRoot, path));
  assert.ok(expected, "in-memory compiler emitted " + path);
  assert.deepEqual(actual, expected, "existing compiled module exactly matches frozen source emission");
  compiledBindings[path] = digest(actual);
}
const { LedgerStore, emptyLedger, setBudget, recordTransaction } = await import(pathToFileURL(join(sourceRoot, "dist/src/ledger.js")).href);
const { previewBudgetCopy, commitBudgetCopy } = await import(pathToFileURL(join(sourceRoot, "dist/src/budget-copy.js")).href);

test("successful budget-copy review still checks source drift and preserves current-value replay boundaries", async () => {
  const dir = await fs.mkdtemp(join(tmpdir(), "hlm-budget-independent-a0eb-"));
  const path = join(dir, "ledger.json");
  const original = new Map();
  const operations = {};
  let writeAttempts = 0;
  let networkAttempts = 0;
  const oldConnect = net.Socket.prototype.connect;
  const oldFetch = globalThis.fetch;
  const phases = [];
  function inside(value) {
    const actual = resolve(typeof value === "string" ? value : value.pathname);
    assert.ok(actual === dir || actual.startsWith(dir + sep), "fixture operation escaped its temporary directory");
  }
  for (const name of ["readFile", "writeFile", "open", "rename", "mkdir", "rm", "stat"]) {
    const old = fs[name]; original.set(name, old);
    fs[name] = async (...args) => {
      inside(args[0]);
      if (name === "rename") inside(args[1]);
      operations[name] = (operations[name] ?? 0) + 1;
      if (["writeFile", "open", "rename", "mkdir", "rm"].includes(name)) writeAttempts++;
      return old(...args);
    };
  }
  net.Socket.prototype.connect = function () { networkAttempts++; throw new Error("network forbidden in private Store probe"); };
  globalThis.fetch = async () => { networkAttempts++; throw new Error("fetch forbidden in private Store probe"); };
  const snapshot = async () => {
    const bytes = await fs.readFile(path);
    const metadata = await fs.stat(path, { bigint: true });
    return { bytes, mtimeNs: metadata.mtimeNs, inode: metadata.ino };
  };
  let completed;
  try {
    const store = new LedgerStore(path);
    await store.save(emptyLedger());
    await store.update(data => {
      setBudget(data, "first", "2026-10", 100, "USD");
      setBudget(data, "second", "2026-10", 0, "USD");
    });
    const preview = await previewBudgetCopy(store, { fromMonth: "2026-10", toMonth: "2026-11", currency: "USD" });
    assert.ok(preview.canCommit);
    assert.deepEqual(preview.review.rows.map(row => row.expectedTargetLimitMinor), [null, null]);
    const args = { review: preview.review, reviewToken: preview.reviewToken };
    assert.equal((await commitBudgetCopy(store, args)).added, 2);
    phases.push({ phase: "first_copy", added: 2 });

    const transaction = await store.update(data => {
      setBudget(data, "first", "2026-11", 777, "EUR");
      setBudget(data, "second", "2026-10", 500, "USD");
      return recordTransaction(data, { type: "income", amountMinor: 19, currency: "USD", date: "2026-11-03", category: "fictional later record", idempotencyKey: "independent:later-record" });
    });
    const afterDrift = await snapshot();
    const writesBeforeDrift = writeAttempts;
    await assert.rejects(() => commitBudgetCopy(new LedgerStore(path), JSON.parse(JSON.stringify(args))), /source limit changed/);
    assert.deepEqual(await snapshot(), afterDrift);
    assert.equal(writeAttempts, writesBeforeDrift);
    assert.deepEqual((await store.load()).transactions, [transaction]);
    phases.push({ phase: "changed_source_despite_matching_targets", refused: true, write_attempts: 0, file_bytes_metadata_unchanged: true });

    await store.update(data => { data.budgets = data.budgets.filter(b => !(b.category === "second" && b.month === "2026-10" && b.currency === "USD")); });
    const afterRemoval = await snapshot();
    const writesBeforeRemoval = writeAttempts;
    await assert.rejects(() => commitBudgetCopy(new LedgerStore(path), args), /must have exactly one explicitly denominated USD budget/);
    assert.deepEqual(await snapshot(), afterRemoval);
    assert.equal(writeAttempts, writesBeforeRemoval);
    assert.deepEqual((await store.load()).transactions, [transaction]);
    phases.push({ phase: "removed_source_despite_matching_targets", refused: true, write_attempts: 0, file_bytes_metadata_unchanged: true });

    await store.update(data => {
      setBudget(data, "second", "2026-10", 0, "USD");
      data.budgets = data.budgets.filter(b => !(b.category === "first" && b.month === "2026-11" && b.currency === "USD"));
    });
    const recreated = await commitBudgetCopy(new LedgerStore(path), args);
    assert.equal(recreated.added, 1);
    assert.equal(recreated.alreadyPresent, 1);
    assert.deepEqual(recreated.budgets.map(b => [b.category, b.limitMinor]), [["first", 100], ["second", 0]]);
    phases.push({ phase: "originally_absent_target_now_absent_again", added: 1, already_present: 1, meaning: "current-value contract, not a durable plan-history receipt" });

    const beforeReplay = await snapshot();
    const writesBeforeReplay = writeAttempts;
    const replay = await commitBudgetCopy(new LedgerStore(path), args);
    assert.equal(replay.added, 0);
    assert.equal(replay.alreadyPresent, 2);
    assert.deepEqual(await snapshot(), beforeReplay);
    assert.equal(writeAttempts, writesBeforeReplay);
    const finalData = await store.load();
    assert.deepEqual(finalData.transactions, [transaction]);
    assert.equal(finalData.budgets.find(b => b.category === "first" && b.month === "2026-11" && b.currency === "EUR").limitMinor, 777);
    assert.equal(networkAttempts, 0);
    phases.push({ phase: "matching_current_replay", added: 0, write_attempts: 0, file_bytes_metadata_unchanged: true, unrelated_record_and_currency_preserved: true });
    completed = {
      schema: "household.budget-copy-independent-replay.v1",
      source_head: "2b77b81ad59c5f3255aa25c37110e91d3bad6a01",
      source_pins: sourcePins, compiled_bindings: compiledBindings,
      compiled_files_exact_in_memory_emit: true,
      schema_or_production_writes: false,
      native_node: process.version, typescript: ts.version,
      phases, filesystem_operations: operations, network_attempts: networkAttempts,
      fixture_only_file_operations: true,
      final_file_sha256: digest(beforeReplay.bytes),
      limits: ["One private real-Store probe with a fictional ledger; no HTTP handler, provider, deployed service or real account is exercised.", "The test deliberately confirms that a review first observing an absent target can add it again when currently absent. It does not establish historical exactly-once execution."],
    };
  } finally {
    for (const [name, old] of original) fs[name] = old;
    net.Socket.prototype.connect = oldConnect;
    globalThis.fetch = oldFetch;
    await fs.rm(dir, { recursive: true, force: true });
  }
  await fs.writeFile(join(reviewRoot, "probe-result.json"), JSON.stringify(completed, null, 2) + "\n");
});
