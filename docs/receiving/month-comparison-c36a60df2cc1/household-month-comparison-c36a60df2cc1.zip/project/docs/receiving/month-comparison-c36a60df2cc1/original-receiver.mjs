import assert from "node:assert/strict";
import { readFile, writeFile, mkdir, stat } from "node:fs/promises";
import { existsSync } from "node:fs";
import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { dirname, resolve, join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const subject = resolve(process.argv[2]);
const output = resolve(process.argv[3]);
await mkdir(output);
const source = JSON.parse(await readFile(join(here, "original-consumer.json"), "utf8"));
const ledgerBytes = Buffer.from(JSON.stringify(source.fixture, null, 2) + "\n");
const ledgerPath = join(output, "fictional-ledger.json");
const htmlPath = join(output, "comparison.html");
await writeFile(ledgerPath, ledgerBytes, { flag: "wx" });
const before = await stat(ledgerPath, { bigint: true });
const checks = [];
const check = async (name, fn) => {
  try { await fn(); checks.push({ name, passed: true }); }
  catch (error) { checks.push({ name, passed: false, error: String(error) }); }
};
const producer = await import(pathToFileURL(join(subject, "dist/src/ledger.js")).href);
await check("unchanged_native_monthly_summary_control", () => {
  const data = producer.validateLedgerData(source.fixture);
  for (const [key, month] of [["first", 8], ["second", 9]]) {
    const actual = producer.monthlySummary(data, 2026, month, "USD");
    for (const name of ["incomeMinor", "expenseMinor", "netMinor"]) {
      assert.equal(actual[name], source.expected[key][name]);
    }
  }
});
const args = [
  join(subject, "dist/src/household-compare.js"),
  "--ledger", ledgerPath, "--first", source.options.firstMonth,
  "--second", source.options.secondMonth, "--currency", source.options.currency,
  "--out", htmlPath,
];
const cli = spawnSync(process.execPath, args, { cwd: subject, encoding: "utf8", timeout: 30000 });
await writeFile(join(output, "cli.stdout.log"), cli.stdout || "", { flag: "wx" });
await writeFile(join(output, "cli.stderr.log"), cli.stderr || "", { flag: "wx" });
let report = null;
await check("actual_comparison_cli_receives_exact_category_budget_pair", async () => {
  assert.equal(cli.status, 0, cli.stderr || String(cli.error || "CLI failed"));
  const html = await readFile(htmlPath, "utf8");
  const match = html.match(/<script id="household-month-comparison-data" type="application\/json">([\s\S]*?)<\/script>/);
  assert.ok(match, "retained comparison data is present");
  report = JSON.parse(match[1]);
  assert.equal(report.schema, "household-ledger-month-comparison/1");
  assert.equal(report.firstMonth, source.options.firstMonth);
  assert.equal(report.secondMonth, source.options.secondMonth);
  assert.equal(report.currency, "USD");
  assert.equal(report.direction, "second-minus-first");
  assert.deepEqual(report.totals.first, source.expected.first);
  assert.deepEqual(report.totals.second, source.expected.second);
  assert.deepEqual(report.totals.change, source.expected.delta);
  assert.deepEqual(report.categories.map(row => row.category), source.expected.categories);
  const food = report.categories.find(row => row.category === "Food");
  assert.equal(food.second.budget.limitMinor, 0);
  assert.equal(food.change.budgetLimitMinor, "-25000");
  assert.equal(food.change.budgetRemainingMinor, "-20000");
  const removed = report.categories.find(row => row.category === "RemovedBudget");
  assert.equal(removed.second.budget, null);
  assert.equal(removed.change.budgetLimitMinor, null);
  assert.equal(report.source.bytes, ledgerBytes.length);
  assert.equal(report.source.sha256, createHash("sha256").update(ledgerBytes).digest("hex"));
});
await check("saved_input_bytes_inode_mtime_and_ctime_preserved", async () => {
  const after = await stat(ledgerPath, { bigint: true });
  assert.deepEqual(await readFile(ledgerPath), ledgerBytes);
  for (const key of ["dev", "ino", "size", "mtimeNs", "ctimeNs"]) {
    assert.equal(after[key], before[key], key);
  }
});
const receipt = {
  subject, output, command: [process.execPath, ...args],
  node: process.version, cliStatus: cli.status,
  checks, passed: checks.filter(x => x.passed).length,
  failed: checks.filter(x => !x.passed).length,
  reportCreated: existsSync(htmlPath), report,
};
await writeFile(join(output, "receipt.json"), JSON.stringify(receipt, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify({ passed: receipt.passed, failed: receipt.failed, cliStatus: cli.status, receipt: join(output, "receipt.json") }));
process.exitCode = receipt.failed ? 1 : 0;
