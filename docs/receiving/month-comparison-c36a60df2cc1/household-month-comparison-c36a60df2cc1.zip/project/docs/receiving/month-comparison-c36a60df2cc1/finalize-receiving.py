#!/usr/bin/env python3
"""Bind the accepted peer receipts and complete the derived owner guide."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json

HERE = Path(__file__).resolve().parent
def sha(data):
    return hashlib.sha256(data).hexdigest()
def encoded(value):
    return (json.dumps(value, indent=2) + "\n").encode()
def read_json(rel, expected=None):
    data = (HERE / rel).read_bytes()
    if expected:
        assert sha(data) == expected, rel
    return json.loads(data)
def pin(rel):
    data = (HERE / rel).read_bytes()
    return {"path": rel, "bytes": len(data), "sha256": sha(data)}

consumer = read_json("independent/consumer/receiver-summary.json",
    "0d4d4270e46fa4679279b0ef95b6801c3c41d9b91159689fc579b37435fe1f75")
visual = read_json("independent/visual/final-review.json",
    "42cdc4ad7f42b610c66dcfbb16f81286acab46f26542c2a11530dd00e495e892")
cc = read_json("independent/consumer-receiving.json")
vc = read_json("independent/visual-receiving.json")
tree = read_json("source-tree-receipt.json",
    "12434683b853efe41f90ab43b629e3f2d0a10e13f62dcedc8dff1be7902b9153")
assert cc["received_files"] == 109 and cc["received_bytes"] == 328155
assert vc["received_files"] == 76 and vc["received_bytes"] == 1664403
assert consumer["domain"]["passes"] == 11 and consumer["cli"]["passes"] == 15
assert visual["status"] == "ACCEPTED_WITH_NONBLOCKING_PRESENTATION_NOTES"
assert visual["browser"]["groups_passed"] == 7 and visual["browser"]["assertions_passed"] == 55
assert visual["pdf"]["text_custody_checks_passed"] == 12
assert visual["final_source"]["author_commit"] == "571ac097c34c1c041ac298ad7d20e60379980db4"
assert visual["final_source"]["compiled_cli_sha256"] == "40828c23fdc295d21ff4ec16500e93cade1d527268aa316b5a17e1d33dfdcb9c"
assert sha((HERE / "independent/visual" / visual["browser"]["receipt"]).read_bytes()) == visual["browser"]["receipt_sha256"]
assert sha((HERE / "independent/visual" / visual["pdf"]["path"]).read_bytes()) == visual["pdf"]["sha256"]
assert tree["parent_leaves_preserved"] == 116 and tree["after_leaves"] == 122

original = (HERE / "owner-guide/original/RECEIVING.md").read_text()
assert sha(original.encode()) == "61116f0028335cc4b718bdf428bf26eb4073f14cb3e2f1070d3ef32d143bc200"
old = [line for line in original.splitlines() if line.startswith("**Browser receiving is pending")]
assert len(old) == 1
browser_paragraph = (
    "Actual LA7 Chrome 154.0.8037.98 opened the exact final-CLI HTML through file: URLs: "
    "**7 groups / 55 assertions passed**, including literal values, keyboard scrolling at 390px, accessibility structure, "
    "legacy/zero budgets and the JavaScript-disabled empty report. All seven screenshots and both tagged PDF pages were "
    "visually inspected; **12 PDF text/custody checks passed**. Browser receipt SHA256 "
    "\u0060375f92453587edc3966ab1870e3b87dd5c45fdc58e7bd7c7a8e7f54155253ad8\u0060; final inspection record "
    "\u006042cdc4ad7f42b610c66dcfbb16f81286acab46f26542c2a11530dd00e495e892\u0060. "
    "A4 headers sometimes wrap within words and a single-category caption says '1 categories'; labels and values remain "
    "readable. Earlier ThinkPad readiness/startup failures remain retained, with no passing HTTP-delivery claim."
)
guide = original.replace(old[0], browser_paragraph)
assert len(guide.split()) <= 700
guide_path = HERE / "owner-guide/RECEIVING.md"
with guide_path.open("x", encoding="utf-8") as f:
    f.write(guide)
guide_update = {
    "schema": "household.owner_guide_final_browser_addendum.v1",
    "recorded_at": datetime.now(timezone.utc).isoformat(),
    "original": pin("owner-guide/original/RECEIVING.md"),
    "derived": pin("owner-guide/RECEIVING.md"),
    "only_change": "Replace the one explicitly pending browser paragraph with the accepted exact source-bound browser/PDF outcome and presentation limits.",
    "final_visual_review": pin("independent/visual/final-review.json"),
    "word_count_whitespace": len(guide.split()),
    "original_preserved": True
}
(HERE / "owner-guide/final-update.json").write_bytes(encoded(guide_update))

receiving_path = HERE / "RECEIVING.md"
text = receiving_path.read_text()
marker = "## Independent receiving and final custody\n\n"
assert text.count(marker) == 1
summary = """The independent command-line consumer packet is preserved unchanged under `independent/consumer/`: Git `65e1431e8d4882119f4b6a37a348ff9130c176ea`, 109 files and 328,155 bytes. Its manifest is SHA256 `756dfdd7b78b4f17351b1c4dd6504d4c279cc39df99e260b12a11163caddc7bf`. The receiver froze nine fixtures before candidate inspection and passed 11/11 pure comparison cases and 15/15 actual final CLI cases. These include exact odd wide deltas in both month orders, whole-snapshot and legacy admission, complete raw category identity, absent versus zero, unchanged input, private output, and independently spawned competing output processes. Source and destination bytes, every manifest hash and each original Git blob were checked during custody; tests were not rerun.

The independent visual packet is preserved unchanged under `independent/visual/`: Git `b45eb8d8b7107951e7283f38538c1b9668cf950d`, 76 files and 1,664,403 bytes including its manifest, SHA256 `dafbf4e56aa473741c1ee2efbdca3b9d3223523e900702fdad3650a2bf69cc0d`. Actual LA7 Chrome 154.0.8037.98 opened the exact final-produced saved HTML directly through file: URLs. Seven groups and 55 assertions passed: visible amounts and raw labels, 390px containment with real keyboard table scrolling, accessibility structure, contextual legacy/zero budgets, print generation, JavaScript-disabled empty report, page request/error and custody checks. All seven screenshots and both pages of the actual tagged PDF were visually inspected; 12 additional PDF text/custody checks passed. Final acceptance SHA256 `42cdc4ad7f42b610c66dcfbb16f81286acab46f26542c2a11530dd00e495e892` closes the separately retained automated receipts' historical pending-manual statuses.

Two presentation notes remain: A4 category headers can wrap within words, and a single-category caption says '1 categories'. Labels and values were present and readable; no source change was requested. The original ThinkPad file route had six readiness failures before product assertions, with no specific navigation cause established. Its proposed loopback attempt then failed browser debugger startup before HTTP receiving. These failures remain evidence and are not relabeled as passing. The final accepted route is actual saved-file Chrome receiving on LA7. It does not establish physical-device, screen-reader, or comprehensive accessibility conformance; page-level no-request observations do not assert that every browser process was network silent.

`independent/consumer-receiving.json` and `independent/visual-receiving.json` retain exact local custody records. `source-tree-receipt.json`, copied byte-identically from the coordinating receiver, records the complete remote content calculation: the 116 accepted PR8 parent leaves remain unchanged and exactly six additions produce tree `2cd593819c919a01e7dd01a4e998eb101abfc0b5`. No source branch, owner branch or canonical main changed during that calculation.

The concise `owner-guide/RECEIVING.md` is a derived final guide. Its independent original remains unchanged under `owner-guide/original/`, with the browser-only replacement pinned in `owner-guide/final-update.json`. `final-receiving.json` binds all source, runtime, outcome and custody pins. The native reproduction bundle retains this private projection's history; it must not be treated as canonical ancestry. The sealed archive excludes dependencies, caches and temporary profiles and retains the independent packets as their literal manifest-selected files.

This contribution is accepted for the established owner's source receiving. Installation, complete inherited-service and Node20 hosted qualification, owner composition and canonical adoption remain outside these receipts.
"""
receiving_path.write_text(text.split(marker)[0] + marker + summary)

published_path = HERE / "source-publication.json"
published = json.loads(published_path.read_bytes())
receivers = {
    "status": "ACCEPTED_FOR_OWNER_RECEIVING",
    "consumer": {
        "commit": cc["source_commit"], "fixture_commit": cc["fixture_commit"],
        "files": cc["received_files"], "bytes": cc["received_bytes"],
        "manifest": pin("independent/consumer/file-manifest.json"),
        "summary": pin("independent/consumer/receiver-summary.json"),
        "custody": pin("independent/consumer-receiving.json"),
        "domain_cases_passed": 11, "actual_cli_cases_passed": 15
    },
    "visual": {
        "commit": vc["source_commit"], "fixture_commit": vc["fixture_commit"],
        "files": vc["received_files"], "bytes": vc["received_bytes"],
        "manifest": pin("independent/visual/manifest.json"),
        "summary": pin("independent/visual/final-review.json"),
        "custody": pin("independent/visual-receiving.json"),
        "actual_browser_groups_passed": 7, "actual_browser_assertions_passed": 55,
        "pdf_text_custody_checks_passed": 12,
        "presentation_notes": visual["nonblocking_notes"]
    }
}
published["independent_receiving"] = receivers
published["canonical_content_receiving"] = pin("source-tree-receipt.json")
published_path.write_bytes(encoded(published))
final = {
    "schema": "household.two_month_final_native_receiving.v1",
    "recorded_at": datetime.now(timezone.utc).isoformat(),
    "disposition": "ACCEPT_FOR_OWNER_RECEIVING_NOT_INSTALLED",
    "repository": published["repository_full_name"],
    "native_source_commit": published["native_source_commit"],
    "required_owner_parent": published["required_owner_receiving_ref"],
    "canonical_artifact_parent": published["canonical_artifact_parent"],
    "owner_route": published["owner_route"],
    "integration_owners": published["integration_owners"],
    "source_files": [{k: v for k, v in f.items() if k != "content"} for f in published["source_files"]],
    "source_patch": pin("source-only.patch"),
    "source_publication": pin("source-publication.json"),
    "canonical_content_receiving": pin("source-tree-receipt.json"),
    "runtime": {"node": "22.22.1", "typescript": "5.9.3", "node_types": "24.19.1",
                "lifecycle_scripts_disabled": True, "locked_private_install": True},
    "author_receiving": {
        "original_frozen_consumer": {"passed": 2, "failed": 1, "expected_failure": "New CLI absent"},
        "r1": {"strict_compile_exit": 0, "tests_passed": 21, "tests_skipped": 0,
               "domain_render_passed": 14, "cli_passed": 7},
        "publication_negative": {"exit": 1, "actual_prefix_written_bytes": 19, "partial_final_exists": True},
        "r2": {"strict_compile_exit": 0, "targeted_cli_passed": 8, "targeted_cli_skipped": 0,
               "same_fault_partial_final_exists": False, "frozen_consumer_passed": 3,
               "pure_source_and_compiled_unchanged": True, "pure_tests_not_repeated": True},
        "pins": [pin(r) for r in ["original/receipt.json", "author-r1/receipt.json",
            "publication-original/fault-observation.json", "author-r2/receipt.json",
            "author-r2/fault-observation.json", "author-r2/consumer/receipt.json",
            "compiled-r2/manifest.json"]]
    },
    "independent_receiving": receivers,
    "owner_guide": pin("owner-guide/RECEIVING.md"),
    "all_independent_raw_evidence_included": True,
    "test_or_browser_reruns_during_custody": False,
    "limits": [
        "The source is six additions over the stated complete owner parent, received locally through a six-file dependency projection.",
        "No full inherited service suite or Node20 hosted-gate claim.",
        "Native generated HTML received directly in LA7 Chrome; product logic was not substituted on LA7.",
        "Exact archived failed routes and original partial-output failure remain unchanged.",
        "No live ledger, account/provider call, production import, source replacement, serving takeover, restart or installation.",
        "Owner integration must preserve established source receiving and requalify relevant dependency drift."
    ]
}
(HERE / "final-receiving.json").write_bytes(encoded(final))
sealer = HERE / "seal-native-package.py"
s = sealer.read_text()
s = s.replace("Independent visual archives, if listed as external in final-receiving.json, remain separately pinned owner custody.",
              "Independent consumer and visual evidence are included unchanged as manifest-selected raw files; no nested peer archives.")
sealer.write_text(s)
print(json.dumps({"final_receiving": pin("final-receiving.json"),
                  "publication": pin("source-publication.json"),
                  "owner_guide": pin("owner-guide/RECEIVING.md"),
                  "guide_words": len(guide.split()),
                  "visual_custody": pin("independent/visual-receiving.json")}, indent=2))
