import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import {execFileSync} from "node:child_process";
const root=path.dirname(new URL(import.meta.url).pathname),parent=path.dirname(root);
const hash=b=>crypto.createHash("sha256").update(b).digest("hex");
const git=(...a)=>execFileSync("git",["-C",root,...a],{encoding:"utf8"}).trim();
const initial="7fb753c10a2e87f87772e787a19d5d49da2609e7";
if(git("rev-parse","HEAD")!==initial)throw Error("Unexpected receiver parent");
const author="/tmp/c36a60df2cc1-household-compare/worktree",commit="571ac097c34c1c041ac298ad7d20e60379980db4";
const source=[];
for(const [name,expected] of [["src/month-comparison.ts","4b6a3afae5fc571145302da6de0aedb5f68c9ee7cf9bab1ef23f8692aa9c211b"],["src/household-compare.ts","84a7266119430953394833d9f428684fb7e4db5405313fdadc7efaf90b1f4680"]]){
 const b=execFileSync("git",["-C",author,"show",commit+":"+name]);if(hash(b)!==expected)throw Error("Author source mismatch "+name);source.push({path:name,bytes:b.length,sha256:hash(b)});
}
const intake=JSON.parse(fs.readFileSync(path.join(root,"candidate-r2-intake.json"),"utf8"));
const compiled=[];
for(const x of intake.files){
 const b=fs.readFileSync(path.join(root,"candidate-r2",x.path));if(hash(b)!==x.sha256||b.length!==x.bytes)throw Error("Compiled intake drift "+x.path);compiled.push({path:"candidate-r2/"+x.path,bytes:b.length,sha256:hash(b)});
}
const admission={observed:new Date().toISOString(),author_source_commit:commit,author_git_object_source:source,received_compiled_files:compiled,no_rebuild_or_suite_rerun:true};
fs.writeFileSync(path.join(root,"source-admission.json"),JSON.stringify(admission,null,2)+"\n",{flag:"wx"});
const ignored=name=>name===".git"||name==="manifest.json"||/^la7-artifacts-\d+\.json$/.test(name)||name==="la7-transfer.json";
const members=[];
function walk(rel=""){
 for(const name of fs.readdirSync(path.join(root,rel)).sort()){
  if(!rel&&ignored(name))continue;
  const item=path.posix.join(rel,name),target=path.join(root,item),st=fs.lstatSync(target);
  if(st.isSymbolicLink())throw Error("Unexpected symlink "+item);
  if(st.isDirectory())walk(item);else if(st.isFile()){const b=fs.readFileSync(target);members.push({path:item,bytes:b.length,sha256:hash(b)});}
 }
}
walk();
const manifest={schema:"household.month-comparison.visual-evidence-manifest.v1",owner:"c36a60df2cc1-coordination",created_at:new Date().toISOString(),frozen_oracle_parent:initial,source_commit:commit,status:"ACCEPTED_WITH_NONBLOCKING_PRESENTATION_NOTES",members,member_count:members.length,total_bytes:members.reduce((n,x)=>n+x.bytes,0),excluded:[".git","manifest.json (self)","la7-artifacts-*.json (duplicate transfer bundles)","la7-transfer.json (duplicate transfer bundle)"]};
const manifestBytes=Buffer.from(JSON.stringify(manifest,null,2)+"\n");fs.writeFileSync(path.join(root,"manifest.json"),manifestBytes,{flag:"wx"});
git("add","--",...members.map(x=>x.path),"manifest.json");
git("commit","-m","Qualify month-comparison browser and printed report outputs");
const status=git("status","--short");if(status)throw Error("Unexpected uncommitted files: "+status);
const result={schema:1,sealed_at:new Date().toISOString(),root,git_commit:git("rev-parse","HEAD"),git_tree:git("rev-parse","HEAD^{tree}"),git_status:status,source_commit:commit,manifest:{path:path.join(root,"manifest.json"),bytes:manifestBytes.length,sha256:hash(manifestBytes),member_count:members.length,total_bytes:manifest.total_bytes},final_review:members.find(x=>x.path==="final-review.json"),browser_receipt:members.find(x=>x.path==="la7/la7-r1/receipt.json"),pdf_receipt:members.find(x=>x.path==="la7/pdf-review/receipt.json"),source_admission:members.find(x=>x.path==="source-admission.json"),no_nested_zip:"Native source owner will receive raw manifest-selected members and bind them in its final archive."};
fs.writeFileSync(path.join(parent,"seal-receipt.json"),JSON.stringify(result,null,2)+"\n",{flag:"wx"});
console.log(JSON.stringify(result));
