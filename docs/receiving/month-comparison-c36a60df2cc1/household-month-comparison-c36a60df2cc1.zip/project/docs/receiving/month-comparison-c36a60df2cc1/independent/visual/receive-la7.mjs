import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import {execFileSync} from "node:child_process";
const root=path.dirname(new URL(import.meta.url).pathname);
const out=path.join(root,"la7");
const sha=b=>crypto.createHash("sha256").update(b).digest("hex");
const received=[];
for(let n=0;n<5;n++){
 const bundle=JSON.parse(fs.readFileSync(path.join(root,"la7-artifacts-"+String(n).padStart(2,"0")+".json"),"utf8"));
 for(const entry of bundle.entries){
  if(entry.path.startsWith("/")||entry.path.split("/").includes(".."))throw Error("Unsafe member");
  const bytes=Buffer.from(entry.base64,"base64");if(bytes.length!==entry.bytes||sha(bytes)!==entry.sha256)throw Error("Identity mismatch "+entry.path);
  const target=path.join(out,entry.path);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,bytes,{flag:"wx"});received.push({path:"la7/"+entry.path,bytes:bytes.length,sha256:sha(bytes)});
 }
}
const pdf=path.join(out,"la7-r1","primary.pdf"),review=path.join(out,"pdf-review");
fs.mkdirSync(review);
const before=sha(fs.readFileSync(pdf));
const info=execFileSync("/usr/bin/pdfinfo",[pdf],{encoding:"utf8"});
fs.writeFileSync(path.join(review,"pdfinfo.txt"),info);
execFileSync("/usr/bin/pdftotext",["-layout",pdf,path.join(review,"primary.txt")]);
execFileSync("/usr/bin/pdftoppm",["-r","120","-png",pdf,path.join(review,"primary-page")],{timeout:30000,stdio:"pipe"});
const text=fs.readFileSync(path.join(review,"primary.txt"),"utf8"),compact=text.replace(/\s+/g," ");
const checks=[
 ["two pages",/^Pages:\s+2$/m.test(info)],
 ["tagged PDF",/^Tagged:\s+yes$/m.test(info)],
 ["full source hash",compact.includes("0c7010a4a3e0ef1986eaaad77296cf76b924191c531f68d5c67e2d09bbb5ddb1")],
 ["two explicit months",compact.includes("2026-09")&&compact.includes("2026-10")],
 ["totals income",/Income 300000 310100 \+10100/.test(compact)],
 ["totals expense",/Expense 101725 107250 \+5525/.test(compact)],
 ["totals net",/Net cash flow 198275 202850 \+4575/.test(compact)],
 ["category union",["Shared","Groceries","October only","Rent","Salary","Zero only","__proto__","constructor"].every(x=>compact.includes(x))],
 ["budget absent and zero wording",compact.includes("Absent")&&compact.includes("present zero limit")&&compact.includes("Not comparable")],
 ["legacy not invented for v2",!compact.includes("Legacy budget")],
 ["footer survives",compact.includes("It can be opened")&&compact.includes("or printed offline.")],
 ["PDF source unchanged",before===sha(fs.readFileSync(pdf))]
];
const artifacts=fs.readdirSync(review).map(name=>{const b=fs.readFileSync(path.join(review,name));return {path:"la7/pdf-review/"+name,bytes:b.length,sha256:sha(b)}});
const receipt={schema:1,observed:new Date().toISOString(),status:checks.every(x=>x[1])?"PASS_PENDING_PAGE_VISUAL_INSPECTION":"FAIL",source:{path:"la7/la7-r1/primary.pdf",bytes:fs.statSync(pdf).size,sha256:before},tool_commands:[["/usr/bin/pdfinfo",pdf],["/usr/bin/pdftotext","-layout",pdf,path.join(review,"primary.txt")],["/usr/bin/pdftoppm","-r","120","-png",pdf,path.join(review,"primary-page")]],checks:checks.map(([name,pass])=>({name,pass})),artifacts};
fs.writeFileSync(path.join(review,"receipt.json"),JSON.stringify(receipt,null,2)+"\n");
fs.writeFileSync(path.join(root,"la7-native-intake.json"),JSON.stringify({received,receipt},null,2)+"\n");
console.log(JSON.stringify({received:received.length,status:receipt.status,checks:receipt.checks,artifacts}));
