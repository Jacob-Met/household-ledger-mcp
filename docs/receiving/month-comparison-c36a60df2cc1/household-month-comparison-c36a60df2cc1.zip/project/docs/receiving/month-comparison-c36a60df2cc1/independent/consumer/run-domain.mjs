import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {fileURLToPath} from 'node:url';
import {expected,sha,refusalPatterns,assertComparison} from './assert-comparison.mjs';
import {compareLedgerSnapshot} from './candidate/src/month-comparison.js';
const root=path.dirname(fileURLToPath(import.meta.url)),observations=[];
const output=root+'/evidence/domain-r1';fs.mkdirSync(output);
for(const [name,want] of Object.entries(expected.scenarios)){
 const p=root+'/fixtures/'+name+'.json',bytes=fs.readFileSync(p),before=sha(bytes);
 const calls=[false,...(want.reverse?[true]:[])];
 for(const reverse of calls){
  const options={firstMonth:reverse?'2026-02':'2026-01',secondMonth:reverse?'2026-01':'2026-02',currency:'USD',sourceLabel:'Authored receiving fixture'};
  let report,caught;
  try{report=compareLedgerSnapshot(bytes,options)}catch(e){caught=e;}
  if(want.consumer==='accept'){
   assert.ifError(caught);assertComparison(name,report,bytes,reverse);
   fs.writeFileSync(output+'/'+name+(reverse?'-reverse':'')+'.json',JSON.stringify(report,null,2)+'\n',{flag:'wx',mode:0o600});
  }else{
   assert.ok(caught,'required refusal '+name);assert.match(caught.message,refusalPatterns[name]);assert.equal(report,undefined);
  }
  assert.equal(sha(bytes),before,'byte-view mutation');assert.equal(sha(fs.readFileSync(p)),before,'input file mutation');
  observations.push({fixture:name,reverse,pass:true,outcome:caught?'refused':'accepted',error:caught?{name:caught.constructor.name,message:caught.message}:null,source_sha256:before,net_delta:report?.totals.change.netMinor});
 }
}
const result={schema:'household.independent_domain_receiving.v1',recorded_at:new Date().toISOString(),runtime:process.version,expectations_sha256:sha(fs.readFileSync(root+'/expected.json')),candidate_compiled_sha256:sha(fs.readFileSync(root+'/candidate/src/month-comparison.js')),cases:observations.length,passes:observations.length,observations,author_suite_rerun:false,input_bytes_unchanged:true};
fs.writeFileSync(output+'/receipt.json',JSON.stringify(result,null,2)+'\n',{flag:'wx',mode:0o600});
console.log(JSON.stringify(result));
