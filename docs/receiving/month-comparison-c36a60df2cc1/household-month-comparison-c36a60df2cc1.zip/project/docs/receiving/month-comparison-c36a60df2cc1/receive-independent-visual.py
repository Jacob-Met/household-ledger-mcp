#!/usr/bin/env python3
"""Receive the peer's sealed comparison evidence without executing its tests."""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import hashlib, json, os, shutil, stat, subprocess

ROOT = Path("/tmp/c36a60df2cc1-household-report-receiver/worktree")
COMMIT = "b45eb8d8b7107951e7283f38538c1b9668cf950d"
EXPECTED_MANIFEST = "dafbf4e56aa473741c1ee2efbdca3b9d3223523e900702fdad3650a2bf69cc0d"
HERE = Path(__file__).resolve().parent
DEST = HERE / "independent" / "visual"

def sha(data):
    return hashlib.sha256(data).hexdigest()

def blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()

def git(*args):
    return subprocess.check_output(["git", "-C", str(ROOT), *args])

assert git("rev-parse", "HEAD").decode().strip() == COMMIT
assert not git("status", "--porcelain", "--untracked-files=all").strip()
manifest_bytes = (ROOT / "manifest.json").read_bytes()
assert sha(manifest_bytes) == EXPECTED_MANIFEST
manifest = json.loads(manifest_bytes)
entries = manifest["members"]
assert len(entries) == 75
listed = [e["path"] for e in entries] + ["manifest.json"]
assert len(set(listed)) == len(listed) == 76
tree = {}
for entry in git("ls-tree", "-r", "-z", COMMIT).split(b"\0"):
    if not entry:
        continue
    meta, name = entry.split(b"\t", 1)
    mode, typ, oid = meta.decode().split()
    tree[name.decode()] = (mode, typ, oid)
assert set(tree) == set(listed), {"unexpected_tracked": sorted(set(tree)-set(listed)), "untracked_manifest": sorted(set(listed)-set(tree))}
payloads = []
records = []
for rel in listed:
    p = PurePosixPath(rel)
    assert not p.is_absolute() and ".." not in p.parts and "." not in p.parts
    source = ROOT.joinpath(*p.parts)
    before = source.stat(follow_symlinks=False)
    assert stat.S_ISREG(before.st_mode)
    data = source.read_bytes()
    after = source.stat(follow_symlinks=False)
    assert (before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns)
    expected = next((e for e in entries if e["path"] == rel), None)
    if expected:
        assert len(data) == expected["bytes"] and sha(data) == expected["sha256"], rel
    mode, typ, oid = tree[rel]
    assert typ == "blob" and mode == "100644" and blob(data) == oid, rel
    assert git("cat-file", "blob", oid) == data, rel
    payloads.append((rel, data))
    records.append({"path": rel, "bytes": len(data), "sha256": sha(data), "git_blob": oid, "git_mode": mode})
assert not DEST.exists(), "Destination must be newly created"
assert shutil.disk_usage(HERE).free > sum(len(data) for _, data in payloads) + 10_000_000
DEST.mkdir(parents=True)
for rel, data in payloads:
    target = DEST / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("xb") as out:
        out.write(data)
    assert target.read_bytes() == data, rel
assert sha((ROOT / "manifest.json").read_bytes()) == EXPECTED_MANIFEST
assert git("rev-parse", "HEAD").decode().strip() == COMMIT
receipt = {
    "schema": "household.peer_evidence_receiving.v1",
    "recorded_at": datetime.now(timezone.utc).isoformat(),
    "producer": "c36a60df2cc1-coordination",
    "receiver": "c36a60df2cc1-native",
    "source_root": str(ROOT),
    "source_commit": COMMIT,
    "fixture_commit": "7fb753c10a2e87f87772e787a19d5d49da2609e7",
    "source_manifest_sha256": EXPECTED_MANIFEST,
    "source_git_clean_before": True,
    "source_tree_exact_manifest_members": True,
    "received_relative_root": "independent/visual",
    "received_files": len(records),
    "received_bytes": sum(r["bytes"] for r in records),
    "all_source_bytes_sha256_git_blobs_and_destination_bytes_verified": True,
    "rerun": False,
    "records": records
}
with (HERE / "independent" / "visual-receiving.json").open("x", encoding="utf-8") as out:
    json.dump(receipt, out, indent=2)
    out.write("\n")
print(json.dumps({k: v for k, v in receipt.items() if k != "records"}, indent=2))
