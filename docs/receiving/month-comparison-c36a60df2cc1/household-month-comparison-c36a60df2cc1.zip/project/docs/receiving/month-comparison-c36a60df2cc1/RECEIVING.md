# Household two-month comparison — native receiving

Producer: `c36a60df2cc1-native`, an external contributor under Jacob's existing HAMON execution mandate.

The new offline consumer is implemented and locally qualified. It reads one explicitly selected saved ledger, compares two caller-selected months in one currency, and creates a complete private HTML report. Native service installation and parent source adoption are separate owner actions.

## Exact source and owner boundary

- Repository: `Jacob-Met/household-ledger-mcp`.
- Parent source: draft PR8 at `591ab6f5a2d65bf596aeb707dbb635ee981ec926`; unchanged ledger blob `2ff8133404f19c705eb7b7f0a943e8190f3328d6`.
- Exact complete ledger SHA256: `743eb94413383d8872b2eb4670d2813c2924d78cf9ae0d2b479432f9e8ae8c07`.
- Private native projection base: `a265a59e1ad3e8de5aec5bd05613212345e6e5fa`; first source generation `e3ba9434e182da82a3b8676246c45a0fa0b58b87`; revised production source `571ac097c34c1c041ac298ad7d20e60379980db4`.
- Ownership declaration: https://github.com/Jacob-Met/household-ledger-mcp/issues/3#issuecomment-6067214316.
- `estate-ce7eb129730f` retains parent integration; `estate-61749b0088e2` retains canonical receiving and sibling composition. Existing cashflow_trend, budget/filter/import/export and single-month report scopes remain theirs.

The six added paths are listed with exact bytes, SHA256, Git blobs and source contents in `source-publication.json`. `source-only.patch` contains only those six additions, SHA256 `48dfdc1fc2d0ffa921d089f29a596cbf2a273a11fef42c73b036f7551fe6b39f`, 65,141 bytes. The actual private-index forward check admits exactly those six new paths; reversing it reconstructs the complete received six-file projection preimage. This is not a full canonical-tree qualification. Root separately inspected all 116 parent blobs and found all six paths absent.

The native history is a reproduction projection. Do not merge it or an artifact branch wholesale into the README-only canonical main. Receive the narrow source patch through the existing owner route and compare the actual dependency before adopting it.

## Native execution

Runtime: ThinkPad Linux, Node `v22.22.1`, TypeScript `5.9.3`, `@types/node` `24.19.1`. The unchanged lockfile is SHA256 `446d4d6122958b393d384d61d3187004e965b9de09dfba34192b17c5a7d1c8ff`. Repository-locked `npm ci` ran in a private runtime/cache with lifecycle scripts disabled; no shared dependency installation was used.

The source projection includes the exact ledger module plus the package, lockfile, TypeScript configuration, ignore file and license. Strict compilation and tests cover that consumer closure and the new files. They are not a rerun of the complete service's inherited 101-test suite or its Node20 hosted gate.

| Receiving step | Actual result |
| --- | --- |
| Original native monthly-summary and input-custody controls | 2 passed; new comparison command absent, one expected consumer failure |
| First generation strict build | Exit 0 |
| First generation focused native suite | 21 passed, 0 failed, 0 skipped: 14 domain/render and 7 CLI tests |
| Unchanged frozen original consumer on first generation | 3 passed, 0 failed; exact manually specified totals, union, zero/absent budget differences and source preservation |
| Maintained public receiving entry | 3 passed, 0 failed; actual fictional report retained |
| Interrupted actual write on first writer | Expected failure: exit 1, a 19-byte partial final report exists; original ledger retained |
| Revised writer strict build | Exit 0 |
| Revised writer targeted CLI suite | 8 passed, 0 failed, 0 skipped, including actual prefix-write interruption |
| Revised writer unchanged frozen consumer | 3 passed, 0 failed |

The arithmetic/render source and compiled module stayed exact across the writer change, so the 14 unchanged domain/render tests were not repeated. Their source SHA256 is `4b6a3afae5fc571145302da6de0aedb5f68c9ee7cf9bab1ef23f8692aa9c211b`; compiled SHA256 is `559d998d069d2f234435c4c9db8410193267f38cfcb4ca8867b1d537cd99c5f2`.

The final CLI source is SHA256 `84a7266119430953394833d9f428684fb7e4db5405313fdadc7efaf90b1f4680`; compiled SHA256 `40828c23fdc295d21ff4ec16500e93cade1d527268aa316b5a17e1d33dfdcb9c`. It writes, syncs and closes a unique exclusive 0600 temporary file, publishes by exclusive hard link, and removes only that owned temporary name. The same real prefix-write fault now returns 1 with no final output and only the original ledger in the directory. Existing outputs, same-source destinations and nonregular inputs are also refused without replacement.

## Preserved evidence

`source-inputs.json` retains authoritative original file/tree pins. `setup/` contains locked installation and original strict build logs. `original-consumer.json` and `original-receiver.mjs` were frozen before product implementation. `original/`, `candidate/`, and `maintained-consumer/` retain their actual commands, receipts, CLI logs and fictional outputs.

`author-r1/` retains the first build/test logs and copied first-generation source/compiled files. `publication-original/` retains the actual partial-write failure, output bytes and later explicit source bindings without rewriting that failure. `author-r2/` retains the revised compile, targeted suite, actual no-output fault witness and unchanged consumer. `compiled-r2/` contains the exact final compiled consumer/test files, maps, declarations and package context.

No report was generated from a live household ledger. Input rows and all publication fixtures are fictional. No production import, account call, Store mutation, provider, serving lease, migration source, running service, shared cleanup or restart was used.

## Running the retained compiled consumer

From this receiving directory, the final compiled entry is:

```sh
node compiled-r2/dist/src/household-compare.js --ledger /path/to/ledger.json --first 2026-08 --second 2026-09 --currency USD --out /existing/folder/NEW.html
```

The complete operator contract and maintained test commands are in the source `docs/MONTH_COMPARISON.md`. Use fresh output locations for receiving; archived producer directories are immutable evidence.

## Independent receiving and final custody

The independent command-line consumer packet is preserved unchanged under `independent/consumer/`: Git `65e1431e8d4882119f4b6a37a348ff9130c176ea`, 109 files and 328,155 bytes. Its manifest is SHA256 `756dfdd7b78b4f17351b1c4dd6504d4c279cc39df99e260b12a11163caddc7bf`. The receiver froze nine fixtures before candidate inspection and passed 11/11 pure comparison cases and 15/15 actual final CLI cases. These include exact odd wide deltas in both month orders, whole-snapshot and legacy admission, complete raw category identity, absent versus zero, unchanged input, private output, and independently spawned competing output processes. Source and destination bytes, every manifest hash and each original Git blob were checked during custody; tests were not rerun.

The independent visual packet is preserved unchanged under `independent/visual/`: Git `b45eb8d8b7107951e7283f38538c1b9668cf950d`, 76 files and 1,664,403 bytes including its manifest, SHA256 `dafbf4e56aa473741c1ee2efbdca3b9d3223523e900702fdad3650a2bf69cc0d`. Actual LA7 Chrome 154.0.8037.98 opened the exact final-produced saved HTML directly through file: URLs. Seven groups and 55 assertions passed: visible amounts and raw labels, 390px containment with real keyboard table scrolling, accessibility structure, contextual legacy/zero budgets, print generation, JavaScript-disabled empty report, page request/error and custody checks. All seven screenshots and both pages of the actual tagged PDF were visually inspected; 12 additional PDF text/custody checks passed. Final acceptance SHA256 `42cdc4ad7f42b610c66dcfbb16f81286acab46f26542c2a11530dd00e495e892` closes the separately retained automated receipts' historical pending-manual statuses.

Two presentation notes remain: A4 category headers can wrap within words, and a single-category caption says '1 categories'. Labels and values were present and readable; no source change was requested. The original ThinkPad file route had six readiness failures before product assertions, with no specific navigation cause established. Its proposed loopback attempt then failed browser debugger startup before HTTP receiving. These failures remain evidence and are not relabeled as passing. The final accepted route is actual saved-file Chrome receiving on LA7. It does not establish physical-device, screen-reader, or comprehensive accessibility conformance; page-level no-request observations do not assert that every browser process was network silent.

`independent/consumer-receiving.json` and `independent/visual-receiving.json` retain exact local custody records. `source-tree-receipt.json`, copied byte-identically from the coordinating receiver, records the complete remote content calculation: the 116 accepted PR8 parent leaves remain unchanged and exactly six additions produce tree `2cd593819c919a01e7dd01a4e998eb101abfc0b5`. No source branch, owner branch or canonical main changed during that calculation.

The concise `owner-guide/RECEIVING.md` is a derived final guide. Its independent original remains unchanged under `owner-guide/original/`, with the browser-only replacement pinned in `owner-guide/final-update.json`. `final-receiving.json` binds all source, runtime, outcome and custody pins. The native reproduction bundle retains this private projection's history; it must not be treated as canonical ancestry. The sealed archive excludes dependencies, caches and temporary profiles and retains the independent packets as their literal manifest-selected files.

This contribution is accepted for the established owner's source receiving. Installation, complete inherited-service and Node20 hosted qualification, owner composition and canonical adoption remain outside these receipts.
