import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url)),author='/tmp/c36a60df2cc1-household-compare/worktree';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const pins=[['dist/src/household-compare.js','candidate/src/household-compare.js','40828c23fdc295d21ff4ec16500e93cade1d527268aa316b5a17e1d33dfdcb9c'],['src/household-compare.ts','candidate/source/household-compare.ts','84a7266119430953394833d9f428684fb7e4db5405313fdadc7efaf90b1f4680']];
const files=pins.map(([from,to,pin])=>{const b=fs.readFileSync(path.join(author,from));if(sha(b)!==pin)throw Error('candidate changed '+from);fs.writeFileSync(path.join(root,to),b,{flag:'wx',mode:0o600});if(sha(fs.readFileSync(path.join(root,to)))!==pin)throw Error('copy differs');return {author_path:from,path:to,bytes:b.length,sha256:pin};});
fs.writeFileSync(root+'/evidence/candidate-cli-custody.json',JSON.stringify({recorded_at:new Date().toISOString(),source_commit:'571ac097c34c1c041ac298ad7d20e60379980db4',files},null,2)+'\n',{flag:'wx',mode:0o600});
console.log(JSON.stringify(files));
