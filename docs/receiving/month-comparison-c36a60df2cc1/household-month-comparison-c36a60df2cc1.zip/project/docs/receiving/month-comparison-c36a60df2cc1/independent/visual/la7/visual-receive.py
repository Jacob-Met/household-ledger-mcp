import base64, contextlib, hashlib, json, os, pathlib, re, shutil, socket, struct, subprocess, sys, tempfile, time, traceback, urllib.parse
ROOT=pathlib.Path(__file__).resolve().parent
OUT=ROOT/"la7-r1"
OUT.mkdir()
SOURCE=ROOT/"source"
SOURCE.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
report={"schema":"household.month-comparison.la7-browser.v1","started_at":time.time(),"driver_sha256":sha(pathlib.Path(__file__).read_bytes()),"runtime":{"python":sys.version,"executable":sys.executable},"delivery":"Exact final-generated authored HTML copied byte-for-byte and opened through file: URLs in fresh native LA7 Chrome. No Node execution or product logic substitution on LA7.","intake":[],"checks":[],"assertions":0,"requests":[],"loading_failures":[],"page_errors":[],"artifacts":[],"cleanup":{}}
transfer=json.loads((ROOT/"transfer.json").read_text(encoding="utf-8"))
for entry in transfer["files"]:
    rel=pathlib.PurePosixPath(entry["path"])
    if rel.is_absolute() or ".." in rel.parts:raise ValueError("unsafe incoming path")
    data=base64.b64decode(entry["base64"],validate=True)
    if len(data)!=entry["bytes"] or sha(data)!=entry["sha256"]:raise ValueError("incoming pin mismatch")
    target=SOURCE.joinpath(*rel.parts);target.parent.mkdir(parents=True,exist_ok=True)
    with target.open("xb") as f:f.write(data)
    report["intake"].append({k:entry[k] for k in ("path","bytes","sha256")})
fixtures=json.loads((SOURCE/"fixtures.json").read_text(encoding="utf-8"))
expected=json.loads((SOURCE/"expected.json").read_text(encoding="utf-8"))
producer=json.loads((SOURCE/"r2/receipt.json").read_text(encoding="utf-8"))
report["native_producer_receipt_sha256"]=sha((SOURCE/"r2/receipt.json").read_bytes())
report["native_final_output_correspondence"]=[{"name":d["name"],"html_sha256":d["html_sha256"],"correspondence":d["r1_comparison"]} for d in producer["generated"]]
def check(value,label,actual=None):
    report["assertions"]+=1
    if not value:raise AssertionError(label+("" if actual is None else "\n"+json.dumps(actual,ensure_ascii=True)))
def save(name,data):
    if isinstance(data,str):data=data.encode("utf-8")
    with (OUT/name).open("xb") as f:f.write(data)
    row={"name":name,"bytes":len(data),"sha256":sha(data)};report["artifacts"].append(row);return row
def save_json(name,data):return save(name,json.dumps(data,ensure_ascii=True,indent=2)+"\n")
@contextlib.contextmanager
def group(name):
    row={"name":name,"started_at":time.time()};before=report["assertions"]
    try:yield row;row["status"]="PASS"
    except Exception:row["status"]="FAIL";row["error"]=traceback.format_exc()
    row["assertions"]=report["assertions"]-before;row["completed_at"]=time.time();report["checks"].append(row)
    print(json.dumps({"group":name,"status":row["status"],"assertions":row["assertions"]}),flush=True)
    (OUT/"progress.json").write_text(json.dumps({"checks":report["checks"]},ensure_ascii=True,indent=2),encoding="utf-8")
class CDP:
    def __init__(self,address):
        u=urllib.parse.urlparse(address);self.sock=socket.create_connection((u.hostname,u.port),15);self.buffer=b"";self.counter=0
        key=base64.b64encode(os.urandom(16)).decode()
        self.sock.sendall(("GET "+u.path+" HTTP/1.1\r\nHost: "+u.netloc+"\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: "+key+"\r\nSec-WebSocket-Version: 13\r\n\r\n").encode())
        data=b""
        while b"\r\n\r\n" not in data:data+=self.sock.recv(4096)
        headers,self.buffer=data.split(b"\r\n\r\n",1)
        accept=base64.b64encode(hashlib.sha1((key+"258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode()).digest())
        if b" 101 " not in headers or accept.lower() not in headers.lower():raise RuntimeError("WebSocket handshake refused")
    def read(self,n):
        while len(self.buffer)<n:
            data=self.sock.recv(max(4096,n-len(self.buffer)))
            if not data:raise EOFError("WebSocket closed")
            self.buffer+=data
        data,self.buffer=self.buffer[:n],self.buffer[n:];return data
    def send_frame(self,data,opcode=1):
        mask=os.urandom(4);n=len(data)
        header=bytes([0x80|opcode,0x80|(n if n<126 else 126 if n<65536 else 127)])
        if n>=126:header+=struct.pack("!H" if n<65536 else "!Q",n)
        self.sock.sendall(header+mask+bytes(b^mask[i%4] for i,b in enumerate(data)))
    def receive(self):
        result=b""
        while True:
            a,b=self.read(2);n=b&127
            if n==126:n=struct.unpack("!H",self.read(2))[0]
            elif n==127:n=struct.unpack("!Q",self.read(8))[0]
            if n>32*1024*1024:raise RuntimeError("oversize CDP frame")
            mask=self.read(4) if b&128 else None;data=self.read(n)
            if mask:data=bytes(v^mask[i%4] for i,v in enumerate(data))
            opcode=a&15
            if opcode==8:raise EOFError("WebSocket close frame")
            if opcode==9:self.send_frame(data,10);continue
            if opcode in (0,1):result+=data
            if a&128 and opcode in (0,1):return json.loads(result)
    def call(self,method,params=None,session=None):
        self.counter+=1;ident=self.counter;request={"id":ident,"method":method,"params":params or {}}
        if session:request["sessionId"]=session
        self.send_frame(json.dumps(request).encode())
        while True:
            msg=self.receive()
            if msg.get("id")==ident:
                if "error" in msg:raise RuntimeError(method+": "+json.dumps(msg["error"]))
                return msg.get("result",{})
            event=msg.get("method");p=msg.get("params",{})
            if event=="Network.requestWillBeSent":
                url=p["request"]["url"];report["requests"].append({"url":url if len(url)<300 else url[:100]+"[TRUNCATED]","url_bytes":len(url),"type":p.get("type")})
            elif event=="Network.loadingFailed":report["loading_failures"].append(p)
            elif event=="Runtime.exceptionThrown":report["page_errors"].append(p)
client=None;session=None;proc=None;profile=None;stderr=None;stdout=None
def page(method,params=None):return client.call(method,params,session)
def evaluate(expression):
    value=page("Runtime.evaluate",{"expression":expression,"returnByValue":True,"awaitPromise":True})
    if "exceptionDetails" in value:raise RuntimeError("Page evaluation: "+json.dumps(value["exceptionDetails"]))
    return value["result"].get("value")
def navigate(name):
    url=(SOURCE/"r2"/(name+".html")).as_uri()
    result=page("Page.navigate",{"url":url});report.setdefault("navigations",[]).append({"name":name,"url":url,"result":result})
    if result.get("errorText"):raise RuntimeError("file navigation: "+result["errorText"])
    end=time.monotonic()+10
    while time.monotonic()<end:
        if evaluate("location.href==="+json.dumps(url)+"&&document.readyState==='complete'&&!!document.getElementById('household-month-comparison-data')"):return
        time.sleep(.06)
    report.setdefault("unready_pages",[]).append(evaluate("({href:location.href,title:document.title,body:document.body?.innerText?.slice(0,2500)})"))
    raise RuntimeError("file page readiness timed out: "+name)
def key(name,code,number):
    for typ in ("keyDown","keyUp"):page("Input.dispatchKeyEvent",{"type":typ,"key":name,"code":code,"windowsVirtualKeyCode":number})
def shot(name,selector=None):
    if selector:evaluate("document.querySelector("+json.dumps(selector)+").scrollIntoView({block:'start'})")
    time.sleep(.10);data=page("Page.captureScreenshot",{"format":"png","fromSurface":True});return save(name,base64.b64decode(data["data"]))
def metrics(w,h,mobile=False):page("Emulation.setDeviceMetricsOverride",{"width":w,"height":h,"deviceScaleFactor":1,"mobile":mobile})
def signed(v):return ("+" if v>0 else "")+str(v)
try:
    chrome=r"C:\Program Files\Google\Chrome\Application\chrome.exe"
    profile=pathlib.Path(tempfile.mkdtemp(prefix="p-",dir=ROOT))
    stderr=(OUT/"chrome-stderr.log").open("wb");stdout=(OUT/"chrome-stdout.log").open("wb")
    args=[chrome,"--headless=new","--remote-debugging-port=0","--remote-debugging-address=127.0.0.1","--user-data-dir="+str(profile),"--no-first-run","--no-default-browser-check","--disable-background-networking","--disable-component-update","--disable-sync","--disable-default-apps","--disable-breakpad","--metrics-recording-only","--disable-features=Translate","about:blank"]
    report["browser_command"]=args;proc=subprocess.Popen(args,stdout=stdout,stderr=stderr);report["browser_pid"]=proc.pid
    portfile=profile/"DevToolsActivePort";end=time.monotonic()+25
    while not portfile.exists():
        if proc.poll() is not None:raise RuntimeError("Chrome exited before debugger: "+str(proc.returncode))
        if time.monotonic()>end:raise TimeoutError("Chrome debugger startup")
        time.sleep(.10)
    port,ws_path=portfile.read_text().splitlines()[:2]
    client=CDP("ws://127.0.0.1:"+port+ws_path);report["runtime"]["browser"]=client.call("Browser.getVersion")
    target=client.call("Target.createTarget",{"url":"about:blank"})
    session=client.call("Target.attachToTarget",{"targetId":target["targetId"],"flatten":True})["sessionId"]
    for method in ("Page.enable","Runtime.enable","Network.enable","Accessibility.enable"):page(method)
    page("Network.setBlockedURLs",{"urls":["http://*","https://*"]})
    page("Network.emulateNetworkConditions",{"offline":True,"latency":0,"downloadThroughput":-1,"uploadThroughput":-1})
    metrics(1365,1100)
    with group("Direct saved file: visible selection, exact totals and complete category/budget union") as g:
        navigate("primary")
        state=evaluate("(()=>{const rows=s=>[...document.querySelectorAll(s+' tbody tr')].map(r=>[...r.cells].map(c=>c.textContent));return {title:document.querySelector('h1').textContent,context:document.querySelector('.context').textContent,totals:rows('.scroll table'),categories:rows('.category-table'),budgets:rows('.budget-table'),record:JSON.parse(document.getElementById('household-month-comparison-data').textContent),body:document.body.textContent,scripts:[...document.scripts].map(s=>({type:s.type,id:s.id,src:s.src})),width:innerWidth,pageWidth:document.documentElement.scrollWidth};})()")
        check(state["title"]=="Compare household months","Title")
        primary=next(d for d in producer["generated"] if d["name"]=="primary")
        for value in ["2026-09","2026-10","USD","Change = second minus first.","exact integer minor units",primary["input_sha256"],str(primary["input_bytes"])]:check(value in state["context"],"Visible context: "+value)
        for i,k in enumerate(("income","expense","net")):
            vals=expected["primary"]["summary"][k];want=[str(vals[0]),str(vals[1]),signed(vals[2])]
            check(state["totals"][i][1:]==want,"Visible "+k,state["totals"][i])
        union=set(expected["primary"]["categories"]+expected["primary"]["first_only_zero_budgets"]+[expected["primary"]["second_only_budget"]])
        check(set(r[0] for r in state["categories"])==union and len(state["categories"])==len(union),"Complete literal category union",state["categories"])
        food=next(r for r in state["categories"] if r[0]=="Groceries")
        check(food[1:]==["0","100","+100","1250","1400","+150","-1250","-1300","-50"],"Category income/expense/net values",food)
        bud={r[0]:r for r in state["budgets"]}
        check(bud["Groceries"][3:]==["+300","+150","+150"],"Budget deltas",bud["Groceries"])
        check("Limit0" in bud["Zero only"][1] and bud["Zero only"][2]=="Absent" and bud["Zero only"][3:]==["Not comparable"]*3,"Absent differs from stored zero",bud["Zero only"])
        check(bud["October only"][1]=="Absent" and "Limit400" in bud["October only"][2],"Second-only budget visible")
        for text in expected["primary"]["excluded"]:check(text not in state["body"],"Private/unselected text absent: "+text)
        check(state["scripts"]==[{"type":"application/json","id":"household-month-comparison-data","src":""}],"Only inert JSON")
        check(state["pageWidth"]<=state["width"]+1,"Desktop containment")
        save_json("primary-dom.json",state);g["screenshot"]=shot("desktop-primary.png")
    with group("Hostile source/category labels are exact inert text, including whitespace and wide values") as g:
        navigate("hostile_wide")
        state=evaluate("({labels:[...document.querySelectorAll('.category')].map(e=>e.textContent),context:document.querySelector('.context').textContent,rows:[...document.querySelectorAll('.category-table tbody tr')].map(r=>[...r.cells].map(c=>c.textContent)),images:document.images.length,frames:document.querySelectorAll('iframe,object,embed').length,pwned:globalThis.COMPARISON_PWNED??null,scripts:[...document.scripts].map(s=>({type:s.type,id:s.id,src:s.src}))})")
        check(state["labels"]==[expected["hostile_wide"]["exact_category"]]*2,"Exact browser Unicode/CR/LF/tab/space identity",state["labels"])
        check('<source>&".json' in state["context"],"Hostile basename is literal")
        check(state["images"]==0 and state["frames"]==0 and state["pwned"] is None and len(state["scripts"])==1 and state["scripts"][0]["type"]=="application/json","No injected element or execution",state)
        vals=expected["hostile_wide"]["expense"];check(state["rows"][0][4:7]==[str(vals[0]),str(vals[1]),signed(vals[2])],"Wide values exact",state["rows"])
        save_json("hostile-dom.json",state);g["screenshot"]=shot("hostile-label.png")
    with group("390px containment, real keyboard table scrolling and accessibility tree") as g:
        metrics(390,844,True);navigate("hostile_wide")
        layout=evaluate("({width:innerWidth,document:document.documentElement.scrollWidth,body:document.body.scrollWidth,regions:[...document.querySelectorAll('.scroll')].map(e=>({client:e.clientWidth,scroll:e.scrollWidth,tabIndex:e.tabIndex,role:e.getAttribute('role'),label:e.getAttribute('aria-label')}))})")
        check(layout["width"]==390 and layout["document"]<=391 and layout["body"]<=391,"Narrow page containment",layout)
        check(len(layout["regions"])==3 and all(r["tabIndex"]==0 and r["role"]=="region" and r["label"] for r in layout["regions"]),"Named focusable regions",layout)
        keyboard=[]
        for selector in (".category-table",".budget-table"):
            expr="document.activeElement===document.querySelector("+json.dumps(selector)+").parentElement"
            for _ in range(10):
                if evaluate(expr):break
                key("Tab","Tab",9)
            check(evaluate(expr),"Native Tab reaches "+selector)
            before=evaluate("document.activeElement.scrollLeft")
            for _ in range(6):key("ArrowRight","ArrowRight",39)
            time.sleep(.2);after=evaluate("document.activeElement.scrollLeft")
            check(after>before and evaluate("scrollX")==0,"Native ArrowRight scrolls internal region",{"selector":selector,"before":before,"after":after})
            keyboard.append({"selector":selector,"before":before,"after":after})
        ax=page("Accessibility.getFullAXTree");save_json("mobile-accessibility.json",ax)
        roles=[{"role":n.get("role",{}).get("value"),"name":n.get("name",{}).get("value")} for n in ax["nodes"] if not n.get("ignored")]
        check(len([n for n in roles if n["role"]=="region" and n["name"]])>=3,"AX exposes named regions")
        check(any(n["role"]=="columnheader" and "Change" in str(n["name"]) for n in roles),"AX exposes change column headers")
        navigate("primary");g.update({"layout":layout,"keyboard":keyboard,"screenshots":[shot("mobile-primary-top.png"),shot("mobile-primary-budgets.png",".budget-table")]})
    with group("Visible contextual legacy budget denomination and zero") as g:
        metrics(1365,1100);navigate("legacy")
        row=evaluate("[...document.querySelector('.budget-table tbody tr').cells].map(c=>c.textContent)")
        check(all("Legacy budget: stored currency absent; native USD month context" in row[i] for i in (1,2)),"Legacy contexts remain explicit",row)
        check(row[3:]==["-100","+15","-115"],"Legacy deltas exact",row)
        check("Limit0" in row[2] and "Absent" not in row[2],"Legacy zero remains present")
        g.update({"row":row,"screenshot":shot("legacy-budgets.png",".budget-table")})
    with group("Actual native browser print restores full tables and produces complete tagged PDF") as g:
        metrics(1100,1400);navigate("primary");page("Emulation.setEmulatedMedia",{"media":"print"})
        layout=evaluate("({print:matchMedia('print').matches,regions:[...document.querySelectorAll('.scroll')].map(e=>getComputedStyle(e).overflowX),header:getComputedStyle(document.querySelector('thead')).display})")
        check(layout["print"] and all(v=="visible" for v in layout["regions"]) and layout["header"]=="table-header-group","Print layout exposes full tables",layout)
        printed=page("Page.printToPDF",{"printBackground":True,"displayHeaderFooter":False,"paperWidth":8.27,"paperHeight":11.69,"marginTop":.35,"marginBottom":.35,"marginLeft":.35,"marginRight":.35,"generateTaggedPDF":True})
        data=base64.b64decode(printed["data"]);check(data.startswith(b"%PDF-") and re.search(rb"%%EOF\s*$",data[-100:]),"Complete actual PDF")
        g.update({"layout":layout,"pdf":save("primary.pdf",data),"print_view":shot("print-layout.png")})
        page("Emulation.setEmulatedMedia",{"media":""})
    with group("Direct empty file loads offline with JavaScript disabled") as g:
        page("Emulation.setScriptExecutionDisabled",{"value":True});navigate("empty")
        state=evaluate("({body:document.body.textContent,empty:[...document.querySelectorAll('.empty')].map(e=>e.textContent),rows:[...document.querySelectorAll('table tbody tr')].map(r=>[...r.cells].map(c=>c.textContent))})")
        check(all(s in state["body"] for s in ["2026-09","2026-10","Currency: USD"]),"Explicit selection remains offline")
        check(len(state["rows"])==3 and all(r[1:]==["0","0","0"] for r in state["rows"]),"Zero values render without scripts",state["rows"])
        check(any("No selected transactions or qualified budgets" in s for s in state["empty"]) and any("No qualified budget rows" in s for s in state["empty"]),"Empty wording is scoped to recorded selection",state["empty"])
        page("Emulation.setScriptExecutionDisabled",{"value":False});g.update({"empty":state["empty"],"screenshot":shot("empty-offline.png")})
    with group("No page external requests, no page errors and exact input custody") as g:
        check(not any(r["url"].startswith(("http:","https:")) for r in report["requests"]),"No page attempted external network",report["requests"])
        check(not report["loading_failures"],"All file requests complete",report["loading_failures"])
        check(not report["page_errors"],"No page runtime errors",report["page_errors"])
        for entry in report["intake"]:check(sha((SOURCE/pathlib.PurePosixPath(entry["path"])).read_bytes())==entry["sha256"],"Incoming bytes unchanged: "+entry["path"])
        g["documents"]=4
    report["status"]="FAIL" if any(c["status"]=="FAIL" for c in report["checks"]) else "PASS_PENDING_VISUAL_AND_PDF_TEXT_INSPECTION"
except Exception:
    report["status"]="SETUP_OR_EXECUTION_FAILED";report["error"]=traceback.format_exc()
finally:
    if client:
        try:client.call("Browser.close")
        except Exception as e:report["cleanup"]["close_note"]=str(e)
        try:client.sock.close()
        except Exception:pass
    if proc:
        try:proc.wait(timeout=10)
        except subprocess.TimeoutExpired:proc.terminate();proc.wait(timeout=10)
        report["cleanup"]["browser_exit"]=proc.returncode
    if stdout:stdout.close()
    if stderr:stderr.close()
    if profile:
        for attempt in range(5):
            try:shutil.rmtree(profile);break
            except OSError:
                if attempt==4:report["cleanup"]["profile_error"]=traceback.format_exc()
                else:time.sleep(.3)
        report["cleanup"]["profile_removed"]=not profile.exists()
    report["completed_at"]=time.time();report["passed_groups"]=sum(c["status"]=="PASS" for c in report["checks"]);report["failed_groups"]=sum(c["status"]=="FAIL" for c in report["checks"])
    data=(json.dumps(report,ensure_ascii=True,indent=2)+"\n").encode();(OUT/"receipt.json").write_bytes(data)
    summary={"status":report["status"],"passed_groups":report["passed_groups"],"failed_groups":report["failed_groups"],"assertions":report["assertions"],"receipt":str(OUT/"receipt.json"),"receipt_sha256":sha(data),"error":report.get("error"),"cleanup":report["cleanup"]}
    (ROOT/"la7-r1-summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8");print(json.dumps(summary),flush=True)
sys.exit(1 if report["status"] in ("FAIL","SETUP_OR_EXECUTION_FAILED") else 0)
