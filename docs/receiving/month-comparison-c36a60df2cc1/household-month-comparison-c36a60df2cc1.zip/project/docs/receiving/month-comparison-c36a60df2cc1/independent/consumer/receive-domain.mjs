import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url)),author='/tmp/c36a60df2cc1-household-compare/worktree';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const specs=[
 ['dist/src/ledger.js','candidate/src/ledger.js','8e80c26b8f68767f80d87bc79a41ff0711f5996dffe5652ef859c4ecef3ac48a'],
 ['dist/src/month-comparison.js','candidate/src/month-comparison.js','559d998d069d2f234435c4c9db8410193267f38cfcb4ca8867b1d537cd99c5f2'],
 ['src/ledger.ts','candidate/source/ledger.ts','743eb94413383d8872b2eb4670d2813c2924d78cf9ae0d2b479432f9e8ae8c07'],
 ['src/month-comparison.ts','candidate/source/month-comparison.ts','4b6a3afae5fc571145302da6de0aedb5f68c9ee7cf9bab1ef23f8692aa9c211b']
];
const files=[];
for(const [from,to,pin] of specs){const b=fs.readFileSync(path.join(author,from));if(sha(b)!==pin)throw Error('candidate changed '+from);const dest=path.join(root,to);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,b,{flag:'wx',mode:0o600});if(sha(fs.readFileSync(dest))!==pin)throw Error('readback '+to);files.push({author_path:from,path:to,bytes:b.length,sha256:pin});}
fs.writeFileSync(root+'/candidate/package.json','{"type":"module","private":true}\n',{flag:'wx',mode:0o600});
fs.writeFileSync(root+'/evidence/candidate-domain-custody.json',JSON.stringify({timestamp:new Date().toISOString(),source_root:author,files,cli_received:false},null,2)+'\n',{flag:'wx',mode:0o600});
console.log(JSON.stringify({files,cli_received:false}));
