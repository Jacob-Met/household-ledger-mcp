import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const own=path.dirname(new URL(import.meta.url).pathname), source='/tmp/c36a60df2cc1-household-compare/worktree';
const hash=b=>createHash('sha256').update(b).digest('hex');
const expected={'dist/src/ledger.js':['8e80c26b8f68767f80d87bc79a41ff0711f5996dffe5652ef859c4ecef3ac48a',15698],'dist/src/month-comparison.js':['559d998d069d2f234435c4c9db8410193267f38cfcb4ca8867b1d537cd99c5f2',16886],'dist/src/household-compare.js':['742cf6179b7abd0a34985b2b095b00d77273b58f32d06c59e1d169bf72819f9f',5732]};
const report={recorded_at:new Date().toISOString(),source_root:source,files:[],commands:[]};
try {
 for(const name of [...Object.keys(expected),'package.json']){
  const from=path.join(source,name),b=fs.readFileSync(from),s=fs.statSync(from);
  const sha=hash(b); if(expected[name]&&(sha!==expected[name][0]||b.length!==expected[name][1]))throw new Error('candidate pin mismatch '+name);
  const target=path.join(own,'candidate',name); fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,b,{flag:'wx'});
  const after=fs.readFileSync(from);if(!after.equals(b))throw new Error('source changed during copy '+name);
  report.files.push({path:name,bytes:b.length,sha256:sha,source_stat:{ino:s.ino,size:s.size,mtimeMs:s.mtimeMs},copy_sha256:hash(fs.readFileSync(target))});
 }
 const chrome=spawnSync('/snap/bin/chromium',['--version'],{encoding:'utf8',timeout:20000});
 report.commands.push({command:['/snap/bin/chromium','--version'],status:chrome.status,stdout:chrome.stdout,stderr:chrome.stderr,error:chrome.error?String(chrome.error):null});
 const f=fs.statfsSync(own);report.available_bytes=f.bavail*f.bsize;
 report.node=process.version; report.status='COPIED_EXACT_CANDIDATE';
}catch(error){report.status='INTAKE_FAILED';report.error=String(error);process.exitCode=1;}
fs.writeFileSync(path.join(own,'candidate-intake.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
