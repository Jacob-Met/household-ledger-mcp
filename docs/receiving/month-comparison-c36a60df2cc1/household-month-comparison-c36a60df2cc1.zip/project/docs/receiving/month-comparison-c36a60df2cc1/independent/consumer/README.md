# Independent Household month comparison receiving

Disposition: ACCEPT bounded pure comparison and actual CLI consumption of the frozen saved-ledger fixtures. Author source commit: 571ac097c34c1c041ac298ad7d20e60379980db4.

Nine authored input files and independent expected values were frozen in commit b318962641a59fd4e14e960c3fb89bce81a9ef45 before candidate source inspection or execution. The unchanged PR8 producer at Git blob2ff8133404f19c705eb7b7f0a943e8190f3328d6 admitted six fixtures, refused two monthly legacy contexts, and rejected one invalid complete ledger. Its exact original TypeScript, compiler provenance and admission outputs are retained.

The candidate domain receiver passed11/11 cases, including reverse selections and odd wide deltas that expose Number-before-BigInt rounding. It verifies raw/reserved category union, budget-only rows, absent versus zero budgets, preserved legacy context and deliberate refusal of duplicate legacy budget pairing. All input byte views and saved files remained unchanged.

Actual isolated CLI process receiving passed15/15 cases. It reads every applicable fixture through the real descriptor/argument path and checks the machine-readable report against frozen expectations. Source hashes, inodes and mtimes are unchanged. Missing input creates no output; existing output and same-source destinations preserve exact prior bytes. Reports remain0600 under umask000. Two separate processes competing for one output produce one successful complete report, one refusal, and no temporary stages left.

No author suite was rerun. No production source was imported. candidate/src contains only the copied byte-pinned compiled three-module closure; candidate/source retains its TypeScript provenance. No toolchain or node_modules is packaged. The initial native Node TypeScript capability refusal and a transient transport/missing-runner failure are retained; neither executed fixture or candidate code. The actual original-producer compile then used existing TypeScript5.9.3 read-only.

Start with receiver-summary.json, expected.json and fixture-manifest.json. Detailed original/positive/refusal receipts and stdout/stderr are under evidence/. Generated HTML is authored receiver output only; browser/visual acceptance belongs to the separate coordination receiver.

For archive intake, preserve every file-manifest.json member plus the manifest itself. The historical runner scripts use exclusive output creation and must not be rerun over preserved evidence. Any new receiving run must choose a fresh owned output directory. No installed adoption, power-loss durability or financial/account action is claimed.
