import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
const root=path.dirname(new URL(import.meta.url).pathname);
const files=['fixtures.json','expected.json','plan.json','freeze-receipt.json','candidate-r2-intake.json','r2/receipt.json','r2/primary.html','r2/hostile_wide.html','r2/legacy.html','r2/empty.html'];
const bundle={schema:'household.month-comparison.visual-transfer.v1',created_at:new Date().toISOString(),source_root:root,files:files.map(name=>{const b=fs.readFileSync(path.join(root,name));return {path:name,bytes:b.length,sha256:createHash('sha256').update(b).digest('hex'),base64:b.toString('base64')};})};
fs.writeFileSync(path.join(root,'la7-transfer.json'),JSON.stringify(bundle)+'\n',{flag:'wx'});
