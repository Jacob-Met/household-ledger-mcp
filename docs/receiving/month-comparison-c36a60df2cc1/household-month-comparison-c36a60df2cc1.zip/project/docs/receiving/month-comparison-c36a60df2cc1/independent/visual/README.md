# Independent Household month-comparison report receiving

## Disposition

Accepted for the bounded report-consumer scope. The actual final native CLI generated four fictional-data HTML files; LA7 Chrome 154.0.8037.98 opened those exact bytes using file URLs in a fresh owned profile. Seven browser groups and 55 assertions pass. All seven captured PNGs and both actual saved PDF pages were inspected; 12 PDF text and custody checks pass.

No clipped, missing or overlapping data was found. Two presentation notes remain nonblocking: some A4 category headers wrap within words, and the singular category caption reads “1 categories”. No source change is requested.

Read **final-review.json** for the exact acceptance, source and artifact pins, original route failures, manual observations and limits. Automated receipts retain their original pending-manual-inspection state; final-review.json closes that review without rewriting the historical files.

## Reproducible evidence

The independent fixtures and exact expectations were frozen before candidate review in commit 7fb753c10a2e87f87772e787a19d5d49da2609e7. The final author source commit is 571ac097c34c1c041ac298ad7d20e60379980db4. candidate-r2-intake.json pins the three actual compiled producer modules. The final CLI is SHA256 40828c23fdc295d21ff4ec16500e93cade1d527268aa316b5a17e1d33dfdcb9c; renderer 559d998d069d2f234435c4c9db8410193267f38cfcb4ca8867b1d537cd99c5f2.

- r1/ preserves the original native direct-file readiness failure, original CLI outputs and logs.
- r2/ preserves the revised CLI outputs and the native browser-startup failure before loopback delivery was exercised. Its four output correspondences normalize only the two explicit generatedAt occurrences; all other JSON and HTML bytes match.
- la7/visual-receive.py is the actual native Python CDP driver. It supplies browser transport and assertions, without implementing any product logic.
- la7/la7-r1/ holds the accepted browser receipt, DOM and AX records, seven PNG captures and the actual tagged two-page PDF.
- la7/pdf-review/ contains independent Poppler text and page renders from that exact PDF.
- la7-native-intake.json verifies all 17 artifacts copied from LA7 without changing any byte.
- source-admission.json and manifest.json are generated during sealing from the exact source/evidence bytes.

## Boundaries

No live ledger or account data was used. Domain arithmetic, CLI admission and competing-file publication are separately owned by the regression receiver. This packet adds actual rendered consumer checks, real keyboard scrolling, visible legacy/absent-zero distinctions, offline disabled-JavaScript behavior, escaped hostile text and print preservation.

The ThinkPad R1 readiness failure has no recorded Page.navigate error code, so no Snap or access-policy explanation is claimed. R2 did not reach browser delivery. The successful LA7 file route is separately identified. Offline request checks cover the observed report page, not every browser process; AX/keyboard checks are not a screen-reader or comprehensive accessibility conformance claim.

The browser process exited 0 and its fresh owned profile was removed. No existing browser profile, selected release, production service, source owner file or shared Git branch was changed. Native home ENOSPC failures and possible partial files remain recorded in plan.json. Source adoption and distribution remain with the canonical receiver.
