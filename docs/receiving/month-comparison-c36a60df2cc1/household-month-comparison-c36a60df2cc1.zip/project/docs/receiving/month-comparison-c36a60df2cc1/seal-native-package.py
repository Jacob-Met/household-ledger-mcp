#!/usr/bin/env python3
"""Seal the qualified private projection; never publishes or changes owner source."""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import hashlib, json, stat, subprocess, zipfile

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[2]
OUT = PROJECT.parent / "sealed"
SOURCE_COMMIT = "571ac097c34c1c041ac298ad7d20e60379980db4"
BASE_COMMIT = "a265a59e1ad3e8de5aec5bd05613212345e6e5fa"
PREFIX = "docs/receiving/month-comparison-c36a60df2cc1/"
PATCH_SHA = "48dfdc1fc2d0ffa921d089f29a596cbf2a273a11fef42c73b036f7551fe6b39f"

def sha(data):
    return hashlib.sha256(data).hexdigest()

def blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()

def encoded(value):
    return (json.dumps(value, indent=2) + "\n").encode()

def git(*args):
    return subprocess.check_output(["git", "-C", str(PROJECT), *args])

def tree(ref):
    result = {}
    for entry in git("ls-tree", "-r", "-z", ref).split(b"\0"):
        if not entry:
            continue
        meta, name = entry.split(b"\t", 1)
        mode, typ, oid = meta.decode().split()
        result[name.decode()] = {"mode": mode, "type": typ, "git_blob": oid}
    return result

assert not git("status", "--porcelain", "--untracked-files=all").strip(), "Commit all intended evidence first"
head = git("rev-parse", "HEAD").decode().strip()
assert git("rev-parse", "refs/heads/month-comparison").decode().strip() == head
subprocess.run(["git", "-C", str(PROJECT), "merge-base", "--is-ancestor", SOURCE_COMMIT, head], check=True)
published = json.loads((HERE / "source-publication.json").read_bytes())
final = json.loads((HERE / "final-receiving.json").read_bytes())
assert final["disposition"] == "ACCEPT_FOR_OWNER_RECEIVING_NOT_INSTALLED"
assert isinstance(published["independent_receiving"], dict)
assert published["native_source_commit"] == SOURCE_COMMIT
assert sha((HERE / "source-only.patch").read_bytes()) == PATCH_SHA
base_tree, final_tree = tree(BASE_COMMIT), tree(head)
assert len(base_tree) == 6
assert all(final_tree.get(p) == value for p, value in base_tree.items())
source_paths = {f["path"] for f in published["source_files"]}
assert len(source_paths) == 6 and not source_paths.intersection(base_tree)
assert all(p in base_tree or p in source_paths or p.startswith(PREFIX) for p in final_tree)
for entry in published["source_files"]:
    data = (PROJECT / entry["path"]).read_bytes()
    assert len(data) == entry["bytes"] and sha(data) == entry["sha256"]
    assert blob(data) == entry["git_blob"] == final_tree[entry["path"]]["git_blob"]
    assert data.decode("utf-8") == entry["content"]
assert not OUT.exists(), "A sealed destination may not be replaced"
OUT.mkdir()
bundle = OUT / "reproduction.bundle"
subprocess.run(["git", "-C", str(PROJECT), "bundle", "create", str(bundle), "refs/heads/month-comparison"], check=True)
verified = subprocess.run(["git", "-C", str(PROJECT), "bundle", "verify", str(bundle)], capture_output=True, text=True)
assert verified.returncode == 0, verified.stderr
payloads, members = [], []
for rel in sorted(final_tree):
    name = PurePosixPath(rel)
    assert not name.is_absolute() and ".." not in name.parts
    path = PROJECT / rel
    assert stat.S_ISREG(path.stat(follow_symlinks=False).st_mode), rel
    data = path.read_bytes()
    info = final_tree[rel]
    assert info["type"] == "blob" and info["mode"] in ("100644", "100755")
    assert blob(data) == info["git_blob"], rel
    archive_path = "project/" + rel
    payloads.append((archive_path, data, info["mode"]))
    members.append({"path": archive_path, "bytes": len(data), "sha256": sha(data),
                    "git_blob": info["git_blob"], "git_mode": info["mode"], "custody": "exact evidence Git tree"})
bundle_bytes = bundle.read_bytes()
payloads.append(("reproduction.bundle", bundle_bytes, "100644"))
members.append({"path": "reproduction.bundle", "bytes": len(bundle_bytes), "sha256": sha(bundle_bytes),
                "custody": "verified complete private projection history; not canonical ancestry"})
manifest = {
    "schema": "household.comparison_native_archive_manifest.v1",
    "recorded_at": datetime.now(timezone.utc).isoformat(),
    "repository": "Jacob-Met/household-ledger-mcp",
    "native_source_commit": SOURCE_COMMIT,
    "native_evidence_commit": head,
    "private_projection_base": BASE_COMMIT,
    "required_owner_parent": published["required_owner_receiving_ref"],
    "owner_receiving_guide": "project/" + PREFIX + "owner-guide/RECEIVING.md",
    "source_publication": "project/" + PREFIX + "source-publication.json",
    "source_patch": "project/" + PREFIX + "source-only.patch",
    "compiled_entry": "project/" + PREFIX + "compiled-r2/dist/src/household-compare.js",
    "bundle_verified_exit": verified.returncode,
    "bundle_verification_stdout": verified.stdout,
    "bundle_verification_stderr": verified.stderr,
    "members_excluding_this_manifest": len(members),
    "member_bytes": sum(m["bytes"] for m in members),
    "members": members,
    "limits": [
        "The history is a native six-file dependency projection, never a canonical merge parent.",
        "Only the six source additions belong in owner source intake.",
        "Independent consumer and visual evidence are included unchanged as manifest-selected raw files; no nested peer archives.",
        "No installed service or owner adoption is claimed; node_modules, caches, .git directories and temporary profiles are excluded."
    ]
}
manifest_bytes = encoded(manifest)
(OUT / "ARCHIVE-MANIFEST.json").write_bytes(manifest_bytes)
payloads.append(("ARCHIVE-MANIFEST.json", manifest_bytes, "100644"))
zip_path = OUT / "household-month-comparison-c36a60df2cc1.zip"
stamp = (2026, 10, 8, 0, 0, 0)
with zipfile.ZipFile(zip_path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data, mode in payloads:
        item = zipfile.ZipInfo(name, stamp)
        item.compress_type = zipfile.ZIP_DEFLATED
        item.external_attr = int(mode, 8) << 16
        archive.writestr(item, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(zip_path) as archive:
    assert archive.namelist() == [p[0] for p in payloads]
    for name, data, mode in payloads:
        assert archive.read(name) == data, name
    assert archive.testzip() is None
zip_bytes = zip_path.read_bytes()
outer_publication = dict(published)
outer_publication["sealed_native_archive"] = {
    "filename": zip_path.name, "bytes": len(zip_bytes), "sha256": sha(zip_bytes),
    "manifest_sha256": sha(manifest_bytes), "archive_members": len(payloads),
    "native_evidence_commit": head
}
publication_bytes = encoded(outer_publication)
publication_path = OUT / "household-month-comparison-publication.json"
publication_path.write_bytes(publication_bytes)
receipt = {
    "schema": "household.comparison_native_seal_receipt.v1",
    "recorded_at": datetime.now(timezone.utc).isoformat(),
    "native_source_commit": SOURCE_COMMIT,
    "native_evidence_commit": head,
    "archive": {"path": str(zip_path), "bytes": len(zip_bytes), "sha256": sha(zip_bytes),
                "members": len(payloads), "all_member_bytes_verified_after_compression": True},
    "manifest": {"path": str(OUT / "ARCHIVE-MANIFEST.json"), "bytes": len(manifest_bytes), "sha256": sha(manifest_bytes)},
    "reproduction_bundle": {"bytes": len(bundle_bytes), "sha256": sha(bundle_bytes), "verify_exit": verified.returncode},
    "source_patch": published["source_patch"],
    "publication_packet": {"path": str(publication_path), "bytes": len(publication_bytes), "sha256": sha(publication_bytes)},
    "disposition": final["disposition"],
    "owner_route": published["owner_route"],
    "installed": False
}
receipt_path = OUT / "household-month-comparison-c36a60df2cc1.receipt.json"
receipt_path.write_bytes(encoded(receipt))
assert not git("status", "--porcelain", "--untracked-files=all").strip()
print(json.dumps(receipt, indent=2))
