import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import {fileURLToPath} from "node:url";
import {execFileSync} from "node:child_process";
import {validateLedgerData, monthlySummary} from "./producer/ledger.ts";
const root=path.dirname(fileURLToPath(import.meta.url));
const sha=b=>crypto.createHash("sha256").update(b).digest("hex");
const assert=(v,m)=>{if(!v)throw Error(m)};
const write=(name,value)=>{const p=path.join(root,name);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,JSON.stringify(value,null,2)+"\n",{flag:"wx",mode:0o600});};
const MAX=9007199254740991;
let id=0;
const tx=(month,type,amountMinor,category,currency="USD")=>({id:"authored-"+(++id),type,amountMinor,currency,date:month+"-15",category,createdAt:"2026-10-08T00:00:00.000Z"});
const budget=(month,category,limitMinor,currency="USD")=>({month,category,limitMinor,...(currency===null?{}:{currency})});
const fixtures={
 "extreme-signed-deltas":{version:2,transactions:[tx("2026-01","income",MAX,"__proto__"),tx("2026-02","expense",MAX,"__proto__")],budgets:[budget("2026-01","__proto__",MAX),budget("2026-02","__proto__",0)]},
 "raw-category-union":{version:2,transactions:[tx("2026-01","income",1250,"salary"),tx("2026-01","income",7,"toString"),tx("2026-01","expense",200,"food"),tx("2026-01","expense",50," food "),tx("2026-01","expense",99,"foreign-only","JPY"),tx("2026-02","income",1000,"salary"),tx("2026-02","expense",300,"food"),tx("2026-02","expense",25,'<pantry & "quoted">'),tx("2026-02","expense",100,"foreign-only","JPY")],budgets:[budget("2026-01","food",0),budget("2026-01","budget-only",400),budget("2026-02","budget-only",600),budget("2026-02","new-budget",0),budget("2026-01","foreign-only",99,"JPY")]},
 "legacy-singleton":{version:1,transactions:[tx("2026-01","expense",25,"food"),tx("2026-02","expense",50,"food")],budgets:[budget("2026-01","food",100,null),budget("2026-02","food",0,null)]},
 "legacy-duplicate":{version:1,transactions:[tx("2026-01","expense",25,"food"),tx("2026-02","expense",50,"food")],budgets:[budget("2026-01","food",100,null),budget("2026-01","food",200,null),budget("2026-02","food",100,null)]},
 "legacy-mixed-currency":{version:1,transactions:[tx("2026-01","expense",10,"food"),tx("2026-01","expense",20,"food","JPY"),tx("2026-02","expense",30,"food")],budgets:[budget("2026-01","food",100,null)]},
 "legacy-empty-month":{version:1,transactions:[tx("2026-02","expense",20,"food")],budgets:[budget("2026-01","food",100,null)]},
 "invalid-outside-compared-months":{version:2,transactions:[tx("2026-01","expense",10,"food"),tx("2026-02","expense",20,"food"),tx("2025-03","expense",-1,"unrelated-invalid")],budgets:[]},
 "empty-explicit-currency":{version:2,transactions:[],budgets:[]}
};
const expected={
 schema:"household.independent_comparison_expectations.v1",
 frozen_before_candidate_read:true,
 producer:{repository:"Jacob-Met/household-ledger-mcp",commit:"591ab6f5a2d65bf596aeb707dbb635ee981ec926",git_blob:"2ff8133404f19c705eb7b7f0a943e8190f3328d6"},
 request:{firstMonth:"2026-01",secondMonth:"2026-02",currency:"USD"},
 delta_direction:"second minus first",
 scenarios:{
  "extreme-signed-deltas":{producer:"accept",consumer:"accept",netDeltaMinor:"-18014398509481982",remainingDeltaMinor:"-18014398509481982",incomeDeltaMinor:"-9007199254740991",expenseDeltaMinor:"9007199254740991",categories:["__proto__"],reverse:{netDeltaMinor:"18014398509481982",remainingDeltaMinor:"18014398509481982"}},
  "raw-category-union":{producer:"accept",consumer:"accept",first:{incomeMinor:1257,expenseMinor:250,netMinor:1007},second:{incomeMinor:1000,expenseMinor:325,netMinor:675},deltas:{incomeMinor:"-257",expenseMinor:"75",netMinor:"-332"},categories:[" food ",'<pantry & "quoted">',"budget-only","food","new-budget","salary","toString"],excludedCategories:["foreign-only"],budgets:{food:{firstPresent:true,firstLimitMinor:0,secondPresent:false,pairedDelta:null},"budget-only":{firstPresent:true,secondPresent:true,limitDeltaMinor:"200",remainingDeltaMinor:"200"},"new-budget":{firstPresent:false,secondPresent:true,secondLimitMinor:0,pairedDelta:null}}},
  "legacy-singleton":{producer:"accept",consumer:"accept",budgetCurrencyFieldAbsentBoth:true,contextualCurrency:"USD",budgetLimitDeltaMinor:"-100",budgetRemainingDeltaMinor:"-125",netDeltaMinor:"-25"},
  "legacy-duplicate":{producer:"accept",consumer:"refuse_ambiguity",beforeBudgetRows:2},
  "legacy-mixed-currency":{producer:"summary_refuses",consumer:"refuse_without_currency_prefilter"},
  "legacy-empty-month":{producer:"summary_refuses",consumer:"refuse_without_inferred_denomination"},
  "invalid-outside-compared-months":{producer:"validation_refuses",consumer:"refuse_whole_snapshot"},
  "empty-explicit-currency":{producer:"accept",consumer:"accept",categories:[],incomeDeltaMinor:"0",expenseDeltaMinor:"0",netDeltaMinor:"0",currency:"USD"}
 },
 cli_controls:{missing_input:"nonzero; no output created; do not synthesize empty ledger",existing_output:"nonzero; exact sentinel bytes, inode and mtime preserved",same_input_output:"nonzero; exact input bytes, inode and mtime preserved",new_output:"exclusive new destination; no world/group permission bits; input bytes and mtime preserved",admission_failure:"nonzero; no destination or success output",private_test_state:"all files authored in this exclusive directory, no live ledger or account access"},
 exclusions:["No author suite reuse","No rendered browser/keyboard/viewport testing; coordination owns those","No mutation of original producer or candidate implementation"]
};
const producer=fs.readFileSync(path.join(root,"producer/ledger.ts"));
assert(crypto.createHash("sha1").update("blob "+producer.length+"\0").update(producer).digest("hex")===expected.producer.git_blob,"producer byte pin");
const observations=[];
for(const [name,data] of Object.entries(fixtures)){
 write("fixtures/"+name+".json",data);
 const original=JSON.stringify(data);let validationError=null,summaries=[],summaryError=null;
 try{validateLedgerData(data)}catch(e){validationError={name:e.constructor.name,message:e.message}}
 if(!validationError)for(const month of [1,2]){
  try{summaries.push(monthlySummary(data,2026,month,"USD"))}catch(e){summaryError={month,name:e.constructor.name,message:e.message};break}
 }
 assert(JSON.stringify(data)===original,"producer mutation "+name);
 const want=expected.scenarios[name].producer;
 assert((want==="accept"&&!validationError&&!summaryError)||(want==="summary_refuses"&&!validationError&&summaryError)||(want==="validation_refuses"&&validationError),name+" producer admission mismatch");
 if(name==="extreme-signed-deltas"){
  assert(summaries[0].netMinor===MAX&&summaries[1].netMinor===-MAX,"extreme endpoints");
  assert(summaries[0].budgets[0].remainingMinor===MAX&&summaries[1].budgets[0].remainingMinor===-MAX,"remaining endpoints");
 }
 if(name==="legacy-duplicate")assert(summaries[0].budgets.length===2,"legacy duplicate was not producer-valid");
 if(name==="raw-category-union"){
  assert(summaries[0].incomeMinor===1257&&summaries[0].expenseMinor===250&&summaries[1].incomeMinor===1000&&summaries[1].expenseMinor===325,"union totals");
 }
 observations.push({fixture:name,validationError,summaryError,summaries});
}
write("expected.json",expected);
const receipt={schema:"household.independent_fixture_producer_receipt.v1",created_at:new Date().toISOString(),runtime:process.version,platform:process.platform,producer:{...expected.producer,bytes:producer.length,sha256:sha(producer)},candidate_inspected:false,application_writes:false,fixtures:observations};
write("producer-receipt.json",receipt);
const pinpaths=["expected.json","producer-receipt.json",...Object.keys(fixtures).map(x=>"fixtures/"+x+".json")];
write("fixture-manifest.json",{schema:"household.frozen_independent_fixtures.v1",files:pinpaths.map(p=>{const b=fs.readFileSync(path.join(root,p));return {path:p,bytes:b.length,sha256:sha(b)}})});
const git=(...args)=>execFileSync("git",["-C",root,...args],{encoding:"utf8"});
git("init","--quiet");git("config","user.name","HAMON independent receiver");git("config","user.email","hamon-receiver@invalid");
git("add","--","package.json","producer","freeze-fixtures.mjs","fixtures","expected.json","producer-receipt.json","fixture-manifest.json");
git("commit","--quiet","-m","Freeze independent month-pair fixtures against unchanged producer");
const result={root,commit:git("rev-parse","HEAD").trim(),producerGitBlob:expected.producer.git_blob,expectationsSha256:sha(fs.readFileSync(path.join(root,"expected.json"))),manifestSha256:sha(fs.readFileSync(path.join(root,"fixture-manifest.json"))),scenarios:observations.map(x=>({fixture:x.fixture,admission:x.validationError?"validation_refuses":x.summaryError?"summary_refuses":"accept"})),candidate_inspected:false};
write("fixture-freeze-result.json",result);
console.log(JSON.stringify(result));
