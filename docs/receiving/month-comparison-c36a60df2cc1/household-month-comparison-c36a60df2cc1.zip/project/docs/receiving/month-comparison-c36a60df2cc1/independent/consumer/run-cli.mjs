import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {fileURLToPath} from 'node:url';import {spawn,spawnSync} from 'node:child_process';
import {expected,sha,refusalPatterns,assertComparison} from './assert-comparison.mjs';
const root=path.dirname(fileURLToPath(import.meta.url)),out=root+'/evidence/cli-r2',cli=root+'/candidate/src/household-compare.js';
fs.mkdirSync(out,{mode:0o700});const observations=[];const oldUmask=process.umask(0);
const put=(p,b)=>fs.writeFileSync(p,b,{flag:'wx',mode:0o600});
const json=(p,x)=>put(p,JSON.stringify(x,null,2)+'\n');
const identity=p=>{const s=fs.statSync(p,{bigint:true});return {sha256:sha(fs.readFileSync(p)),bytes:Number(s.size),inode:String(s.ino),mtime_ns:String(s.mtimeNs),mode:Number(s.mode&0o777n)}};
const command=(input,output,reverse=false)=>[cli,'--ledger',input,'--first',reverse?'2026-02':'2026-01','--second',reverse?'2026-01':'2026-02','--currency','USD','--out',output];
function invoke(args){const r=spawnSync(process.execPath,args,{encoding:'utf8',timeout:20000});assert.ifError(r.error);assert.equal(r.signal,null);return {exit:r.status,stdout:r.stdout,stderr:r.stderr};}
function reportAt(p){const b=fs.readFileSync(p);const text=b.toString('utf8');const matches=[...text.matchAll(/<script\b[^>]*id="household-month-comparison-data"[^>]*>([\s\S]*?)<\/script>/g)];assert.equal(matches.length,1,'one machine-readable report');assert.equal(fs.statSync(p).mode&0o777,0o600,'private completed report despite umask000');return {report:JSON.parse(matches[0][1]),bytes:b.length,sha256:sha(b)};}
function retain(dir,r){put(dir+'/stdout.txt',r.stdout);put(dir+'/stderr.txt',r.stderr);}
try{
 for(const [name,want] of Object.entries(expected.scenarios)){
  for(const reverse of [false,...(want.reverse?[true]:[])]){
   const label=name+(reverse?'-reverse':''),dir=out+'/'+label;fs.mkdirSync(dir,{mode:0o700});
   const source=root+'/fixtures/'+name+'.json',inputBefore=identity(source),bytes=fs.readFileSync(source),output=dir+'/report.html';
   const args=command(source,output,reverse),r=invoke(args);retain(dir,r);assert.deepEqual(identity(source),inputBefore);
   let published=null;
   if(want.consumer==='accept'){
    assert.equal(r.exit,0,r.stderr);assert.equal(r.stderr,'');published=reportAt(output);assertComparison(name,published.report,bytes,reverse);
    assert.deepEqual(fs.readdirSync(dir).sort(),['report.html','stderr.txt','stdout.txt']);
   }else{
    assert.notEqual(r.exit,0);assert.match(r.stderr,refusalPatterns[name]);assert.equal(fs.existsSync(output),false);assert.equal(r.stdout,'');
    assert.deepEqual(fs.readdirSync(dir).sort(),['stderr.txt','stdout.txt']);
   }
   const item={case:label,pass:true,command:[process.execPath,...args],exit:r.exit,input_unchanged:true,output:published?{bytes:published.bytes,sha256:published.sha256,mode:'0600',net_delta:published.report.totals.change.netMinor}:null};
   json(dir+'/receipt.json',item);observations.push(item);
  }
 }
 for(const kind of ['missing-input','existing-output','same-input-output']){
  const dir=out+'/'+kind;fs.mkdirSync(dir,{mode:0o700});const source=dir+'/ledger.json';let output=dir+'/report.html',before=null,sentinel=null;
  if(kind!=='missing-input'){put(source,fs.readFileSync(root+'/fixtures/raw-category-union.json'));before=identity(source);}
  if(kind==='existing-output'){put(output,'existing privately authored report\n');sentinel=identity(output);}
  if(kind==='same-input-output')output=source;
  const args=command(source,output),r=invoke(args);assert.notEqual(r.exit,0);assert.equal(r.stdout,'');assert.match(r.stderr,/Comparison refused:/);
  if(before)assert.deepEqual(identity(source),before);
  if(sentinel)assert.deepEqual(identity(output),sentinel);
  if(kind==='missing-input')assert.deepEqual(fs.readdirSync(dir),[]);
  if(kind==='same-input-output')assert.deepEqual(fs.readdirSync(dir),['ledger.json']);
  if(kind==='existing-output')assert.deepEqual(fs.readdirSync(dir).sort(),['ledger.json','report.html']);
  retain(dir,r);const item={case:kind,pass:true,command:[process.execPath,...args],exit:r.exit,existing_source_unchanged:!!before,existing_output_unchanged:!!sentinel,no_owned_stage_left:true};json(dir+'/receipt.json',item);observations.push(item);
 }
 const raceDir=out+'/two-independent-processes';fs.mkdirSync(raceDir,{mode:0o700});const destination=raceDir+'/report.html';
 const fixtureNames=['odd-cross-bound-deltas','raw-category-union'];
 const inputs=fixtureNames.map(name=>root+'/fixtures/'+name+'.json'),identities=inputs.map(identity);
 const runAsync=args=>new Promise((resolve,reject)=>{const child=spawn(process.execPath,args,{timeout:20000});let stdout='',stderr='';child.stdout.on('data',b=>stdout+=b);child.stderr.on('data',b=>stderr+=b);child.on('error',reject);child.on('close',(exit,signal)=>{if(signal)reject(Error('child signal '+signal));else resolve({exit,stdout,stderr});});});
 const results=await Promise.all(inputs.map(input=>runAsync(command(input,destination))));
 assert.deepEqual(results.map(x=>x.exit).sort(),[0,1]);assert.deepEqual(fs.readdirSync(raceDir),['report.html']);
 const winner=results.findIndex(x=>x.exit===0),published=reportAt(destination);
 assertComparison(fixtureNames[winner],published.report,fs.readFileSync(inputs[winner]));
 inputs.forEach((p,i)=>assert.deepEqual(identity(p),identities[i]));
 results.forEach((r,i)=>{put(raceDir+'/process-'+i+'-stdout.txt',r.stdout);put(raceDir+'/process-'+i+'-stderr.txt',r.stderr);});
 const race={case:'two-independent-processes',pass:true,exits:results.map(x=>x.exit),winner_fixture:fixtureNames[winner],final_source_sha256:published.report.source.sha256,output_sha256:published.sha256,mode:'0600',both_inputs_unchanged:true,only_one_complete_output:true,no_owned_stages_left:true};
 json(raceDir+'/receipt.json',race);observations.push(race);
 const result={schema:'household.independent_actual_cli_receiving.v1',recorded_at:new Date().toISOString(),runtime:process.version,cli_sha256:sha(fs.readFileSync(cli)),domain_sha256:sha(fs.readFileSync(root+'/candidate/src/month-comparison.js')),frozen_expectations_sha256:sha(fs.readFileSync(root+'/expected.json')),cases:observations.length,passes:observations.length,observations,author_suite_rerun:false,umask_during_output_receiving:'000',application_input_bytes_unchanged:true,live_ledger_or_account_access:false};
 json(out+'/receipt.json',result);console.log(JSON.stringify({cases:result.cases,passes:result.passes,receipt:out+'/receipt.json',sha256:sha(fs.readFileSync(out+'/receipt.json')),cli_sha256:result.cli_sha256}));
}catch(e){json(out+'/receiver-failure.json',{recorded_at:new Date().toISOString(),error:String(e.stack),completed:observations});throw e;}finally{process.umask(oldUmask);}
