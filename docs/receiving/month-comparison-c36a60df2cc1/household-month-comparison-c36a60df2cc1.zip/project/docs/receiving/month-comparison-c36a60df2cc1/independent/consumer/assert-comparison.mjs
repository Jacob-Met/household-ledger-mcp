import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import assert from 'node:assert/strict';import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
export const expected=JSON.parse(fs.readFileSync(root+'/expected.json','utf8'));
export const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
export const refusalPatterns={
 'legacy-duplicate':/multiple native budget rows/,
 'legacy-mixed-currency':/monthly category budgets have no currency/,
 'legacy-empty-month':/monthly category budgets have no currency/,
 'invalid-outside-compared-months':/transaction.amountMinor must be a positive integer/
};
export function assertComparison(name,report,bytes,reverse=false){
 const want=expected.scenarios[name];
 assert.equal(want.consumer,'accept');
 assert.equal(report.schema,'household-ledger-month-comparison/1');
 assert.equal(report.direction,'second-minus-first');
 assert.equal(report.firstMonth,reverse?'2026-02':'2026-01');
 assert.equal(report.secondMonth,reverse?'2026-01':'2026-02');
 assert.equal(report.currency,'USD');
 assert.equal(report.source.bytes,bytes.length);
 assert.equal(report.source.sha256,sha(bytes));
 for(const value of Object.values(report.totals.change))assert.match(value,/^(?:0|-?[1-9]\d*)$/);
 for(const row of report.categories){
  for(const side of [row.first,row.second])for(const key of ['incomeMinor','expenseMinor','netMinor'])assert.ok(Number.isSafeInteger(side[key]));
  for(const [key,value] of Object.entries(row.change)){
   if(key.startsWith('budget')&&value===null)continue;
   assert.match(value,/^(?:0|-?[1-9]\d*)$/);
  }
 }
 if(want.categories)assert.deepEqual(report.categories.map(x=>x.category),[...want.categories].sort());
 if(name==='extreme-signed-deltas'||name==='odd-cross-bound-deltas'){
  const amounts=reverse?want.reverse:want;
  assert.equal(report.totals.change.netMinor,amounts.netDeltaMinor);
  assert.equal(report.categories[0].change.netMinor,amounts.netDeltaMinor);
  assert.equal(report.categories[0].change.budgetRemainingMinor,amounts.remainingDeltaMinor);
  if(!reverse){assert.equal(report.totals.change.incomeMinor,want.incomeDeltaMinor);assert.equal(report.totals.change.expenseMinor,want.expenseDeltaMinor);}
 }
 if(name==='raw-category-union'){
  assert.deepEqual(report.totals.first,want.first);assert.deepEqual(report.totals.second,want.second);assert.deepEqual(report.totals.change,want.deltas);
  const rows=new Map(report.categories.map(x=>[x.category,x]));
  for(const category of want.excludedCategories)assert.equal(rows.has(category),false);
  for(const [category,budget] of Object.entries(want.budgets)){
   const r=rows.get(category);assert.ok(r);
   assert.equal(r.first.budget!==null,budget.firstPresent);assert.equal(r.second.budget!==null,budget.secondPresent);
   if('firstLimitMinor'in budget)assert.equal(r.first.budget.limitMinor,budget.firstLimitMinor);
   if('secondLimitMinor'in budget)assert.equal(r.second.budget.limitMinor,budget.secondLimitMinor);
   if(budget.pairedDelta===null)for(const key of ['budgetLimitMinor','budgetSpentMinor','budgetRemainingMinor'])assert.equal(r.change[key],null);
   if('limitDeltaMinor'in budget)assert.equal(r.change.budgetLimitMinor,budget.limitDeltaMinor);
   if('remainingDeltaMinor'in budget)assert.equal(r.change.budgetRemainingMinor,budget.remainingDeltaMinor);
  }
  assert.notEqual(rows.get('food'),rows.get(' food '));assert.equal(rows.get('toString').first.incomeMinor,7);
 }
 if(name==='legacy-singleton'){
  const r=report.categories[0];
  assert.equal(report.totals.change.netMinor,want.netDeltaMinor);
  for(const side of [r.first,r.second])assert.equal(Object.hasOwn(side.budget,'currency'),false);
  assert.equal(r.change.budgetLimitMinor,want.budgetLimitDeltaMinor);
  assert.equal(r.change.budgetRemainingMinor,want.budgetRemainingDeltaMinor);
 }
 if(name==='empty-explicit-currency'){
  assert.deepEqual(report.categories,[]);
  assert.deepEqual(report.totals.first,{incomeMinor:0,expenseMinor:0,netMinor:0});
  assert.deepEqual(report.totals.second,{incomeMinor:0,expenseMinor:0,netMinor:0});
  assert.deepEqual(report.totals.change,{incomeMinor:'0',expenseMinor:'0',netMinor:'0'});
 }
}
