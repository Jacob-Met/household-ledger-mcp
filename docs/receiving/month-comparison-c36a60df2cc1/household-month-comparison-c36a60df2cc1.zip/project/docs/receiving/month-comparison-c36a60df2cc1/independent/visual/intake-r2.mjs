import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
const own=path.dirname(new URL(import.meta.url).pathname),source='/tmp/c36a60df2cc1-household-compare/worktree';
const hash=b=>createHash('sha256').update(b).digest('hex');
const expected={'dist/src/ledger.js':['8e80c26b8f68767f80d87bc79a41ff0711f5996dffe5652ef859c4ecef3ac48a',15698],'dist/src/month-comparison.js':['559d998d069d2f234435c4c9db8410193267f38cfcb4ca8867b1d537cd99c5f2',16886],'dist/src/household-compare.js':['40828c23fdc295d21ff4ec16500e93cade1d527268aa316b5a17e1d33dfdcb9c',6446],'package.json':['ac1ca2cd7d921bc88e6c54ef854b9650cc7e683318ace579f386b113809c8835',703]};
const report={recorded_at:new Date().toISOString(),source,files:[]};
for(const [name,pin] of Object.entries(expected)){const b=fs.readFileSync(path.join(source,name));if(hash(b)!==pin[0]||b.length!==pin[1])throw Error('candidate pin mismatch '+name);const out=path.join(own,'candidate-r2',name);fs.mkdirSync(path.dirname(out),{recursive:true});fs.writeFileSync(out,b,{flag:'wx'});if(!fs.readFileSync(path.join(source,name)).equals(b))throw Error('source moved '+name);report.files.push({path:name,bytes:b.length,sha256:hash(b),copy_sha256:hash(fs.readFileSync(out))});}
fs.writeFileSync(path.join(own,'candidate-r2-intake.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});
