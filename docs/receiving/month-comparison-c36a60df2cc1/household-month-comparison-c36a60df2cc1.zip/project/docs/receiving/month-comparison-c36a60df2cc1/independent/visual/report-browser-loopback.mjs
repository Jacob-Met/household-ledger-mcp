import {spawn,spawnSync} from 'node:child_process';
import {createServer} from 'node:http';
import {createHash} from 'node:crypto';
import fs from 'node:fs';
import {promises as fsp} from 'node:fs';
import path from 'node:path';
import {once} from 'node:events';
import {fileURLToPath,pathToFileURL} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const round=process.argv[2]||'r1';
if(!/^[a-z0-9-]+$/.test(round))throw Error('simple unique round required');
const output=path.join(root,round);
fs.mkdirSync(output);
const fixtures=JSON.parse(fs.readFileSync(path.join(root,'fixtures.json'),'utf8'));
const expected=JSON.parse(fs.readFileSync(path.join(root,'expected.json'),'utf8'));
const hash=b=>createHash('sha256').update(b).digest('hex');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const report={schema:'household.month-comparison.independent-browser.v1',started_at:new Date().toISOString(),round,
driver_sha256:hash(fs.readFileSync(fileURLToPath(import.meta.url))),frozen_cases_commit:'7fb753c10a2e87f87772e787a19d5d49da2609e7',
runtime:{node:process.version,platform:process.platform,chrome:'/snap/bin/chromium'},
generated:[],checks:[],assertions:0,requests:[],page_errors:[],artifacts:[],cleanup:{},
scope:'Actual revised candidate CLI and isolated native Chromium rendering, keyboard, accessibility structure and print. Exact saved HTML is delivered by an ephemeral127.0.0.1-only fixture server because Snap did not open host/tmp file URLs. Page requests outside that origin are blocked; offline appearance is checked after document delivery. No direct-file, unit-suite, live-service or browser-wide network-isolation claim.'};
const snapshot=()=>['fixtures.json','expected.json','plan.json','candidate-r2/package.json','candidate-r2/dist/src/ledger.js','candidate-r2/dist/src/month-comparison.js','candidate-r2/dist/src/household-compare.js'].map(name=>{const b=fs.readFileSync(path.join(root,name));return {path:name,bytes:b.length,sha256:hash(b)}});
report.source_before=snapshot();
function check(ok,label,actual){report.assertions++;if(!ok)throw Error(label+(actual===undefined?'':'\n'+JSON.stringify(actual)));}
async function group(name,fn){
const g={name,started_at:new Date().toISOString(),before:report.assertions};
try{g.observed=await fn();g.status='PASS';}catch(e){g.status='FAIL';g.error=e.stack||String(e);}
g.assertions=report.assertions-g.before;delete g.before;g.completed_at=new Date().toISOString();report.checks.push(g);
}
function artifact(name,b){fs.writeFileSync(path.join(output,name),b,{flag:'wx',mode:0o600});const r={name,bytes:b.length,sha256:hash(b)};report.artifacts.push(r);return r;}
function command(exe,args){const p=spawnSync(exe,args,{cwd:root,encoding:'utf8',timeout:30000,maxBuffer:4*1024*1024});return {command:[exe,...args],code:p.status,signal:p.signal,stdout:p.stdout,stderr:p.stderr,error:p.error?String(p.error):null};}
async function until(fn,label,timeout=12000){const end=Date.now()+timeout;while(Date.now()<end){const v=await fn();if(v)return v;await sleep(60);}throw Error('Timed out: '+label);}
let browser,browserClosed=false,cdp,session,profile,chromeOut='',chromeErr='',socket;
class CDP{
constructor(ws){this.ws=ws;this.id=0;this.pending=new Map();ws.addEventListener('message',event=>{const msg=JSON.parse(event.data);if(msg.id){const p=this.pending.get(msg.id);if(!p)return;clearTimeout(p.timer);this.pending.delete(msg.id);msg.error?p.reject(Error(p.method+': '+JSON.stringify(msg.error))):p.resolve(msg.result);}else if(msg.method==='Network.requestWillBeSent'){const u=msg.params.request.url;report.requests.push({url:u.length>300?u.slice(0,100)+'[TRUNCATED]':u,url_bytes:u.length,type:msg.params.type});}else if(msg.method==='Runtime.exceptionThrown'){report.page_errors.push(msg.params.exceptionDetails);}else if(msg.method==='Fetch.requestPaused'){const u=msg.params.request.url;const allow=fixtureOrigin&&new URL(u).origin===fixtureOrigin; if(!allow)report.blocked_page_requests.push(u);this.send(allow?'Fetch.continueRequest':'Fetch.failRequest',{requestId:msg.params.requestId,...(allow?{}:{errorReason:'BlockedByClient'})},msg.sessionId).catch(e=>{report.fetch_error=String(e);});}});}
send(method,params={},sessionId){const id=++this.id;return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{this.pending.delete(id);reject(Error('CDP timeout '+method));},15000);this.pending.set(id,{resolve,reject,timer,method});this.ws.send(JSON.stringify({id,method,params,...(sessionId?{sessionId}:{})}));});}}
const page=(method,params={})=>cdp.send(method,params,session);
async function evaluate(expression){const r=await page('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error('Page evaluation '+JSON.stringify(r.exceptionDetails));return r.result.value;}
async function navigate(doc){const url=fixtureOrigin+'/'+doc.name+'.html';const result=await page('Page.navigate',{url});report.navigations.push({name:doc.name,url,result});if(result.errorText)throw Error('Fixture navigation '+result.errorText);await until(()=>evaluate('location.href==='+JSON.stringify(url)+'&&document.readyState==="complete"&&!!document.getElementById("household-month-comparison-data")'),'saved report '+doc.name);}
async function key(key,code,n){await page('Input.dispatchKeyEvent',{type:'keyDown',key,code,windowsVirtualKeyCode:n});await page('Input.dispatchKeyEvent',{type:'keyUp',key,code,windowsVirtualKeyCode:n});}
async function screenshot(name,selector){if(selector)await evaluate('document.querySelector('+JSON.stringify(selector)+').scrollIntoView({block:"start"})');await sleep(80);const p=await page('Page.captureScreenshot',{format:'png',fromSurface:true});return artifact(name,Buffer.from(p.data,'base64'));}
const signed=n=>n>0?'+'+String(n):String(n);
const digits=a=>a.map((n,i)=>i===2?signed(n):String(n));
function saveJSON(name,v){return artifact(name,Buffer.from(JSON.stringify(v,null,2)+'\n'));}
const docs={};let fixtureServer,fixtureOrigin;
report.fixture_requests=[];report.blocked_page_requests=[];report.navigations=[];

try{
const space=fs.statfsSync(root);report.available_bytes_before=space.bavail*space.bsize;check(report.available_bytes_before>128*1024*1024,'128MiB available before browser');
for(const [name,data] of Object.entries(fixtures.cases)){
const inputName=name==='hostile_wide'?'<source>&".json':name+'.json';
const input=path.join(output,inputName),dest=path.join(output,name+'.html');
const bytes=Buffer.from(JSON.stringify(data,null,2)+'\n');fs.writeFileSync(input,bytes,{flag:'wx',mode:0o600});
const stat=fs.statSync(input);
const run=command(process.execPath,[path.join(root,'candidate-r2/dist/src/household-compare.js'),'--ledger',input,'--first',fixtures.first,'--second',fixtures.second,'--currency',fixtures.currency,'--out',dest]);
report.generated.push({name,input:inputName,input_sha256:hash(bytes),input_bytes:bytes.length,command:run});
check(run.code===0&&run.stderr==='',name+' actual candidate CLI creates report',run);
const html=fs.readFileSync(dest);const doc={name,path:dest,input,input_bytes:bytes,input_stat:{ino:stat.ino,mtimeMs:stat.mtimeMs},source_sha256:hash(bytes),source_bytes:bytes.length,html_sha256:hash(html),html_bytes:html.length};
docs[name]=doc;Object.assign(report.generated.at(-1),{html:path.basename(dest),html_bytes:html.length,html_sha256:doc.html_sha256});
const original=fs.readFileSync(path.join(root,'r1',name+'.html'),'utf8'),current=html.toString('utf8');
const extract=s=>JSON.parse(s.match(/<script id="household-month-comparison-data" type="application\/json">([\s\S]*?)<\/script>/)[1]);
const prior=extract(original),next=extract(current),priorTime=prior.generatedAt,nextTime=next.generatedAt;
delete prior.generatedAt;delete next.generatedAt;
const oldCount=original.split(priorTime).length-1,newCount=current.split(nextTime).length-1;
check(oldCount===2&&newCount===2&&JSON.stringify(prior)===JSON.stringify(next)&&original.replaceAll(priorTime,'<GENERATED_AT>')===current.replaceAll(nextTime,'<GENERATED_AT>'),'Final CLI preserves all report bytes except two generatedAt occurrences: '+name);
report.generated.at(-1).r1_comparison={prior_sha256:hash(Buffer.from(original)),prior_generatedAt:priorTime,new_generatedAt:nextTime,prior_timestamp_occurrences:oldCount,new_timestamp_occurrences:newCount,remaining_json_and_normalized_html_exact:true};
}
fixtureServer=createServer((req,res)=>{const name=Object.keys(docs).find(n=>req.url==='/'+n+'.html');if(req.method!=='GET'||!name){report.fixture_requests.push({method:req.method,url:req.url,status:404});res.writeHead(404);res.end();return;}const b=fs.readFileSync(docs[name].path);if(hash(b)!==docs[name].html_sha256){res.writeHead(409);res.end();return;}report.fixture_requests.push({method:req.method,url:req.url,status:200,bytes:b.length,sha256:hash(b)});res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Content-Length':String(b.length),'Cache-Control':'no-store'});res.end(b);});fixtureServer.listen(0,'127.0.0.1');await once(fixtureServer,'listening');fixtureOrigin='http://127.0.0.1:'+fixtureServer.address().port;report.fixture_origin=fixtureOrigin;
profile=fs.mkdtempSync(path.join('/tmp','c36a-household-chromium-'));
report.profile=profile;
const args=['--headless=new','--remote-debugging-port=0','--remote-debugging-address=127.0.0.1','--user-data-dir='+profile,'--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-component-update','--disable-sync','--disable-default-apps','--disable-breakpad','--metrics-recording-only','--disable-features=Translate','about:blank'];
report.browser_command=['/snap/bin/chromium',...args];
browser=spawn('/snap/bin/chromium',args,{stdio:['ignore','pipe','pipe']});
browser.once('close',(code,signal)=>{browserClosed=true;report.browser_exit={code,signal};});
browser.stdout.on('data',b=>{chromeOut+=b.toString();});browser.stderr.on('data',b=>{chromeErr+=b.toString();});
browser.once('error',e=>{report.browser_spawn_error=String(e);browserClosed=true;});
const address=await until(()=>{const m=chromeErr.match(/DevTools listening on (ws:\/\/[^\s]+)/);if(m)return m[1];if(browserClosed)throw Error('Chromium closed before debugger: '+chromeErr);return false;},'fresh Chromium debugger',20000);
socket=new WebSocket(address);await once(socket,'open');cdp=new CDP(socket);
report.runtime.browser=await cdp.send('Browser.getVersion');
const target=await cdp.send('Target.createTarget',{url:'about:blank'});session=(await cdp.send('Target.attachToTarget',{targetId:target.targetId,flatten:true})).sessionId;
await page('Page.enable');await page('Runtime.enable');await page('Network.enable');await page('Accessibility.enable');
await page('Fetch.enable',{patterns:[{urlPattern:'http://*'},{urlPattern:'https://*'}]});
await page('Network.emulateNetworkConditions',{offline:false,latency:0,downloadThroughput:-1,uploadThroughput:-1});
await page('Emulation.setDeviceMetricsOverride',{width:1365,height:1100,deviceScaleFactor:1,mobile:false});
await group('Actual saved report: visible selection, exact totals, union and budget presence',async()=>{
await navigate(docs.primary);
const state=await evaluate('(()=>{const rows=s=>[...document.querySelectorAll(s+" tbody tr")].map(r=>[...r.cells].map(c=>c.textContent));return {title:document.querySelector("h1").textContent,context:document.querySelector(".context").textContent,totals:rows(".scroll table"),categories:rows(".category-table"),budgets:rows(".budget-table"),record:JSON.parse(document.getElementById("household-month-comparison-data").textContent),body:document.body.textContent,scripts:[...document.scripts].map(s=>({type:s.type,id:s.id,src:s.src})),width:innerWidth,pageWidth:document.documentElement.scrollWidth};})()');
check(state.title==='Compare household months','Main title');
for(const text of [fixtures.first,fixtures.second,fixtures.currency,'Change = second minus first.','exact integer minor units',docs.primary.source_sha256,String(docs.primary.source_bytes)])check(state.context.includes(text),'Visible context retains '+text);
for(const [i,k] of ['income','expense','net'].entries())check(JSON.stringify(state.totals[i].slice(1))===JSON.stringify(digits(expected.primary.summary[k])),'Visible '+k+' values and signed change',state.totals[i]);
const union=[...new Set([...expected.primary.categories,...expected.primary.first_only_zero_budgets,expected.primary.second_only_budget])].sort();
check(JSON.stringify(state.categories.map(r=>r[0]).sort())===JSON.stringify(union),'Complete transaction and budget category union',state.categories.map(r=>r[0]));
const food=state.categories.find(r=>r[0]==='Groceries');
check(JSON.stringify(food.slice(1))===JSON.stringify(['0','100','+100','1250','1400','+150','-1250','-1300','-50']),'Groceries income, expense and net retain direction',food);
const budget=name=>state.budgets.find(r=>r[0]===name);
check(JSON.stringify(budget('Groceries').slice(3))===JSON.stringify(['+300','+150','+150']),'Visible grocery budget deltas',budget('Groceries'));
check(budget('Zero only')[1].includes('Limit0')&&budget('Zero only')[2]==='Absent'&&budget('Zero only').slice(3).every(v=>v==='Not comparable'),'Explicit zero budget differs from absence',budget('Zero only'));
check(budget('October only')[1]==='Absent'&&budget('October only')[2].includes('Limit400'),'Second-only budget remains visible',budget('October only'));
for(const absent of expected.primary.excluded)check(!state.body.includes(absent),'Private/unselected text excluded: '+absent);
check(state.scripts.length===1&&state.scripts[0].type==='application/json'&&state.scripts[0].id==='household-month-comparison-data'&&state.scripts[0].src==='','Only inert JSON script exists',state.scripts);
check(state.pageWidth<=state.width+1,'Desktop page contains its tables',state);
saveJSON('primary-dom.json',state);delete state.body;return {...state,screenshot:await screenshot('desktop-primary.png')};
});
await group('Exact hostile labels and wide numbers remain inert browser text',async()=>{
await navigate(docs.hostile_wide);
const state=await evaluate('({labels:[...document.querySelectorAll(".category")].map(e=>e.textContent),context:document.querySelector(".context").textContent,rows:[...document.querySelectorAll(".category-table tbody tr")].map(r=>[...r.cells].map(c=>c.textContent)),images:document.images.length,frames:document.querySelectorAll("iframe,object,embed").length,pwned:globalThis.COMPARISON_PWNED??null,scripts:[...document.scripts].map(s=>({type:s.type,id:s.id,src:s.src})),json:JSON.parse(document.getElementById("household-month-comparison-data").textContent)})');
check(state.labels.length===2&&state.labels.every(t=>t===expected.hostile_wide.exact_category),'Raw spaces, CR/LF/tab and Unicode preserved in both label consumers',state.labels);
check(state.context.includes('<source>&".json'),'Hostile source basename is literal text');
check(state.images===0&&state.frames===0&&state.pwned===null&&state.scripts.length===1&&state.scripts[0].type==='application/json','Hostile text creates no executable or external element',state);
check(JSON.stringify(state.rows[0].slice(4,7))===JSON.stringify(digits(expected.hostile_wide.expense)),'Wide exact expense values remain complete strings',state.rows[0]);
saveJSON('hostile-dom.json',state);return state;
});
await group('390px containment, actual keyboard scrolling and accessibility structure',async()=>{
await page('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true});await navigate(docs.hostile_wide);
const layout=await evaluate('({width:innerWidth,document:document.documentElement.scrollWidth,body:document.body.scrollWidth,regions:[...document.querySelectorAll(".scroll")].map(e=>({client:e.clientWidth,scroll:e.scrollWidth,tabIndex:e.tabIndex,role:e.getAttribute("role"),label:e.getAttribute("aria-label")}))})');
check(layout.width===390&&layout.document<=391&&layout.body<=391,'No horizontal page overflow at390px',layout);
check(layout.regions.length===3&&layout.regions.every(r=>r.tabIndex===0&&r.role==='region'&&r.label),'Every scroll region is named and keyboard reachable',layout);
const keyboard=[];
for(const selector of ['.category-table','.budget-table']){
for(let n=0;n<10;n++){if(await evaluate('document.activeElement===document.querySelector('+JSON.stringify(selector)+').parentElement'))break;await key('Tab','Tab',9);}
check(await evaluate('document.activeElement===document.querySelector('+JSON.stringify(selector)+').parentElement'),'Native Tab reaches '+selector);
const before=await evaluate('document.activeElement.scrollLeft');for(let n=0;n<6;n++)await key('ArrowRight','ArrowRight',39);await sleep(180);
const after=await evaluate('document.activeElement.scrollLeft');check(after>before&&(await evaluate('scrollX'))===0,'Native ArrowRight scrolls only '+selector,{before,after});keyboard.push({selector,before,after});
}
const ax=await page('Accessibility.getFullAXTree');saveJSON('mobile-accessibility.json',ax);
const roles=ax.nodes.filter(n=>!n.ignored).map(n=>({role:n.role?.value,name:n.name?.value}));
check(roles.filter(n=>n.role==='region'&&n.name).length>=3,'Accessibility tree exposes three named regions',roles.filter(n=>n.role==='region'));
check(roles.some(n=>n.role==='columnheader'&&String(n.name).includes('Change')),'Accessibility tree exposes change headers');
await navigate(docs.primary);
return {layout,keyboard,accessibility:{named_regions:roles.filter(n=>n.role==='region'),column_headers:roles.filter(n=>n.role==='columnheader')},screenshots:[await screenshot('mobile-primary-top.png'),await screenshot('mobile-primary-budgets.png','.budget-table')]};
});
await group('Legacy denomination remains distinct in the visible budget report',async()=>{
await page('Emulation.setDeviceMetricsOverride',{width:1365,height:1100,deviceScaleFactor:1,mobile:false});await navigate(docs.legacy);
const state=await evaluate('({row:[...document.querySelector(".budget-table tbody tr").cells].map(c=>c.textContent),record:JSON.parse(document.getElementById("household-month-comparison-data").textContent)})');
check(state.row[1].includes('Legacy budget: stored currency absent; native USD month context')&&state.row[2].includes('Legacy budget: stored currency absent; native USD month context'),'Both admitted legacy contexts are explicit',state.row);
check(JSON.stringify(state.row.slice(3))===JSON.stringify(['-100','+15','-115']),'Visible legacy deltas exact',state.row);
check(state.row[2].includes('Limit0')&&!state.row[2].includes('Absent'),'Stored zero is present in legacy view');
return {...state,screenshot:await screenshot('legacy-budgets.png','.budget-table')};
});
await group('Actual tagged PDF preserves rows, direction, wide provenance and private boundaries',async()=>{
await page('Emulation.setDeviceMetricsOverride',{width:1100,height:1400,deviceScaleFactor:1,mobile:false});await navigate(docs.primary);await page('Emulation.setEmulatedMedia',{media:'print'});
const layout=await evaluate('({print:matchMedia("print").matches,regions:[...document.querySelectorAll(".scroll")].map(e=>getComputedStyle(e).overflowX),header:getComputedStyle(document.querySelector("thead")).display})');
check(layout.print&&layout.regions.every(v=>v==='visible')&&layout.header==='table-header-group','Print exposes full tables and repeating headers',layout);
const printed=await page('Page.printToPDF',{printBackground:true,displayHeaderFooter:false,paperWidth:8.27,paperHeight:11.69,marginTop:0.35,marginBottom:0.35,marginLeft:0.35,marginRight:0.35,generateTaggedPDF:true});
const bytes=Buffer.from(printed.data,'base64');check(bytes.subarray(0,5).toString()==='%PDF-'&&/%%EOF\s*$/.test(bytes.subarray(-100).toString()),'Complete saved PDF');
artifact('primary.pdf',bytes);
const extracted=command('/usr/bin/pdftotext',['-layout',path.join(output,'primary.pdf'),path.join(output,'primary-pdf.txt')]);
check(extracted.code===0&&extracted.stderr==='','Poppler reads actual saved PDF',extracted);
const text=fs.readFileSync(path.join(output,'primary-pdf.txt'),'utf8');
for(const s of ['Compare household months','2026-09','2026-10','300000','310100','10100','198275','202850','4575','Groceries','Zero only','October only','Not comparable'])check(text.includes(s),'Printed output retains '+s);
check(text.replace(/\s/g,'').includes(docs.primary.source_sha256),'Printed source SHA is complete');
for(const s of expected.primary.excluded)check(!text.includes(s),'Printed output excludes '+s);
const pages=text.split('\f').filter(t=>t.trim()).length;check(pages>=1&&pages<=5,'Bounded complete print page count',pages);
const rendered=command('/usr/bin/pdftoppm',['-png','-r','90',path.join(output,'primary.pdf'),path.join(output,'primary-print')]);
check(rendered.code===0&&rendered.stderr==='','Render actual printed pages for visual inspection',rendered);
for(const name of fs.readdirSync(output).filter(n=>/^primary-print-\d+\.png$/.test(n))){const b=fs.readFileSync(path.join(output,name));report.artifacts.push({name,bytes:b.length,sha256:hash(b)});}
await page('Emulation.setEmulatedMedia',{media:''});return {layout,pages,pdf_bytes:bytes.length,text_sha256:hash(Buffer.from(text)),extract:extracted,render:rendered};
});
await group('Empty saved comparison stays complete with scripts disabled and offline after fixture delivery',async()=>{
await page('Emulation.setScriptExecutionDisabled',{value:true});await navigate(docs.empty);await page('Network.emulateNetworkConditions',{offline:true,latency:0,downloadThroughput:-1,uploadThroughput:-1});
const state=await evaluate('({body:document.body.textContent,empty:[...document.querySelectorAll(".empty")].map(e=>e.textContent),rows:[...document.querySelectorAll("table tbody tr")].map(r=>[...r.cells].map(c=>c.textContent)),scripts:[...document.scripts].map(s=>s.type)})');
check(state.body.includes(fixtures.first)&&state.body.includes(fixtures.second)&&state.body.includes('Currency: USD'),'Disabled-JS report retains explicit selection');
check(state.rows.length===3&&state.rows.every(r=>r.slice(1).every(v=>v==='0')),'Empty month values render without JavaScript',state.rows);
check(state.empty.some(t=>t.includes('No selected transactions or qualified budgets'))&&state.empty.some(t=>t.includes('No qualified budget rows')),'Empty data is described as recorded selection, not account completeness',state.empty);
await page('Emulation.setScriptExecutionDisabled',{value:false});return {...state,screenshot:await screenshot('empty-offline.png')};
});
await group('Offline and unchanged source/input/output custody',async()=>{
check(report.requests.filter(r=>/^https?:/.test(r.url)&&new URL(r.url).origin!==fixtureOrigin).length===0&&report.blocked_page_requests.length===0,'No report attempted a request outside the fixture origin',{requests:report.requests,blocked:report.blocked_page_requests});
check(report.page_errors.length===0,'No page errors',report.page_errors);
for(const doc of Object.values(docs)){const st=fs.statSync(doc.input);check(fs.readFileSync(doc.input).equals(doc.input_bytes)&&st.ino===doc.input_stat.ino&&st.mtimeMs===doc.input_stat.mtimeMs,'Synthetic input bytes/inode/mtime unchanged: '+doc.name);check(hash(fs.readFileSync(doc.path))===doc.html_sha256,'HTML unchanged after viewing/print: '+doc.name);}
check(JSON.stringify(snapshot())===JSON.stringify(report.source_before),'Exact source and frozen oracles unchanged');
return {documents:Object.keys(docs).length,requests:report.requests};
});
report.status=report.checks.some(g=>g.status==='FAIL')?'FAIL':'PASS';
}catch(e){report.status='SETUP_OR_EXECUTION_FAILED';report.error=e.stack||String(e);process.exitCode=1;}
finally{
if(cdp){try{await cdp.send('Browser.close');}catch(e){report.cleanup.close_note=String(e);}try{socket.close();}catch{}}
if(browser&&!browserClosed){await Promise.race([once(browser,'close'),sleep(1500)]);if(!browserClosed){browser.kill('SIGTERM');await Promise.race([once(browser,'close'),sleep(1500)]);}if(!browserClosed){browser.kill('SIGKILL');await Promise.race([once(browser,'close'),sleep(1500)]);}}
report.cleanup.browser_closed=!browser||browserClosed;
if(profile){try{await fsp.rm(profile,{recursive:true,force:true,maxRetries:2,retryDelay:100});report.cleanup.requested_profile_removed=!fs.existsSync(profile);}catch(e){report.cleanup.profile_error=String(e);report.status='FAIL';}}
if(fixtureServer){await new Promise(resolve=>fixtureServer.close(resolve));report.cleanup.fixture_server_closed=true;}
artifact('chromium-stdout.log',Buffer.from(chromeOut));artifact('chromium-stderr.log',Buffer.from(chromeErr));
report.source_after=snapshot();report.source_unchanged=JSON.stringify(report.source_before)===JSON.stringify(report.source_after);
if(!report.source_unchanged)report.status='FAIL';
report.completed_at=new Date().toISOString();report.passed_groups=report.checks.filter(g=>g.status==='PASS').length;report.failed_groups=report.checks.filter(g=>g.status==='FAIL').length;
if(report.status!=='PASS')process.exitCode=1;
const bytes=Buffer.from(JSON.stringify(report,null,2)+'\n');fs.writeFileSync(path.join(output,'receipt.json'),bytes,{flag:'wx'});
fs.writeFileSync(path.join(root,round+'-summary.json'),JSON.stringify({status:report.status,passed_groups:report.passed_groups,failed_groups:report.failed_groups,assertions:report.assertions,receipt:path.join(output,'receipt.json'),receipt_sha256:hash(bytes),error:report.error,cleanup:report.cleanup},null,2)+'\n',{flag:'wx'});
}
