import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const root=path.dirname(new URL(import.meta.url).pathname);
const hash=b=>createHash('sha256').update(b).digest('hex');
const commands=[];
function run(args){const r=spawnSync('git',args,{cwd:root,encoding:'utf8'});commands.push({args,code:r.status,stdout:r.stdout,stderr:r.stderr});if(r.status!==0)throw new Error('git failed '+args[0]);return r.stdout.trim();}
let record={recorded_at:new Date().toISOString(),candidate_seen:false,files:[],commands};
try{
for(const name of ['fixtures.json','expected.json','plan.json']){const b=fs.readFileSync(path.join(root,name));JSON.parse(b);record.files.push({path:name,bytes:b.length,sha256:hash(b)});}
run(['init','.']); run(['remote','add','origin','https://github.com/Jacob-Met/household-ledger-mcp.git']);
run(['add','--','fixtures.json','expected.json','plan.json','freeze.mjs']);
run(['commit','-m','Freeze independent month-comparison report receiving cases']);
record.commit=run(['rev-parse','HEAD']);record.tree=run(['rev-parse','HEAD^{tree}']);record.status='FROZEN_BEFORE_CANDIDATE';
}catch(e){record.status='SETUP_FAILED';record.error=String(e);process.exitCode=1;}
fs.writeFileSync(path.join(root,'freeze-receipt.json'),JSON.stringify(record,null,2)+'\n',{flag:'wx'});
