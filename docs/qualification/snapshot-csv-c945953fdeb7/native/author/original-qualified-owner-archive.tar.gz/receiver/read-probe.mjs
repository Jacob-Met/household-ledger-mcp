import { promises as fs } from "node:fs";
import { createHash } from "node:crypto";
const target=process.env.ROOT_EXPORT_PROBE_TARGET;
const replacement=process.env.ROOT_EXPORT_PROBE_REPLACEMENT;
const log=process.env.ROOT_EXPORT_PROBE_LOG;
if(!target||!replacement||!log)throw Error("Owned receiver probe paths required");
const read=fs.readFile.bind(fs);
let count=0;
fs.readFile=async function(path,...options){
  const bytes=await read(path,...options);
  if(String(path)!==target)return bytes;
  count++;
  const event={read:count,readSha256:createHash("sha256").update(bytes).digest("hex"),returnedOriginalBytes:true};
  if(count===1){
    const next=await read(replacement);
    const staging=target+".observer-replacement";
    await fs.writeFile(staging,next,{flag:"wx"});await fs.rename(staging,target);
    event.receiverReplacementSha256=createHash("sha256").update(next).digest("hex");
  }
  await fs.appendFile(log,JSON.stringify(event)+"\n");
  return bytes;
};
