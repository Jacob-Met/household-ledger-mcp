import pathlib,json,hashlib,datetime
p=pathlib.Path("/Users/me/hamon-household-export-receiving-7a9310dad255")
r=json.loads((p/"candidate-run/receipt.json").read_text())
b=json.loads((p/"baseline-run/receipt.json").read_text())
e=json.loads((p/"candidate-execution.json").read_text())
assert r["outcome"]==b["outcome"]=="passed"
assert e["exitCode"]==0 and not e["timeout"] and e["stderrBytes"]==0
assert r["calls"]==64 and len(r["deliveries"])==19 and len(r["groups"])==8
assert r["sourceEntries"]==181 and b["sourceEntries"]==163
assert r["sourceAndCompiledUnchanged"] and b["sourceAndCompiledUnchanged"]
assert all(g["outcome"]=="passed" for g in r["groups"])
freeze=json.loads((p/"runner-freeze.json").read_text())
for entry in freeze["files"]:
 raw=(p/entry["path"]).read_bytes()
 assert len(raw)==entry["bytes"] and hashlib.sha256(raw).hexdigest()==entry["sha256"],entry["path"]
for delivery in r["deliveries"]:
 raw=(p/"candidate-run"/delivery["path"]).read_bytes()
 assert len(raw)==delivery["bytes"] and hashlib.sha256(raw).hexdigest()==delivery["sha256"],delivery["path"]
rows=[]
for i in range(2305):
 rows.append({"id":"A"+str(i).zfill(5),"type":"expense" if i%2 else "income","amountMinor":i+1,"currency":"USD" if i%3 else "EUR","date":"2026-10-"+str(i%28+1).zfill(2),"category":"Needle" if i in [0,1000,5000] else "Bulk","note":"row "+str(i),"createdAt":"2026-10-01T00:00:00.000Z"})
original=(json.dumps({"version":2,"transactions":rows,"budgets":[]},ensure_ascii=False,indent=2)+"\n").encode()
expected=r["groups"][-1]["reads"][0]["readSha256"]
assert hashlib.sha256(original).hexdigest()==expected
with (p/"candidate-run/single-snapshot/reconstructed-initial-ledger.json").open("xb") as f:f.write(original)
receipt_raw=(p/"candidate-run/receipt.json").read_bytes()
accepted={"format":"independent-household-export-acceptance/v1","accepted_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"source_tree":"81aeb4162cf6d793093f920ac7ca03a520169258","source_files":103,"compiled_files":78,"unrelated_parent_files_exact":92,"baseline_calls":9,"candidate_groups":8,"candidate_calls":64,"client_saved_csvs":19,"actual_private_server_processes":len(r["servers"]),"receiver_exit":e["exitCode"],"receiver_elapsed_seconds":e["elapsedSeconds"],"receiver_stderr_bytes":e["stderrBytes"],"source_and_compiled_unchanged":True,"receipt_sha256":hashlib.sha256(receipt_raw).hexdigest(),"receiver_freeze":freeze,"reconstructed_initial_snapshot":{"path":"candidate-run/single-snapshot/reconstructed-initial-ledger.json","bytes":len(original),"sha256":expected,"identity":"Deterministically reconstructed after execution from frozen fixture generator; equals the actual first read hash. Not a relabeled runtime capture."},"failed_metadata_admission":"source-admission-v1-failure.json","source_review":"shared-source-review.patch","boundary":"Client-saved synthetic statements through the real native HTTP service. Existing owner integration route only; no canonical merge, live ledger or deployment."}
with (p/"receiving-acceptance.json").open("x") as f:f.write(json.dumps(accepted,indent=2)+"\n")
files=[]
for path in sorted(p.rglob("*")):
 if path.is_symlink(): raise AssertionError("Unexpected symlink: "+str(path))
 if not path.is_file(): continue
 if path.name=="ROOT-MANIFEST.json": raise AssertionError("Packet was already frozen")
 raw=path.read_bytes()
 files.append({"path":path.relative_to(p).as_posix(),"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"git_blob":hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()})
manifest={"format":"independent-household-export-custody/v1","source_tree":accepted["source_tree"],"files":files,"total_files":len(files),"total_bytes":sum(x["bytes"] for x in files),"scope":"Exact files under the independent receiver only; add ROOT-MANIFEST.json itself to the archive."}
with (p/"ROOT-MANIFEST.json").open("x") as f:f.write(json.dumps(manifest,indent=2)+"\n")
m=(p/"ROOT-MANIFEST.json").read_bytes();a=(p/"receiving-acceptance.json").read_bytes()
print(json.dumps({"source_tree":accepted["source_tree"],"files":len(files),"bytes":manifest["total_bytes"],"manifest_bytes":len(m),"manifest_sha256":hashlib.sha256(m).hexdigest(),"manifest_git_blob":hashlib.sha1(b"blob "+str(len(m)).encode()+b"\0"+m).hexdigest(),"acceptance_sha256":hashlib.sha256(a).hexdigest(),"receipt_sha256":accepted["receipt_sha256"],"reconstructed_original_input_sha256":expected}))
