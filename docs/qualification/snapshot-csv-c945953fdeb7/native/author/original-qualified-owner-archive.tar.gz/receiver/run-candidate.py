import pathlib,subprocess,json,time,hashlib,datetime,os,signal
p=pathlib.Path("/Users/me/hamon-household-export-receiving-7a9310dad255")
freeze=json.loads((p/"runner-freeze.json").read_text())
for e in freeze["files"]:
 b=(p/e["path"]).read_bytes()
 assert len(b)==e["bytes"] and hashlib.sha256(b).hexdigest()==e["sha256"],e["path"]
admission=json.loads((p/"candidate-source-admission.json").read_text())
assert admission["source_tree"]=="81aeb4162cf6d793093f920ac7ca03a520169258"
cmd=["/opt/homebrew/bin/node",str(p/"receive.mjs"),"candidate","/Users/me/hamon-household-export-7a9310dad255/candidate",str(p/"candidate-run"),"/Users/me/hamon-household-import-a219f250962c/node_modules"]
started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
proc=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
timeout=False
try: out,err=proc.communicate(timeout=60)
except subprocess.TimeoutExpired:
 timeout=True;os.killpg(proc.pid,signal.SIGTERM)
 try: out,err=proc.communicate(timeout=5)
 except subprocess.TimeoutExpired:
  os.killpg(proc.pid,signal.SIGKILL);out,err=proc.communicate()
for name,b in [("candidate.stdout.log",out),("candidate.stderr.log",err)]:
 with (p/name).open("xb") as f:f.write(b)
receipt={"command":cmd,"started":started,"finished":datetime.datetime.now(datetime.timezone.utc).isoformat(),"elapsedSeconds":time.monotonic()-t,"exitCode":proc.returncode,"timeout":timeout,"stdoutSha256":hashlib.sha256(out).hexdigest(),"stderrBytes":len(err),"frozenReceiverFiles":freeze["files"],"sourceAdmission":admission}
with (p/"candidate-execution.json").open("x") as f:f.write(json.dumps(receipt,indent=2)+"\n")
print(out.decode()[:6000]);print(json.dumps({k:v for k,v in receipt.items() if k not in ["frozenReceiverFiles","sourceAdmission"]}))
raise SystemExit(proc.returncode or (1 if timeout else 0))
