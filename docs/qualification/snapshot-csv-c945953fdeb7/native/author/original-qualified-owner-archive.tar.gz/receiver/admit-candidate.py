import pathlib,json,hashlib,difflib,datetime
def tree(entries):
 root={}
 for e in entries:
  node=root
  parts=e["path"].split("/")
  for name in parts[:-1]:
   node=node.setdefault(name,{})
  assert parts[-1] not in node, e["path"]
  node[parts[-1]]=(e["mode"],e.get("git_blob",e.get("sha")))
 def emit(node):
  raw=b""
  for name,value in sorted(node.items(),key=lambda pair:pair[0].encode()+(b"/" if isinstance(pair[1],dict) else b"")):
   mode,digest=("40000",emit(value)) if isinstance(value,dict) else value
   raw+=mode.encode()+b" "+name.encode()+b"\0"+bytes.fromhex(digest)
  return hashlib.sha1(b"tree "+str(len(raw)).encode()+b"\0"+raw).hexdigest()
 return emit(root)
def check_bytes(raw,e):
 assert len(raw)==e["bytes"],e["path"]
 assert hashlib.sha256(raw).hexdigest()==e["sha256"],e["path"]
 expected=e.get("git_blob",e.get("sha"))
 if expected:
  assert hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()==expected,e["path"]
def leaves(t):
 assert not t.get("truncated")
 return [e for e in t["tree"] if e["type"]!="tree"]
def mapping(entries):
 return {e["path"]:(e["mode"],e.get("sha",e.get("git_blob"))) for e in entries}

p=pathlib.Path("/Users/me/hamon-household-export-receiving-7a9310dad255")
owner=pathlib.Path("/Users/me/hamon-household-export-7a9310dad255")
src=owner/"candidate"
manifest_raw=(owner/"candidate-final-source-manifest.json").read_bytes()
assert hashlib.sha256(manifest_raw).hexdigest()=="30ffa80337ae70fb4a29fa7064e8b18832ce8b7d72ddeaab28e3d705519f1fd0"
m=json.loads(manifest_raw)
artifact_raw=(owner/"candidate-artifact-manifest.json").read_bytes()
assert hashlib.sha256(artifact_raw).hexdigest()=="db7987539fd28f759543ed59c127dad4387b52b878aded8b14f5b2a4df9899bc"
a=json.loads(artifact_raw)
assert len(m["entries"])==103 and len(a["compiled_files"])==78
for e in m["entries"]+a["compiled_files"]:
 check_bytes((src/e["path"]).read_bytes(),e)
 if "mode" in e: assert bool((src/e["path"]).stat().st_mode&0o111)==(e["mode"]=="100755"),e["path"]
assert tree(m["entries"])==m["tree"]=="81aeb4162cf6d793093f920ac7ca03a520169258"
braw=(owner/"baseline-source-manifest.json").read_bytes()
assert hashlib.sha256(braw).hexdigest()=="f18faaac133285d09bd9e533d3e43e1cee521c0887e5a7ec8bba4a90940167df"
bm=json.loads(braw)
be=bm.get("entries",bm.get("files"))
assert isinstance(be,list) and len(be)==97,(bm.keys(),type(be))
assert tree(be)=="940438aed7af43d841ff7700da8bd4f83a838afd"
owned={e["path"] for e in m["contribution"]}
parent=mapping(be);candidate=mapping(m["entries"])
unchanged=[path for path in parent if path not in owned]
assert len(unchanged)==92
for path in unchanged: assert candidate[path]==parent[path],path
patch=""
for path in sorted(owned&set(parent)):
 old=(owner/"baseline"/path).read_text().splitlines(keepends=True)
 new=(src/path).read_text().splitlines(keepends=True)
 patch+="".join(difflib.unified_diff(old,new,fromfile="baseline/"+path,tofile="candidate/"+path))
(p/"shared-source-review.patch").write_text(patch)
out={"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"source_tree":m["tree"],"source_files":103,"compiled_files":78,"parent_tree":"940438aed7af43d841ff7700da8bd4f83a838afd","unrelated_parent_files_exact":92,"owned_paths":sorted(owned),"source_manifest_sha256":hashlib.sha256(manifest_raw).hexdigest(),"artifact_manifest_sha256":hashlib.sha256(artifact_raw).hexdigest(),"shared_source_diff_sha256":hashlib.sha256(patch.encode()).hexdigest()}
with (p/"candidate-source-admission.json").open("x") as f:f.write(json.dumps(out,indent=2)+"\n")
print(json.dumps(out))
