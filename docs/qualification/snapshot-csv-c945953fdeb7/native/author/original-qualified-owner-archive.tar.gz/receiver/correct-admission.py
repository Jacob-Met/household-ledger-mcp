import pathlib
p=pathlib.Path("/Users/me/hamon-household-export-receiving-7a9310dad255")
s=(p/"admit-candidate.py").read_text()
old='be=bm.get("entries",bm.get("files"))'
assert s.count(old)==1
with (p/"admit-candidate-v2.py").open("x") as f:f.write(s.replace(old,'be=bm["source_entries"]'))
