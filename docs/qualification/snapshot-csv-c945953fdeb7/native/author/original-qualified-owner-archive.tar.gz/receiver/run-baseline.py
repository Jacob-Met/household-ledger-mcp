import pathlib,subprocess,json,time,hashlib,datetime
p=pathlib.Path("/Users/me/hamon-household-export-receiving-7a9310dad255")
cmd=["/opt/homebrew/bin/node",str(p/"receive.mjs"),"baseline","/Users/me/hamon-household-export-7a9310dad255/baseline",str(p/"baseline-run"),"/Users/me/hamon-household-import-a219f250962c/node_modules"]
t=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat()
r=subprocess.run(cmd,capture_output=True,timeout=45)
for name,b in [("baseline.stdout.log",r.stdout),("baseline.stderr.log",r.stderr)]:
 with (p/name).open("xb") as f:f.write(b)
receipt={"command":cmd,"started":started,"finished":datetime.datetime.now(datetime.timezone.utc).isoformat(),"elapsedSeconds":time.monotonic()-t,"exitCode":r.returncode,"stdoutSha256":hashlib.sha256(r.stdout).hexdigest(),"stderrBytes":len(r.stderr)}
with (p/"baseline-execution.json").open("x") as f:f.write(json.dumps(receipt,indent=2)+"\n")
print(r.stdout.decode());print(json.dumps(receipt))
raise SystemExit(r.returncode)
