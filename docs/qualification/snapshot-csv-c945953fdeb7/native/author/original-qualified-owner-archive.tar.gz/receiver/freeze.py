import pathlib,json,hashlib,datetime,sys
p=pathlib.Path("/Users/me/hamon-household-export-receiving-7a9310dad255")
names=["independent-cases.json","literal-ledger.json"]
if (p/"receive.mjs").exists(): names+=["receive.mjs","read-probe.mjs"]
r={"format":"independent-household-receiver-freeze/v1","at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"candidate_source_seen":False,"files":[]}
for n in names:
 b=(p/n).read_bytes();r["files"].append({"path":n,"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()})
name="runner-freeze.json" if "receive.mjs" in names else "cases-freeze.json"
with (p/name).open("x") as f: f.write(json.dumps(r,indent=2)+"\n")
print(json.dumps(r))
