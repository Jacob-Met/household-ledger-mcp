import pathlib,subprocess,json,hashlib,time,datetime
p=pathlib.Path("/Users/me/hamon-household-export-receiving-7a9310dad255")
node="/opt/homebrew/bin/node"
commands=[[node,"--check",str(p/"receive.mjs")],[node,"--check",str(p/"read-probe.mjs")],["python3","-B",str(p/"freeze.py")]]
rows=[]
for i,cmd in enumerate(commands):
 t=time.monotonic();r=subprocess.run(cmd,capture_output=True,text=True)
 (p/("prepare-"+str(i)+".stdout.log")).write_text(r.stdout)
 (p/("prepare-"+str(i)+".stderr.log")).write_text(r.stderr)
 rows.append({"command":cmd,"exitCode":r.returncode,"elapsedSeconds":time.monotonic()-t,"stdout":r.stdout,"stderr":r.stderr})
 if r.returncode: break
(p/"prepare-execution.json").write_text(json.dumps(rows,indent=2)+"\n")
print(json.dumps(rows))
raise SystemExit(rows[-1]["exitCode"])
