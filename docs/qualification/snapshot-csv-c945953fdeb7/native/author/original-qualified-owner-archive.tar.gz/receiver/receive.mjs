import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { once } from "node:events";
import { createHash } from "node:crypto";
import * as fs from "node:fs/promises";
import { createServer } from "node:net";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const [mode, sourceArg, outputArg, depsArg] = process.argv.slice(2);
assert.ok(["baseline","candidate"].includes(mode) && sourceArg && outputArg && depsArg);
const source=resolve(sourceArg), output=resolve(outputArg), dependencies=resolve(depsArg);
const root=dirname(fileURLToPath(import.meta.url));
assert.ok(output.startsWith(root + "/"));
const spec=JSON.parse(await fs.readFile(join(root,"independent-cases.json"),"utf8"));
const literal=JSON.parse(await fs.readFile(join(root,"literal-ledger.json"),"utf8"));
const { Client } = await import(pathToFileURL(join(dependencies,"@modelcontextprotocol/sdk/dist/esm/client/index.js")).href);
const { StreamableHTTPClientTransport } = await import(pathToFileURL(join(dependencies,"@modelcontextprotocol/sdk/dist/esm/client/streamableHttp.js")).href);
await fs.mkdir(output);
await fs.mkdir(join(output,"deliveries"));
const hash=b=>createHash("sha256").update(b).digest("hex");
const receipt={format:"household-csv-independent-native/v1",mode,source,node:process.version,started:new Date().toISOString(),groups:[],servers:[],calls:0,deliveries:[],outcome:"pending"};
let serial=0,deliverySerial=0;
const active=new Set();
const writeJson=(path,value)=>fs.writeFile(path,JSON.stringify(value,null,2)+"\n",{flag:"wx"});
async function sourcePins(dir,rel=""){
  const pins=[];
  for(const ent of (await fs.readdir(join(dir,rel),{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){
    if(ent.name==="node_modules"||ent.name===".git"||ent.name===".DS_Store")continue;
    const name=rel?rel+"/"+ent.name:ent.name, path=join(dir,name);
    if(ent.isDirectory())pins.push(...await sourcePins(dir,name));
    else if(ent.isFile()){const b=await fs.readFile(path),s=await fs.stat(path);pins.push({path:name,bytes:b.length,mode:s.mode&0o777,sha256:hash(b)});}
    else if(ent.isSymbolicLink())pins.push({path:name,symlink:await fs.readlink(path)});
  }
  return pins;
}
async function state(path){
  try{const b=await fs.readFile(path),s=await fs.stat(path,{bigint:true});return{exists:true,bytes:b.length,sha256:hash(b),mtimeNs:String(s.mtimeNs),mode:String(s.mode)};}
  catch(e){if(e.code==="ENOENT")return{exists:false};throw e;}
}
async function prepare(label,data,{missing=false,raw=false}={}){
  const dir=join(output,label);await fs.mkdir(dir);
  const path=join(dir,"ledger.json");
  if(!missing){await fs.writeFile(path,raw?data:JSON.stringify(data,null,2)+"\n",{flag:"wx"});await fs.chmod(path,0o444);}
  return {label,dir,path,before:await state(path)};
}
async function start(fixture,{probeReplacement}={}){
  const n=++serial,label=fixture.label+"-"+n,probe=createServer();
  probe.listen(0,"127.0.0.1");await once(probe,"listening");
  const port=probe.address().port;await new Promise((ok,no)=>probe.close(e=>e?no(e):ok()));
  const env={PATH:process.env.PATH,HOUSEHOLD_LEDGER_DATA_PATH:fixture.path,HOUSEHOLD_LEDGER_HOST:"127.0.0.1",HOUSEHOLD_LEDGER_PORT:String(port)};
  const args=[];
  if(probeReplacement){Object.assign(env,{ROOT_EXPORT_PROBE_TARGET:fixture.path,ROOT_EXPORT_PROBE_REPLACEMENT:probeReplacement,ROOT_EXPORT_PROBE_LOG:join(fixture.dir,"read-probe.jsonl")});args.push("--import",join(root,"read-probe.mjs"));}
  args.push(join(source,"dist/src/index.js"));
  const child=spawn(process.execPath,args,{cwd:source,env,stdio:["ignore","pipe","pipe"]});
  const s={label,child,stdout:"",stderr:"",client:null,fixture,args};
  active.add(s);
  child.stdout.on("data",b=>s.stdout+=b.toString());child.stderr.on("data",b=>s.stderr+=b.toString());
  const began=Date.now();
  while(!s.stdout.includes("listening on")){
    assert.equal(child.exitCode,null,"Server exited before startup: "+s.stdout+s.stderr);
    if(Date.now()-began>6000)throw Error("Private server startup timed out: "+label);
    await new Promise(r=>setTimeout(r,20));
  }
  const url=new URL("http://127.0.0.1:"+port+"/mcp");
  const health=await fetch(new URL("/healthz",url));assert.equal(health.status,200);s.health=await health.json();
  s.client=new Client({name:"independent-household-export-root-7a9310dad255",version:"1"},{capabilities:{}});
  await s.client.connect(new StreamableHTTPClientTransport(url));
  return s;
}
async function stop(s){
  if(!active.has(s))return;
  try{if(s.client)await s.client.close();}
  finally{
    if(s.child.exitCode===null&&s.child.signalCode===null){
      const ending=once(s.child,"exit");s.child.kill("SIGTERM");
      const timer=setTimeout(()=>s.child.kill("SIGKILL"),5000);
      try{await ending;}finally{clearTimeout(timer);}
    }
    active.delete(s);
    await fs.writeFile(join(output,s.label+".stdout.log"),s.stdout,{flag:"wx"});
    await fs.writeFile(join(output,s.label+".stderr.log"),s.stderr,{flag:"wx"});
    receipt.servers.push({label:s.label,health:s.health,args:s.args,exitCode:s.child.exitCode,signal:s.child.signalCode,stdoutBytes:Buffer.byteLength(s.stdout),stderrBytes:Buffer.byteLength(s.stderr)});
    assert.equal(s.stderr,"","Native server stderr: "+s.label);
  }
}
async function call(s,name,args){
  let result;
  try{result=await s.client.callTool({name,arguments:args});}
  catch(e){result={protocolError:{name:e.name,code:e.code,message:e.message}};}
  receipt.calls++;
  await fs.appendFile(join(output,"actual-calls.jsonl"),JSON.stringify({sequence:receipt.calls,server:s.label,name,args,result})+"\n");
  return result;
}
function payload(r){
  assert.equal(r.protocolError,undefined,JSON.stringify(r));
  assert.notEqual(r.isError,true,JSON.stringify(r));
  assert.equal(r.content.length,1);assert.equal(r.content[0].type,"text");
  return JSON.parse(r.content[0].text);
}
async function listing(s,args){
  const rows=[];let total;
  for(let offset=0;;offset+=1000){
    const p=payload(await call(s,"list_transactions",{...args,limit:1000,offset}));
    if(total===undefined)total=p.total;else assert.equal(p.total,total);
    assert.ok(Array.isArray(p.transactions));rows.push(...p.transactions);
    if(rows.length>=total)break;
    assert.equal(p.transactions.length,1000);
  }
  assert.equal(rows.length,total);
  return rows;
}
function parseCsv(text){
  assert.equal(text.charCodeAt(0)===0xfeff,false);assert.equal(text.isWellFormed(),true);
  const rows=[];let i=0;
  while(i<text.length){
    const row=[];
    for(;;){
      assert.equal(text[i++],'"',"Every cell must begin with a quote");
      let field="",closed=false;
      while(i<text.length){
        const c=text[i++];
        if(c!=='"'){field+=c;continue;}
        if(text[i]==='"'){field+='"';i++;continue;}
        closed=true;break;
      }
      assert.ok(closed,"Unterminated quoted field");row.push(field);
      if(text[i]===","){i++;continue;}
      assert.equal(text.slice(i,i+2),"\r\n","Record terminator must be CRLF");i+=2;break;
    }
    assert.equal(row.length,9);rows.push(row);
  }
  assert.deepEqual(rows[0],spec.columns);return rows.slice(1);
}
function values(row){return spec.columns.map(k=>k==="amountMinor"?String(row[k]):row[k]===undefined?"":row[k]);}
async function accept(r,expected,label,{exactCsv,exactBytes}={}){
  const p=payload(r);
  assert.deepEqual(Object.keys(p).sort(),["format","filename","mediaType","rowCount","byteCount","sha256","csv"].sort());
  assert.equal(p.format,"csv");assert.equal(p.filename,"household-transactions.csv");assert.equal(p.mediaType,"text/csv; charset=utf-8");
  assert.equal(typeof p.csv,"string");
  const bytes=Buffer.from(p.csv,"utf8");
  assert.equal(p.byteCount,bytes.length);assert.equal(p.sha256,hash(bytes));assert.match(p.sha256,/^[0-9a-f]{64}$/);
  assert.equal(p.rowCount,expected.length);assert.ok(p.rowCount<=5000&&p.byteCount<=1048576);
  const fields=parseCsv(p.csv);assert.deepEqual(fields,expected.map(values));
  if(exactCsv!==undefined)assert.equal(p.csv,exactCsv);
  if(exactBytes!==undefined)assert.equal(bytes.length,exactBytes);
  const name=String(++deliverySerial).padStart(3,"0")+"-"+label+".csv",path=join(output,"deliveries",name);
  await fs.writeFile(path,bytes,{flag:"wx"});assert.deepEqual(await fs.readFile(path),bytes);
  receipt.deliveries.push({path:"deliveries/"+name,rows:p.rowCount,bytes:bytes.length,sha256:p.sha256,clientSaved:true});
  return p;
}
function refuse(r,{toolOnly=false}={}){
  if(toolOnly)assert.equal(r.isError,true,JSON.stringify(r));
  else assert.ok(r.isError===true||r.protocolError,JSON.stringify(r));
  if(r.content)for(const b of r.content)if(b.type==="text"){
    let p;try{p=JSON.parse(b.text);}catch{}
    if(p&&typeof p==="object")assert.equal(Object.hasOwn(p,"csv"),false,"Refusal must not contain a partial CSV");
  }
}
async function unchanged(f){assert.deepEqual(await state(f.path),f.before,f.label+" ledger changed");}
async function group(name,fn){
  const began=Date.now(),entry={name,outcome:"pending"};receipt.groups.push(entry);
  try{await fn(entry);entry.outcome="passed";}
  catch(e){entry.outcome="failed";entry.error={name:e.name,message:e.message,stack:e.stack};throw e;}
  finally{entry.elapsedMs=Date.now()-began;}
}
function bulk(n,prefix="r"){return{version:2,transactions:Array.from({length:n},(_,i)=>({id:prefix+String(i).padStart(5,"0"),type:i%2?"expense":"income",amountMinor:i+1,currency:i%3?"USD":"EUR",date:"2026-10-"+String(i%28+1).padStart(2,"0"),category:[0,1000,5000].includes(i)?"Needle":"Bulk",note:"row "+i,createdAt:"2026-10-01T00:00:00.000Z"})),budgets:[]};}
const before=await sourcePins(source);await writeJson(join(output,"source-before.json"),before);
try{
  const primary=await prepare("literal",literal),s=await start(primary);
  const catalog=await s.client.listTools();await writeJson(join(output,"catalog.json"),catalog);
  const originalNames=["cashflow_trend","commit_budget_copy","commit_transaction_import","get_budgets","list_transactions","monthly_summary","preview_budget_copy","preview_transaction_import","record_transaction","set_budget"];
  assert.deepEqual(catalog.tools.map(t=>t.name).sort(),[...originalNames,...(mode==="candidate"?["export_transactions_csv"]:[])].sort());
  if(mode==="candidate")assert.equal(catalog.tools.find(t=>t.name==="export_transactions_csv").annotations.readOnlyHint,true);
  const observed=[];
  let first;
  await group("literal selections and actual client delivery",async e=>{
    for(let i=0;i<spec.selectors.length;i++){
      const selector=spec.selectors[i],rows=await listing(s,selector.args);
      assert.deepEqual(rows.map(r=>r.id),selector.ids);
      for(const row of rows)assert.deepEqual(row,literal.transactions.find(t=>t.id===row.id));
      observed.push({args:selector.args,rows});
      if(mode==="candidate"){
        const p=await accept(await call(s,"export_transactions_csv",selector.args),rows,"literal-"+i);
        if(i===0)first=p;
      }
    }
    if(mode==="baseline"){
      const absent=await call(s,"export_transactions_csv",{});
      assert.equal(absent.isError,true);assert.deepEqual(absent.content,[{type:"text",text:"Unknown tool: export_transactions_csv"}]);
      e.missingFeature=true;
    }
    e.selections=observed.map(x=>({args:x.args,ids:x.rows.map(r=>r.id)}));await unchanged(primary);
  });
  await writeJson(join(output,"literal-listing-oracle.json"),observed);
  if(mode==="candidate"){
    await group("invalid arguments and unchanged reads",async e=>{
      const invalid=[...spec.invalid_args,null,[],7,"invalid"];
      for(const args of invalid)refuse(await call(s,"export_transactions_csv",args));
      e.refusals=invalid.length;await unchanged(primary);
    });
    await group("repeat and real process restart",async e=>{
      assert.deepEqual(await accept(await call(s,"export_transactions_csv",{}),observed[0].rows,"repeat"),first);
      await stop(s);const restarted=await start(primary);
      assert.deepEqual(await accept(await call(restarted,"export_transactions_csv",{}),observed[0].rows,"restart"),first);
      await stop(restarted);await unchanged(primary);e.responseExact=true;e.fileMetadataExact=true;
    });
    await group("missing and empty ledgers",async e=>{
      for(const missing of [false,true]){
        const f=await prepare(missing?"missing":"empty",{version:1,transactions:[],budgets:[]},{missing});
        const server=await start(f);
        await accept(await call(server,"export_transactions_csv",{}),[],f.label,{exactCsv:spec.header});
        await stop(server);await unchanged(f);
      }e.headerExact=true;
    });
    await group("complete bounded pages",async e=>{
      const f=await prepare("five-thousand",bulk(5000)),server=await start(f);
      const rows=await listing(server,{});assert.equal(rows.length,5000);assert.equal(new Set(rows.map(r=>r.id)).size,5000);
      await accept(await call(server,"export_transactions_csv",{}),rows,"5000");await stop(server);await unchanged(f);
      const excess=await prepare("five-thousand-one",bulk(5001)),over=await start(excess);
      refuse(await call(over,"export_transactions_csv",{}),{toolOnly:true});
      const selected=await listing(over,{category:"Needle"});assert.deepEqual(selected.map(r=>r.id),["r01000","r05000","r00000"]);
      await accept(await call(over,"export_transactions_csv",{category:"Needle"}),selected,"5001-small-selection");
      await stop(over);await unchanged(excess);e.exactRows=5000;e.excessRowsRefused=5001;e.smallSelection=3;
    });
    await group("exact UTF8 byte limit and whole refusals",async e=>{
      const prefix=spec.header+'"edge","expense","1","USD","2026-10-08","Edge","',suffix='","","2026-10-08T00:00:00.000Z"\r\n';
      const note="a".repeat(1048576-Buffer.byteLength(prefix+suffix));
      const edge={id:"edge",type:"expense",amountMinor:1,currency:"USD",date:"2026-10-08",category:"Edge",note,createdAt:"2026-10-08T00:00:00.000Z"};
      const variants=[["exact",note],["one-byte-over",note+"b"],["quote-expanded",note.slice(0,-1)+'"'],["unicode-expanded",note.slice(0,-1)+"🥦"]];
      for(const [label,value] of variants){
        const tx={...edge,note:value},f=await prepare("bytes-"+label,{version:1,transactions:[tx],budgets:[]}),server=await start(f);
        const r=await call(server,"export_transactions_csv",{});
        if(label==="exact")await accept(r,[tx],"exact-1mib",{exactCsv:prefix+note+suffix,exactBytes:1048576});else refuse(r,{toolOnly:true});
        await stop(server);await unchanged(f);
      }e.exactBytes=1048576;e.wholeRefusals=3;
    });
    await group("stored data refusal without repairing original files",async e=>{
      const good={id:"good",type:"expense",amountMinor:7,currency:"USD",date:"2026-10-08",category:"Good",createdAt:"2026-10-08T00:00:00.000Z"};
      for(const [label,changes] of [["timestamp",{createdAt:0}],["high-surrogate",{note:"x\ud800y"}],["low-surrogate",{note:"x\udc00y"}]]){
        const bad={...good,id:"bad-"+label,category:"Bad",...changes},f=await prepare("stored-"+label,{version:1,transactions:[bad,good],budgets:[]}),server=await start(f);
        refuse(await call(server,"export_transactions_csv",{}),{toolOnly:true});
        await accept(await call(server,"export_transactions_csv",{category:"Good"}),[good],label+"-unselected");
        await stop(server);await unchanged(f);
      }
      const invalid=[["malformed","{"],["version",JSON.stringify({version:99,transactions:[],budgets:[]})],["native-invalid",JSON.stringify({version:1,transactions:[{...good,amountMinor:0}],budgets:[]})]];
      for(const [label,raw] of invalid){
        const f=await prepare(label,raw,{raw:true}),server=await start(f);
        refuse(await call(server,"export_transactions_csv",{}),{toolOnly:true});
        await stop(server);await unchanged(f);
      }e.selectedTextRefusals=3;e.unselectedSuccesses=3;e.storeRefusals=3;
    });
    await group("one real Store snapshot while receiver changes private file",async e=>{
      const a=bulk(2305,"A"),b=bulk(3,"B"),f=await prepare("single-snapshot",a),control=await start(f);
      const expected=await listing(control,{});await stop(control);await unchanged(f);
      const replacement=join(f.dir,"replacement.json");await fs.writeFile(replacement,JSON.stringify(b,null,2)+"\n",{flag:"wx"});
      const changed=await start(f,{probeReplacement:replacement});
      await accept(await call(changed,"export_transactions_csv",{}),expected,"one-snapshot");
      await stop(changed);
      const reads=(await fs.readFile(join(f.dir,"read-probe.jsonl"),"utf8")).trim().split("\n").map(JSON.parse);
      assert.equal(reads.length,1);assert.equal(reads[0].readSha256,f.before.sha256);
      assert.deepEqual(await fs.readFile(f.path),await fs.readFile(replacement));
      e.reads=reads;e.returnedRows=expected.length;e.receiverReplacementExplicit=true;
    });
  }
  await stop(s);
  receipt.outcome="passed";
}catch(e){
  receipt.outcome="failed";receipt.error={name:e.name,message:e.message,stack:e.stack};process.exitCode=1;
}finally{
  for(const s of [...active])try{await stop(s);}catch(e){receipt.cleanupError={message:e.message,stack:e.stack};process.exitCode=1;receipt.outcome="failed";}
  const after=await sourcePins(source);await writeJson(join(output,"source-after.json"),after);
  try{assert.deepEqual(after,before);receipt.sourceAndCompiledUnchanged=true;}catch(e){receipt.sourceDrift=e.message;receipt.outcome="failed";process.exitCode=1;}
  receipt.finished=new Date().toISOString();receipt.sourceEntries=before.length;
  await writeJson(join(output,"receipt.json"),receipt);
  console.log(JSON.stringify({outcome:receipt.outcome,groups:receipt.groups.map(g=>({name:g.name,outcome:g.outcome,error:g.error?.message})),calls:receipt.calls,deliveries:receipt.deliveries.length,sourceAndCompiledUnchanged:receipt.sourceAndCompiledUnchanged,error:receipt.error?.message}));
}
