import hashlib,json,pathlib,time
root=pathlib.Path("/Users/me/hamon-household-export-7a9310dad255")
base=json.loads((root/"baseline-source-manifest.json").read_text());final=json.loads((root/"candidate-final-source-manifest.json").read_text())
baseline=root/"baseline";candidate=root/"candidate"
def pin(raw):return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"sha":hashlib.sha1(("blob "+str(len(raw))+"\0").encode()+raw).hexdigest()}
for manifest,folder,key in [(base,baseline,"source_entries"),(final,candidate,"entries")]:
 for row in manifest[key]:
  p=folder/row["path"];assert pin(p.read_bytes())["sha"]==row["sha"],row["path"]
  assert ("100755" if p.stat().st_mode & 0o111 else "100644")==row["mode"],row["path"]
index=(candidate/"src/index.ts").read_bytes()
removals=[
 b'import { exportTransactionsCsv, TRANSACTION_EXPORT_TOOL_DEF } from "./transaction-export.js";\n',
 b'  TRANSACTION_EXPORT_TOOL_DEF,\n',
 b'        case "export_transactions_csv": {\n          const result = exportTransactionsCsv(await store.load(), args);\n          return { content: [{ type: "text", text: JSON.stringify(result) }] };\n        }\n']
for addition in removals:
 assert index.count(addition)==1;index=index.replace(addition,b"")
assert index==(baseline/"src/index.ts").read_bytes()
readme=(candidate/"README.md").read_bytes()
bt=chr(96)
readme_additions=[
 ("| ^export_transactions_csv^ | Prepare a complete bounded CSV statement with original transaction values for the client to save. |\n").replace("^",bt).encode(),
 b"\nSee [transaction CSV statements](docs/TRANSACTION_EXPORT.md) for exact columns, literal text preservation, whole-result limits and client-side saving.\n"]
for addition in readme_additions:
 assert readme.count(addition)==1;readme=readme.replace(addition,b"")
assert readme==(baseline/"README.md").read_bytes()
for name in ["test/mcp.test.ts","test/transaction-import-http.test.ts"]:
 raw=(candidate/name).read_bytes();addition=b'"commit_transaction_import", "export_transactions_csv", "get_budgets"'
 assert raw.count(addition)==1
 assert raw.replace(addition,b'"commit_transaction_import", "get_budgets"')==(baseline/name).read_bytes(),name
raw=(candidate/"test/budget-copy-http.test.ts").read_bytes()
assert raw.count(b"assert.equal(catalogue.length, 11)")==1
assert raw.replace(b"assert.equal(catalogue.length, 11)",b"assert.equal(catalogue.length, 10)")==(baseline/"test/budget-copy-http.test.ts").read_bytes()
parent={r["path"]:r for r in base["source_entries"]};current={r["path"]:r for r in final["entries"]}
inherited=[name for name in parent if parent[name]["sha"]==current[name]["sha"] and parent[name]["mode"]==current[name]["mode"]]
assert len(inherited)==92
assert all(name in current for name in parent)
for name in ["src/ledger.ts","src/stdio.ts","src/cashflow.ts","src/transaction-import.ts","src/budget-copy.ts","package.json","package-lock.json","tsconfig.json",".github/workflows/ci.yml"]:assert name in inherited,name
checks=json.loads((root/"candidate-checks-v3/execution.json").read_text())
assert all(r["exit_code"]==0 for r in checks["commands"])
for row in checks["compiled_files"]:assert pin((candidate/row["path"]).read_bytes())["sha"]==row["sha"],row["path"]
old_compiled={r["path"]:r for r in json.loads((root/"baseline-execution.json").read_text())["compiled_files"]}
new_compiled={r["path"]:r for r in checks["compiled_files"]}
changed_runtime=[name for name in old_compiled if name.startswith("dist/src/") and old_compiled[name]["sha"]!=new_compiled[name]["sha"]]
assert sorted(changed_runtime)==["dist/src/index.js","dist/src/index.js.map"],changed_runtime
for row in base["dependencies"]["entries"]:assert pin(pathlib.Path(row["path"]).read_bytes())["sha256"]==row["sha256"],row["path"]
report={"verified_at":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"base_head":base["source_head"],"base_tree":base["source_tree"],"computed_candidate_source_tree":final["tree"],"parent_files":97,"candidate_files":103,"contribution_paths":11,"unchanged_parent_files":92,"new_files":[name for name in current if name not in parent],"modified_files":[name for name in parent if name not in inherited],"whole_index_restored_by_removing_exact_3_insertions":True,"whole_readme_restored_by_removing_exact_2_additions":True,"two_name_rosters_restore_exactly":True,"one_numeric_catalog_count_restores_exactly":True,"existing_ledger_store_filter_and_write_handlers_unchanged":True,"all_dependency_and_workflow_bytes_unchanged":True,"only_changed_inherited_compiled_runtime_files":changed_runtime,"all_78_compiled_files_verified":True,"final_manifest":pin((root/"candidate-final-source-manifest.json").read_bytes()),"patch":pin((root/"candidate-final-source.patch").read_bytes()),"final_execution":pin((root/"candidate-checks-v3/execution.json").read_bytes()),"qualification":"Native Mac Node26.3.0, TypeScript5.9.3, SDK1.32.1; existing installed dependencies reused read-only. No hosted Node20, provider, live ledger, canonical adoption or deployment claim."}
p=root/"source-preservation.json";p.write_text(json.dumps(report,indent=2)+"\n")
artifact={"source_manifest":pin((root/"candidate-final-source-manifest.json").read_bytes()),"source_tree":final["tree"],"source_root":str(candidate),"node":base["node"],"dependencies":base["dependencies"],"compiled_files":checks["compiled_files"],"entrypoint":next(r for r in checks["compiled_files"] if r["path"]=="dist/src/index.js"),"export_module":next(r for r in checks["compiled_files"] if r["path"]=="dist/src/transaction-export.js"),"source_preservation":pin(p.read_bytes()),"execution":pin((root/"candidate-checks-v3/execution.json").read_bytes())}
q=root/"candidate-artifact-manifest.json";q.write_text(json.dumps(artifact,indent=2)+"\n")
print(json.dumps({"base":str(root),"source_preservation":pin(p.read_bytes()),"artifact_manifest":pin(q.read_bytes()),"entrypoint":artifact["entrypoint"],"export_module":artifact["export_module"],"unchanged_parent_files":92,"source_tree":final["tree"],"contribution_count":11}))
