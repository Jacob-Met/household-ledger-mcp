# Household transaction CSV export: frozen consumer contract

Frozen before export implementation by worker 7a9310dad255, memory lane.
Repository: Jacob-Met/household-ledger-mcp.
Native receiving base: 2b77b81ad59c5f3255aa25c37110e91d3bad6a01; tree 940438aed7af43d841ff7700da8bd4f83a838afd; 97 source files.
Canonical main remains README-only c063549f5caae75a6bef764a5da703f0dccfec9f. Native snapshot ancestry is not a proposed main merge.

## Public consumer interface

Add one read-only MCP tool, export_transactions_csv, to the existing native HTTP and inherited stdio server. Its optional object arguments are type, category, from and to only. Type is income or expense; category is a string used exactly, without trimming, case folding or Unicode normalization; dates are the existing inclusive calendar date selectors. Omitting a selector means the existing listing behavior. A reversed valid date interval produces no matches, as list_transactions does. Reject non-object arguments, unknown keys, explicit null or other wrong selector types, invalid type/date values, and caller limit/offset. This scope does not add currency/query selectors or alter the existing listing handler owned by issue 6.

Use one LedgerStore.load snapshot and the existing listTransactions function for every selection and ordering operation. Retrieve complete results through its bounded pages; no copied matcher, independent sort or current-page export. Expected identities, original records and order are the actual saved snapshot's native listing result. Same-date ordering is whatever the native listing returns. Do not modify any record, budget, ID, idempotency key, timestamp, schema, file bytes or mtime.

## Successful result

The tool's existing text-content JSON envelope contains exactly:
- format: "csv"
- filename: "household-transactions.csv"
- mediaType: "text/csv; charset=utf-8"
- rowCount: integer number of exported transaction records
- byteCount: exact UTF-8 CSV byte count, including header, quotes and record terminators
- sha256: lowercase SHA-256 of those exact bytes
- csv: the complete CSV text

The service prepares text and metadata. It does not write a requested path, automatically attach a file, open a spreadsheet, contact a provider or mutate a live ledger. Receiving saves the actual csv response exclusively into the receiver's own directory and verifies those saved bytes. Client saving is the observed delivery boundary.

## CSV bytes and field values

Exactly nine columns, in this order:
id,type,amountMinor,currency,date,category,note,idempotencyKey,createdAt

Quote every header and value cell using double quotes. Double embedded double quotes. Separate cells with comma and records with CRLF, including a final CRLF. Encode UTF-8, without BOM. Preserve embedded commas, quotes, CRLF, lone LF/CR, whitespace, Unicode and formula-like literal strings beginning with =, +, -, or @ as field data, with no apostrophe or other spreadsheet-specific prefix. This is faithful CSV text; the consuming application's interpretation is outside this server.

amountMinor is the original safe positive integer rendered in decimal, without division, grouping or scientific notation. Preserve the original currency/text fields returned by the native listing. There is no sum or currency conversion.

Absent note/idempotencyKey become empty cells, matching their optional nature. An absent createdAt in a legacy snapshot also becomes an empty cell; do not invent a timestamp. An explicitly present createdAt that is not a string is refused rather than converted to a fabricated text value. All other exported values retain the native store's accepted shape. Refuse a selected text field with an unpaired UTF-16 surrogate because it cannot be represented losslessly as UTF-8. Do not rewrite the source to repair either condition.

This is a statement export, not a native ledger backup or a round-trip import file. In particular, missing versus empty optional strings share an empty cell, budgets are absent, and the current transaction importer has a different accepted column set.

## Whole-result limits and refusal

At most 5,000 matched transactions and 1,048,576 UTF-8 CSV bytes, inclusive. Both limits apply to the complete result, not individual pages; a large ledger with a small matching result can succeed. Compute limits before returning a successful report. Refuse the whole result when either limit is exceeded, including CSV quote expansion and multibyte Unicode. Never return a truncated or partial csv field as success.

Zero matches, including a missing ledger file, succeed with a quoted header and final CRLF, rowCount 0 and matching byteCount/hash. A read-only call must not create the missing ledger.

Malformed or unsupported ledger content and invalid arguments use the existing MCP isError result boundary. No CSV is offered as a successful file on refusal. The existing ten tools retain their source behavior.

## Required receiving observations

1. Exact original native HTTP service catalog lacks the new tool; actual call returns Unknown tool while native listing succeeds.
2. Actual saved ledger and list_transactions responses determine expected rows/order for all transactions and combined type/category/date selectors, including ties and exact category case/whitespace.
3. Actual response is saved and parsed with an independent CSV reader; fields containing commas, quotes, CRLF/LF/CR, Unicode and formula-like strings survive exactly. Mixed currencies and maximum safe integer amount remain individual original fields.
4. Complete results cross the native 1,000-row page boundary and admit exactly 5,000 rows; 5,001 matches refuse, while a small selection from that ledger succeeds.
5. Exact UTF-8 byte boundary admits; one byte over, quote-expanded excess and multibyte excess refuse the whole result.
6. Empty/header-only, missing ledger, repeat/restart determinism and explicit read-only-file operation preserve source and ledger bytes/mtime.
7. Wrong selector types, unknown keys/pagination/path requests, invalid dates/type, malformed/unsupported ledger and unrepresentable selected text refuse.
8. Source diff and maintained tests retain original handlers, ledger/store/filter code, all dependencies and unrelated source bytes. The native CI-equivalent suite runs only once the implementation is frozen.

## Ownership fence

ce7/source-parent and estate-61749b0088e2/canonical receiving retain aggregate adoption; issue 3 retains prior recording/idempotency/currency/category/budget/cashflow/import behavior; issue 5 retains budget-copy source; issue 6 retains ListTransactionsFilter/listTransactions and the existing list_transactions schema/description/dispatch. The new export module, additive new-tool wiring, focused tests/docs and unique evidence are the only proposed contribution. No Git mutation or claim is made by this lane.
