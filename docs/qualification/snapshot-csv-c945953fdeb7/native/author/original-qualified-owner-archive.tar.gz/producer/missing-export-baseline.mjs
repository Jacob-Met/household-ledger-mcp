import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { once } from "node:events";
import { createHash } from "node:crypto";
import { readFile, writeFile, stat, readdir } from "node:fs/promises";
import { createServer } from "node:net";
import { join } from "node:path";
import { pathToFileURL } from "node:url";

const [source, output, dependencies] = process.argv.slice(2);
assert.ok(source && output && dependencies);
const { Client } = await import(pathToFileURL(join(dependencies, "@modelcontextprotocol/sdk/dist/esm/client/index.js")).href);
const { StreamableHTTPClientTransport } = await import(pathToFileURL(join(dependencies, "@modelcontextprotocol/sdk/dist/esm/client/streamableHttp.js")).href);
const { LedgerStore, listTransactions } = await import(pathToFileURL(join(source, "dist/src/ledger.js")).href);
const path = join(output, "ledger.json");
const original = await readFile(path);
const before = await stat(path, { bigint: true });
const snapshot = await new LedgerStore(path).load();
const snapshotText = JSON.stringify(snapshot);
const sourceName = "2b77b81ad59c5f3255aa25c37110e91d3bad6a01";
const calls = [];
let client, child, serverStdout = "", serverStderr = "";
const receipt = { source: sourceName, outcome: "pending", node: process.version, snapshotCount: snapshot.transactions.length, calls };
const hash = bytes => createHash("sha256").update(bytes).digest("hex");
function payload(result) {
  assert.equal(result.isError, undefined, JSON.stringify(result));
  assert.equal(result.content.length, 1);
  assert.equal(result.content[0].type, "text");
  return JSON.parse(result.content[0].text);
}
async function call(name, arguments_) {
  const result = await client.callTool({ name, arguments: arguments_ });
  calls.push({ name, arguments: arguments_, result });
  return result;
}
try {
  const probe = createServer();
  probe.listen(0, "127.0.0.1");
  await once(probe, "listening");
  const address = probe.address();
  assert.ok(address && typeof address !== "string");
  const port = address.port;
  await new Promise((resolve, reject) => probe.close(error => error ? reject(error) : resolve()));
  child = spawn(process.execPath, [join(source, "dist/src/index.js")], {
    cwd: source,
    env: { PATH: process.env.PATH, HOUSEHOLD_LEDGER_DATA_PATH: path, HOUSEHOLD_LEDGER_HOST: "127.0.0.1", HOUSEHOLD_LEDGER_PORT: String(port) },
    stdio: ["ignore", "pipe", "pipe"],
  });
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("Private server startup timed out")), 5000);
    child.once("error", error => { clearTimeout(timer); reject(error); });
    child.once("exit", code => { clearTimeout(timer); reject(new Error("Private server exited before startup: " + code)); });
    child.stderr.on("data", chunk => { serverStderr += String(chunk); });
    child.stdout.on("data", chunk => {
      serverStdout += String(chunk);
      if (serverStdout.includes("listening on")) { clearTimeout(timer); resolve(); }
    });
  });
  const url = new URL("http://127.0.0.1:" + port + "/mcp");
  const health = await fetch(new URL("/healthz", url));
  assert.equal(health.status, 200);
  receipt.health = await health.json();
  client = new Client({ name: "household-export-missing-consumer-7a9310dad255", version: "1" }, { capabilities: {} });
  await client.connect(new StreamableHTTPClientTransport(url));
  receipt.catalog = await client.listTools();
  assert.deepEqual(receipt.catalog.tools.map(tool => tool.name).sort(), ["cashflow_trend", "commit_budget_copy", "commit_transaction_import", "get_budgets", "list_transactions", "monthly_summary", "preview_budget_copy", "preview_transaction_import", "record_transaction", "set_budget"]);
  assert.equal(receipt.catalog.tools.some(tool => tool.name === "export_transactions_csv"), false);
  const selectors = [{}, { type: "expense", from: "2026-10-03", to: "2026-10-04" }, { category: "Food" }, { category: " Food " }, { category: "food" }, { category: '食費, "週末"' }, { from: "2026-10-06", to: "2026-10-01" }];
  receipt.listingControls = [];
  for (const filter of selectors) {
    const expected = listTransactions(snapshot, { ...filter, limit: 1000, offset: 0 });
    const actual = payload(await call("list_transactions", { ...filter, limit: 1000, offset: 0 }));
    assert.deepEqual(actual, expected);
    receipt.listingControls.push({ filter, total: actual.total, ids: actual.transactions.map(row => row.id), originalRecordsExact: true });
  }
  assert.deepEqual(receipt.listingControls[0].ids, ["fixture-newest", "fixture-max-safe", 'fixture-食費,"two"', "fixture-food-tie-a", "fixture-food-tie-b", "fixture-empty-note", "fixture-salary", "fixture-spaced"]);
  const absent = await call("export_transactions_csv", {});
  assert.equal(absent.isError, true);
  assert.deepEqual(absent.content, [{ type: "text", text: "Unknown tool: export_transactions_csv" }]);
  assert.deepEqual(await readFile(path), original);
  const after = await stat(path, { bigint: true });
  assert.equal(after.mtimeNs, before.mtimeNs);
  assert.equal(after.mode, before.mode);
  assert.equal(JSON.stringify(snapshot), snapshotText);
  assert.equal((await readdir(output)).some(name => name.endsWith(".csv")), false);
  receipt.ledger = { sha256: hash(original), bytes: original.length, mtimeNs: String(before.mtimeNs), mode: String(before.mode), bytesAndMtimeUnchanged: true };
  receipt.delivery = "No CSV returned or saved; actual original tool is missing.";
  receipt.outcome = "missing feature confirmed; existing listing controls passed";
} catch (error) {
  receipt.outcome = "receiver failure";
  receipt.error = { name: error.name, message: error.message, stack: error.stack };
  process.exitCode = 1;
} finally {
  if (client) await client.close();
  if (child && child.exitCode === null && child.signalCode === null) {
    const exit = once(child, "exit");
    child.kill("SIGTERM");
    await exit;
  }
  receipt.serverExit = child ? { code: child.exitCode, signal: child.signalCode } : null;
  await writeFile(join(output, "server.stdout.log"), serverStdout, { flag: "wx" });
  await writeFile(join(output, "server.stderr.log"), serverStderr, { flag: "wx" });
  if (serverStderr) { receipt.serverError = serverStderr; process.exitCode = 1; }
  await writeFile(join(output, "receipt.json"), JSON.stringify(receipt, null, 2) + "\n", { flag: "wx" });
  console.log(JSON.stringify({ outcome: receipt.outcome, listingControls: receipt.listingControls?.length, calls: calls.length, ledgerUnchanged: receipt.ledger?.bytesAndMtimeUnchanged, stderrBytes: Buffer.byteLength(serverStderr), serverExit: receipt.serverExit }));
}
