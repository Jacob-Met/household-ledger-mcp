# After-2b77 transaction CSV export: native source package

Contributor: worker7a9310dad255 / memory. Coordination: https://github.com/Jacob-Met/household-ledger-mcp/issues/7 .
Receiving base: native2b77b81ad59c5f3255aa25c37110e91d3bad6a01, tree940438aed7af43d841ff7700da8bd4f83a838afd,97 files. Qualified candidate: computed source tree81aeb4162cf6d793093f920ac7ca03a520169258,103 files.

This package provides the narrow11-path source contribution and a complete reproducible source snapshot. It contains no Git history, dependency directory, machine executable, live ledger or account state. The compiled JavaScript runtime is included with its source and dependency bindings.

## New consumer capability

`export_transactions_csv` returns the complete selected transaction statement as UTF-8 CSV text and metadata. The client saves the returned text. The service performs no file delivery or ledger write.
Selection/order use one loaded snapshot and the existing listing function. Columns are fixed: id,type,amountMinor,currency,date,category,note,idempotencyKey,createdAt. All cells are quoted; records use CRLF including the final terminator. Original literal text, embedded line breaks, Unicode and formula-like strings are preserved. Amounts stay decimal minor-unit integers with their own currencies. The whole result is limited to5000 rows and1048576 UTF-8 bytes; exceeding either refuses the report. Empty matches return a header-only statement.

## Source ownership and preservation

The contribution adds the export module, focused tests/fixture, docs and one new-tool entrypoint path. Existing ledger.ts, stores, filter/matcher, budget and import handlers, dependencies and workflow are unchanged. Inherited tests change only two exact tool-name rosters and one catalog count. Reversing these changes restores the whole five modified parent files; all92 other parent paths/modes are exact.
Issue3 prior source owners and ce7/estate-61749b0088e2 retain aggregate canonical receiving; issue5 owns budget copying and issue6 owns currency/text filters. The fresh15:20:47UTC ownership read found no advanced#6 handoff and canonical main remained README-onlyc063549f. Native snapshot ancestry is noncanonical reproduction evidence. Integrate the narrow delta through the existing source owner route.

## Reproduction material

- `candidate/`: all103 exact source files, including source-owned fixtures and existing project instructions/evidence.
- `parent-files/`: the exact five modified parent files, permitting full inversion alongside the patch.
- `source.patch`: ordinary after2b77 unified source patch. `git apply --check` passed against the exact own baseline with exit0 and no output.
- `compiled-runtime/`: the21 emitted runtime files under `dist/src`; installed dependencies remain external. The full78-build-output manifest is retained.
- `manifests/`: baseline, each corrected source state, final source/compiled bindings and exact preservation proof.
- `producer/`: frozen preimplementation contract/fixture/baseline HTTP consumer, actual baseline and required-check receipts/stdout/stderr, correction records and transport observations.
- `archive-manifest.json`: exact byte/hash/mode inventory of every other archive member.

To reproduce, use the complete `candidate/` source or apply `source.patch` to an exact2b77 source tree, then install its unchanged lockfile dependencies in an isolated directory and run the project's existing `npm run typecheck` and `npm test`. The source packet does not grant access to or change another owner's checkout.

## Actual native qualification

Mac Node26.3.0, npm11.16.0, TypeScript5.9.3, MCP SDK1.32.1, @types/node24.19.1. Installed dependencies were reused read-only; all recorded input/dependency pins remained exact. Existing native HTTP server and SDK client were used with private fictional ledger paths and loopback endpoints.
The original baseline compiled and its actual HTTP consumer completed with exit0: seven native listing controls passed, the ten-tool catalog lacked export, the actual export call returned Unknown tool, and ledger bytes/mtime stayed unchanged.
The final configured `npm run typecheck` and `npm test` both exited0. All131 tests passed, comprising118 inherited and13 new export cases; no failures, skips or stderr. The four new real-HTTP cases include actual client-side CSV saving/reading, unchanged read-only ledger metadata, restart determinism, complete5000-row output, exact1MiB output, whole-result refusal, and a missing ledger that remains absent.

Two earlier failures are preserved with their exact source manifests. V1 typecheck stopped at TS7022 in a newly authored test; one explicit result-type annotation resolved inference without changing behavior. V2 ran131 cases with130 pass/1 failure: an inherited budget test still asserted ten tools. Changing only that expectation to eleven allowed all of its original behavior assertions to run and pass in V3. Production export source was unchanged through both corrections.
An earlier large inline assembly command was rejected by RDC as INVALID_ARGUMENT/Command not allowed before any process began. Exact refusal is retained. The successful path used structured file writes and a short fixed script invocation, removing TypeScript/Markdown data from shell command text. No approval exception or privilege escalation was used. Some short-lived auxiliary sessions had retired by a later status read; their original outputs are retained, and the substantive native baseline/final-check receipts include explicit process exits.

## Receiving status and limits

This producer packet is frozen while root's separately authored eleven-group actual-HTTP receiver executes. Its outcome/source review must be recorded separately; no independent acceptance is asserted here yet. This packet qualifies native development source. It makes no hosted Node20, canonical-main adoption, Alexa/provider onboarding, live-ledger or deployment claim.
