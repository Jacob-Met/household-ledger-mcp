import base64, datetime, gzip, hashlib, io, json, os, pathlib, stat, tarfile, traceback

BASE = pathlib.Path("/Users/me/hamon-household-export-7a9310dad255")
RECEIVER = pathlib.Path("/Users/me/hamon-household-export-receiving-7a9310dad255")
ARCHIVE = BASE / "household-transaction-export-after2b77-receiving.tar.gz"
RECEIPT = BASE / "owner-package-receipt.json"
MANIFEST = BASE / "owner-archive-manifest.json"
FAILURE = BASE / "owner-package-failure-v1.json"

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=True) + "\n").encode()

def hash_file(path):
    if path.is_symlink() or not path.is_file():
        raise ValueError("Not a regular immutable input: " + str(path))
    before = path.stat()
    h = hashlib.sha256()
    g = hashlib.sha1(b"blob " + str(before.st_size).encode() + b"\0")
    count = 0
    with path.open("rb") as stream:
        while True:
            chunk = stream.read(1024 * 1024)
            if not chunk:
                break
            count += len(chunk)
            h.update(chunk)
            g.update(chunk)
    after = path.stat()
    if (before.st_size, before.st_mtime_ns, before.st_ino) != (after.st_size, after.st_mtime_ns, after.st_ino) or count != before.st_size:
        raise ValueError("Input changed while hashing: " + str(path))
    return {"bytes": count, "sha256": h.hexdigest(), "git_blob": g.hexdigest(), "mode": format(stat.S_IMODE(before.st_mode), "04o")}

def hash_bytes(raw, mode="0644"):
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(), "git_blob": hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest(), "mode": mode}

def validate_name(name):
    path = pathlib.PurePosixPath(name)
    if path.is_absolute() or ".." in path.parts or not path.parts or str(path) != name:
        raise ValueError("Unsafe archive name: " + name)

def admit_manifest(name, expected):
    path = BASE / name
    pins = hash_file(path)
    assert pins["sha256"] == expected, (name, pins)
    return json.loads(path.read_bytes())

def check_pins(name, pins, expected):
    for key in ("bytes", "sha256"):
        if key in expected:
            assert pins[key] == expected[key], (name, key, pins[key], expected[key])
    expected_blob = expected.get("git_blob", expected.get("sha"))
    if expected_blob:
        assert pins["git_blob"] == expected_blob, (name, "git_blob")
    if "mode" in expected:
        expected_mode = expected["mode"]
        if expected_mode.startswith("100"):
            expected_mode = expected_mode[-3:]
        assert int(pins["mode"], 8) == int(expected_mode, 8), (name, "mode")

started = now()
try:
    assert not ARCHIVE.exists() and not RECEIPT.exists() and not MANIFEST.exists()
    baseline = admit_manifest("baseline-source-manifest.json", "f18faaac133285d09bd9e533d3e43e1cee521c0887e5a7ec8bba4a90940167df")
    final = admit_manifest("candidate-final-source-manifest.json", "30ffa80337ae70fb4a29fa7064e8b18832ce8b7d72ddeaab28e3d705519f1fd0")
    artifacts = admit_manifest("candidate-artifact-manifest.json", "db7987539fd28f759543ed59c127dad4387b52b878aded8b14f5b2a4df9899bc")
    receiver_manifest_path = RECEIVER / "ROOT-MANIFEST.json"
    receiver_manifest_pins = hash_file(receiver_manifest_path)
    assert receiver_manifest_pins["sha256"] == "3c29843c3637f92c5fa67cda1e1c3a69f7f85d44fea362ead139870f7c2fc671"
    assert receiver_manifest_pins["git_blob"] == "f76e035744e6a3b507baa6a1d99722170f482bc0"
    receiver_manifest = json.loads(receiver_manifest_path.read_bytes())
    assert final["tree"] == artifacts["source_tree"] == receiver_manifest["source_tree"] == "81aeb4162cf6d793093f920ac7ca03a520169258"
    assert len(final["entries"]) == 103 and len(artifacts["compiled_files"]) == 78
    assert len(receiver_manifest["files"]) == receiver_manifest["total_files"] == 120
    assert sum(row["bytes"] for row in receiver_manifest["files"]) == receiver_manifest["total_bytes"] == 12693627

    members = {}
    def add(name, source, expected=None):
        validate_name(name)
        assert name not in members, name
        pins = hash_file(source)
        if expected is not None:
            check_pins(name, pins, expected)
        members[name] = {"source": source, "pins": pins}

    add("README.md", BASE / "SOURCE_PACKAGE.md")
    for row in final["entries"]:
        add("candidate/" + row["path"], BASE / "candidate" / row["path"], row)
    for row in artifacts["compiled_files"]:
        add("compiled/" + row["path"], BASE / "candidate" / row["path"], row)
    baseline_rows = {row["path"]: row for row in baseline["source_entries"]}
    modified = [row for row in final["contribution"] if row["path"] in baseline_rows]
    assert len(modified) == 5 and len(final["contribution"]) == 11
    for row in modified:
        add("parent-files/" + row["path"], BASE / "baseline" / row["path"], baseline_rows[row["path"]])
    add("source.patch", BASE / "candidate-final-source.patch")
    for name in (
        "baseline-source-manifest.json",
        "candidate-source-manifest.json",
        "candidate-corrected-source-manifest.json",
        "candidate-final-source-manifest.json",
        "candidate-artifact-manifest.json",
        "source-preservation.json",
    ):
        add("manifests/" + name, BASE / name)
    producer_paths = [
        "contract.md", "contract-freeze.json", "fixtures/literal-ledger.json",
        "missing-export-baseline.mjs", "build-and-receive-baseline.py",
        "baseline-execution.json", "authority-read.json", "owner-read-current.json",
        "capture-process.json", "native-process-results.json", "candidate-inline-refusal.json",
        "test-proposal/freeze.json", "test-proposal/http-freeze.json",
        "candidate-v1-changed-test.ts", "test-annotation-correction.json",
        "catalog-count-correction.json", "apply-test-annotation.py", "apply-catalog-count.py",
        "assemble-candidate.py", "candidate-input.json",
        "run-candidate-checks-v1.py", "run-candidate-checks-v2.py", "run-candidate-checks-v3.py",
        "verify-source-preservation.py", "package-source.py", "package-owner-receiving.py",
        "packaging-count-failure.json", "SOURCE_PACKAGE-before-count-correction.md",
        "baseline-evidence/ledger.json", "baseline-evidence/receipt.json",
        "baseline-evidence/build.stdout.log", "baseline-evidence/build.stderr.log",
        "baseline-evidence/consumer.stdout.log", "baseline-evidence/consumer.stderr.log",
        "baseline-evidence/server.stdout.log", "baseline-evidence/server.stderr.log",
        "candidate-checks-v1/execution.json", "candidate-checks-v1/typecheck.stdout.log",
        "candidate-checks-v1/typecheck.stderr.log",
        "candidate-checks-v2/execution.json", "candidate-checks-v2/typecheck.stdout.log",
        "candidate-checks-v2/typecheck.stderr.log", "candidate-checks-v2/tests.stdout.log",
        "candidate-checks-v2/tests.stderr.log",
        "candidate-checks-v3/execution.json", "candidate-checks-v3/typecheck.stdout.log",
        "candidate-checks-v3/typecheck.stderr.log", "candidate-checks-v3/tests.stdout.log",
        "candidate-checks-v3/tests.stderr.log",
    ]
    for name in producer_paths:
        add("producer/" + name, BASE / name)
    for row in receiver_manifest["files"]:
        add("receiver/" + row["path"], RECEIVER / row["path"], row)
    add("receiver/ROOT-MANIFEST.json", receiver_manifest_path, receiver_manifest_pins)

    records = [{"path": name, **members[name]["pins"]} for name in sorted(members)]
    archive_manifest = {
        "format": "household-transaction-export-owner-archive/v1",
        "created_at": started,
        "base_head": final["base_head"],
        "base_tree": final["base_tree"],
        "candidate_tree": final["tree"],
        "candidate_source_files": len(final["entries"]),
        "compiled_files": len(artifacts["compiled_files"]),
        "runtime_compiled_files": sum(row["path"].startswith("dist/src/") for row in artifacts["compiled_files"]),
        "receiver_root_manifest": {"path": "receiver/ROOT-MANIFEST.json", **receiver_manifest_pins},
        "file_count_excluding_this_manifest": len(records),
        "bytes_excluding_this_manifest": sum(row["bytes"] for row in records),
        "files": records,
        "scope": "Exact content-pinned after-owner source and actual native producer/independent receiving evidence. No fabricated Git ancestry, hosted CI, canonical adoption, or deployment."
    }
    manifest_raw = encoded(archive_manifest)
    with MANIFEST.open("xb") as stream:
        stream.write(manifest_raw)
    manifest_pins = hash_bytes(manifest_raw)
    all_records = records + [{"path": "archive-manifest.json", **manifest_pins}]
    with ARCHIVE.open("xb") as output:
        with gzip.GzipFile(filename="", mode="wb", fileobj=output, compresslevel=9, mtime=0) as compressed:
            with tarfile.open(mode="w", fileobj=compressed, format=tarfile.PAX_FORMAT) as archive:
                for name in sorted(members):
                    entry = members[name]
                    info = tarfile.TarInfo(name)
                    info.size = entry["pins"]["bytes"]
                    info.mode = int(entry["pins"]["mode"], 8)
                    info.uid = info.gid = info.mtime = 0
                    info.uname = info.gname = ""
                    with entry["source"].open("rb") as source:
                        archive.addfile(info, source)
                info = tarfile.TarInfo("archive-manifest.json")
                info.size = len(manifest_raw)
                info.mode = 0o644
                info.uid = info.gid = info.mtime = 0
                info.uname = info.gname = ""
                archive.addfile(info, io.BytesIO(manifest_raw))
        output.flush()
        os.fsync(output.fileno())

    expected_members = {row["path"]: row for row in all_records}
    seen = set()
    with tarfile.open(ARCHIVE, mode="r:gz") as archive:
        for member in archive:
            assert member.isfile(), member.name
            assert member.name in expected_members and member.name not in seen, member.name
            seen.add(member.name)
            expected = expected_members[member.name]
            assert member.size == expected["bytes"] and member.mode == int(expected["mode"], 8), member.name
            h = hashlib.sha256()
            g = hashlib.sha1(b"blob " + str(member.size).encode() + b"\0")
            count = 0
            with archive.extractfile(member) as source:
                while True:
                    chunk = source.read(1024 * 1024)
                    if not chunk:
                        break
                    count += len(chunk)
                    h.update(chunk)
                    g.update(chunk)
            assert count == member.size and h.hexdigest() == expected["sha256"] and g.hexdigest() == expected["git_blob"], member.name
    assert seen == set(expected_members)
    for name, entry in members.items():
        check_pins(name, hash_file(entry["source"]), entry["pins"])
    assert hash_file(MANIFEST) == manifest_pins
    archive_pins = hash_file(ARCHIVE)
    receipt = {
        "format": "household-transaction-export-owner-package-receipt/v1",
        "started_at": started, "finished_at": now(),
        "archive": {"path": str(ARCHIVE), **archive_pins},
        "archive_manifest": {"path": str(MANIFEST), **manifest_pins},
        "archive_members": len(all_records),
        "uncompressed_member_bytes": sum(row["bytes"] for row in all_records),
        "source_tree": final["tree"], "source_base_head": final["base_head"], "source_base_tree": final["base_tree"],
        "source_manifest": {"path": str(BASE / "candidate-final-source-manifest.json"), **hash_file(BASE / "candidate-final-source-manifest.json")},
        "artifact_manifest": {"path": str(BASE / "candidate-artifact-manifest.json"), **hash_file(BASE / "candidate-artifact-manifest.json")},
        "receiver_manifest": {"path": str(receiver_manifest_path), **receiver_manifest_pins},
        "counts": {"candidate_source": 103, "compiled": 78, "modified_parent_files": 5,
                   "producer_files": len(producer_paths), "receiver_files_including_manifest": 121,
                   "source_manifests": 6, "readme": 1, "source_patch": 1, "archive_manifest": 1},
        "verification": {"every_input_hash_before_stream": True, "every_archive_member_bytes_hash_mode": True,
                         "every_input_hash_after_stream": True, "source_or_receiver_writes": 0,
                         "receiver_raw_staging_copies": 0},
        "native_qualification": {"producer": "typecheck and 131/131 tests passed on Node 26.3.0",
                                 "independent": "8 HTTP groups, 64 tool calls, 19 client-saved CSVs passed",
                                 "boundary": "Actual native development/receiving only; no hosted Node 20, canonical-main adoption, provider/live-ledger mutation, or deployment."}
    }
    with RECEIPT.open("xb") as stream:
        stream.write(encoded(receipt))
    print(json.dumps({"base": str(BASE), "receipt": {"path": str(RECEIPT), **hash_file(RECEIPT)}, **receipt}, separators=(",", ":")))
except Exception as exc:
    failure = {"at": now(), "started_at": started, "exception": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc(),
               "archive_exists": ARCHIVE.exists(), "manifest_exists": MANIFEST.exists()}
    if ARCHIVE.exists():
        failure["partial_archive"] = hash_file(ARCHIVE)
    try:
        with FAILURE.open("xb") as stream:
            stream.write(encoded(failure))
    except Exception as failure_exc:
        failure["failure_receipt_error"] = str(failure_exc)
    print(json.dumps(failure))
    raise
