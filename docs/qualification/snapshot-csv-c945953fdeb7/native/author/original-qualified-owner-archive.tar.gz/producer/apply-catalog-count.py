import difflib,hashlib,json,pathlib,time
root=pathlib.Path("/Users/me/hamon-household-export-7a9310dad255");source=root/"candidate"
manifest=json.loads((root/"candidate-corrected-source-manifest.json").read_text())
def pin(raw):return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"sha":hashlib.sha1(("blob "+str(len(raw))+"\0").encode()+raw).hexdigest()}
def tree_hash(rows):
 tree={}
 for r in rows:
  at=tree;parts=r["path"].split("/")
  for part in parts[:-1]:at=at.setdefault(part,{})
  at[parts[-1]]=(r["mode"],r["sha"])
 def digest(node):
  pieces=[]
  for name,value in sorted(node.items(),key=lambda pair:(pair[0]+("/" if isinstance(pair[1],dict) else "")).encode()):
   mode,sha=("40000",digest(value)) if isinstance(value,dict) else value
   pieces.append((mode+" "+name+"\0").encode()+bytes.fromhex(sha))
  raw=b"".join(pieces);return hashlib.sha1(("tree "+str(len(raw))+"\0").encode()+raw).hexdigest()
 return digest(tree)
for row in manifest["entries"]:assert pin((source/row["path"]).read_bytes())["sha"]==row["sha"],row["path"]
name="test/budget-copy-http.test.ts";p=source/name;before=p.read_bytes()
needle=b"    assert.equal(catalogue.length, 10);";replacement=b"    assert.equal(catalogue.length, 11);"
assert before.count(needle)==1
after=before.replace(needle,replacement);p.write_bytes(after)
assert after.replace(replacement,needle)==(root/"baseline"/name).read_bytes()
change={"path":name,"before":pin(before),"after":pin(after),"reason":"One new export tool makes the exact catalog count eleven; every budget tool and behavior assertion is unchanged.","patch":"".join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile="a/"+name,tofile="b/"+name))}
(root/"catalog-count-correction.json").write_text(json.dumps(change,indent=2)+"\n")
changed=None
for row in manifest["entries"]:
 if row["path"]==name:
  row.update(pin(after));changed=dict(row)
assert changed is not None
manifest["contribution"].append(changed);manifest["contribution"].sort(key=lambda r:r["path"])
assert len(manifest["contribution"])==11
manifest["tree"]=tree_hash(manifest["entries"])
manifest["unchanged_parent_files"]=92
manifest["previous_manifest"]=pin((root/"candidate-corrected-source-manifest.json").read_bytes())
manifest["catalog_count_correction"]=pin((root/"catalog-count-correction.json").read_bytes())
manifest["created_at"]=time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime())
q=root/"candidate-final-source-manifest.json";q.write_text(json.dumps(manifest,indent=2)+"\n")
baseline=root/"baseline";parent={r["path"] for r in json.loads((root/"baseline-source-manifest.json").read_text())["source_entries"]}
patch=[]
for row in manifest["contribution"]:
 rel=row["path"];old=(baseline/rel).read_text() if rel in parent else "";new=(source/rel).read_text()
 patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile="a/"+rel if rel in parent else "/dev/null",tofile="b/"+rel))
(root/"candidate-final-source.patch").write_text("".join(patch))
for row in manifest["entries"]:assert pin((source/row["path"]).read_bytes())["sha"]==row["sha"],row["path"]
print(json.dumps({"base":str(root),"tree":manifest["tree"],"manifest":pin(q.read_bytes()),"correction":change,"all_other_source_files_exact":102,"contribution_count":len(manifest["contribution"])}))
