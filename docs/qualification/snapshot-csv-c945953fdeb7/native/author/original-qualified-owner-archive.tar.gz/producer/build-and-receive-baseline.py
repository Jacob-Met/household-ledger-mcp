import hashlib,json,pathlib,subprocess,time
root=pathlib.Path("/Users/me/hamon-household-export-7a9310dad255")
manifest=json.loads((root/"baseline-source-manifest.json").read_text())
def pin(raw):return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"sha":hashlib.sha1(("blob "+str(len(raw))+"\0").encode()+raw).hexdigest()}
def verify():
 for row in manifest["source_entries"]:
  p=root/"baseline"/row["path"];assert pin(p.read_bytes())["sha"]==row["sha"],row["path"]
 for row in manifest["dependencies"]["entries"]:
  assert pin(pathlib.Path(row["path"]).read_bytes())["sha256"]==row["sha256"],row["path"]
verify()
freeze=json.loads((root/"contract-freeze.json").read_text())
for row in freeze["files"]:
 assert pin(pathlib.Path(row["path"]).read_bytes())["sha256"]==row["sha256"],row["path"]
commands=[
 ("build",[manifest["node"]["path"],str(pathlib.Path(manifest["dependencies"]["path"])/"typescript/bin/tsc"),"--project",str(root/"baseline/tsconfig.json")]),
 ("consumer",[manifest["node"]["path"],str(root/"missing-export-baseline.mjs"),str(root/"baseline"),str(root/"baseline-evidence"),manifest["dependencies"]["path"]])
]
results=[]
for label,argv in commands:
 started=time.time()
 run=subprocess.run(argv,cwd=root/"baseline",stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (root/"baseline-evidence"/(label+".stdout.log")).write_bytes(run.stdout)
 (root/"baseline-evidence"/(label+".stderr.log")).write_bytes(run.stderr)
 results.append({"label":label,"argv":argv,"cwd":str(root/"baseline"),"exit_code":run.returncode,"elapsed_seconds":time.time()-started,"stdout":pin(run.stdout),"stderr":pin(run.stderr)})
 if run.returncode:break
verify()
compiled=[]
for p in sorted((root/"baseline/dist").rglob("*")):
 if p.is_file():compiled.append({"path":p.relative_to(root/"baseline").as_posix(),**pin(p.read_bytes())})
receipt={"source_head":manifest["source_head"],"source_tree":manifest["source_tree"],"node":manifest["node"],"dependencies":manifest["dependencies"],"commands":results,"all_97_source_inputs_unchanged":True,"all_dependency_entry_pins_unchanged":True,"compiled_files":compiled,"no_owner_or_git_mutation":True}
path=root/"baseline-execution.json";path.write_text(json.dumps(receipt,indent=2)+"\n")
raw=root/"baseline-evidence/receipt.json"
print(json.dumps({"base":str(root),"execution":pin(path.read_bytes()),"commands":results,"compiled_files":len(compiled),"consumer_receipt":pin(raw.read_bytes()) if raw.exists() else None,"consumer_summary":json.loads(raw.read_text())["outcome"] if raw.exists() else None}))
raise SystemExit(0 if len(results)==2 and all(r["exit_code"]==0 for r in results) else 1)
