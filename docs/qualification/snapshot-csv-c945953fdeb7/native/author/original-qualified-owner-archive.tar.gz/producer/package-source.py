import gzip,hashlib,io,json,pathlib,tarfile,time
root=pathlib.Path("/Users/me/hamon-household-export-7a9310dad255")
base=json.loads((root/"baseline-source-manifest.json").read_text())
final=json.loads((root/"candidate-final-source-manifest.json").read_text())
artifact=json.loads((root/"candidate-artifact-manifest.json").read_text())
members={}
def pin(raw):return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"sha":hashlib.sha1(("blob "+str(len(raw))+"\0").encode()+raw).hexdigest()}
def add(name,path,mode=0o644):
 assert not pathlib.PurePosixPath(name).is_absolute() and ".." not in pathlib.PurePosixPath(name).parts
 assert name not in members,name
 p=pathlib.Path(path);assert p.is_file() and not p.is_symlink(),str(p)
 members[name]=(p.read_bytes(),mode)
for row in final["entries"]:
 p=root/"candidate"/row["path"];assert pin(p.read_bytes())["sha"]==row["sha"],row["path"]
 add("candidate/"+row["path"],p,0o755 if row["mode"]=="100755" else 0o644)
parent={r["path"]:r for r in base["source_entries"]}
for row in final["contribution"]:
 if row["path"] in parent:
  p=root/"baseline"/row["path"];assert pin(p.read_bytes())["sha"]==parent[row["path"]]["sha"]
  add("parent-files/"+row["path"],p,0o755 if parent[row["path"]]["mode"]=="100755" else 0o644)
runtime=[r for r in artifact["compiled_files"] if r["path"].startswith("dist/src/")]
assert len(runtime)==21
for row in runtime:
 p=root/"candidate"/row["path"];assert pin(p.read_bytes())["sha"]==row["sha"],row["path"]
 add("compiled-runtime/"+row["path"],p)
add("README.md",root/"SOURCE_PACKAGE.md")
add("source.patch",root/"candidate-final-source.patch")
for name in ["baseline-source-manifest.json","candidate-source-manifest.json","candidate-corrected-source-manifest.json","candidate-final-source-manifest.json","candidate-artifact-manifest.json","source-preservation.json"]:
 add("manifests/"+name,root/name)
for name in [
 "contract.md","contract-freeze.json","fixtures/literal-ledger.json","missing-export-baseline.mjs","build-and-receive-baseline.py","baseline-execution.json",
 "authority-read.json","owner-read-current.json","capture-process.json","native-process-results.json","candidate-inline-refusal.json",
 "test-proposal/freeze.json","test-proposal/http-freeze.json","candidate-v1-changed-test.ts","test-annotation-correction.json","catalog-count-correction.json",
 "run-candidate-checks-v1.py","run-candidate-checks-v2.py","run-candidate-checks-v3.py","verify-source-preservation.py",
 "baseline-evidence/ledger.json","baseline-evidence/receipt.json","baseline-evidence/build.stdout.log","baseline-evidence/build.stderr.log",
 "baseline-evidence/consumer.stdout.log","baseline-evidence/consumer.stderr.log","baseline-evidence/server.stdout.log","baseline-evidence/server.stderr.log",
 "candidate-checks-v1/execution.json","candidate-checks-v1/typecheck.stdout.log","candidate-checks-v1/typecheck.stderr.log",
 "candidate-checks-v2/execution.json","candidate-checks-v2/typecheck.stdout.log","candidate-checks-v2/typecheck.stderr.log","candidate-checks-v2/tests.stdout.log","candidate-checks-v2/tests.stderr.log",
 "candidate-checks-v3/execution.json","candidate-checks-v3/typecheck.stdout.log","candidate-checks-v3/typecheck.stderr.log","candidate-checks-v3/tests.stdout.log","candidate-checks-v3/tests.stderr.log"]:
 add("producer/"+name,root/name)
manifest={
 "archive_kind":"Complete frozen source with narrow after2b77 delta and native producer evidence; no Git history or dependency binaries",
 "source_base":{"head":base["source_head"],"tree":base["source_tree"],"files":len(base["source_entries"])},
 "source_candidate":{"computed_tree":final["tree"],"files":len(final["entries"]),"contribution_paths":len(final["contribution"]),"unchanged_parent_files":92},
 "source_files_included":103,"compiled_runtime_files_included":21,
 "independent_receiving_status":"Root eleven-group receiver frozen and executing separately; producer archive does not claim its outcome.",
 "members":[{"path":name,"mode":oct(mode),**pin(raw)} for name,(raw,mode) in sorted(members.items())]
}
manifest_bytes=(json.dumps(manifest,indent=2)+"\n").encode()
members["archive-manifest.json"]=(manifest_bytes,0o644)
target=root/"after2b77-source-reproduction.tar.gz";assert not target.exists()
with target.open("xb") as output:
 with gzip.GzipFile(filename="",fileobj=output,mode="wb",compresslevel=9,mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode="w",format=tarfile.PAX_FORMAT) as tar:
   for name,(raw,mode) in sorted(members.items()):
    info=tarfile.TarInfo(name);info.size=len(raw);info.mode=mode;info.mtime=0;info.uid=0;info.gid=0;info.uname="";info.gname=""
    tar.addfile(info,io.BytesIO(raw))
with tarfile.open(target,"r:gz") as tar:
 entries=tar.getmembers();assert len(entries)==len(members)
 for entry in entries:
  assert entry.isfile() and not entry.issym() and not entry.islnk()
  expected,mode=members[entry.name];assert tar.extractfile(entry).read()==expected and entry.mode==mode,entry.name
for row in final["entries"]:assert pin((root/"candidate"/row["path"]).read_bytes())["sha"]==row["sha"],row["path"]
for row in artifact["compiled_files"]:assert pin((root/"candidate"/row["path"]).read_bytes())["sha"]==row["sha"],row["path"]
receipt={"packaged_at":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"archive_path":str(target),"archive":pin(target.read_bytes()),"archive_members":len(members),"uncompressed_member_bytes":sum(len(raw) for raw,mode in members.values()),"archive_manifest":pin(manifest_bytes),"all_members_read_back_exact":True,"source_tree":final["tree"],"source_manifest":pin((root/"candidate-final-source-manifest.json").read_bytes()),"source_patch":pin((root/"candidate-final-source.patch").read_bytes()),"compiled_artifact_manifest":pin((root/"candidate-artifact-manifest.json").read_bytes()),"all_103_source_and_78_compiled_outputs_remain_frozen":True,"publication_status":"Prepared native packet only; root owns all Git mutations and receiving-owner handoff."}
p=root/"producer-package-receipt.json";p.write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps({"base":str(root),"receipt":pin(p.read_bytes()),**receipt}))
