import hashlib,json,os,pathlib,subprocess,time
root=pathlib.Path("/Users/me/hamon-household-export-7a9310dad255")
source=root/"candidate"
baseline=json.loads((root/"baseline-source-manifest.json").read_text())
manifest=json.loads((root/"candidate-corrected-source-manifest.json").read_text())
out=root/"candidate-checks-v2";out.mkdir()
def pin(raw):return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"sha":hashlib.sha1(("blob "+str(len(raw))+"\0").encode()+raw).hexdigest()}
def verify():
 for row in manifest["entries"]:
  p=source/row["path"];assert pin(p.read_bytes())["sha"]==row["sha"],row["path"]
  assert ("100755" if p.stat().st_mode & 0o111 else "100644")==row["mode"],row["path"]
 for row in baseline["dependencies"]["entries"]:
  assert pin(pathlib.Path(row["path"]).read_bytes())["sha256"]==row["sha256"],row["path"]
verify()
env=dict(os.environ)
env["PATH"]="/opt/homebrew/bin:"+env.get("PATH","")
env["npm_config_cache"]=str(root/"npm-cache")
env["npm_config_update_notifier"]="false"
env["npm_config_audit"]="false"
env["npm_config_fund"]="false"
npm="/opt/homebrew/bin/npm"
assert pathlib.Path(npm).exists()
versions={"node":subprocess.check_output([baseline["node"]["path"],"--version"],text=True).strip(),"npm":subprocess.check_output([npm,"--version"],env=env,text=True).strip(),"npm_cli":str(pathlib.Path(npm).resolve())}
results=[]
for label,argv in [("typecheck",[npm,"run","typecheck"]),("tests",[npm,"test"])]:
 start=time.time()
 run=subprocess.run(argv,cwd=source,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (out/(label+".stdout.log")).write_bytes(run.stdout);(out/(label+".stderr.log")).write_bytes(run.stderr)
 results.append({"label":label,"argv":argv,"cwd":str(source),"exit_code":run.returncode,"elapsed_seconds":time.time()-start,"stdout":pin(run.stdout),"stderr":pin(run.stderr)})
 if run.returncode:break
verify()
compiled=[]
for p in sorted((source/"dist").rglob("*")):
 if p.is_file():compiled.append({"path":p.relative_to(source).as_posix(),**pin(p.read_bytes())})
receipt={"started_from_source_tree":manifest["tree"],"source_manifest":pin((root/"candidate-corrected-source-manifest.json").read_bytes()),"versions":versions,"commands":results,"all_103_source_inputs_unchanged":True,"all_readonly_dependency_pins_unchanged":True,"compiled_files":compiled,"dependency_install_performed":False,"git_mutations":False}
p=out/"execution.json";p.write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps({"base":str(root),"execution":pin(p.read_bytes()),"versions":versions,"commands":results,"compiled_files":len(compiled),"test_tail":(out/"tests.stdout.log").read_text().splitlines()[-14:] if (out/"tests.stdout.log").exists() else None,"failure_output":(out/(results[-1]["label"]+".stdout.log")).read_text()[-6000:] if results[-1]["exit_code"] else None}))
raise SystemExit(0 if len(results)==2 and all(r["exit_code"]==0 for r in results) else 1)
