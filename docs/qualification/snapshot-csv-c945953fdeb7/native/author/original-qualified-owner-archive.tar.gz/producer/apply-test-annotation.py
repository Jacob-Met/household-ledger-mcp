import difflib,hashlib,json,pathlib,time
root=pathlib.Path("/Users/me/hamon-household-export-7a9310dad255")
source=root/"candidate"
manifest=json.loads((root/"candidate-source-manifest.json").read_text())
def pin(raw):return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"sha":hashlib.sha1(("blob "+str(len(raw))+"\0").encode()+raw).hexdigest()}
def tree_hash(rows):
 tree={}
 for r in rows:
  at=tree;parts=r["path"].split("/")
  for part in parts[:-1]:at=at.setdefault(part,{})
  at[parts[-1]]=(r["mode"],r["sha"])
 def digest(node):
  pieces=[]
  for name,value in sorted(node.items(),key=lambda pair:(pair[0]+("/" if isinstance(pair[1],dict) else "")).encode()):
   mode,sha=("40000",digest(value)) if isinstance(value,dict) else value
   pieces.append((mode+" "+name+"\0").encode()+bytes.fromhex(sha))
  raw=b"".join(pieces);return hashlib.sha1(("tree "+str(len(raw))+"\0").encode()+raw).hexdigest()
 return digest(tree)
for row in manifest["entries"]:assert pin((source/row["path"]).read_bytes())["sha"]==row["sha"],row["path"]
relative="test/transaction-export-http.test.ts"
p=source/relative;before=p.read_bytes();text=before.decode()
needle="      const report = payload<TransactionCsvExport>(await guardedCall(service.client, path, filter));"
assert text.count(needle)==1
after=text.replace(needle,"      const report: TransactionCsvExport = payload<TransactionCsvExport>(await guardedCall(service.client, path, filter));").encode()
old=root/"candidate-v1-changed-test.ts";old.write_bytes(before)
p.write_bytes(after)
change={"path":relative,"before":pin(before),"after":pin(after),"reason":"TypeScript5.9 TS7022 inference in new authored HTTP test; explicit annotation only, no assertion or production change","patch":"".join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile="a/"+relative,tofile="b/"+relative))}
(root/"test-annotation-correction.json").write_text(json.dumps(change,indent=2)+"\n")
for collection in ["entries","contribution"]:
 for row in manifest[collection]:
  if row["path"]==relative:row.update(pin(after))
manifest["tree"]=tree_hash(manifest["entries"])
manifest["previous_manifest"]=pin((root/"candidate-source-manifest.json").read_bytes())
manifest["test_annotation_correction"]=pin((root/"test-annotation-correction.json").read_bytes())
manifest["created_at"]=time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime())
q=root/"candidate-corrected-source-manifest.json";q.write_text(json.dumps(manifest,indent=2)+"\n")
baseline=root/"baseline";parent={r["path"] for r in json.loads((root/"baseline-source-manifest.json").read_text())["source_entries"]}
patch=[]
for row in manifest["contribution"]:
 name=row["path"];old=(baseline/name).read_text() if name in parent else "";new=(source/name).read_text()
 patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile="a/"+name if name in parent else "/dev/null",tofile="b/"+name))
(root/"candidate-corrected-source.patch").write_text("".join(patch))
for row in manifest["entries"]:assert pin((source/row["path"]).read_bytes())["sha"]==row["sha"],row["path"]
print(json.dumps({"base":str(root),"tree":manifest["tree"],"manifest":pin(q.read_bytes()),"correction":change,"all_other_source_files_exact":102}))
