import difflib,hashlib,json,pathlib,time
spec=json.loads(pathlib.Path("/Users/me/hamon-household-export-7a9310dad255/candidate-input.json").read_text());root=pathlib.Path(spec["base"])
manifest=json.loads((root/"baseline-source-manifest.json").read_text())
baseline=root/"baseline";candidate=root/"candidate";assert not candidate.exists();candidate.mkdir()
def pin(raw):return {"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest(),"sha":hashlib.sha1(("blob "+str(len(raw))+"\0").encode()+raw).hexdigest()}
def tree_hash(rows):
 tree={}
 for r in rows:
  at=tree
  parts=r["path"].split("/")
  for part in parts[:-1]:at=at.setdefault(part,{})
  at[parts[-1]]=(r["mode"],r["sha"])
 def digest(node):
  pieces=[]
  for name,value in sorted(node.items(),key=lambda pair:(pair[0]+("/" if isinstance(pair[1],dict) else "")).encode()):
   mode,sha=("40000",digest(value)) if isinstance(value,dict) else value
   pieces.append((mode+" "+name+"\0").encode()+bytes.fromhex(sha))
  raw=b"".join(pieces)
  return hashlib.sha1(("tree "+str(len(raw))+"\0").encode()+raw).hexdigest()
 return digest(tree)
assert tree_hash(manifest["source_entries"])==manifest["source_tree"]
for row in manifest["source_entries"]:
 raw=(baseline/row["path"]).read_bytes();assert pin(raw)["sha"]==row["sha"]
 p=candidate/row["path"];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);p.chmod(0o755 if row["mode"]=="100755" else 0o644)
(candidate/"node_modules").symlink_to(manifest["dependencies"]["path"],target_is_directory=True)
for name,text in spec["tests"].items():
 assert (root/"test-proposal"/name).read_bytes()==text.encode("utf8"),name
new_files={"src/transaction-export.ts":spec["module"],"docs/TRANSACTION_EXPORT.md":spec["docs"],**spec["tests"]}
for path,text in new_files.items():
 p=candidate/path;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
source=(candidate/"src/index.ts").read_text()
import_anchor='import { commitBudgetCopy, previewBudgetCopy, BUDGET_COPY_TOOL_DEFS } from "./budget-copy.js";\n'
assert source.count(import_anchor)==1
source=source.replace(import_anchor,import_anchor+'import { exportTransactionsCsv, TRANSACTION_EXPORT_TOOL_DEF } from "./transaction-export.js";\n')
defs_anchor='  ...BUDGET_COPY_TOOL_DEFS,\n'
assert source.count(defs_anchor)==1
source=source.replace(defs_anchor,defs_anchor+'  TRANSACTION_EXPORT_TOOL_DEF,\n')
case_anchor='      switch (request.params.name) {\n'
assert source.count(case_anchor)==1
source=source.replace(case_anchor,case_anchor+'        case "export_transactions_csv": {\n          const result = exportTransactionsCsv(await store.load(), args);\n          return { content: [{ type: "text", text: JSON.stringify(result) }] };\n        }\n')
(candidate/"src/index.ts").write_text(source)
readme=(candidate/"README.md").read_text()
bt=chr(96)
table_anchor=("| ^list_transactions^ | Filter and page the recorded transactions. |\n").replace("^",bt)
assert readme.count(table_anchor)==1
readme=readme.replace(table_anchor,table_anchor+("| ^export_transactions_csv^ | Prepare a complete bounded CSV statement with original transaction values for the client to save. |\n").replace("^",bt))
link_anchor='See [CSV transaction import](docs/TRANSACTION_IMPORT.md) for the required source columns, preview/review/commit flow and retry rules.\n'
assert readme.count(link_anchor)==1
readme=readme.replace(link_anchor,link_anchor+'\nSee [transaction CSV statements](docs/TRANSACTION_EXPORT.md) for exact columns, literal text preservation, whole-result limits and client-side saving.\n')
(candidate/"README.md").write_text(readme)
for path in ["test/mcp.test.ts","test/transaction-import-http.test.ts"]:
 p=candidate/path;text=p.read_text()
 needle='"commit_transaction_import", "get_budgets"';assert text.count(needle)==1
 p.write_text(text.replace(needle,'"commit_transaction_import", "export_transactions_csv", "get_budgets"'))
entries=[]
for p in sorted(candidate.rglob("*")):
 if p.is_file() and not p.is_symlink():
  entries.append({"path":p.relative_to(candidate).as_posix(),"mode":"100755" if p.stat().st_mode & 0o111 else "100644",**pin(p.read_bytes())})
parent={r["path"]:r for r in manifest["source_entries"]}
changed=[r for r in entries if r["path"] not in parent or r["sha"]!=parent[r["path"]]["sha"]]
assert len(entries)==103 and len(changed)==10
assert (candidate/"src/ledger.ts").read_bytes()==(baseline/"src/ledger.ts").read_bytes()
patch=[]
for r in changed:
 name=r["path"];old=(baseline/name).read_text() if name in parent else ""
 new=(candidate/name).read_text()
 patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile="a/"+name if name in parent else "/dev/null",tofile="b/"+name))
(root/"candidate-source.patch").write_text("".join(patch))
receipt={"created_at":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"base_head":manifest["source_head"],"base_tree":manifest["source_tree"],"source_root":str(candidate),"tree":tree_hash(entries),"entries":entries,"contribution":changed,"unchanged_parent_files":len(parent)-4,"node":manifest["node"],"dependency_source_manifest_sha256":pin((root/"baseline-source-manifest.json").read_bytes())["sha256"],"ownership_scope":"Additive export module/tool/tests/docs only; no Git metadata or owner writes."}
p=root/"candidate-source-manifest.json";p.write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps({"base":str(root),"tree":receipt["tree"],"source_manifest":pin(p.read_bytes()),"contribution":changed,"unchanged_parent_files":receipt["unchanged_parent_files"],"patch":pin((root/"candidate-source.patch").read_bytes())}))
