import { test } from "node:test";
import assert from "node:assert/strict";
import { promises as fs } from "node:fs";
import { mkdtemp, readFile, readdir, rm, stat } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { emptyLedger, LedgerStore, recordTransaction, setBudget, type LedgerData } from "../src/ledger.js";
import { commitBudgetCopy, previewBudgetCopy, type BudgetCopyPreview } from "../src/budget-copy.js";

const request = { fromMonth: "2026-10", toMonth: "2026-11", currency: "USD" };
const commitArgs = (p: BudgetCopyPreview) => ({ review: p.review, reviewToken: p.reviewToken });
async function snapshot(path: string) {
  return { bytes: await readFile(path), mtimeNs: (await stat(path, { bigint: true })).mtimeNs };
}
async function withLedger(work: (store: LedgerStore, path: string, dir: string) => Promise<void>) {
  const dir = await mkdtemp(join(tmpdir(), "hlm-budget-copy-a0eb-"));
  const path = join(dir, "ledger.json");
  const store = new LedgerStore(path);
  try { await store.save(emptyLedger()); await work(store, path, dir); }
  finally { await rm(dir, { recursive: true, force: true }); }
}
async function seed(store: LedgerStore) {
  await store.update(data => {
    setBudget(data, "groceries", "2026-10", 12500, "USD");
    setBudget(data, "travel", "2026-10", 0, "USD");
    setBudget(data, "groceries", "2026-10", 7100, "EUR");
  });
}
async function unchangedRejection(path: string, work: () => Promise<unknown>, pattern: RegExp) {
  const before = await snapshot(path);
  await assert.rejects(work, pattern);
  assert.deepEqual(await snapshot(path), before);
}

test("preview and whole-month copy retain zero limits, other denominations and recorded identities", async () => withLedger(async (store, path) => {
  await seed(store);
  const tx = await store.update(data => {
    setBudget(data, "groceries", "2026-11", 5000, "EUR");
    setBudget(data, "other month", "2026-12", 8800, "USD");
    return recordTransaction(data, { type: "expense", amountMinor: 123, currency: "USD", date: "2026-11-01", category: "groceries", idempotencyKey: "unchanged:record" });
  });
  const before = await snapshot(path);
  const preview = await previewBudgetCopy(store, { ...request, currency: " usd " });
  assert.deepEqual(preview.counts, { total: 2, add: 2, alreadyPresent: 0, conflict: 0 });
  assert.deepEqual(preview.rows.map(r => [r.category, r.limitMinor]), [["groceries", 12500], ["travel", 0]]);
  assert.equal(preview.currency, "USD");
  assert.deepEqual(await snapshot(path), before);
  const result = await commitBudgetCopy(store, commitArgs(preview));
  assert.equal(result.added, 2);
  assert.equal(result.alreadyPresent, 0);
  assert.deepEqual(result.budgets.map(b => [b.category, b.month, b.currency, b.limitMinor]), [
    ["groceries", "2026-11", "USD", 12500], ["travel", "2026-11", "USD", 0],
  ]);
  const data = await store.load();
  assert.deepEqual(data.transactions, [tx]);
  assert.equal(data.budgets.find(b => b.month === "2026-11" && b.currency === "EUR")!.limitMinor, 5000);
  assert.equal(data.budgets.find(b => b.month === "2026-12")!.limitMinor, 8800);
  assert.equal(data.version, 2);
}));

test("explicit subset preserves literal Unicode and reserved category names without expanding later source additions", async () => withLedger(async (store, path) => {
  await store.update(data => {
    setBudget(data, "__proto__", "2026-10", 1, "USD");
    setBudget(data, "旅行\n予定 🧭", "2026-10", 2, "USD");
    setBudget(data, "not selected", "2026-10", 3, "USD");
  });
  const preview = await previewBudgetCopy(store, { ...request, categories: ["旅行\n予定 🧭", "__proto__"] });
  assert.deepEqual(preview.review!.rows.map(r => r.category), ["旅行\n予定 🧭", "__proto__"]);
  await store.update(data => setBudget(data, "added after review", "2026-10", 4, "USD"));
  const result = await commitBudgetCopy(store, commitArgs(preview));
  assert.deepEqual(result.budgets.map(b => b.category), ["旅行\n予定 🧭", "__proto__"]);
  const saved = await store.load();
  assert.equal(saved.budgets.filter(b => b.month === "2026-11").length, 2);
  const beforeReplay = await snapshot(path);
  const replay = await commitBudgetCopy(new LedgerStore(path), JSON.parse(JSON.stringify(commitArgs(preview))));
  assert.equal(replay.added, 0);
  assert.equal(replay.alreadyPresent, 2);
  assert.deepEqual(await snapshot(path), beforeReplay);
}));

test("unassigned source budgets stay unassigned and require deliberate denominated selection", async () => withLedger(async (store, path) => {
  await store.update(data => setBudget(data, "rent", "2026-10", 90000));
  assert.equal((await store.load()).version, 1);
  await unchangedRejection(path, () => previewBudgetCopy(store, request), /unassigned/);
  await unchangedRejection(path, () => previewBudgetCopy(store, { ...request, categories: ["rent"] }), /unassigned/);
  assert.equal((await store.load()).version, 1);
  await store.update(data => setBudget(data, "food", "2026-10", 100, "USD"));
  await unchangedRejection(path, () => previewBudgetCopy(store, request), /unassigned/);
  const preview = await previewBudgetCopy(store, { ...request, categories: ["food"] });
  await commitBudgetCopy(store, commitArgs(preview));
  const data = await store.load();
  assert.deepEqual(data.budgets.find(b => b.category === "rent"), { category: "rent", month: "2026-10", limitMinor: 90000 });
  assert.equal(data.budgets.filter(b => b.month === "2026-11").length, 1);
}));

test("preview reports conflicting and unassigned destinations without issuing a commit review", async () => withLedger(async (store, path) => {
  await seed(store);
  await store.update(data => {
    setBudget(data, "groceries", "2026-11", 2, "USD");
    setBudget(data, "travel", "2026-11", 3);
  });
  const before = await snapshot(path);
  const preview = await previewBudgetCopy(store, request);
  assert.equal(preview.canCommit, false);
  assert.deepEqual(preview.counts, { total: 2, add: 0, alreadyPresent: 0, conflict: 2 });
  assert.equal(preview.review, null);
  assert.equal(preview.reviewToken, null);
  assert.match(preview.rows[0].reason!, /different limit/);
  assert.match(preview.rows[1].reason!, /unassigned/);
  assert.deepEqual(await snapshot(path), before);
}));

test("late source change refuses every destination addition and a fresh review can recover", async () => withLedger(async (store, path) => {
  await seed(store);
  const preview = await previewBudgetCopy(store, request);
  await store.update(data => setBudget(data, "travel", "2026-10", 500, "USD"));
  await unchangedRejection(path, () => commitBudgetCopy(store, commitArgs(preview)), /source limit changed/);
  assert.equal((await store.load()).budgets.filter(b => b.month === "2026-11").length, 0);
  const fresh = await previewBudgetCopy(store, request);
  assert.equal((await commitBudgetCopy(store, commitArgs(fresh))).added, 2);
  assert.equal((await store.load()).budgets.find(b => b.month === "2026-11" && b.category === "travel")!.limitMinor, 500);
}));

test("a queued conflicting writer is observed by the whole-batch commit from another Store", async () => withLedger(async (store, path) => {
  await seed(store);
  const preview = await previewBudgetCopy(store, request);
  let release!: () => void;
  let entered!: () => void;
  const held = new Promise<void>(r => { release = r; });
  const started = new Promise<void>(r => { entered = r; });
  const predecessor = store.update(async data => {
    entered(); await held;
    setBudget(data, "travel", "2026-11", 777, "USD");
  });
  await started;
  const copying = commitBudgetCopy(new LedgerStore(path), commitArgs(preview));
  const rejected = assert.rejects(copying, /destination conflict/);
  release();
  await predecessor;
  const afterWriter = await snapshot(path);
  await rejected;
  assert.deepEqual(await snapshot(path), afterWriter);
  const target = (await store.load()).budgets.filter(b => b.month === "2026-11");
  assert.deepEqual(target, [{ category: "travel", month: "2026-11", limitMinor: 777, currency: "USD" }]);
}));

test("matching concurrent destination and unrelated recordings survive a queued copy", async () => withLedger(async (store, path) => {
  await seed(store);
  const preview = await previewBudgetCopy(store, request);
  let release!: () => void;
  let entered!: () => void;
  const held = new Promise<void>(r => { release = r; });
  const started = new Promise<void>(r => { entered = r; });
  let recordedId = "";
  const predecessor = store.update(async data => {
    entered(); await held;
    setBudget(data, "groceries", "2026-11", 12500, "USD");
    setBudget(data, "groceries", "2026-11", 9900, "EUR");
    recordedId = recordTransaction(data, { type: "income", amountMinor: 75, currency: "USD", date: "2026-11-01", category: "gift", idempotencyKey: "queued:gift" }).id;
  });
  await started;
  const copying = commitBudgetCopy(new LedgerStore(path), commitArgs(preview));
  release(); await predecessor;
  const result = await copying;
  assert.equal(result.added, 1);
  assert.equal(result.alreadyPresent, 1);
  const data = await store.load();
  assert.equal(data.transactions[0].id, recordedId);
  assert.equal(data.budgets.find(b => b.month === "2026-11" && b.currency === "EUR")!.limitMinor, 9900);
  const beforeReplay = await snapshot(path);
  assert.equal((await commitBudgetCopy(store, commitArgs(preview))).added, 0);
  assert.deepEqual(await snapshot(path), beforeReplay);
}));

test("a previously present destination removed after review cannot be silently recreated", async () => withLedger(async (store, path) => {
  await seed(store);
  await store.update(data => setBudget(data, "travel", "2026-11", 0, "USD"));
  const preview = await previewBudgetCopy(store, request);
  assert.equal(preview.review!.rows.find(r => r.category === "travel")!.expectedTargetLimitMinor, 0);
  await store.update(data => { data.budgets = data.budgets.filter(b => !(b.category === "travel" && b.month === "2026-11")); });
  await unchangedRejection(path, () => commitBudgetCopy(store, commitArgs(preview)), /destination disappeared/);
  assert.equal((await store.load()).budgets.filter(b => b.month === "2026-11").length, 0);
}));

test("an old successful review refuses a later conflicting destination instead of restoring its old limit", async () => withLedger(async (store, path) => {
  await seed(store);
  const preview = await previewBudgetCopy(store, request);
  await commitBudgetCopy(store, commitArgs(preview));
  await store.update(data => setBudget(data, "travel", "2026-11", 600, "USD"));
  await unchangedRejection(path, () => commitBudgetCopy(store, commitArgs(preview)), /destination conflict/);
}));

test("actual atomic rename failure preserves the original file, removes its temp and permits an explicit retry", async () => withLedger(async (store, path, dir) => {
  await seed(store);
  const preview = await previewBudgetCopy(store, request);
  const before = await snapshot(path);
  const rename = fs.rename;
  let faults = 0;
  fs.rename = async (from, to) => {
    if (String(to) === path) { faults++; throw Object.assign(new Error("private rename EIO"), { code: "EIO" }); }
    return rename(from, to);
  };
  try { await assert.rejects(() => commitBudgetCopy(store, commitArgs(preview)), /private rename EIO/); }
  finally { fs.rename = rename; }
  assert.equal(faults, 1);
  assert.deepEqual(await snapshot(path), before);
  assert.deepEqual(await readdir(dir), ["ledger.json"]);
  const result = await commitBudgetCopy(store, commitArgs(preview));
  assert.equal(result.added, 2);
  assert.equal((await store.load()).transactions.length, 0);
}));

test("changed review content, unknown fields and malformed arguments refuse without writing", async () => withLedger(async (store, path) => {
  await seed(store);
  const preview = await previewBudgetCopy(store, request);
  const altered = JSON.parse(JSON.stringify(commitArgs(preview)));
  altered.review.rows[0].limitMinor++;
  await unchangedRejection(path, () => commitBudgetCopy(store, altered), /reviewToken/);
  await unchangedRejection(path, () => commitBudgetCopy(store, { ...commitArgs(preview), filePath: path }), /unsupported field/);
  const unknownRow = JSON.parse(JSON.stringify(commitArgs(preview)));
  unknownRow.review.rows[0].replace = true;
  await unchangedRejection(path, () => commitBudgetCopy(store, unknownRow), /unsupported field/);
  const oldExpected = JSON.parse(JSON.stringify(commitArgs(preview)));
  oldExpected.review.rows[0].expectedTargetLimitMinor = 3;
  await unchangedRejection(path, () => commitBudgetCopy(store, oldExpected), /cannot authorize replacement/);
  for (const args of [
    { ...request, toMonth: request.fromMonth }, { ...request, fromMonth: "2026-13" },
    { ...request, currency: "" }, { fromMonth: "2026-10", toMonth: "2026-11" },
    { ...request, categories: [] }, { ...request, categories: ["groceries", " groceries "] },
    { ...request, categories: ["missing"] }, { ...request, categories: ["travel"], replace: true },
    null, undefined,
  ]) await unchangedRejection(path, () => previewBudgetCopy(store, args), /month|currency|required|categories|category|unsupported|object|JSON/);
}));

test("500 selected budgets copy and replay; 501 are refused before a write", async () => withLedger(async (store, path) => {
  await store.update(data => {
    for (let n = 0; n < 500; n++) setBudget(data, "category-" + n, "2026-10", n === 499 ? Number.MAX_SAFE_INTEGER : n, "USD");
  });
  const preview = await previewBudgetCopy(store, request);
  assert.equal(preview.rows.length, 500);
  const first = await commitBudgetCopy(store, commitArgs(preview));
  assert.equal(first.added, 500);
  assert.equal(first.budgets[499].limitMinor, Number.MAX_SAFE_INTEGER);
  const before = await snapshot(path);
  assert.equal((await commitBudgetCopy(store, commitArgs(preview))).alreadyPresent, 500);
  assert.deepEqual(await snapshot(path), before);
  await store.update(data => setBudget(data, "one-too-many", "2026-10", 0, "USD"));
  await unchangedRejection(path, () => previewBudgetCopy(store, request), /1–500/);
}));

test("oversized or invalid Unicode categories refuse; an emitted bounded review remains committable", async () => withLedger(async (store, path) => {
  await store.update(data => {
    for (let n = 0; n < 30; n++) setBudget(data, "長".repeat(2000) + n, "2026-10", n, "USD");
  });
  await unchangedRejection(path, () => previewBudgetCopy(store, request), /256 KiB/);
  const categories = ["長".repeat(2000) + "0", "長".repeat(2000) + "1"];
  const preview = await previewBudgetCopy(store, { ...request, categories });
  assert.equal((await commitBudgetCopy(store, commitArgs(JSON.parse(JSON.stringify(preview))))).added, 2);
  await store.update(data => setBudget(data, "\ud800", "2026-12", 1, "USD"));
  await unchangedRejection(path, () => previewBudgetCopy(store, { fromMonth: "2026-12", toMonth: "2027-01", currency: "USD" }), /Unicode/);
}));

test("noncanonical stored source and destination names refuse instead of changing their identity", async () => withLedger(async (store, path) => {
  const raw: LedgerData = { version: 2, transactions: [], budgets: [
    { category: " food ", month: "2026-10", limitMinor: 1, currency: "USD" },
  ] };
  await store.save(raw);
  await unchangedRejection(path, () => previewBudgetCopy(store, request), /whitespace/);
  raw.budgets = [
    { category: "food", month: "2026-10", limitMinor: 1, currency: "USD" },
    { category: " food ", month: "2026-11", limitMinor: 1, currency: "USD" },
  ];
  await store.save(raw);
  const before = await snapshot(path);
  const preview = await previewBudgetCopy(store, request);
  assert.equal(preview.canCommit, false);
  assert.match(preview.rows[0].reason!, /not canonical/);
  assert.deepEqual(await snapshot(path), before);
}));
