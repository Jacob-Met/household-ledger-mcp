import assert from "node:assert/strict";

/** Strict test-only reader for the contract's fully quoted, CRLF-terminated CSV. */
export function readStatementCsv(text: string): string[][] {
  const rows: string[][] = [];
  let at = 0;
  while (at < text.length) {
    const row: string[] = [];
    while (true) {
      assert.equal(text[at++], '"');
      let field = "";
      while (true) {
        assert.ok(at < text.length, "unterminated quoted CSV cell");
        const next = text[at++];
        if (next !== '"') field += next;
        else if (text[at] === '"') { field += '"'; at++; }
        else break;
      }
      row.push(field);
      if (text[at] === ",") { at++; continue; }
      assert.equal(text.slice(at, at + 2), "\r\n", "record must end with CRLF");
      at += 2;
      break;
    }
    rows.push(row);
  }
  return rows;
}
