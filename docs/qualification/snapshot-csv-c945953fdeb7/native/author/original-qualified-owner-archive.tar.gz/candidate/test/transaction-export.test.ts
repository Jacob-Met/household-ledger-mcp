import { test } from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { listTransactions, validateLedgerData, ValidationError, type LedgerData, type Transaction } from "../src/ledger.js";
import { exportTransactionsCsv } from "../src/transaction-export.js";
import { readStatementCsv } from "./transaction-export-csv-reader.js";

const COLUMNS = ["id", "type", "amountMinor", "currency", "date", "category", "note", "idempotencyKey", "createdAt"];
const HEADER = '"id","type","amountMinor","currency","date","category","note","idempotencyKey","createdAt"\r\n';
const tx = (id: string, changes: Partial<Transaction> = {}): Transaction => ({
  id, type: "expense", amountMinor: 1, currency: "USD", date: "2026-10-01", category: "Food",
  createdAt: "2026-10-01T00:00:00.000Z", ...changes,
});
const data = (...transactions: Transaction[]): LedgerData => ({
  version: 2, transactions,
  budgets: [{ category: "Food", month: "2026-10", currency: "USD", limitMinor: 77 }],
});
function cells(row: Transaction): string[] {
  return COLUMNS.map(key => {
    const value = row[key as keyof Transaction];
    return value === undefined ? "" : String(value);
  });
}
function checkMetadata(result: ReturnType<typeof exportTransactionsCsv>, expectedRows: number): void {
  assert.deepEqual(Object.keys(result).sort(), ["byteCount", "csv", "filename", "format", "mediaType", "rowCount", "sha256"]);
  assert.equal(result.format, "csv");
  assert.equal(result.filename, "household-transactions.csv");
  assert.equal(result.mediaType, "text/csv; charset=utf-8");
  assert.equal(result.rowCount, expectedRows);
  assert.equal(result.byteCount, Buffer.byteLength(result.csv, "utf8"));
  assert.equal(result.sha256, createHash("sha256").update(result.csv, "utf8").digest("hex"));
  assert.deepEqual(readStatementCsv(result.csv)[0], COLUMNS);
}

test("statement preserves literal text, quoting, Unicode, formula-like fields and integer minor units", () => {
  const rows = [
    tx('one,"雪"', { note: '  café, "quoted"\r\n第二行 😺\nlast\rEND  ', idempotencyKey: 'key:"quoted",€', amountMinor: Number.MAX_SAFE_INTEGER, category: "=SUM(1,2)" }),
    tx("two", { note: "+1+2", currency: "EUR" }),
    tx("three", { note: "-9", currency: "JPY" }),
    tx("four", { note: "@SUM(A1:A2)" }),
    tx("five", { note: "=1+1" }),
  ];
  const snapshot = validateLedgerData(data(...rows));
  const before = JSON.stringify(snapshot);
  const result = exportTransactionsCsv(snapshot);
  checkMetadata(result, rows.length);
  assert.deepEqual(readStatementCsv(result.csv).slice(1), rows.map(cells));
  assert.ok(result.csv.includes('"9007199254740991"'));
  assert.ok(result.csv.startsWith(HEADER));
  assert.equal(result.csv.startsWith("\uFEFF"), false);
  assert.equal(JSON.stringify(snapshot), before);
  assert.deepEqual(exportTransactionsCsv(snapshot), result);
});

test("selection and tie order are exactly the existing native listing over the same snapshot", () => {
  const snapshot = data(
    tx("old", { date: "2026-09-30", category: " Food " }),
    tx("tie-first", { date: "2026-10-03", currency: "EUR" }),
    tx("salary", { date: "2026-10-02", type: "income", category: "salary" }),
    tx("new", { date: "2026-10-04" }),
    tx("tie-second", { date: "2026-10-03", currency: "JPY" }),
  );
  const before = JSON.stringify(snapshot);
  const filters = [{}, { type: "expense" as const, from: "2026-10-03", to: "2026-10-03" }, { category: " Food " }, { category: "Food" }, { category: "food" }, { category: "" }, { from: "2026-10-05", to: "2026-10-01" }];
  for (const filter of filters) {
    const expected = listTransactions(snapshot, { ...filter, limit: 1000 });
    const result = exportTransactionsCsv(snapshot, filter);
    checkMetadata(result, expected.total);
    assert.deepEqual(readStatementCsv(result.csv).slice(1), expected.transactions.map(cells));
  }
  assert.equal(JSON.stringify(snapshot), before);
});

test("empty results include only the exact quoted header", () => {
  for (const result of [exportTransactionsCsv(data()), exportTransactionsCsv(data(tx("one")), { category: "missing" })]) {
    checkMetadata(result, 0);
    assert.equal(result.csv, HEADER);
    assert.deepEqual(readStatementCsv(result.csv), [COLUMNS]);
  }
});

test("complete results cross a thousand-row page and admit exactly five thousand matching records", () => {
  const snapshot = data(...Array.from({ length: 5000 }, (_, n) => tx("row-" + n, { date: n % 2 ? "2026-10-02" : "2026-10-01" })));
  const before = JSON.stringify(snapshot);
  const expected: Transaction[] = [];
  for (let offset = 0; offset < 5000; offset += 1000) expected.push(...listTransactions(snapshot, { limit: 1000, offset }).transactions);
  const result = exportTransactionsCsv(snapshot);
  checkMetadata(result, 5000);
  assert.deepEqual(readStatementCsv(result.csv).slice(1), expected.map(cells));
  assert.equal(JSON.stringify(snapshot), before);
});

test("five thousand and one matches refuse the whole result but a small subset can still succeed", () => {
  const snapshot = data(...Array.from({ length: 5001 }, (_, n) => tx("row-" + n, { category: n === 5000 ? "Only" : "Food" })));
  assert.throws(() => exportTransactionsCsv(snapshot), ValidationError);
  const result = exportTransactionsCsv(snapshot, { category: "Only" });
  checkMetadata(result, 1);
  assert.deepEqual(readStatementCsv(result.csv).slice(1), [cells(snapshot.transactions[5000])]);
});

test("the inclusive UTF-8 byte boundary includes header and CSV quote expansion", () => {
  const prefix = HEADER + '"boundary","expense","1","USD","2026-10-01","Food","","","2026-10-01T00:00:00.000Z"\r\n';
  const room = 1048576 - Buffer.byteLength(prefix);
  const ascii = "a".repeat(room);
  const exact = exportTransactionsCsv(data(tx("boundary", { note: ascii })));
  assert.equal(exact.byteCount, 1048576);
  assert.equal(readStatementCsv(exact.csv)[1][6], ascii);
  assert.throws(() => exportTransactionsCsv(data(tx("boundary", { note: ascii + "a" }))), ValidationError);
  assert.throws(() => exportTransactionsCsv(data(tx("boundary", { note: ascii.slice(1) + '"' }))), ValidationError);
  const unicode = "é".repeat(Math.floor(room / 2)) + (room % 2 ? "a" : "");
  assert.equal(exportTransactionsCsv(data(tx("boundary", { note: unicode }))).byteCount, 1048576);
  assert.throws(() => exportTransactionsCsv(data(tx("boundary", { note: unicode + "😺" }))), ValidationError);
});

test("optional or legacy absent values stay empty without inventing a timestamp", () => {
  const absent = tx("absent");
  delete (absent as Partial<Transaction>).createdAt;
  const result = exportTransactionsCsv(validateLedgerData(data(absent, tx("empty", { note: "" }))));
  assert.deepEqual(readStatementCsv(result.csv).slice(1), [cells(absent), cells(tx("empty", { note: "" }))]);
});

test("selected unrepresentable text and an explicitly non-string timestamp are refused", () => {
  const malformed = tx("bad", { createdAt: null as unknown as string });
  const snapshot = validateLedgerData(data(malformed, tx("healthy", { category: "Other" })));
  assert.throws(() => exportTransactionsCsv(snapshot), ValidationError);
  assert.equal(exportTransactionsCsv(snapshot, { category: "Other" }).rowCount, 1);
  for (const note of ["\ud800", "\udc00", "x\ud800y"]) {
    assert.throws(() => exportTransactionsCsv(data(tx("bad-note", { note }))), ValidationError);
  }
  assert.equal(readStatementCsv(exportTransactionsCsv(data(tx("paired", { note: "😺" }))).csv)[1][6], "😺");
});

test("new tool arguments reject unsupported keys and wrong shapes without changing existing selectors", () => {
  const snapshot = data(tx("one"));
  const before = JSON.stringify(snapshot);
  for (const filter of [null, [], "", { limit: 1 }, { offset: 0 }, { path: "/tmp/never-write.csv" }, { currency: "USD" }, { query: "food" }, { category: null }, { category: 1 }, { type: null }, { type: "other" }, { from: null }, { from: "2026-02-30" }, { to: "tomorrow" }, { from: 1 }]) {
    assert.throws(() => exportTransactionsCsv(snapshot, filter), ValidationError);
  }
  assert.equal(JSON.stringify(snapshot), before);
});
