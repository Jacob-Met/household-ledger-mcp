import { test } from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { once } from "node:events";
import { createHash } from "node:crypto";
import { access, chmod, mkdir, mkdtemp, readFile, rm, stat, writeFile } from "node:fs/promises";
import { createServer } from "node:net";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";
import { validateLedgerData, type LedgerData, type Transaction } from "../src/ledger.js";
import { type TransactionCsvExport } from "../src/transaction-export.js";
import { readStatementCsv } from "./transaction-export-csv-reader.js";

type ToolReply = { isError?: boolean; content: Array<{ type: string; text?: string }> };
const COLUMNS = ["id", "type", "amountMinor", "currency", "date", "category", "note", "idempotencyKey", "createdAt"];
const HEADER = '"id","type","amountMinor","currency","date","category","note","idempotencyKey","createdAt"\r\n';
const fixturePath = new URL("../../test/fixtures/transaction-export-ledger.json", import.meta.url);
const hash = (value: string | Buffer): string => createHash("sha256").update(value).digest("hex");
function payload<T>(value: unknown): T {
  const reply = value as ToolReply;
  assert.equal(reply.isError, undefined, JSON.stringify(reply));
  assert.equal(reply.content.length, 1);
  assert.equal(reply.content[0].type, "text");
  return JSON.parse(reply.content[0].text!) as T;
}
function failure(value: unknown): void {
  const reply = value as ToolReply;
  assert.equal(reply.isError, true, JSON.stringify(reply));
  assert.equal(reply.content[0].type, "text");
  assert.ok(reply.content[0].text);
  assert.equal(reply.content[0].text!.includes('"csv":'), false);
}
function expectedCells(row: Transaction): string[] {
  return COLUMNS.map(key => {
    const value = row[key as keyof Transaction];
    return value === undefined ? "" : String(value);
  });
}
async function launch(path: string): Promise<{ client: Client; stop: () => Promise<void> }> {
  const probe = createServer();
  probe.listen(0, "127.0.0.1");
  await once(probe, "listening");
  const address = probe.address();
  assert.ok(address && typeof address !== "string");
  const port = address.port;
  await new Promise<void>((resolve, reject) => probe.close(error => error ? reject(error) : resolve()));
  const child = spawn(process.execPath, [fileURLToPath(new URL("../src/index.js", import.meta.url))], {
    env: { ...process.env, HOUSEHOLD_LEDGER_DATA_PATH: path, HOUSEHOLD_LEDGER_HOST: "127.0.0.1", HOUSEHOLD_LEDGER_PORT: String(port) },
    stdio: ["ignore", "pipe", "pipe"],
  });
  let errors = "";
  child.stderr.on("data", chunk => { errors += String(chunk); });
  try {
    await new Promise<void>((resolve, reject) => {
      let output = "";
      const timer = setTimeout(() => reject(new Error("private export server startup timed out: " + errors)), 5000);
      child.once("error", error => { clearTimeout(timer); reject(error); });
      child.once("exit", code => { clearTimeout(timer); reject(new Error("private export server exited " + code + ": " + errors)); });
      child.stdout.on("data", chunk => {
        output += String(chunk);
        if (output.includes("listening on")) { clearTimeout(timer); resolve(); }
      });
    });
    assert.equal((await fetch("http://127.0.0.1:" + port + "/healthz")).status, 200);
    const client = new Client({ name: "transaction-export-http-tests", version: "1" }, { capabilities: {} });
    await client.connect(new StreamableHTTPClientTransport(new URL("http://127.0.0.1:" + port + "/mcp")));
    return { client, stop: async () => {
      await client.close();
      if (child.exitCode === null && child.signalCode === null) {
        const exit = once(child, "exit"); child.kill("SIGTERM"); await exit;
      }
      assert.equal(errors, "");
    } };
  } catch (error) {
    child.kill("SIGTERM");
    throw error;
  }
}
async function guardedCall(client: Client, path: string, args: Record<string, unknown> = {}): Promise<unknown> {
  const bytes = await readFile(path), before = await stat(path);
  const reply = await client.callTool({ name: "export_transactions_csv", arguments: args });
  assert.deepEqual(await readFile(path), bytes);
  assert.equal((await stat(path)).mtimeMs, before.mtimeMs);
  return reply;
}
async function listing(client: Client, filter: Record<string, unknown> = {}): Promise<Transaction[]> {
  const first = payload<{ total: number; transactions: Transaction[] }>(await client.callTool({ name: "list_transactions", arguments: { ...filter, limit: 1000, offset: 0 } }));
  const rows = [...first.transactions];
  for (let offset = 1000; offset < first.total; offset += 1000) {
    const next = payload<{ total: number; transactions: Transaction[] }>(await client.callTool({ name: "list_transactions", arguments: { ...filter, limit: 1000, offset } }));
    assert.equal(next.total, first.total);
    rows.push(...next.transactions);
  }
  assert.equal(rows.length, first.total);
  return rows;
}

test("real HTTP export saves exact native listing records as literal CSV without writing the read-only ledger", async () => {
  const dir = await mkdtemp(join(tmpdir(), "hlm-http-export-literals-"));
  const path = join(dir, "ledger", "ledger.json");
  let service: Awaited<ReturnType<typeof launch>> | undefined;
  try {
    await mkdir(dirname(path));
    const source = await readFile(fixturePath);
    const snapshot = validateLedgerData(JSON.parse(source.toString("utf8")));
    await writeFile(path, source);
    await chmod(path, 0o444);
    await chmod(dirname(path), 0o555);
    service = await launch(path);
    const tool = (await service.client.listTools()).tools.find(item => item.name === "export_transactions_csv");
    assert.ok(tool);
    assert.deepEqual(tool.annotations, { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false });
    assert.equal(tool.inputSchema.additionalProperties, false);
    assert.deepEqual(Object.keys(tool.inputSchema.properties ?? {}).sort(), ["category", "from", "to", "type"]);
    const filters = [{}, { type: "expense", from: "2026-10-03", to: "2026-10-04" }, { category: "Food" }, { category: " Food " }, { category: "food" }, { category: '食費, "週末"' }];
    let first: TransactionCsvExport | undefined;
    for (const filter of filters) {
      const expected = await listing(service.client, filter);
      const report: TransactionCsvExport = payload<TransactionCsvExport>(await guardedCall(service.client, path, filter));
      assert.deepEqual(readStatementCsv(report.csv), [COLUMNS, ...expected.map(expectedCells)]);
      assert.equal(report.rowCount, expected.length);
      assert.equal(report.byteCount, Buffer.byteLength(report.csv));
      assert.equal(report.sha256, hash(report.csv));
      assert.equal(report.filename, "household-transactions.csv");
      assert.equal(report.mediaType, "text/csv; charset=utf-8");
      if (!first) first = report;
    }
    assert.ok(first);
    const saved = join(dir, first.filename);
    await writeFile(saved, first.csv, { encoding: "utf8", flag: "wx" });
    assert.equal(hash(await readFile(saved)), first.sha256);
    assert.equal((await stat(saved)).size, first.byteCount);
    assert.deepEqual(readStatementCsv((await readFile(saved)).toString("utf8")).slice(1), (await listing(service.client)).map(expectedCells));
    assert.equal(snapshot.transactions.length, 8);
    await service.stop(); service = undefined;
    service = await launch(path);
    assert.deepEqual(payload(await guardedCall(service.client, path)), first);
  } finally {
    await service?.stop();
    await chmod(dirname(path), 0o755).catch(() => undefined);
    await chmod(path, 0o644).catch(() => undefined);
    await rm(dir, { recursive: true, force: true });
  }
});

test("real HTTP export completes all pages and refuses whole row or byte excess", async () => {
  const dir = await mkdtemp(join(tmpdir(), "hlm-http-export-bounds-"));
  const path = join(dir, "ledger.json");
  let service: Awaited<ReturnType<typeof launch>> | undefined;
  const makeRow = (id: string, changes: Partial<Transaction> = {}): Transaction => ({
    id, type: "expense", amountMinor: 1, currency: "USD", date: "2026-10-01", category: "Food", createdAt: "2026-10-01T00:00:00.000Z", ...changes,
  });
  const saveRows = async (rows: Transaction[]): Promise<void> => {
    const snapshot: LedgerData = { version: 1, transactions: rows, budgets: [] };
    await writeFile(path, JSON.stringify(snapshot) + "\n");
  };
  try {
    const rows = Array.from({ length: 5000 }, (_, n) => makeRow("row-" + n));
    await saveRows(rows);
    service = await launch(path);
    const expected = await listing(service.client);
    const complete = payload<TransactionCsvExport>(await guardedCall(service.client, path));
    assert.equal(complete.rowCount, 5000);
    assert.deepEqual(readStatementCsv(complete.csv).slice(1), expected.map(expectedCells));
    await saveRows([...rows, makeRow("only", { category: "Only" })]);
    failure(await guardedCall(service.client, path));
    const selected = payload<TransactionCsvExport>(await guardedCall(service.client, path, { category: "Only" }));
    assert.deepEqual(readStatementCsv(selected.csv).slice(1), [expectedCells(makeRow("only", { category: "Only" }))]);
    const baseCsv = HEADER + '"boundary","expense","1","USD","2026-10-01","Food","","","2026-10-01T00:00:00.000Z"\r\n';
    const note = "a".repeat(1048576 - Buffer.byteLength(baseCsv));
    await saveRows([makeRow("boundary", { note })]);
    const exact = payload<TransactionCsvExport>(await guardedCall(service.client, path));
    assert.equal(exact.byteCount, 1048576);
    assert.equal(Buffer.byteLength(exact.csv), 1048576);
    assert.equal(readStatementCsv(exact.csv)[1][6], note);
    await saveRows([makeRow("boundary", { note: note + "a" })]);
    failure(await guardedCall(service.client, path));
  } finally {
    await service?.stop();
    await rm(dir, { recursive: true, force: true });
  }
});

test("real HTTP refusals retain invalid arguments and ledger failures as errors without partial CSV", async () => {
  const dir = await mkdtemp(join(tmpdir(), "hlm-http-export-refusals-"));
  const path = join(dir, "ledger.json");
  let service: Awaited<ReturnType<typeof launch>> | undefined;
  try {
    const valid = await readFile(fixturePath);
    await writeFile(path, valid);
    service = await launch(path);
    for (const args of [{ limit: 1 }, { offset: 0 }, { path: join(dir, "not-created.csv") }, { currency: "USD" }, { query: "Food" }, { category: null }, { type: "bad" }, { from: "2026-02-30" }, { to: 2026 }]) {
      failure(await guardedCall(service.client, path, args));
    }
    await assert.rejects(access(join(dir, "not-created.csv")), { code: "ENOENT" });
    for (const invalid of ["{", '{"version":99,"transactions":[],"budgets":[]}', JSON.stringify({ version: 1, transactions: [{ id: "invalid", type: "expense", amountMinor: 0 }], budgets: [] })]) {
      await writeFile(path, invalid);
      failure(await guardedCall(service.client, path));
    }
    for (const change of [{ createdAt: { invented: true } }, { note: "\ud800" }]) {
      const snapshot = JSON.parse(valid.toString("utf8"));
      Object.assign(snapshot.transactions[0], change);
      await writeFile(path, JSON.stringify(snapshot));
      failure(await guardedCall(service.client, path));
    }
  } finally {
    await service?.stop();
    await rm(dir, { recursive: true, force: true });
  }
});

test("real HTTP empty export returns header only and does not create an absent ledger or parent", async () => {
  const dir = await mkdtemp(join(tmpdir(), "hlm-http-export-missing-"));
  const path = join(dir, "never-created", "ledger.json");
  let service: Awaited<ReturnType<typeof launch>> | undefined;
  try {
    service = await launch(path);
    const report = payload<TransactionCsvExport>(await service.client.callTool({ name: "export_transactions_csv", arguments: {} }));
    assert.equal(report.rowCount, 0);
    assert.equal(report.csv, HEADER);
    assert.equal(report.byteCount, Buffer.byteLength(HEADER));
    assert.equal(report.sha256, hash(HEADER));
    await assert.rejects(access(dirname(path)), { code: "ENOENT" });
  } finally {
    await service?.stop();
    await rm(dir, { recursive: true, force: true });
  }
});
