/** Reviewed monthly-budget copying through the existing Store and budget rules. */
import { createHash } from "node:crypto";
import { getBudgets, LedgerStore, setBudget, validateMonth, ValidationError, type Budget, type LedgerData } from "./ledger.js";

export const BUDGET_COPY_SCHEMA = "household-budget-copy/1";
export const MAX_COPY_BUDGETS = 500;
const MAX_ARGUMENT_BYTES = 256 * 1024;
const MAX_CATEGORY_BYTES = 8192;

export interface BudgetCopyReview {
  schema: typeof BUDGET_COPY_SCHEMA;
  fromMonth: string;
  toMonth: string;
  currency: string;
  rows: Array<{ category: string; limitMinor: number; expectedTargetLimitMinor: number | null }>;
}

export interface BudgetCopyPreview {
  schema: typeof BUDGET_COPY_SCHEMA;
  fromMonth: string;
  toMonth: string;
  currency: string;
  canCommit: boolean;
  counts: { total: number; add: number; alreadyPresent: number; conflict: number };
  rows: Array<{
    category: string;
    limitMinor: number;
    action: "add" | "already_present" | "conflict";
    destination: Budget[];
    reason?: string;
  }>;
  review: BudgetCopyReview | null;
  reviewToken: string | null;
}

function requireValue(condition: unknown, message: string): asserts condition {
  if (!condition) throw new ValidationError(message);
}

function fields(value: unknown, allowed: string[], required: string[], label: string): Record<string, unknown> {
  requireValue(typeof value === "object" && value !== null && !Array.isArray(value), `${label} must be an object`);
  const object = value as Record<string, unknown>;
  requireValue(Object.keys(object).every(key => allowed.includes(key)), `${label} contains an unsupported field`);
  requireValue(required.every(key => Object.hasOwn(object, key)), `${label} is missing a required field`);
  return object;
}

function bounded(value: unknown): void {
  let text: string | undefined;
  try { text = JSON.stringify(value); } catch { throw new ValidationError("budget-copy arguments must be bounded JSON"); }
  requireValue(typeof text === "string", "budget-copy arguments must be JSON");
  requireValue(Buffer.byteLength(text, "utf8") <= MAX_ARGUMENT_BYTES, "budget-copy arguments exceed 256 KiB UTF-8");
}

function currencyOf(value: unknown): string {
  requireValue(typeof value === "string" && /^[A-Za-z]{3}$/.test(value.trim()), "currency must be an explicit 3-letter code");
  return value.trim().toUpperCase();
}

function categoryOf(value: unknown, canonical = false): string {
  requireValue(typeof value === "string" && value.trim().length > 0, "category must be a non-empty string");
  requireValue(Buffer.from(value, "utf8").toString("utf8") === value, "category must contain valid Unicode");
  const category = value.trim();
  requireValue(Buffer.byteLength(category, "utf8") <= MAX_CATEGORY_BYTES, "category exceeds 8192 UTF-8 bytes");
  requireValue(!canonical || value === category, "stored/reviewed category has surrounding whitespace; copying would change its identity");
  return category;
}

function limitOf(value: unknown): number {
  requireValue(typeof value === "number" && Number.isSafeInteger(value) && value >= 0, "budget limit must be a non-negative safe integer in minor units");
  return value;
}

function months(from: unknown, to: unknown): { fromMonth: string; toMonth: string } {
  const fromMonth = validateMonth(from);
  const toMonth = validateMonth(to);
  requireValue(fromMonth !== toMonth, "source and destination months must differ");
  return { fromMonth, toMonth };
}

function reviewToken(review: BudgetCopyReview): string {
  return createHash("sha256").update(JSON.stringify(review)).digest("hex");
}

function sourceFor(data: LedgerData, month: string, currency: string, category: string): Budget {
  const matching = getBudgets(data, month).filter(b => b.category.trim() === category);
  requireValue(!matching.some(b => b.currency === undefined), `source category ${JSON.stringify(category)} has an unassigned budget; explicitly assign its currency through set_budget first`);
  const selected = matching.filter(b => b.currency !== undefined && currencyOf(b.currency) === currency);
  requireValue(selected.length === 1, `source category ${JSON.stringify(category)} must have exactly one explicitly denominated ${currency} budget`);
  categoryOf(selected[0].category, true);
  limitOf(selected[0].limitMinor);
  return selected[0];
}

function destinationFor(data: LedgerData, month: string, currency: string, category: string, limitMinor: number): BudgetCopyPreview["rows"][number] {
  const matching = getBudgets(data, month).filter(b =>
    b.category.trim() === category && (b.currency === undefined || currencyOf(b.currency) === currency)
  );
  const destination = matching.slice(0, 2).map(b => ({
    category: b.category, month: b.month, limitMinor: b.limitMinor,
    ...(b.currency === undefined ? {} : { currency: b.currency }),
  }));
  let reason: string | undefined;
  if (matching.length > 1) reason = "The destination identity is ambiguous.";
  else if (destination.some(b => b.category !== category)) reason = "The stored destination category is not canonical; copying would change its identity.";
  else if (destination.some(b => b.currency === undefined)) reason = "The destination has an unassigned budget; this copy cannot choose or replace its currency.";
  else if (destination.some(b => b.limitMinor !== limitMinor)) reason = "The destination already has a different limit; this copy does not overwrite it.";
  return {
    category, limitMinor, destination,
    action: reason ? "conflict" : destination.length ? "already_present" : "add",
    ...(reason ? { reason } : {}),
  };
}

function readReview(raw: unknown): BudgetCopyReview {
  const value = fields(raw, ["schema", "fromMonth", "toMonth", "currency", "rows"], ["schema", "fromMonth", "toMonth", "currency", "rows"], "review");
  requireValue(value.schema === BUDGET_COPY_SCHEMA, "unsupported budget-copy review schema");
  const period = months(value.fromMonth, value.toMonth);
  const currency = currencyOf(value.currency);
  requireValue(value.currency === currency, "review currency must retain its normalized value");
  requireValue(Array.isArray(value.rows) && value.rows.length > 0 && value.rows.length <= MAX_COPY_BUDGETS, "review must contain 1–500 budget rows");
  const seen = new Set<string>();
  const rows = value.rows.map(rawRow => {
    const row = fields(rawRow, ["category", "limitMinor", "expectedTargetLimitMinor"], ["category", "limitMinor", "expectedTargetLimitMinor"], "review row");
    const category = categoryOf(row.category, true);
    requireValue(!seen.has(category), "review contains a repeated category");
    seen.add(category);
    const limitMinor = limitOf(row.limitMinor);
    const expectedTargetLimitMinor = row.expectedTargetLimitMinor === null ? null : limitOf(row.expectedTargetLimitMinor);
    requireValue(expectedTargetLimitMinor === null || expectedTargetLimitMinor === limitMinor, "review cannot authorize replacement of a different destination limit");
    return { category, limitMinor, expectedTargetLimitMinor };
  });
  return { schema: BUDGET_COPY_SCHEMA, ...period, currency, rows };
}

export async function previewBudgetCopy(store: LedgerStore, args: unknown): Promise<BudgetCopyPreview> {
  bounded(args);
  const value = fields(args, ["fromMonth", "toMonth", "currency", "categories"], ["fromMonth", "toMonth", "currency"], "preview arguments");
  const period = months(value.fromMonth, value.toMonth);
  const currency = currencyOf(value.currency);
  let categories: string[] | undefined;
  if (Object.hasOwn(value, "categories")) {
    requireValue(Array.isArray(value.categories) && value.categories.length > 0 && value.categories.length <= MAX_COPY_BUDGETS, "categories must contain 1–500 names");
    categories = value.categories.map(category => categoryOf(category));
    requireValue(new Set(categories).size === categories.length, "categories contains repeated normalized names");
  }
  const data = await store.load();
  const allSource = getBudgets(data, period.fromMonth);
  if (categories === undefined) {
    requireValue(!allSource.some(b => b.currency === undefined), "source month contains unassigned budgets; select explicit denominated categories or assign their currencies first");
    categories = getBudgets(data, period.fromMonth, currency).map(b => categoryOf(b.category, true));
  }
  requireValue(categories.length > 0 && categories.length <= MAX_COPY_BUDGETS, "select 1–500 explicitly denominated source budgets");
  requireValue(new Set(categories).size === categories.length, "source contains ambiguous category identities");
  const source = categories.map(category => sourceFor(data, period.fromMonth, currency, category));
  const rows = source.map(b => destinationFor(data, period.toMonth, currency, b.category, b.limitMinor));
  const counts = {
    total: rows.length,
    add: rows.filter(row => row.action === "add").length,
    alreadyPresent: rows.filter(row => row.action === "already_present").length,
    conflict: rows.filter(row => row.action === "conflict").length,
  };
  const canCommit = counts.conflict === 0;
  const review: BudgetCopyReview | null = canCommit ? {
    schema: BUDGET_COPY_SCHEMA, ...period, currency,
    rows: rows.map(row => ({ category: row.category, limitMinor: row.limitMinor, expectedTargetLimitMinor: row.action === "already_present" ? row.limitMinor : null })),
  } : null;
  const token = review ? reviewToken(review) : null;
  if (review) bounded({ review, reviewToken: token });
  const preview: BudgetCopyPreview = { schema: BUDGET_COPY_SCHEMA, ...period, currency, canCommit, counts, rows, review, reviewToken: token };
  bounded(preview);
  return preview;
}

export async function commitBudgetCopy(store: LedgerStore, args: unknown): Promise<{
  schema: typeof BUDGET_COPY_SCHEMA;
  fromMonth: string; toMonth: string; currency: string; reviewToken: string;
  added: number; alreadyPresent: number; budgets: Budget[];
}> {
  bounded(args);
  const value = fields(args, ["review", "reviewToken"], ["review", "reviewToken"], "commit arguments");
  const review = readReview(value.review);
  const token = reviewToken(review);
  requireValue(typeof value.reviewToken === "string" && /^[0-9a-f]{64}$/.test(value.reviewToken) && value.reviewToken === token,
    "reviewToken does not match the reviewed budget values; preview and review again");
  return store.update(data => {
    // Check the entire current source and destination before preparing any write.
    const current = review.rows.map(row => {
      const source = sourceFor(data, review.fromMonth, review.currency, row.category);
      requireValue(source.limitMinor === row.limitMinor, `source limit changed for ${JSON.stringify(row.category)}; preview again`);
      const target = destinationFor(data, review.toMonth, review.currency, row.category, row.limitMinor);
      requireValue(target.action !== "conflict", `destination conflict for ${JSON.stringify(row.category)}; preview again`);
      requireValue(row.expectedTargetLimitMinor === null || target.action === "already_present",
        `previously reviewed destination disappeared for ${JSON.stringify(row.category)}; preview again`);
      return target;
    });
    const added = current.filter(row => row.action === "add").length;
    // The existing setter remains the only budget writer. A staging copy keeps
    // its late validation failures from altering this callback's admitted data.
    const staged: LedgerData = { ...data, budgets: data.budgets.map(b => ({ ...b })) };
    const budgets = current.map(row => row.action === "already_present"
      ? row.destination[0]
      : setBudget(staged, row.category, review.toMonth, row.limitMinor, review.currency));
    if (added > 0) {
      data.budgets = staged.budgets;
      data.version = staged.version;
    }
    return {
      schema: BUDGET_COPY_SCHEMA, fromMonth: review.fromMonth, toMonth: review.toMonth,
      currency: review.currency, reviewToken: token, added, alreadyPresent: current.length - added, budgets,
    };
  });
}

const REVIEW_SCHEMA = {
  type: "object", additionalProperties: false,
  properties: {
    schema: { type: "string", const: BUDGET_COPY_SCHEMA },
    fromMonth: { type: "string", description: "Reviewed source YYYY-MM." },
    toMonth: { type: "string", description: "Reviewed different destination YYYY-MM." },
    currency: { type: "string", pattern: "^[A-Z]{3}$" },
    rows: {
      type: "array", minItems: 1, maxItems: MAX_COPY_BUDGETS,
      items: {
        type: "object", additionalProperties: false,
        properties: {
          category: { type: "string", minLength: 1, maxLength: MAX_CATEGORY_BYTES },
          limitMinor: { type: "integer", minimum: 0, maximum: Number.MAX_SAFE_INTEGER },
          expectedTargetLimitMinor: { anyOf: [{ type: "integer", minimum: 0, maximum: Number.MAX_SAFE_INTEGER }, { type: "null" }] },
        },
        required: ["category", "limitMinor", "expectedTargetLimitMinor"],
      },
    },
  },
  required: ["schema", "fromMonth", "toMonth", "currency", "rows"],
} as const;

export const BUDGET_COPY_TOOL_DEFS = [
  {
    name: "preview_budget_copy",
    description: "Review selected explicitly denominated category budgets before copying their exact limits to another month. Shows destination matches/conflicts without writing. Supply one explicit currency; unassigned budgets are never guessed. Review every returned row before commit.",
    annotations: { readOnlyHint: true, destructiveHint: false, idempotentHint: true, openWorldHint: false },
    inputSchema: {
      type: "object", additionalProperties: false,
      properties: {
        fromMonth: { type: "string", description: "Source YYYY-MM." },
        toMonth: { type: "string", description: "Different destination YYYY-MM." },
        currency: { type: "string", description: "Explicit 3-letter denomination; normalized to uppercase. No conversion." },
        categories: { type: "array", minItems: 1, maxItems: MAX_COPY_BUDGETS, items: { type: "string", minLength: 1, maxLength: MAX_CATEGORY_BYTES }, description: "Optional specific source category names. Omit to select all budgets in this currency only when the source month has no unassigned budgets." },
      },
      required: ["fromMonth", "toMonth", "currency"],
    },
  },
  {
    name: "commit_budget_copy",
    description: "After reviewing preview_budget_copy, explicitly copy its exact budget review. Rechecks source and destination inside the existing writer; any stale source or conflicting target refuses the entire batch. Matching targets are preserved and an unchanged repeat does not rewrite. The token binds content, not authentication or approval; run one server process per ledger file.",
    annotations: { readOnlyHint: false, destructiveHint: false, idempotentHint: true, openWorldHint: false },
    inputSchema: {
      type: "object", additionalProperties: false,
      properties: { review: REVIEW_SCHEMA, reviewToken: { type: "string", pattern: "^[0-9a-f]{64}$" } },
      required: ["review", "reviewToken"],
    },
  },
] as const;
