# Transaction CSV statements

Use `export_transactions_csv` to prepare a complete statement of matching recorded transactions. Call it through the connected MCP client:

```json
{"type":"expense","from":"2026-10-01","to":"2026-10-31"}
```

All selectors are optional. `type` accepts `income` or `expense`; `category` matches exactly, including case and whitespace; `from` and `to` are inclusive calendar dates. The existing transaction listing determines selection and newest-first order, including ties. An empty object selects every transaction. A reversed valid date interval has no matches.

This tool accepts only these four selectors. It returns all matching records within the limits below, so there are no caller `limit` or `offset` arguments. Existing listing tools and their selectors remain available independently.

## Save the returned text

The tool's text content is a JSON object with these fields:

| Field | Meaning |
| --- | --- |
| `format` | `csv` |
| `filename` | Suggested name `household-transactions.csv` |
| `mediaType` | `text/csv; charset=utf-8` |
| `rowCount` | Number of transaction records, excluding the header |
| `byteCount` | Exact UTF-8 byte count, including header and line endings |
| `sha256` | Lowercase SHA-256 of the exact CSV bytes |
| `csv` | Complete CSV text to save |

Have the client save `csv` as UTF-8, preserving its line endings. The service returns text and metadata; it does not create an attachment, write a requested path or open a spreadsheet. Repeated calls over the same selected snapshot produce identical bytes and metadata.

## Fixed columns and literal values

The columns always appear in this order:

```text
id,type,amountMinor,currency,date,category,note,idempotencyKey,createdAt
```

Every header and value is enclosed in double quotes. Embedded double quotes are doubled. Commas separate fields, and CRLF separates records, including the final record. There is no byte-order mark.

Original commas, quotes, embedded CRLF/LF/CR, Unicode and whitespace remain part of the field. Formula-like strings beginning with `=`, `+`, `-` or `@` remain literal stored text without an added prefix; the consuming application determines how it imports that text.

`amountMinor` is the original integer in decimal. Each row retains its currency. The statement neither combines currencies nor converts amounts.

Absent notes and idempotency keys become empty fields. A missing legacy `createdAt` also becomes an empty field; the exporter does not invent a timestamp. An explicitly present non-string timestamp or text that cannot be encoded losslessly as UTF-8 refuses the statement.

This is a transaction statement. It omits budgets, does not distinguish absent optional strings from empty strings, and has a different column set from [transaction import](TRANSACTION_IMPORT.md). Keep the native ledger JSON when a complete ledger backup is needed.

## Complete results and limits

A statement can contain at most **5,000 matching transactions** and **1,048,576 UTF-8 bytes**, including the quoted header, escaping and line endings. Both limits are inclusive and apply to the whole result. The exporter reads one saved snapshot and obtains complete results through the native listing's bounded pages.

If either limit is exceeded, the tool returns an error without a partial CSV report. Narrow the date, type or exact category selection and call again. A large ledger can still yield a small selected statement.

Zero matches succeed with the quoted header and final CRLF, `rowCount: 0`, and the corresponding byte count and hash. Reading a missing ledger also returns this empty statement without creating a file. Invalid selectors or invalid ledger content return the existing MCP error result.

Exporting performs no ledger write, migration, budget change or provider request.
