# Copy reviewed monthly budgets

Use `preview_budget_copy` and `commit_budget_copy` to carry chosen category limits from one month into another. This copies budget limits; it does not record income or expenses, move money, schedule future actions or convert currencies.

Both tools use the existing ledger and its serialized writer. Connect clients to one server process for each ledger file, as required by the existing service.

## Review the proposed copy

Choose a source month, a different destination month and an explicit currency:

```json
{
  "fromMonth": "2026-10",
  "toMonth": "2026-11",
  "currency": "USD"
}
```

Call `preview_budget_copy` with these arguments. It selects the source month's explicitly USD-denominated budgets in their existing order. Currency input is normalized to uppercase. To select particular categories, add `"categories": ["groceries", "travel"]`; their reviewed order follows that selection. Category matching is case-sensitive and trims surrounding whitespace in the request.

The preview returns each selected category and its exact `limitMinor`, plus its current destination:

| Action | Meaning |
| --- | --- |
| `add` | This category has no matching destination budget. |
| `already_present` | The destination already has the same limit in the selected currency; it will remain untouched. |
| `conflict` | The destination has a different limit, an unassigned budget, an ambiguous identity or a noncanonical stored category. This copy cannot overwrite or reinterpret it. |

A zero limit is a valid budget and remains zero. Different currencies remain separate. For example, a USD copy preserves an existing EUR budget for the same category and month.

Inspect all rows, the source and destination months, and the currency. If any row conflicts, `canCommit` is false and both `review` and `reviewToken` are null. Adjust the selection or use the existing explicit `set_budget` operation to resolve the intended destination, then preview again.

The preview does not write or change the ledger version.

## Commit only the reviewed values

A qualified preview contains a complete `review` object and a `reviewToken`. After reviewing it, call `commit_budget_copy` with those two returned values:

```text
commit_budget_copy({
  review: preview.review,
  reviewToken: preview.reviewToken
})
```

Do not substitute a new month, category or limit into an old review. Preview again when the intended copy changes.

The review records:

- Source month, different destination month and normalized currency.
- Every selected category and its exact source limit.
- The expected destination limit, or `null` when that destination was absent.

The token binds this content. It does not authenticate the caller, prove a person approved it, or reserve the ledger. The commit reloads current state inside the existing serialized Store and checks every selected source and destination before preparing any write.

The whole batch refuses if a selected source is missing or has a different limit, a destination now conflicts, or a destination that was already present at review has disappeared. No earlier row from that batch is saved on a later-row refusal.

The commit uses the unchanged native `setBudget` function only for qualified additions. Its receipt includes the actual added and already-present counts and resulting budgets in reviewed order. A matching budget created by another request after preview is retained, so the actual addition count can shrink. Categories added to the source after review are not silently included.

## Retry and change boundaries

Repeating the same review against matching current destinations returns `added: 0` and preserves file bytes and modification time, including after restarting the service. A failed atomic file replacement preserves the previous file; the caller may explicitly retry after resolving the failure. The tool performs no automatic retry.

Current values are the check, not a historical revision log. The service stores no durable execution receipt for a budget-copy plan. For a row reviewed as absent, an absent current destination remains an allowed addition; the tool cannot infer whether a matching budget existed and was removed in between. A destination that was already present in the original review must still be present with the reviewed value. Any different current limit refuses instead of being overwritten.

Unrelated transactions, transaction IDs/idempotency keys, other months and other currencies remain unchanged. The original recording, CSV import, cashflow and monthly-summary behavior is preserved.

## Unassigned and noncanonical records

The copy requires explicitly denominated source budgets. If the source month contains an unassigned budget, omitting `categories` refuses rather than guessing which currency it belongs to. Select only known denominated categories, or use the existing `set_budget` flow to assign the intended currency first. A selected unassigned category always refuses.

An unassigned destination is a conflict; this tool never supplies `replaceUnassigned`. Legacy-only files stay version 1 when a preview refuses. Copying does not introduce a file format or a migration rule.

Stored category names with surrounding whitespace are refused when selected or encountered at the matching destination, because the native setter would normalize that name and change its identity. Normal category names, Unicode, line breaks and reserved object-property names remain literal. Unsupported request/review fields are refused.

## Bounds and receiving

Select 1–500 budgets. Each category is limited to 8,192 UTF-8 bytes and must contain valid Unicode. Arguments and returned previews are bounded to 256 KiB UTF-8; select fewer budgets when a large preview exceeds that bound. Every emitted review also fits its complete commit request. Amounts retain the native non-negative safe-integer minor-unit rule, with no aggregate currency conversion.

The focused tests exercise actual Store persistence and real Streamable HTTP requests with temporary fictional ledgers. They cover source and destination changes, held competing writers, partial failure refusal, zero limits, Unicode, current matching replay, restart, original recording identities, unaffected currencies and an actual injected atomic-rename failure. No live ledger, deployed service, provider account or financial operation is used.

This contribution is an after-owner source increment on native `07e223b5da19cea0f048219d8c85689fcc1ba83f`. Its inherited snapshot ancestry is not canonical main. Preserve the existing implementation and receiving authors when importing the narrow patch.
