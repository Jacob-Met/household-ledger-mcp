import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { once } from "node:events";
import { mkdtemp, readFile, writeFile, rm } from "node:fs/promises";
import { createServer } from "node:net";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { createHash } from "node:crypto";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";

const dir = await mkdtemp(join(tmpdir(), "hlm-a0eb-budget-baseline-"));
const ledger = join(dir, "ledger.json");
const probe = createServer();
probe.listen(0, "127.0.0.1");
await once(probe, "listening");
const port = probe.address().port;
await new Promise((resolve, reject) => probe.close(e => e ? reject(e) : resolve()));
let errors = "";
const child = spawn(process.execPath, [fileURLToPath(new URL("../../dist/src/index.js", import.meta.url))], {
  env: { ...process.env, HOUSEHOLD_LEDGER_DATA_PATH: ledger, HOUSEHOLD_LEDGER_HOST: "127.0.0.1", HOUSEHOLD_LEDGER_PORT: String(port) },
  stdio: ["ignore", "pipe", "pipe"],
});
child.stderr.on("data", chunk => { errors += String(chunk); });
let client;
const result = { source: "07e223b5da19cea0f048219d8c85689fcc1ba83f", observedAt: new Date().toISOString(), node: process.version, fixtureOnly: true, calls: [] };
function payload(reply) {
  assert.equal(reply.isError, undefined, JSON.stringify(reply));
  assert.equal(reply.content[0].type, "text");
  return JSON.parse(reply.content[0].text);
}
try {
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("Private baseline server did not become ready")), 15000);
    let output = "";
    child.once("error", e => { clearTimeout(timer); reject(e); });
    child.once("exit", code => { clearTimeout(timer); reject(new Error("Private baseline child exit " + code)); });
    child.stdout.on("data", chunk => {
      output += String(chunk);
      if (output.includes("listening on")) { clearTimeout(timer); resolve(); }
    });
  });
  client = new Client({ name: "budget-copy-baseline-a0eb", version: "1" }, { capabilities: {} });
  await client.connect(new StreamableHTTPClientTransport(new URL("http://127.0.0.1:" + port + "/mcp")));
  const call = async (name, args) => {
    const reply = await client.callTool({ name, arguments: args });
    result.calls.push({ name, arguments: args, reply });
    return reply;
  };
  result.tools = (await client.listTools()).tools.map(x => x.name).sort();
  assert.equal(result.tools.length, 8);
  assert.ok(!result.tools.includes("preview_budget_copy"));
  assert.ok(!result.tools.includes("commit_budget_copy"));
  payload(await call("set_budget", { category: "groceries", month: "2026-10", limitMinor: 12500, currency: "USD" }));
  payload(await call("set_budget", { category: "travel", month: "2026-10", limitMinor: 0, currency: "USD" }));
  payload(await call("set_budget", { category: "groceries", month: "2026-10", limitMinor: 7000, currency: "EUR" }));
  const budgets = payload(await call("get_budgets", { month: "2026-10", currency: "USD" }));
  assert.deepEqual(budgets.map(x => [x.category, x.limitMinor, x.currency]), [["groceries", 12500, "USD"], ["travel", 0, "USD"]]);
  const before = await readFile(ledger);
  for (const [name, args] of [
    ["preview_budget_copy", { fromMonth: "2026-10", toMonth: "2026-11", currency: "USD" }],
    ["commit_budget_copy", { review: {}, reviewToken: "0".repeat(64) }],
  ]) {
    const reply = await call(name, args);
    assert.equal(reply.isError, true);
    assert.equal(reply.content[0].text, "Unknown tool: " + name);
  }
  assert.deepEqual(await readFile(ledger), before);
  assert.deepEqual(payload(await call("get_budgets", { month: "2026-11" })), []);
  result.status = "original_missing_capability_confirmed";
  result.ledgerSha256 = createHash("sha256").update(before).digest("hex");
  result.originalBudgetControl = true;
  result.noWriteFromMissingTools = true;
  result.childErrors = errors;
  assert.equal(errors, "");
  await writeFile(new URL("./baseline-missing-tools.json", import.meta.url), JSON.stringify(result, null, 2) + "\n");
  console.log(JSON.stringify({ status: result.status, tools: result.tools.length, originalBudgetControl: true, missingTools: 2, ledgerUnchanged: true }));
} finally {
  if (client) await client.close();
  if (child.exitCode === null && child.signalCode === null) {
    const exit = once(child, "exit");
    child.kill("SIGTERM");
    await exit;
  }
  await rm(dir, { recursive: true, force: true });
}
