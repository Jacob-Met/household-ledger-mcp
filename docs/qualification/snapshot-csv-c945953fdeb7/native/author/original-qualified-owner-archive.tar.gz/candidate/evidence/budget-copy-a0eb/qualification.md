# Budget-copy native qualification

External contributor: chatgpt-a0eb505c4971/estate_products. Native claims 4163 and the catalogue-only addendum 4176; project scope https://github.com/Jacob-Met/household-ledger-mcp/issues/5.

The receiving parent is native 07e223b5da19cea0f048219d8c85689fcc1ba83f, tree 76cd2cc60b10dabdd301d32a53da4b833015193d. Its 83 source files were read back before changes. The complete original ce7/e3/401c/566d/a219 ancestry and evidence remain preserved; this snapshot history is not canonical-main ancestry.

## Actual original control

baseline-missing-tools.mjs starts the unchanged native Streamable HTTP entrypoint with one private temporary ledger and uses the official SDK client. Its eight original tools are discoverable, existing USD/EUR and zero-limit budgets work, and both proposed copy names return Unknown tool. The ledger bytes remain unchanged and the destination month remains empty.

- baseline-source.json SHA-256: efd432558a1771255e75e0a2cbd94778e4521087ea5ea3e5303ca6cfaf63f49d
- baseline-build.log SHA-256: 9a1a6eaf2a9ebafa314727e5025c596030999cd26f284feec16d42ff587806b2
- baseline-missing-tools.log SHA-256: bfbff94480aa0e597b88450d58b61a17e1df37965be2d71b90eb0057ab6ea838

The successful exit is the expected missing-capability control, not a successful budget copy.

## Candidate receiving

Native runtime: Mac Node v26.3.0. Dependencies are read-only reuse of the exact existing installed owner dependency tree. No installation or lockfile edit occurred.

The first typecheck passed. The single combined candidate run passed 118 tests in six suites with zero failures, skips or cancellations: the 101 existing receiving-parent cases plus 14 new budget-copy domain/Store cases and three real HTTP cases. npm test rebuilt the source and ran the maintained whole suite. All 25 compiled source/test/config inputs were unchanged across the run.

- candidate-typecheck-first.log SHA-256: af9ba32d8f249cf7cc1cc2f563cbd7954c36fda9b83d6a19af5bd9e45006a9a1
- candidate-suite-first.log SHA-256: ba5b3d889b0018f8d94b9a449cd44ed4e6ac3b28c4d062e4a9e0cfacb864773c
- candidate-suite-first.json SHA-256: a5193043f47ae4ea22892ac0d6bfd4d608a7bcb9f4ec53ff34c2c6f278f855da

The new tests exercise exact preview and whole-batch copy, existing zero limits, literal Unicode/reserved category names, source and destination drift, a held predecessor through two actual Stores, matching concurrent writes plus recording, source selection remaining fixed, replay after a fresh process, byte/mtime-preserving matching replay, actual private rename EIO and temporary-file cleanup, 500-row admission, malformed/oversized inputs and noncanonical stored names.

The real HTTP tests start only their own loopback child services and fictional ledgers; they use the actual MCP SDK path and ordinary budget, summary and recording tools. They close those children and remove their own temporary ledgers. No live ledger, account, provider, deployed service or native goal is involved.

These are author qualification results. Independent source/contract receiving is separate and remains pending at this source freeze. No hosted or other Node-version result is claimed.

## Preservation and semantics

Production changes are a new budget-copy module and three additive index seams. ledger.ts, all original handlers, Store persistence/idempotency, budget versions, currency/category rules, cashflow, CSV import and dependencies are unchanged. The only prior-test changes add the two discoverable tool names to the two existing catalogue lists, and rename the corresponding eight-tool title to ten. README additions only describe the new tools.

The copy rechecks current selected source limits and destinations inside the existing writer, stages every addition with unchanged setBudget, then commits the complete qualified budget array. A matching target stays untouched. A conflicting target or changed/missing selected source refuses the whole batch. Originally present reviewed destinations must remain present.

There is no durable execution-history receipt for a copy plan. Current-value equality is the contract; change-away-and-back is not detected as a revision. An originally absent row can be added when currently absent, including after an intervening creation/removal. This limit is explicit in the product guide. The token binds content, not authentication or proof of human approval; there is no automatic retry or historical replay.

Deliver this contribution as a narrow after-owner patch/bundle over the exact receiving parent. Existing canonical integration owners retain their branch and deployment authority.
