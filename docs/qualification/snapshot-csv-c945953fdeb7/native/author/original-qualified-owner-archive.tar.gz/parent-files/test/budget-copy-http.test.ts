import { test } from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { once } from "node:events";
import { mkdtemp, readFile, rm, stat } from "node:fs/promises";
import { createServer } from "node:net";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";
import { type BudgetCopyPreview } from "../src/budget-copy.js";
import { type Budget, type Transaction } from "../src/ledger.js";

type ToolReply = { isError?: boolean; content: Array<{ type: string; text?: string }> };
type CopyResult = { added: number; alreadyPresent: number; budgets: Budget[] };
const request = { fromMonth: "2026-10", toMonth: "2026-11", currency: "USD" };
function payload<T>(value: unknown): T {
  const reply = value as ToolReply;
  assert.equal(reply.isError, undefined, JSON.stringify(reply));
  assert.equal(reply.content[0].type, "text");
  return JSON.parse(reply.content[0].text!) as T;
}
function failure(value: unknown, pattern: RegExp) {
  const reply = value as ToolReply;
  assert.equal(reply.isError, true, JSON.stringify(reply));
  assert.match(reply.content[0].text!, pattern);
}
const argsFor = (p: BudgetCopyPreview) => ({ review: p.review, reviewToken: p.reviewToken });
async function snapshot(path: string) {
  return { bytes: await readFile(path), mtimeNs: (await stat(path, { bigint: true })).mtimeNs };
}

async function launch(path: string): Promise<{ client: Client; stop: () => Promise<void> }> {
  const portProbe = createServer();
  portProbe.listen(0, "127.0.0.1");
  await once(portProbe, "listening");
  const address = portProbe.address();
  assert.ok(address && typeof address !== "string");
  const port = address.port;
  await new Promise<void>((resolve, reject) => portProbe.close(error => error ? reject(error) : resolve()));
  const child = spawn(process.execPath, [fileURLToPath(new URL("../src/index.js", import.meta.url))], {
    env: { ...process.env, HOUSEHOLD_LEDGER_DATA_PATH: path, HOUSEHOLD_LEDGER_HOST: "127.0.0.1", HOUSEHOLD_LEDGER_PORT: String(port) },
    stdio: ["ignore", "pipe", "pipe"],
  });
  let errors = "";
  child.stderr.on("data", chunk => { errors += String(chunk); });
  let client: Client | undefined;
  async function stop() {
    try { if (client) await client.close(); }
    finally {
      if (child.exitCode === null && child.signalCode === null) {
        const exit = once(child, "exit");
        child.kill("SIGTERM");
        await exit;
      }
    }
    assert.equal(errors, "", "private budget-copy server emitted an error");
  }
  try {
    await new Promise<void>((resolve, reject) => {
      let output = "";
      const timer = setTimeout(() => reject(new Error("private budget-copy server startup timed out")), 15000);
      child.once("error", error => { clearTimeout(timer); reject(error); });
      child.once("exit", code => { clearTimeout(timer); reject(new Error("private child exited " + code)); });
      child.stdout.on("data", chunk => {
        output += String(chunk);
        if (output.includes("listening on")) { clearTimeout(timer); resolve(); }
      });
    });
    assert.equal((await fetch("http://127.0.0.1:" + port + "/healthz")).status, 200);
    client = new Client({ name: "budget-copy-http-a0eb", version: "1" }, { capabilities: {} });
    await client.connect(new StreamableHTTPClientTransport(new URL("http://127.0.0.1:" + port + "/mcp")));
    return { client, stop };
  } catch (error) { await stop(); throw error; }
}

test("actual HTTP client reviews, copies, uses monthly summaries and repeats without writing after restart", async () => {
  const dir = await mkdtemp(join(tmpdir(), "hlm-budget-http-a0eb-"));
  const path = join(dir, "ledger.json");
  let service: Awaited<ReturnType<typeof launch>> | undefined;
  try {
    service = await launch(path);
    const catalogue = (await service.client.listTools()).tools;
    assert.equal(catalogue.length, 10);
    assert.equal(catalogue.find(t => t.name === "preview_budget_copy")!.annotations!.readOnlyHint, true);
    assert.equal(catalogue.find(t => t.name === "commit_budget_copy")!.annotations!.readOnlyHint, false);
    const call = (name: string, args: Record<string, unknown>) => service!.client.callTool({ name, arguments: args });
    for (const [category, month, limitMinor, currency] of [
      ["groceries", "2026-10", 12500, "USD"], ["travel", "2026-10", 0, "USD"],
      ["groceries", "2026-10", 7000, "EUR"], ["groceries", "2026-11", 12500, "USD"],
      ["groceries", "2026-11", 3000, "EUR"],
    ]) payload(await call("set_budget", { category, month, limitMinor, currency }));
    const before = await snapshot(path);
    const preview = payload<BudgetCopyPreview>(await call("preview_budget_copy", request));
    assert.deepEqual(preview.counts, { total: 2, add: 1, alreadyPresent: 1, conflict: 0 });
    assert.deepEqual(await snapshot(path), before);
    const txInput = { type: "expense", amountMinor: 125, currency: "USD", date: "2026-11-01", category: "groceries", idempotencyKey: "budget-http:original" };
    const tx = payload<Transaction>(await call("record_transaction", txInput));
    const copied = payload<CopyResult>(await call("commit_budget_copy", argsFor(preview)));
    assert.equal(copied.added, 1);
    assert.equal(copied.alreadyPresent, 1);
    const summary = payload<{ expenseMinor: number; budgets: Array<{ category: string; limitMinor: number; remainingMinor: number }> }>(
      await call("monthly_summary", { year: 2026, month: 11, currency: "USD" }));
    assert.equal(summary.expenseMinor, 125);
    assert.equal(summary.budgets.find(b => b.category === "groceries")!.remainingMinor, 12375);
    assert.equal(summary.budgets.find(b => b.category === "travel")!.limitMinor, 0);
    const eur = payload<Budget[]>(await call("get_budgets", { month: "2026-11", currency: "EUR" }));
    assert.equal(eur[0].limitMinor, 3000);
    await service.stop(); service = undefined;
    const afterFirst = await snapshot(path);
    service = await launch(path);
    const replay = payload<CopyResult>(await call("commit_budget_copy", JSON.parse(JSON.stringify(argsFor(preview)))));
    assert.equal(replay.added, 0);
    assert.equal(replay.alreadyPresent, 2);
    assert.deepEqual(await snapshot(path), afterFirst);
    assert.deepEqual(payload<Transaction>(await call("record_transaction", txInput)), tx);
    assert.deepEqual(await snapshot(path), afterFirst);
  } finally {
    if (service) await service.stop();
    await rm(dir, { recursive: true, force: true });
  }
});

test("actual HTTP stale source and conflicting destination refuse every addition, then a new review recovers", async () => {
  const dir = await mkdtemp(join(tmpdir(), "hlm-budget-stale-a0eb-"));
  const path = join(dir, "ledger.json");
  let service: Awaited<ReturnType<typeof launch>> | undefined;
  try {
    service = await launch(path);
    const call = (name: string, args: Record<string, unknown>) => service!.client.callTool({ name, arguments: args });
    for (const [category, limitMinor] of [["first", 1], ["second", 2]]) {
      payload(await call("set_budget", { category, month: "2026-10", limitMinor, currency: "USD" }));
    }
    const old = payload<BudgetCopyPreview>(await call("preview_budget_copy", request));
    payload(await call("set_budget", { category: "second", month: "2026-10", limitMinor: 9, currency: "USD" }));
    const changedSource = await snapshot(path);
    failure(await call("commit_budget_copy", argsFor(old)), /source limit changed/);
    assert.deepEqual(await snapshot(path), changedSource);
    assert.deepEqual(payload(await call("get_budgets", { month: "2026-11" })), []);
    const current = payload<BudgetCopyPreview>(await call("preview_budget_copy", request));
    payload(await call("set_budget", { category: "second", month: "2026-11", limitMinor: 77, currency: "USD" }));
    const conflict = await snapshot(path);
    failure(await call("commit_budget_copy", argsFor(current)), /destination conflict/);
    assert.deepEqual(await snapshot(path), conflict);
    assert.deepEqual(payload<Budget[]>(await call("get_budgets", { month: "2026-11" })).map(b => [b.category, b.limitMinor]), [["second", 77]]);
    payload(await call("set_budget", { category: "second", month: "2026-11", limitMinor: 9, currency: "USD" }));
    const reviewed = payload<BudgetCopyPreview>(await call("preview_budget_copy", request));
    const recovered = payload<CopyResult>(await call("commit_budget_copy", argsFor(reviewed)));
    assert.equal(recovered.added, 1);
    assert.equal(recovered.alreadyPresent, 1);
    const final = await snapshot(path);
    const tampered = JSON.parse(JSON.stringify(argsFor(reviewed)));
    tampered.review.toMonth = "2026-12";
    failure(await call("commit_budget_copy", tampered), /reviewToken/);
    failure(await call("preview_budget_copy", { ...request, filePath: "/unused" }), /unsupported field/);
    assert.deepEqual(await snapshot(path), final);
  } finally {
    if (service) await service.stop();
    await rm(dir, { recursive: true, force: true });
  }
});

test("overlapping real HTTP copies and ordinary tools retain one target set plus unrelated writes", async () => {
  const dir = await mkdtemp(join(tmpdir(), "hlm-budget-overlap-a0eb-"));
  const path = join(dir, "ledger.json");
  let service: Awaited<ReturnType<typeof launch>> | undefined;
  try {
    service = await launch(path);
    const call = (name: string, args: Record<string, unknown>) => service!.client.callTool({ name, arguments: args });
    for (const category of ["__proto__", "旅行\n予定 🧭"]) {
      payload(await call("set_budget", { category, month: "2026-10", limitMinor: 25, currency: "USD" }));
    }
    const preview = payload<BudgetCopyPreview>(await call("preview_budget_copy", request));
    const replies = await Promise.all([
      call("commit_budget_copy", argsFor(preview)),
      call("commit_budget_copy", argsFor(preview)),
      call("record_transaction", { type: "income", amountMinor: 3, currency: "USD", date: "2026-11-01", category: "gift", idempotencyKey: "concurrent:gift" }),
      call("set_budget", { category: "__proto__", month: "2026-11", limitMinor: 90, currency: "EUR" }),
    ]);
    const copies = replies.slice(0, 2).map(r => payload<CopyResult>(r));
    assert.deepEqual(copies.map(r => r.added).sort(), [0, 2]);
    assert.deepEqual(copies.map(r => r.alreadyPresent).sort(), [0, 2]);
    const tx = payload<Transaction>(replies[2]);
    payload(replies[3]);
    const target = payload<Budget[]>(await call("get_budgets", { month: "2026-11" }));
    assert.equal(target.length, 3);
    assert.deepEqual(target.filter(b => b.currency === "USD").map(b => [b.category, b.limitMinor]), [["__proto__", 25], ["旅行\n予定 🧭", 25]]);
    const listed = payload<{ transactions: Transaction[] }>(await call("list_transactions", {}));
    assert.deepEqual(listed.transactions, [tx]);
    const before = await snapshot(path);
    assert.equal(payload<CopyResult>(await call("commit_budget_copy", argsFor(preview))).added, 0);
    assert.deepEqual(await snapshot(path), before);
  } finally {
    if (service) await service.stop();
    await rm(dir, { recursive: true, force: true });
  }
});
