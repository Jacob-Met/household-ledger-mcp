import pathlib,subprocess,json,time,hashlib
root=pathlib.Path("/tmp/household-budget-reallocation-6e5752b49b6f-production");work=root/"candidate"
expected=json.loads((root/"candidate-full-r1.json").read_text())["unchangedSources"]
for name,digest in expected.items():assert hashlib.sha256((work/name).read_bytes()).hexdigest()==digest,name
cmd=["node","--test","--test-concurrency=1","dist/test/http-cashflow.test.js"]
started=time.monotonic()
p=subprocess.run(cmd,cwd=work,capture_output=True,text=True,timeout=60)
raw=p.stdout+p.stderr;(root/"candidate-cashflow-r2.tap").write_text(raw)
receipt={"command":cmd,"exit":p.returncode,"durationSeconds":time.monotonic()-started,"sourceCommit":"c83f0a6aee72df86eed17272ee8be6a79b7f941e","logSha256":hashlib.sha256(raw.encode()).hexdigest()}
for name,digest in expected.items():assert hashlib.sha256((work/name).read_bytes()).hexdigest()==digest,name
(root/"candidate-cashflow-r2.json").write_text(json.dumps(receipt,indent=2)+"\n");print(json.dumps(receipt));print(raw);raise SystemExit(p.returncode)
