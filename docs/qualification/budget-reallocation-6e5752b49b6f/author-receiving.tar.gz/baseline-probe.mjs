import assert from "node:assert/strict";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { InMemoryTransport } from "@modelcontextprotocol/sdk/inMemory.js";
import { createMcpServer } from "./dist/src/index.js";
import { LedgerStore } from "./dist/src/ledger.js";
const root=await mkdtemp("/tmp/household-budget-reallocation-6e5752b49b6f-production/baseline-probe-");
const path=join(root,"ledger.json");
const initial=JSON.stringify({version:2,transactions:[],budgets:[{category:"food",month:"2026-10",currency:"USD",limitMinor:1000},{category:"travel",month:"2026-10",currency:"USD",limitMinor:500}]});
await writeFile(path,initial);
const client=new Client({name:"budget-baseline",version:"1"},{capabilities:{}});
const server=createMcpServer(new LedgerStore(path));
const [a,b]=InMemoryTransport.createLinkedPair();
try{
 await server.connect(a);await client.connect(b);
 const names=(await client.listTools()).tools.map(t=>t.name);
 assert(!names.includes("preview_budget_reallocation"));assert(!names.includes("commit_budget_reallocation"));
 const unavailable=await client.callTool({name:"preview_budget_reallocation",arguments:{month:"2026-10",currency:"USD",fromCategory:"food",toCategory:"travel",amountMinor:250}});
 assert.equal(unavailable.isError,true);assert.match(unavailable.content[0].text,/Unknown tool/);
 assert.equal(await readFile(path,"utf8"),initial);
 const control=await client.callTool({name:"get_budgets",arguments:{month:"2026-10",currency:"USD"}});
 assert.deepEqual(JSON.parse(control.content[0].text),JSON.parse(initial).budgets);
 console.log(JSON.stringify({accepted:true,baseline:"591ab6f5a2d65bf596aeb707dbb635ee981ec926",names,missingToolResult:unavailable,readOnly:true,nativeBudgetControl:true}));
}finally{await client.close();await server.close();await rm(root,{recursive:true,force:true});}
