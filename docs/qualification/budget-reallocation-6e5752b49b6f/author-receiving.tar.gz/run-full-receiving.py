import pathlib,json,subprocess,hashlib,time
root=pathlib.Path("/tmp/household-budget-reallocation-6e5752b49b6f-production");work=root/"candidate"
def inventory():
 result={}
 for base in ["src","test"]:
  for p in sorted((work/base).rglob("*")):
   if p.is_file():result[str(p.relative_to(work))]=hashlib.sha256(p.read_bytes()).hexdigest()
 for name in ["package.json","package-lock.json","tsconfig.json"]:
  result[name]=hashlib.sha256((work/name).read_bytes()).hexdigest()
 return result
before=inventory()
commands=["node","--test","--test-concurrency=1"]+[str(p.relative_to(work)) for p in sorted((work/"dist/test").glob("*.test.js"))]
started=time.monotonic()
with (root/"candidate-full-r1.tap").open("w") as log:
 p=subprocess.run(commands,cwd=work,stdout=log,stderr=subprocess.STDOUT,timeout=240)
after=inventory();assert before==after
receipt={"sourceCommit":"c83f0a6aee72df86eed17272ee8be6a79b7f941e","sourceTree":"f039e5d078827746c896e5e167ba95299e48cd17","command":commands,"exit":p.returncode,"durationSeconds":time.monotonic()-started,"unchangedSources":before,"logSha256":hashlib.sha256((root/"candidate-full-r1.tap").read_bytes()).hexdigest(),"node":subprocess.check_output(["node","--version"],text=True).strip(),"uid":__import__("os").getuid(),"serialFilesReason":"Retain existing 5s HTTP startup bounds while avoiding concurrent native test-file startup load; actual within-test concurrency remains unchanged."}
(root/"candidate-full-r1.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt));print("\n".join((root/"candidate-full-r1.tap").read_text().splitlines()[-16:]));raise SystemExit(p.returncode)
