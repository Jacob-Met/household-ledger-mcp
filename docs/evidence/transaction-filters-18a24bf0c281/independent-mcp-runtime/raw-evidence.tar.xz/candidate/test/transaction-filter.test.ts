import assert from "node:assert/strict";
import { test } from "node:test";
import {
  emptyLedger, listTransactions, recordTransaction, validateLedgerData, ValidationError,
  type LedgerData, type ListTransactionsFilter,
} from "../src/ledger.js";

function select(data: LedgerData, filters: Record<string, unknown>) {
  // Keep the same runtime witnesses compilable on the pre-filter baseline.
  return listTransactions(data, filters as ListTransactionsFilter);
}

function add(data: LedgerData, input: Record<string, unknown> = {}) {
  return recordTransaction(data, {
    type: "expense", amountMinor: 100, currency: "USD", date: "2026-10-06", category: "food", ...input,
  } as never);
}

test("currency filters normalize valid stored codes without rewriting original records", () => {
  const data = emptyLedger();
  add(data, { note: "first" }).currency = " uSd ";
  add(data, { currency: "EUR", note: "second" });
  add(data, { currency: "USD", note: "third" });
  const loaded = validateLedgerData(JSON.parse(JSON.stringify(data)));
  const before = JSON.stringify(loaded);
  loaded.transactions.forEach(Object.freeze);
  Object.freeze(loaded.transactions);
  Object.freeze(loaded);
  const result = select(loaded, { currency: " UsD " });
  assert.equal(result.total, 2);
  assert.equal(result.transactions[0], loaded.transactions[0]);
  assert.equal(result.transactions[1], loaded.transactions[2]);
  assert.equal(result.transactions[0].currency, " uSd ");
  assert.equal(JSON.stringify(loaded), before);
});

test("query matches category or note with canonical Unicode comparison and retains exact text", () => {
  const data = emptyLedger();
  const category = add(data, { category: "Café outings" });
  const note = add(data, { note: "  Cafe\u0301 milk 🥛\nreceipt  " });
  add(data, { idempotencyKey: "needle-private", note: "plumber" });
  const before = JSON.stringify(data);
  const result = select(data, { query: " CAFÉ " });
  assert.equal(result.total, 2);
  assert.equal(result.transactions[0], category);
  assert.equal(result.transactions[1], note);
  assert.equal("note" in category, false);
  assert.equal(note.note, "  Cafe\u0301 milk 🥛\nreceipt  ");
  assert.deepEqual(select(data, { query: "needle-private" }), { total: 0, transactions: [] });
  assert.equal(JSON.stringify(data), before);
});

test("literal queries do not interpret punctuation or combine separate fields", () => {
  const data = emptyLedger();
  const row = add(data, { category: "food", note: "milk .* [local]" });
  add(data, { category: "other", note: "milk ordinary" });
  assert.deepEqual(select(data, { query: ".*" }), { total: 1, transactions: [row] });
  assert.deepEqual(select(data, { query: "[LOCAL]" }), { total: 1, transactions: [row] });
  assert.deepEqual(select(data, { query: "^milk" }), { total: 0, transactions: [] });
  assert.deepEqual(select(data, { query: "food milk" }), { total: 0, transactions: [] });
});

test("query bounds count Unicode characters and reject malformed or blank input", () => {
  const data = emptyLedger();
  const atLimit = "🪙".repeat(256);
  const row = add(data, { note: atLimit });
  assert.deepEqual(select(data, { query: atLimit }), { total: 1, transactions: [row] });
  const before = JSON.stringify(data);
  for (const query of ["x".repeat(257), "🪙".repeat(257), " ".repeat(256) + "x", "", " \n\t ", null, 42, false, {}, []]) {
    assert.throws(() => select(data, { query }), ValidationError, JSON.stringify(query));
  }
  assert.equal(JSON.stringify(data), before);
});

test("invalid currency selectors are refused instead of returning an unfiltered result", () => {
  const data = emptyLedger();
  add(data);
  const before = JSON.stringify(data);
  for (const currency of ["", "US", "USDD", "U$D", null, 42, false, {}, []]) {
    assert.throws(() => select(data, { currency }), ValidationError, JSON.stringify(currency));
  }
  assert.equal(JSON.stringify(data), before);
});

test("omitting the new selectors preserves existing exact filters and stable date ordering", () => {
  const data = emptyLedger();
  add(data, { date: "2026-09-30", note: "earlier" });
  const first = add(data, { date: "2026-10-06", note: "first on date" });
  const second = add(data, { date: "2026-10-06", note: "second on date" });
  add(data, { date: "2026-10-07", category: "Food", note: "different exact category" });
  add(data, { date: "2026-10-08", type: "income", note: "different type" });
  const before = JSON.stringify(data);
  const filters = { type: "expense", category: "food", from: "2026-10-06", to: "2026-10-06" };
  assert.deepEqual(select(data, filters), { total: 2, transactions: [first, second] });
  assert.deepEqual(select(data, { ...filters, limit: 1, offset: 1 }), { total: 2, transactions: [second] });
  assert.deepEqual(select(data, { ...filters, limit: 0 }), { total: 2, transactions: [] });
  assert.equal(select(data, {}).total, 5);
  assert.equal(JSON.stringify(data), before);
});
