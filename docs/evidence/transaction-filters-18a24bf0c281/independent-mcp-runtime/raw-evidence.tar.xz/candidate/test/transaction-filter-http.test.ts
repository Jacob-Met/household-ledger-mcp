import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { once } from "node:events";
import { mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { createServer } from "node:net";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { test } from "node:test";
import { fileURLToPath } from "node:url";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";

async function launch(path: string) {
  const probe = createServer();
  probe.listen(0, "127.0.0.1");
  await once(probe, "listening");
  const address = probe.address();
  assert.ok(address && typeof address === "object");
  const port = address.port;
  await new Promise<void>((resolve, reject) => probe.close(error => error ? reject(error) : resolve()));
  const child = spawn(process.execPath, [fileURLToPath(new URL("../src/index.js", import.meta.url))], {
    env: { ...process.env, HOUSEHOLD_LEDGER_DATA_PATH: path, HOUSEHOLD_LEDGER_HOST: "127.0.0.1", HOUSEHOLD_LEDGER_PORT: String(port) },
    stdio: ["ignore", "pipe", "pipe"],
  });
  let diagnostic = "";
  child.stderr.on("data", chunk => { diagnostic += String(chunk); });
  const stopChild = async () => {
    if (child.exitCode !== null || child.signalCode !== null) return;
    const exited = once(child, "exit");
    child.kill("SIGTERM");
    await exited;
  };
  try {
    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("server startup timed out: " + diagnostic)), 5000);
      child.once("error", error => { clearTimeout(timer); reject(error); });
      child.once("exit", code => { clearTimeout(timer); reject(new Error("server exited " + code + ": " + diagnostic)); });
      child.stdout.on("data", chunk => {
        if (String(chunk).includes("listening on")) { clearTimeout(timer); resolve(); }
      });
    });
    const client = new Client({ name: "transaction-filter-http-receiver", version: "1" }, { capabilities: {} });
    await client.connect(new StreamableHTTPClientTransport(new URL("http://127.0.0.1:" + port + "/mcp")));
    return { client, stop: async () => { try { await client.close(); } finally { await stopChild(); } } };
  } catch (error) {
    await stopChild();
    throw error;
  }
}

function unpack(result: unknown): any {
  const value = result as { isError?: boolean; content: Array<{ text: string }> };
  assert.notEqual(value.isError, true, value.content[0]?.text);
  return JSON.parse(value.content[0].text);
}

test("real HTTP filters imported original records before paging, without writes, across restart", { timeout: 25000 }, async () => {
  const dir = await mkdtemp(join(tmpdir(), "ledger-transaction-filter-"));
  const path = join(dir, "ledger.json");
  const artifactRoot = process.env.HOUSEHOLD_FILTER_ARTIFACTS;
  const events: unknown[] = [];
  const checks: Array<{ name: string; pass: boolean; error?: string }> = [];
  const check = (name: string, verify: () => void) => {
    try { verify(); checks.push({ name, pass: true }); }
    catch (error) { checks.push({ name, pass: false, error: String(error) }); }
  };
  const inputs = [
    { idempotencyKey: "filter:earlier", type: "expense", amountMinor: 450, currency: "USD", date: "2026-10-01", category: "food", note: "Café milk" },
    { idempotencyKey: "filter:usd-a", type: "expense", amountMinor: 1530, currency: "USD", date: "2026-10-06", category: "food", note: "  CAFÉ milk, \"local\" 🥛\nReceipt A  " },
    { idempotencyKey: "filter:eur", type: "expense", amountMinor: 1200, currency: "EUR", date: "2026-10-07", category: "food", note: "CAFÉ milk" },
    { idempotencyKey: "filter:usd-b", type: "expense", amountMinor: 850, currency: "USD", date: "2026-10-06", category: "food", note: "Cafe\u0301 milk" },
    { idempotencyKey: "filter:other", type: "expense", amountMinor: 9000, currency: "USD", date: "2026-10-08", category: "housing", note: "rent" },
    { idempotencyKey: "filter:salary", type: "income", amountMinor: 5000, currency: "USD", date: "2026-10-09", category: "food", note: "Café refund" },
    { idempotencyKey: "filter:literal", type: "expense", amountMinor: 100, currency: "USD", date: "2026-10-05", category: "food", note: "coupon .*" },
  ];
  const columns = ["idempotencyKey", "type", "amountMinor", "currency", "date", "category", "note"] as const;
  const cell = (value: unknown) => '"' + String(value).replace(/"/g, '""') + '"';
  const csv = [columns.join(","), ...inputs.map(row => columns.map(key => cell(row[key])).join(","))].join("\r\n") + "\r\n";
  const selected = { currency: " usd ", query: " CAFÉ MILK ", type: "expense", category: "food", from: "2026-10-02", to: "2026-10-31" };
  let server: Awaited<ReturnType<typeof launch>> | undefined;
  let before = "";
  let after = "";
  try {
    server = await launch(path);
    const call = async (name: string, args: Record<string, unknown>) => {
      const result = await server!.client.callTool({ name, arguments: args }, undefined, { timeout: 3000 });
      events.push({ name, arguments: args, result });
      return result;
    };
    const definitions = (await server.client.listTools()).tools;
    events.push({ method: "tools/list", result: definitions });
    const list = definitions.find(tool => tool.name === "list_transactions");
    check("existing tool advertises both optional filters", () => {
      assert.ok(list?.inputSchema.properties?.currency);
      assert.ok(list?.inputSchema.properties?.query);
      assert.ok(!list?.inputSchema.required?.includes("currency"));
      assert.ok(!list?.inputSchema.required?.includes("query"));
    });
    const preview = unpack(await call("preview_transaction_import", { csv }));
    assert.equal(preview.canCommit, true);
    const imported = unpack(await call("commit_transaction_import", { csv, reviewToken: preview.reviewToken }));
    assert.equal(imported.added, 7);
    const originals = imported.transactions as Array<Record<string, unknown>>;
    const original = (key: string) => originals.find(row => row.idempotencyKey === key)!;
    await call("set_budget", { category: "food", month: "2026-10", currency: "USD", limitMinor: 5000 }).then(unpack);
    before = await readFile(path, "utf8");
    const all = unpack(await call("list_transactions", {}));
    check("ordinary listing remains usable", () => assert.equal(all.total, 7));
    const currencyOnly = unpack(await call("list_transactions", { currency: "usd" }));
    check("currency selects only the six USD originals", () => {
      assert.equal(currencyOnly.total, 6);
      assert.ok(currencyOnly.transactions.every((row: any) => row.currency === "USD"));
    });
    const first = unpack(await call("list_transactions", { ...selected, limit: 1, offset: 0 }));
    const second = unpack(await call("list_transactions", { ...selected, limit: 1, offset: 1 }));
    check("all predicates precede total and first page", () => {
      assert.equal(first.total, 2);
      assert.deepEqual(first.transactions, [original("filter:usd-a")]);
    });
    check("equal-date second page retains original identity and note", () => {
      assert.equal(second.total, 2);
      assert.deepEqual(second.transactions, [original("filter:usd-b")]);
    });
    const countOnly = unpack(await call("list_transactions", { ...selected, limit: 0 }));
    check("zero limit reports filtered total without records", () => assert.deepEqual(countOnly, { total: 2, transactions: [] }));
    const exhausted = unpack(await call("list_transactions", { ...selected, offset: 2 }));
    check("offset after filtered matches returns an empty page", () => assert.deepEqual(exhausted, { total: 2, transactions: [] }));
    const absent = unpack(await call("list_transactions", { currency: "JPY", query: "milk" }));
    check("unrecorded currency has no matches", () => assert.deepEqual(absent, { total: 0, transactions: [] }));
    const literal = unpack(await call("list_transactions", { query: ".*" }));
    check("query punctuation is literal", () => assert.deepEqual(literal, { total: 1, transactions: [original("filter:literal")] }));
    for (const args of [{ query: "   " }, { query: "x".repeat(257) }, { query: {} }, { currency: "US" }]) {
      const refused = await call("list_transactions", args) as { isError?: boolean; content: Array<{ text: string }> };
      check("malformed filter is refused: " + JSON.stringify(args), () => {
        assert.equal(refused.isError, true);
        assert.match(refused.content[0].text, /query|currency/);
      });
    }
    after = await readFile(path, "utf8");
    check("reads and refusals preserve exact ledger bytes", () => assert.equal(after, before));
    await server.stop();
    server = undefined;
    server = await launch(path);
    const restarted = unpack(await call("list_transactions", { ...selected, limit: 1, offset: 1 }));
    check("fresh process returns the same selected original", () => assert.deepEqual(restarted, { total: 2, transactions: [original("filter:usd-b")] }));
    const replayed = unpack(await call("record_transaction", inputs[1]));
    check("later recording replay retains original identity", () => assert.deepEqual(replayed, original("filter:usd-a")));
    after = await readFile(path, "utf8");
    check("restart and exact replay preserve ledger version, budgets and all bytes", () => assert.equal(after, before));
    assert.deepEqual(checks.filter(item => !item.pass), [], "actual HTTP receiving checks failed");
  } finally {
    await server?.stop();
    if (artifactRoot) {
      await mkdir(artifactRoot, { recursive: true });
      await writeFile(join(artifactRoot, "http-receipt.json"), JSON.stringify({ fixture: { inputs, csv, selected }, ledgerPath: path, events, checks, ledgerBefore: before, ledgerAfter: after }, null, 2) + "\n");
    } else {
      await rm(dir, { recursive: true, force: true });
    }
  }
});
