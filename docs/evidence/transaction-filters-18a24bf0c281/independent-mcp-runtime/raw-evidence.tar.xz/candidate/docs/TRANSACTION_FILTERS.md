# Find recorded household transactions

Use the existing `list_transactions` MCP tool to review records by currency and
literal category or note text. Combine those selectors with the existing type,
exact category, inclusive dates and pagination fields.

For example, find USD food expenses whose category or note contains “café milk”
within the selected dates:

```json
{
  "name": "list_transactions",
  "arguments": {
    "currency": "USD",
    "query": "café milk",
    "type": "expense",
    "category": "food",
    "from": "2026-10-02",
    "to": "2026-10-31",
    "limit": 1,
    "offset": 0
  }
}
```

The response keeps the existing `{ "total": ..., "transactions": [...] }` shape.
Every returned transaction is the original recorded object, including its ID,
creation timestamp, note, amount, currency and recording key when present.

## Matching rules

| Selector | Rule |
| --- | --- |
| `currency` | Optional three-letter code. Surrounding whitespace is removed and letters are uppercased for comparison, using the existing currency rules. A valid currency with no matching records returns an empty result. |
| `query` | Optional nonempty string of at most 256 Unicode characters, including any surrounding whitespace in that bound. Surrounding query whitespace is ignored for matching. |
| `type` | Existing exact `income` or `expense` selector. |
| `category` | Existing exact, case-sensitive category selector. |
| `from`, `to` | Existing inclusive `YYYY-MM-DD` date bounds. |

All supplied selectors combine with **AND**. Within `query`, a literal substring
match in either the category **or** the note is sufficient. The two fields are
searched separately; a query cannot span from the category into the note. Absent
notes are treated as empty text for matching. IDs, recording keys, dates, amounts
and other fields are outside the text search.

Text comparisons use Unicode NFC normalization and locale-independent Unicode
lowercasing. For example, `CAFÉ`, `Café` and `Cafe` followed by a combining acute
accent match each other. An unaccented `cafe` remains a different spelling.
Punctuation is literal: `.*` searches for those two characters. Internal spaces
and line breaks remain significant. The service does not rewrite stored text or
replace it with the comparison form.

Omit a selector to leave that dimension unfiltered. A supplied blank query,
overlong query, non-string query or invalid currency returns the existing MCP
validation-error response. The search adds no currency conversion or aggregate
money calculation.

## Counts, pages and retained records

All predicates are applied **before** counting, ordering and pagination. `total`
is the number of matching records across all pages. Results retain the existing
newest-date-first order; records with the same date retain their stored order.

The existing default is `limit: 50`, `offset: 0`. Limits remain integers from 0
through 1000; offsets remain nonnegative integers. `limit: 0` returns the filtered
total and no records. An offset beyond the matches returns an empty page with the
same filtered total. When two records match, `limit: 1` with offsets 0 and 1 returns
their respective original records while both responses report `total: 2`.

Listing is a read operation. Successful searches, empty results and validation
refusals do not change ledger bytes, budgets, versions or transaction identities.
Imported notes retain their exact original whitespace, accents, quotes and line
breaks. The existing CSV import, recording retry and budget tools keep their own
contracts; finding a record does not alter its recording key or future retry.
